# Odysseus

[![CI](https://github.com/thoonnadi2003/odysseus/actions/workflows/ci.yml/badge.svg)](https://github.com/thoonnadi2003/odysseus/actions/workflows/ci.yml)

An MCP server that turns any AI agent into a quantitative researcher — and holds it to the discipline
that makes a result mean something.

You run it locally beside your own agent. It downloads and freezes real market history, measures what
is actually in it, translates a formal hypothesis into a real
[StockSharp](https://github.com/StockSharp/StockSharp) `Strategy` class, compiles it, backtests it with
costs, searches its parameters, and reports what every run came to.

**It measures. It does not judge.** There is no score in it, no threshold, no accept-or-reject. Whether
a drawdown is bearable or a return is worth having depends on what you are researching, and that is
your call, not a server's.

![An agent driving Odysseus over stdio](assets/mcp-session.gif)

---

## Why an MCP server

Because the agent is the researcher, and it already exists.

A backtesting product with a chat window has to ship a model, a conversation, an interface, and an
opinion about what a good strategy is. This ships none of them. Your agent brings the reasoning; this
brings the parts an agent is bad at on its own — real data that cannot quietly change under a result,
a translator that turns a hypothesis into the same code every time, an emulator that charges for the
spread, and a slice of history it is not allowed to look at until the end.

That last one is the point. An agent asked to find a profitable strategy will find one. The only thing
that separates a finding from a search is data the search could not reach.

---

## What it does

```
create_project
  → import_history          real bars, frozen and hashed
  → analyze_market          what the instrument does, before you propose anything for it
  → propose_spec            the hypothesis, as a formal document
  → build_candidate         translated to C#, compiled, hashed
  → evaluate_candidate      six fixed runs, reported in full
  → measure_on_closed_data  once, against data nobody was allowed to see
  → complete_strategy       you decide; the server keeps the code and every number behind it
```

Thirty-five tools in all: projects, data, hypotheses, candidates, backtests, a seeded genetic search,
the closed-data measurement, and paper trading against either Alpaca Paper or Binance Spot Testnet.

Ninety days of NVDA at five minutes, downloaded and frozen, then measured — how much it moves, whether
its moves continue or come back, and what followed the events a strategy would trade. Read this before
proposing anything: a breakout hypothesis on an instrument whose breakouts led nowhere costs a
generation of candidates to disprove, and the numbers here say so beforehand.

![analyze_market over real Alpaca data](assets/measuring-the-market.png)

### The data discipline

An imported dataset is cut by time into three parts — roughly 60% to form a hypothesis on, 20% to
measure it on, and the rest closed. The proportions come from the dataset's own content hash, so they
cannot be guessed. The closed part's boundaries are never disclosed, and it is measured **once**: not
once per project, but once per stretch of history, recorded in a ledger beside the projects, because
starting a second project and importing the same dates does not make the answer unseen.

### What a measurement looks like

Six runs, always the same six: the development slice, the validation slice, the validation slice again
with costs half again as high, and three consecutive walk-forward windows. Profit, drawdown, trade
count, win rate, exposure, what share of the result rests on a single trade, the spread between the
windows, what survived the higher costs. No verdict — that part is yours.

---

## Running it

You need the [.NET 10 SDK](https://dotnet.microsoft.com/download).

```bash
git clone https://github.com/thoonnadi2003/odysseus.git
cd odysseus/open
dotnet build -c Release
```

Point your agent at the server over stdio:

```json
{
  "mcpServers": {
    "odysseus": {
      "command": "path/to/Odysseus.Server.exe",
      "env": {
        "ODYSSEUS_PROJECTS_ROOT": "path/to/where/projects/should/live"
      }
    }
  }
}
```

Then ask it to `import_demo_dataset` and work through a hypothesis. The bundled dataset is generated,
so nothing measured on it says anything about any market — it is there to prove the machinery runs
without an account.

### With real data

Put one broker's credentials in a file:

```
key: PK...
secret: ...
```

For Alpaca Paper, set `ODYSSEUS_BROKER=alpaca` and point `ODYSSEUS_ALPACA_KEYS` at that file. For
Binance, set `ODYSSEUS_BROKER=binance` and point `ODYSSEUS_BINANCE_KEYS` at it. If exactly one usable
key file is configured, the broker is inferred; if both are present, the explicit selector is required.

Only file paths are put in the environment—not key values—because environment values are inherited by
child processes and may appear in process diagnostics. `alpaca.txt`, `binance.txt`, and `.env` are
ignored by Git. Credentials are never copied into a project or emitted by `describe_server`.

Without credentials everything else still works: the demo dataset, `analyze_market`, every backtest,
the closed-data measurement and `complete_strategy` all read history that is already frozen.
`describe_server` says which half of the product you have.

Paper accounts only. Alpaca is pinned to its paper endpoint; Binance order and account traffic is
pinned to **Spot Testnet**, and there is no setting for production trading. Binance history is read from
the public production market-data endpoint so research uses observed candles. Spot Testnet supplies
virtual balances and may reset periodically. Binance Spot strategies must be long-only; short-enabled
specifications are rejected instead of being simulated as an order the venue cannot execute.

### From a terminal

The same research, in columns instead of JSON — the same services, the same numbers, laid out for a
person rather than a parser:

![The command line walking through a study](assets/cli-session.gif)

```bash
cd open/src/Odysseus.Cli
dotnet run -- new "my study"
dotnet run -- demo
dotnet run -- propose hypothesis.json
dotnet run -- build
dotnet run -- backtest
dotnet run -- measure
dotnet run -- closed
dotnet run -- complete "why you believe it"
```

A backtest reports what the run cost as well as what it made, because only one of the two charges can
be traded around: holding longer pays the spread less often, while the fees follow the volume either
way.

![A backtest, with what it was charged and the account through the run](assets/backtest.png)

And any run can be cut apart — by month, by part of the session, by how long a position was held, by
direction. Every cut is of the same trades, so each adds back up to the run. A result that came from
one month, or from the last half hour of the day, says so here rather than in six weeks of paper.

![The same run cut apart four ways](assets/explain.png)

---

## What it will not do

- **It will not tell you a strategy is good.** It reports what happened and leaves the reading to you.
- **It will not trade real money.** Paper accounts only, and it never places an order the strategy
  did not.
- **It will not let you measure the closed slice twice.** That is the whole of its value.
- **It will not pretend a backtest is a result.** The emulator fills against bars; a fill that never
  comes is the most common difference between a backtest and an account.

---

## The contract

The tools describe themselves. Every one carries a description written for the agent that has to
choose it without trying it first, and every argument says what it is; a test fails the build if one
does not. Connect and call `tools/list` — that is the contract, and it cannot go stale.

What the tools return is specified in [`open/schemas/`](open/schemas) as JSON Schema: the error shape
every failure arrives in, the strategy specification, the dataset manifest, run results, and the paper
account. Those files are read by the tests, so they describe the product rather than an intention.

---

## Licence

MIT for our code. StockSharp is consumed as NuGet packages and remains under its own terms; nothing of
StockSharp — source, binaries or keys — belongs in this repository.

There is no telemetry. A fresh installation makes no network call except to the broker, and only when
asked to.
