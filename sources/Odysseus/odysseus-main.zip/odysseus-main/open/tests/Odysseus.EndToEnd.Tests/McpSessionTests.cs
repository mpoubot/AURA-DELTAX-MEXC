namespace Odysseus.EndToEnd.Tests;

using System;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.TestKit;

/// <summary>
/// The server as an agent meets it: a real process, a real handshake, real tool calls over standard
/// input and output.
/// </summary>
/// <remarks>
/// Everything below this level is tested without a transport, which is faster and sharper. This suite
/// exists for the things only the whole thing can be wrong about: that the tools are actually
/// published, that answers survive serialisation, that a refusal reaches the caller as something it can
/// act on, and that nothing leaks on the way out.
/// </remarks>
[TestClass]
public class McpSessionTests : OdysseusTestBase
{
	private McpSession _session;
	private string _root;

	/// <summary>Starts a server over a temporary projects root.</summary>
	[TestInitialize]
	public void StartServer()
	{
		var executable = McpSession.FindServer();

		if (executable is null)
		{
			Assert.Inconclusive(
				"The server executable has not been built. Build the solution before running the end-to-end suite.");
		}

		_root = Path.Combine(Path.GetTempPath(), "odysseus-e2e", Guid.NewGuid().ToString("n"));
		_session = McpSession.Start(executable, _root);
	}

	/// <summary>Stops the server and removes its files.</summary>
	[TestCleanup]
	public void StopServer()
	{
		_session?.Dispose();

		if (_root is not null && Directory.Exists(_root))
			Directory.Delete(_root, recursive: true);
	}

	/// <summary>The server completes the handshake and publishes its tools.</summary>
	[TestMethod]
	public async Task ServerPublishesItsTools()
	{
		var tools = await _session.ListToolsAsync(CancellationToken);

		string[] expected =
		[
			"describe_server", "create_project", "list_projects", "get_project_state", "rename_project",
			"get_audit_log", "import_demo_dataset", "get_dataset_report", "describe_split",
			"get_indicator_catalog", "validate_spec", "propose_spec", "list_specs",
		];

		foreach (var name in expected)
			IsTrue(tools.Contains(name), $"the server does not publish '{name}'; it published {string.Join(", ", tools)}.");
	}

	/// <summary>
	/// Every tool has to explain itself well enough for an agent to choose it without trying it, since
	/// the description is all it has to go on.
	/// </summary>
	[TestMethod]
	public async Task EveryToolExplainsItself()
	{
		var described = await _session.CallAsync("tools/list", new { }, CancellationToken);

		foreach (var tool in described.GetProperty("tools").EnumerateArray())
		{
			var name = tool.GetProperty("name").GetString();
			var description = tool.TryGetProperty("description", out var value) ? value.GetString() : null;

			IsTrue(!string.IsNullOrWhiteSpace(description) && description.Length > 40,
				$"'{name}' publishes no usable description.");
		}
	}

	/// <summary>A project can be created, found again and listed.</summary>
	[TestMethod]
	public async Task ProjectSurvivesTheRoundTrip()
	{
		var created = await _session.ToolAsync("create_project",
			new { name = "NVDA breakout", operationKey = "e2e-1" }, CancellationToken);

		var id = created.GetProperty("projectId").GetString();

		AreEqual("NVDA breakout", created.GetProperty("name").GetString());
		AreEqual("Draft", created.GetProperty("status").GetString());

		var state = await _session.ToolAsync("get_project_state", new { projectId = id }, CancellationToken);

		AreEqual(id, state.GetProperty("projectId").GetString());

		var listed = await _session.ToolAsync("list_projects", new { }, CancellationToken);

		AreEqual(1, listed.GetProperty("projects").GetArrayLength());
	}

	/// <summary>A retry of the same intent does not produce a second project.</summary>
	[TestMethod]
	public async Task RepeatedCallWithTheSameKeyIsHarmless()
	{
		var first = await _session.ToolAsync("create_project",
			new { name = "once", operationKey = "e2e-1" }, CancellationToken);

		var again = await _session.ToolAsync("create_project",
			new { name = "once", operationKey = "e2e-1" }, CancellationToken);

		AreEqual(first.GetProperty("projectId").GetString(), again.GetProperty("projectId").GetString());

		var listed = await _session.ToolAsync("list_projects", new { }, CancellationToken);

		AreEqual(1, listed.GetProperty("projects").GetArrayLength(), "a retry created a second project.");
	}

	/// <summary>Importing data freezes it onto the project and is recorded.</summary>
	[TestMethod]
	public async Task ImportedDataIsFrozenAndRecorded()
	{
		var id = await NewProjectAsync();

		var dataset = await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "e2e-import" }, CancellationToken);

		IsTrue(dataset.GetProperty("isSynthetic").GetBoolean(),
			"generated bars must be marked as generated when they reach the agent.");

		IsTrue(dataset.GetProperty("warning").GetString().Contains("say nothing about any market", StringComparison.Ordinal),
			"the warning about generated data must reach the agent, not only the log.");

		var state = await _session.ToolAsync("get_project_state", new { projectId = id }, CancellationToken);

		AreEqual("Ready", state.GetProperty("status").GetString());

		var trail = await _session.ToolAsync("get_audit_log", new { projectId = id }, CancellationToken);
		var types = trail.GetProperty("events").EnumerateArray()
			.Select(e => e.GetProperty("type").GetString())
			.ToArray();

		CollectionAssert.AreEqual(new[] { "ProjectCreated", "DatasetFrozen" }, types);
	}

	/// <summary>
	/// The strongest end-to-end check there is here: nothing an agent can reach places the closed slice.
	/// A last bar time or a total count, next to the end of validation, would be enough.
	/// </summary>
	[TestMethod]
	public async Task NothingAnAgentCanReachPlacesTheClosedSlice()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "e2e-import" }, CancellationToken);

		var split = await _session.ToolAsync("describe_split", new { projectId = id }, CancellationToken);

		IsTrue(split.GetProperty("sealedSlice").GetProperty("exists").GetBoolean());
		IsFalse(split.GetProperty("sealedSlice").GetProperty("consumed").GetBoolean());

		IsFalse(split.TryGetProperty("validationTo", out _),
			"the end of validation is where the closed slice begins, and it is published.");

		var developmentFrom = split.GetProperty("developmentFrom").GetDateTime();
		var developmentTo = split.GetProperty("developmentTo").GetDateTime();

		var report = await _session.ToolAsync("get_dataset_report", new { projectId = id }, CancellationToken);

		// What the agent can see of the data ends inside the open part. Where the open part itself ends is
		// not published and cannot be worked out from what is: the proportions are drawn from the bars.
		foreach (var quality in report.GetProperty("quality").EnumerateArray())
		{
			var last = quality.GetProperty("to").GetDateTime();
			var span = developmentTo - developmentFrom;

			IsTrue(last < developmentFrom + span * 2,
				$"'{quality.GetProperty("symbol").GetString()}' discloses a bar far past development, " +
				"which would place the closed slice however the range was divided.");
		}

		// The audit trail is readable by the agent too, so it is held to the same rule.
		var trail = await _session.ToolAsync("get_audit_log", new { projectId = id }, CancellationToken);

		foreach (var entry in trail.GetProperty("events").EnumerateArray())
		{
			var detail = entry.GetProperty("detail").GetString();

			IsFalse(detail.Contains(" 8000 ", StringComparison.Ordinal),
				"the record states the size of the whole dataset, which dates its end.");
		}
	}

	/// <summary>
	/// A refusal has to arrive as something the caller can act on. Told only that something went wrong,
	/// an agent has nothing to aim at and spends its remaining attempts guessing.
	/// </summary>
	[TestMethod]
	public async Task ARefusalArrivesAsSomethingToActOn()
	{
		var refused = await _session.ToolAsync("get_project_state", new { projectId = "not-an-id" }, CancellationToken);

		var error = refused.GetProperty("error");

		AreEqual("InvalidRequest", error.GetProperty("category").GetString());

		IsTrue(error.GetProperty("message").GetString().Contains("prj_", StringComparison.Ordinal),
			"the message must show what a real identifier looks like.");

		IsTrue(error.GetProperty("remediation").GetString().Length > 20,
			"the caller must be told what to do next.");

		IsFalse(string.IsNullOrWhiteSpace(error.GetProperty("correlationId").GetString()),
			"a failure must be traceable to the server logs.");
	}

	/// <summary>Asking about data before importing any names the tool that fixes it.</summary>
	[TestMethod]
	public async Task AskingTooEarlyNamesTheToolThatFixesIt()
	{
		var id = await NewProjectAsync();

		var refused = await _session.ToolAsync("get_dataset_report", new { projectId = id }, CancellationToken);
		var error = refused.GetProperty("error");

		AreEqual("PreconditionFailed", error.GetProperty("category").GetString());

		IsTrue(error.GetProperty("message").GetString().Contains("import_demo_dataset", StringComparison.Ordinal),
			"the refusal must name the tool that resolves it.");
	}

	/// <summary>An unexpected defect must not hand the caller anything about the machine.</summary>
	[TestMethod]
	public async Task DescribeServerReportsTheProfileItRunsUnder()
	{
		var described = await _session.ToolAsync("describe_server", new { }, CancellationToken);

		AreEqual("Odysseus", described.GetProperty("product").GetString());
		AreEqual("Local", described.GetProperty("mode").GetString());

		IsTrue(described.GetProperty("acceptsHandWrittenSource").GetBoolean());
		IsFalse(described.GetProperty("securityAnalyzersEnforced").GetBoolean());
	}

	/// <summary>
	/// The whole point of the specification layer: an agent describes a strategy, the server checks it,
	/// and a bad one is refused with everything that is wrong at once rather than one thing per attempt.
	/// </summary>
	[TestMethod]
	public async Task ASpecificationIsCheckedBeforeItIsRecorded()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "e2e-import" }, CancellationToken);

		var broken = await _session.ToolAsync("validate_spec", new { spec = BrokenSpec }, CancellationToken);

		IsFalse(broken.GetProperty("isValid").GetBoolean());

		var problems = broken.GetProperty("problems").EnumerateArray().ToArray();

		IsTrue(problems.Length >= 2, "everything wrong must be reported together, not one problem per attempt.");

		foreach (var problem in problems)
		{
			IsFalse(string.IsNullOrWhiteSpace(problem.GetProperty("path").GetString()),
				"a problem with no place in the document leaves the caller searching.");

			IsFalse(string.IsNullOrWhiteSpace(problem.GetProperty("remedy").GetString()),
				"a problem with no remedy leaves the caller guessing.");
		}

		var refused = await _session.ToolAsync("propose_spec",
			new { projectId = id, spec = BrokenSpec, operationKey = "e2e-bad" }, CancellationToken);

		AreEqual("SpecValidation", refused.GetProperty("error").GetProperty("category").GetString());

		var listed = await _session.ToolAsync("list_specs", new { projectId = id }, CancellationToken);

		AreEqual(0, listed.GetProperty("specs").GetArrayLength(),
			"a refused specification must not become part of the history: nothing was ever tried with it.");
	}

	/// <summary>A sound specification is recorded, numbered and hashed.</summary>
	[TestMethod]
	public async Task ASoundSpecificationIsRecorded()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "e2e-import" }, CancellationToken);

		var proposed = await _session.ToolAsync("propose_spec",
			new { projectId = id, spec = SoundSpec, operationKey = "e2e-spec" }, CancellationToken);

		AreEqual(1, proposed.GetProperty("revision").GetInt32());
		IsFalse(string.IsNullOrWhiteSpace(proposed.GetProperty("hash").GetString()));
		AreEqual("Agent", proposed.GetProperty("author").GetString());

		var trail = await _session.ToolAsync("get_audit_log", new { projectId = id }, CancellationToken);
		var types = trail.GetProperty("events").EnumerateArray()
			.Select(e => e.GetProperty("type").GetString())
			.ToArray();

		IsTrue(types.Contains("SpecRevised"), "recording a specification must leave a permanent trace.");
	}

	/// <summary>
	/// The whole loop over the wire: a project, data, a specification, a compiled strategy, a run, and
	/// numbers to read. Every part of this is tested on its own elsewhere; what is tested here is that
	/// an agent holding nothing but the tool descriptions can get from one end to the other.
	/// </summary>
	[TestMethod]
	public async Task TheWholeLoopRunsOverTheWire()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "loop-import" }, CancellationToken);

		var proposed = await _session.ToolAsync("propose_spec",
			new { projectId = id, spec = SoundSpec, operationKey = "loop-spec" }, CancellationToken);

		var built = await _session.ToolAsync("build_candidate",
			new
			{
				projectId = id,
				specId = proposed.GetProperty("specId").GetString(),
				operationKey = "loop-build",
			},
			CancellationToken);

		var candidateId = built.GetProperty("candidateId").GetString();

		AreEqual("Compiled", built.GetProperty("status").GetString());
		IsFalse(string.IsNullOrWhiteSpace(built.GetProperty("assemblyHash").GetString()));

		var source = await _session.ToolAsync("get_candidate_source",
			new { projectId = id, candidateId }, CancellationToken);

		var code = source.GetProperty("source").GetString();

		IsTrue(code.Contains(": Strategy", StringComparison.Ordinal),
			"what was built is not a StockSharp strategy.");

		IsTrue(code.Contains("// entries.e1", StringComparison.Ordinal),
			"the generated code cannot be read next to the specification it came from.");

		var run = await _session.ToolAsync("run_backtest",
			new
			{
				projectId = id,
				candidateId,
				slice = "development",
				symbol = "",
				scenario = "",
				parameters = "",
				operationKey = "loop-run",
			},
			CancellationToken);

		AreEqual("Completed", run.GetProperty("status").GetString(),
			$"the run did not finish: {run}");

		IsTrue(run.GetProperty("barsProcessed").GetInt32() > 0, "the strategy saw no bars.");
		IsFalse(run.GetProperty("wasAlreadyRun").GetBoolean());

		// The costs are charged from the first run, so the two sides of the cost line differ.
		AreNotEqual(
			run.GetProperty("gross").GetProperty("profit").GetDecimal(),
			run.GetProperty("net").GetProperty("profit").GetDecimal(),
			"the run was charged nothing at all.");

		var metrics = await _session.ToolAsync("get_metrics",
			new { projectId = id, runId = run.GetProperty("runId").GetString() }, CancellationToken);

		AreEqual(
			run.GetProperty("net").GetProperty("profit").GetDecimal(),
			metrics.GetProperty("net").GetProperty("profit").GetDecimal());

		var trail = await _session.ToolAsync("get_audit_log", new { projectId = id }, CancellationToken);
		var types = trail.GetProperty("events").EnumerateArray()
			.Select(e => e.GetProperty("type").GetString())
			.ToArray();

		IsTrue(types.Contains("CandidateBuilt") && types.Contains("RunCompleted"),
			$"the permanent record holds only {string.Join(", ", types)}.");
	}

	/// <summary>
	/// The same run asked for twice is answered rather than repeated. An agent that loses its connection
	/// mid-run and retries would otherwise pay twice for one measurement.
	/// </summary>
	[TestMethod]
	public async Task RunningTheSameThingTwiceCostsOnce()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "twice-import" }, CancellationToken);

		var proposed = await _session.ToolAsync("propose_spec",
			new { projectId = id, spec = SoundSpec, operationKey = "twice-spec" }, CancellationToken);

		var built = await _session.ToolAsync("build_candidate",
			new { projectId = id, specId = proposed.GetProperty("specId").GetString(), operationKey = "twice-build" },
			CancellationToken);

		var candidateId = built.GetProperty("candidateId").GetString();

		object Request(string key) => new
		{
			projectId = id,
			candidateId,
			slice = "development",
			symbol = "",
			scenario = "",
			parameters = "",
			operationKey = key,
		};

		var first = await _session.ToolAsync("run_backtest", Request("twice-run-a"), CancellationToken);

		// A different key, so the answer cannot come from the operation log: it has to be recognised as
		// the same run by what the run actually was.
		var again = await _session.ToolAsync("run_backtest", Request("twice-run-b"), CancellationToken);

		AreEqual(first.GetProperty("runId").GetString(), again.GetProperty("runId").GetString());
		IsTrue(again.GetProperty("wasAlreadyRun").GetBoolean());

		var state = await _session.ToolAsync("get_project_state", new { projectId = id }, CancellationToken);

		var budget = state.GetProperty("budget");

		AreEqual(
			budget.GetProperty("backtestsTotal").GetInt32() - 1,
			budget.GetProperty("backtestsRemaining").GetInt32(),
			"the repeated run was charged a second time.");
	}

	/// <summary>
	/// The numbers arrive, and only the numbers. What matters here is not which way they went — that
	/// depends on the demo data — but that every slice is reported in full and nothing anywhere says
	/// whether it was good enough, because that is the model's call and not the server's.
	/// </summary>
	[TestMethod]
	public async Task TheMeasurementArrivesAsNumbersAndNoVerdict()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "judge-import" }, CancellationToken);

		var proposed = await _session.ToolAsync("propose_spec",
			new { projectId = id, spec = SoundSpec, operationKey = "judge-spec" }, CancellationToken);

		var built = await _session.ToolAsync("build_candidate",
			new { projectId = id, specId = proposed.GetProperty("specId").GetString(), operationKey = "judge-build" },
			CancellationToken);

		var candidateId = built.GetProperty("candidateId").GetString();

		var measured = await _session.ToolAsync("evaluate_candidate",
			new { projectId = id, candidateId, symbol = "", parameters = "", operationKey = "judge-run" },
			CancellationToken);

		IsTrue(measured.TryGetProperty("measurement", out var m), $"evaluate_candidate answered: {measured}");

		foreach (var slice in new[] { "development", "heldOut", "heldOutStressed" })
		{
			IsTrue(m.TryGetProperty(slice, out var block), $"the {slice} run was not reported: {measured}");

			foreach (var figure in new[] { "netProfit", "maxDrawdownPercent", "trades", "winRatePercent" })
			{
				IsTrue(block.TryGetProperty(figure, out _),
					$"the {slice} run was reported without {figure}.");
			}
		}

		var walkForward = m.GetProperty("walkForward");

		AreEqual(3, walkForward.GetProperty("returnPercentByWindow").GetArrayLength(),
			"the walk-forward windows were not reported one by one.");

		IsTrue(walkForward.TryGetProperty("spread", out _), "the spread between windows was not reported.");

		// Six runs, and the measurement names every one of them.
		AreEqual(6, measured.GetProperty("runs").GetArrayLength());

		// Nothing here decides anything. The words a scoring server would have used are absent.
		var text = measured.ToString();

		foreach (var word in new[] { "verdict", "score", "gate", "threshold", "accepted", "rejected" })
		{
			IsFalse(text.Contains(word, StringComparison.OrdinalIgnoreCase),
				$"the measurement passed judgement by saying '{word}': {text}");
		}

		// Reading it back changes nothing and costs nothing.
		var read = await _session.ToolAsync("get_evaluation",
			new { projectId = id, candidateId }, CancellationToken);

		AreEqual(
			m.GetProperty("heldOut").GetProperty("netProfit").GetDecimal(),
			read.GetProperty("measurement").GetProperty("heldOut").GetProperty("netProfit").GetDecimal());

		IsTrue(read.GetProperty("wasAlreadyMeasured").GetBoolean());
	}

	/// <summary>
	/// The closed part of the history cannot be run as though it were an ordinary slice. Everything the
	/// firewall protects rests on it never having been measured before the one time it is.
	/// </summary>
	[TestMethod]
	public async Task TheClosedSliceCannotBeRunAsAnOrdinaryOne()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "closed-import" }, CancellationToken);

		var proposed = await _session.ToolAsync("propose_spec",
			new { projectId = id, spec = SoundSpec, operationKey = "closed-spec" }, CancellationToken);

		var built = await _session.ToolAsync("build_candidate",
			new { projectId = id, specId = proposed.GetProperty("specId").GetString(), operationKey = "closed-build" },
			CancellationToken);

		var refused = await _session.ToolAsync("run_backtest",
			new
			{
				projectId = id,
				candidateId = built.GetProperty("candidateId").GetString(),
				slice = "final",
				symbol = "",
				scenario = "",
				parameters = "",
				operationKey = "closed-run",
			},
			CancellationToken);

		IsTrue(refused.TryGetProperty("error", out var error), $"the closed slice was run: {refused}");
		IsTrue(error.GetProperty("message").GetString().Contains("once", StringComparison.Ordinal),
			$"the refusal does not say why: {error}");
	}

	/// <summary>
	/// The closed part of the history is spent once. Everything the earlier numbers are worth rests on
	/// that, so the second attempt on the same candidate is refused rather than quietly repeated.
	/// </summary>
	[TestMethod]
	public async Task TheClosedSliceIsSpentOnceAndOnlyOnce()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "final-import" }, CancellationToken);

		var proposed = await _session.ToolAsync("propose_spec",
			new { projectId = id, spec = SoundSpec, operationKey = "final-spec" }, CancellationToken);

		var built = await _session.ToolAsync("build_candidate",
			new { projectId = id, specId = proposed.GetProperty("specId").GetString(), operationKey = "final-build" },
			CancellationToken);

		var candidateId = built.GetProperty("candidateId").GetString();

		var untouched = await _session.ToolAsync("get_closed_data_state", new { projectId = id }, CancellationToken);

		IsFalse(untouched.GetProperty("spent").GetBoolean());

		// The same fact, asked of the data rather than of the runs, has to agree with itself.
		var before = await _session.ToolAsync("describe_split", new { projectId = id }, CancellationToken);

		IsFalse(before.GetProperty("sealedSlice").GetProperty("consumed").GetBoolean(),
			"the split says the closed slice is spent before anything has been measured on it.");

		// Before the candidate has been measured on the open data there is nothing to compare against, and
		// the slice stays closed.
		var tooEarly = await _session.ToolAsync("measure_on_closed_data",
			new { projectId = id, candidateId, operationKey = "final-early" },
			CancellationToken);

		IsTrue(tooEarly.TryGetProperty("error", out _), $"an unmeasured candidate reached the closed slice: {tooEarly}");

		await _session.ToolAsync("evaluate_candidate",
			new { projectId = id, candidateId, symbol = "", parameters = "", operationKey = "final-judge" },
			CancellationToken);

		var confirmed = await _session.ToolAsync("measure_on_closed_data",
			new { projectId = id, candidateId, operationKey = "final-check" },
			CancellationToken);

		IsTrue(confirmed.TryGetProperty("onClosedData", out var closed), $"the closed data answered: {confirmed}");
		IsTrue(closed.TryGetProperty("heldOut", out _), "the closed measurement is missing its runs.");

		IsTrue(confirmed.TryGetProperty("onOpenData", out _),
			"what the candidate did on the open data was not returned beside it.");

		AreEqual(0, confirmed.GetProperty("provenance").GetProperty("earlierCandidatesThatSpentTheSlice").GetInt32());

		IsTrue(confirmed.GetProperty("note").GetString().Contains("spent", StringComparison.Ordinal),
			"the report does not say that the closed slice has been used up.");

		var spent = await _session.ToolAsync("get_closed_data_state", new { projectId = id }, CancellationToken);

		IsTrue(spent.GetProperty("spent").GetBoolean());

		var after = await _session.ToolAsync("describe_split", new { projectId = id }, CancellationToken);

		IsTrue(after.GetProperty("sealedSlice").GetProperty("consumed").GetBoolean(),
			"the split still says the closed slice is untouched after it was measured.");
		AreEqual(candidateId, spent.GetProperty("measuredCandidates")[0].GetString());

		// Nothing anywhere says where the closed part starts or how long it is.
		IsFalse(spent.ToString().Contains("2020", StringComparison.Ordinal) ||
			spent.ToString().Contains("2026", StringComparison.Ordinal),
			$"the state disclosed a date: {spent}");

		var again = await _session.ToolAsync("measure_on_closed_data",
			new { projectId = id, candidateId, operationKey = "final-again" },
			CancellationToken);

		IsTrue(again.TryGetProperty("error", out var error), $"the same candidate was measured twice: {again}");
		IsTrue(error.GetProperty("message").GetString().Contains("already", StringComparison.Ordinal));

		var listed = await _session.ToolAsync("list_candidates", new { projectId = id }, CancellationToken);

		var status = listed.GetProperty("candidates")[0].GetProperty("status").GetString();

		AreEqual("FinalChecked", status,
			"the candidate was left at the wrong stage after the closed data was measured.");
	}

	/// <summary>The catalog is the vocabulary, and an unknown name is refused against it by suggestion.</summary>
	[TestMethod]
	public async Task TheCatalogIsTheVocabulary()
	{
		var catalog = await _session.ToolAsync("get_indicator_catalog", new { }, CancellationToken);
		var names = catalog.GetProperty("indicators").EnumerateArray()
			.Select(i => i.GetProperty("name").GetString())
			.ToArray();

		IsTrue(names.Contains("sma") && names.Contains("atr"), $"the catalog published {string.Join(", ", names)}.");

		var misspelled = SoundSpec.Replace("\"highest\"", "\"highst\"", StringComparison.Ordinal);
		var checkResult = await _session.ToolAsync("validate_spec", new { spec = misspelled }, CancellationToken);

		var remedy = checkResult.GetProperty("problems")[0].GetProperty("remedy").GetString();

		IsTrue(remedy.Contains("highest", StringComparison.Ordinal),
			$"a misspelled indicator must be answered with the nearest real name; the remedy said: {remedy}");
	}

	private const string SoundSpec = """
		{
		  "name": "Volume confirmed breakout",
		  "thesis": "A close above a recent high carries on when participation confirms it.",
		  "allowLong": true,
		  "allowShort": false,
		  "timeFrame": "00:05:00",
		  "warmupBars": 61,
		  "entries": [
		    {
		      "id": "e1",
		      "direction": "Long",
		      "condition": {
		        "kind": "Compare",
		        "left": { "kind": "Field", "field": "Close" },
		        "operator": "GreaterThan",
		        "right": {
		          "kind": "Indicator",
		          "name": "highest",
		          "length": { "kind": "Parameter", "name": "BreakoutPeriod" },
		          "source": "High",
		          "offset": 1
		        }
		      }
		    }
		  ],
		  "exits": [
		    { "id": "x1", "kind": "AtrStop", "direction": "Long",
		      "length": { "kind": "Constant", "value": 14 },
		      "multiplier": { "kind": "Constant", "value": 2 } },
		    { "id": "x2", "kind": "SessionEnd", "direction": "Long" }
		  ],
		  "parameters": [
		    { "name": "BreakoutPeriod", "type": "Integer", "default": 20, "minimum": 10, "maximum": 60, "step": 5, "optimizable": true }
		  ],
		  "risk": { "maxPositionPercent": 0.1, "maxDailyLossPercent": 0.02 },
		  "assumptions": [],
		  "invalidationConditions": []
		}
		""";

	private const string BrokenSpec = """
		{
		  "name": "",
		  "thesis": "",
		  "allowLong": true,
		  "allowShort": false,
		  "timeFrame": "00:05:00",
		  "warmupBars": 2,
		  "entries": [
		    {
		      "id": "e1",
		      "direction": "Long",
		      "condition": {
		        "kind": "Compare",
		        "left": { "kind": "Field", "field": "Close" },
		        "operator": "GreaterThan",
		        "right": { "kind": "Parameter", "name": "Undeclared" }
		      }
		    }
		  ],
		  "exits": [],
		  "parameters": [],
		  "risk": { "maxPositionPercent": 0.1, "maxDailyLossPercent": 0.02 },
		  "assumptions": [],
		  "invalidationConditions": []
		}
		""";

	/// <summary>
	/// The whole path, ending where the product ends: the model reads the numbers, decides, and the
	/// server writes down what was decided along with everything needed to check it later.
	/// </summary>
	/// <remarks>
	/// This is the one conclusion in the product and it arrives from outside. What is asserted here is
	/// that the server keeps it whole — the code, the specification, the instrument, the data it was
	/// measured on and every run — because a folder holding a headline figure is a strategy nobody can
	/// check.
	/// </remarks>
	[TestMethod]
	public async Task AStrategyIsFinishedByTheModelAndKeptByTheServer()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "done-import" }, CancellationToken);

		var proposed = await _session.ToolAsync("propose_spec",
			new { projectId = id, spec = SoundSpec, operationKey = "done-spec" }, CancellationToken);

		var built = await _session.ToolAsync("build_candidate",
			new { projectId = id, specId = proposed.GetProperty("specId").GetString(), operationKey = "done-build" },
			CancellationToken);

		var candidateId = built.GetProperty("candidateId").GetString();

		// Nothing has been measured on the closed data, so there is nothing to conclude from yet.
		var tooEarly = await _session.ToolAsync("complete_strategy",
			new { projectId = id, candidateId, notes = "Looks good." }, CancellationToken);

		IsTrue(tooEarly.TryGetProperty("error", out _), $"a candidate was finished on no evidence: {tooEarly}");

		await _session.ToolAsync("evaluate_candidate",
			new { projectId = id, candidateId, symbol = "", parameters = "", operationKey = "done-measure" },
			CancellationToken);

		await _session.ToolAsync("measure_on_closed_data",
			new { projectId = id, candidateId, operationKey = "done-closed" }, CancellationToken);

		var finished = await _session.ToolAsync("complete_strategy",
			new
			{
				projectId = id,
				candidateId,
				notes = "Held its shape on the closed slice and traded often enough to believe.",
			},
			CancellationToken);

		AreEqual("Completed", finished.GetProperty("status").GetString());

		var kept = finished.GetProperty("kept");

		IsFalse(string.IsNullOrWhiteSpace(kept.GetProperty("symbol").GetString()),
			"the instrument it was measured on was not kept.");

		IsFalse(string.IsNullOrWhiteSpace(kept.GetProperty("dataset").GetProperty("contentHash").GetString()),
			"the data it was measured on cannot be identified.");

		IsTrue(kept.GetProperty("runs").GetArrayLength() >= 7,
			"the runs behind the result were not kept.");

		IsTrue(finished.TryGetProperty("onOpenData", out _) && finished.TryGetProperty("onClosedData", out _),
			"the two measurements were not returned side by side.");

		// The folder is a real one, holding files that can be opened without this server.
		var folder = finished.GetProperty("folder").GetString();

		IsTrue(Directory.Exists(folder), $"nothing was written to {folder}.");
		IsTrue(File.Exists(Path.Combine(folder, "strategy.json")), "the metadata file is missing.");
		IsTrue(File.Exists(Path.Combine(folder, "spec.json")), "the specification is missing.");

		IsTrue(Directory.EnumerateFiles(folder, "*.cs").Any(), "the strategy source is missing.");

		var listed = await _session.ToolAsync("list_completed_strategies", new { projectId = id }, CancellationToken);

		AreEqual(1, listed.GetProperty("completed").GetArrayLength());

		AreEqual(candidateId, listed.GetProperty("completed")[0].GetProperty("candidateId").GetString());

		// Concluding it twice would rewrite the conclusion.
		var again = await _session.ToolAsync("complete_strategy",
			new { projectId = id, candidateId, notes = "Still good." }, CancellationToken);

		IsTrue(again.TryGetProperty("error", out _), $"the same strategy was finished twice: {again}");
	}

	/// <summary>
	/// Measuring history that is already frozen needs no account, and the server must not pretend
	/// otherwise.
	/// </summary>
	/// <remarks>
	/// analyze_market reads bars off the disk and computes over them. It happens to live on the service
	/// that also downloads, and that accident is not a reason to refuse it on a machine with no keys -
	/// which is most machines trying the product out.
	/// </remarks>
	[TestMethod]
	public async Task MeasuringFrozenDataNeedsNoAccount()
	{
		var id = await NewProjectAsync();

		await _session.ToolAsync("import_demo_dataset",
			new { projectId = id, operationKey = "nokeys-import" }, CancellationToken);

		var measured = await _session.ToolAsync("analyze_market",
			new { projectId = id, symbol = "" }, CancellationToken);

		IsFalse(measured.TryGetProperty("error", out var refused),
			$"measuring frozen data was refused without an account: {refused}");

		IsTrue(measured.GetProperty("coverage").GetProperty("bars").GetInt32() > 0,
			$"nothing was measured: {measured}");
	}

	/// <summary>
	/// What genuinely needs an account says so, in the published error shape, naming what is missing and
	/// what still works without it.
	/// </summary>
	/// <remarks>
	/// The failure mode this replaces was the worst kind: the tool's arguments could not be bound, so no
	/// code of ours ran, and the agent received the transport's own wording - that something went wrong
	/// invoking a tool. No category to branch on, no mention of credentials, nothing to do next.
	/// </remarks>
	[TestMethod]
	public async Task WhatNeedsAnAccountSaysSoAndSaysWhatStillWorks()
	{
		var id = await NewProjectAsync();

		var refused = await _session.ToolAsync("import_history",
			new { projectId = id, symbols = "NVDA", timeFrame = "5m", days = 5, operationKey = "nokeys-download" },
			CancellationToken);

		IsTrue(refused.TryGetProperty("error", out var error),
			$"downloading without an account was not refused: {refused}");

		AreEqual("ConfigurationInvalid", error.GetProperty("category").GetString());

		IsTrue(error.GetProperty("message").GetString().Contains("broker account", StringComparison.Ordinal),
			$"the refusal does not say what is missing: {error}");

		var remediation = error.GetProperty("remediation").GetString();

		IsTrue(remediation.Contains("ODYSSEUS_ALPACA_KEYS", StringComparison.Ordinal),
			$"the refusal does not say how to supply an account: {remediation}");
		IsTrue(remediation.Contains("ODYSSEUS_BINANCE_KEYS", StringComparison.Ordinal),
			$"the refusal does not say how to supply Binance Testnet: {remediation}");

		IsTrue(remediation.Contains("import_demo_dataset", StringComparison.Ordinal),
			$"the refusal does not say what can be done without one: {remediation}");
	}

	/// <summary>
	/// Reading what has been deployed works without an account: the answer is that nothing has, and a
	/// question about our own records never needed a broker to answer.
	/// </summary>
	[TestMethod]
	public async Task ReadingDeploymentsNeedsNoAccount()
	{
		var id = await NewProjectAsync();

		var listed = await _session.ToolAsync("list_deployments", new { projectId = id }, CancellationToken);

		IsFalse(listed.TryGetProperty("error", out var refused),
			$"listing our own records was refused without an account: {refused}");

		AreEqual(0, listed.GetProperty("deployments").GetArrayLength());
	}

	/// <summary>
	/// Reading the account is a tool, and on a server with no account it refuses like every other one.
	/// </summary>
	/// <remarks>
	/// It exists because for a long time nothing could answer the question. Every figure an agent could
	/// see about a deployment came from what this product recorded while it was watching, so one left by
	/// a server that died read as flat forever - and the tools told the caller to go and check the
	/// account, with nothing to check it with.
	/// </remarks>
	[TestMethod]
	public async Task ReadingTheAccountIsPublishedAndRefusesWithoutOne()
	{
		var tools = await _session.ListToolsAsync(CancellationToken);

		IsTrue(tools.Contains("get_paper_account_state"),
			$"the account cannot be read at all; the server published {string.Join(", ", tools)}.");

		var refused = await _session.ToolAsync("get_paper_account_state", new { }, CancellationToken);

		IsTrue(refused.TryGetProperty("error", out var error),
			$"an account was reported on a server that has none: {refused}");

		AreEqual("ConfigurationInvalid", error.GetProperty("category").GetString());
	}

	/// <summary>
	/// Every argument a tool publishes is one the caller is expected to supply, and one it can only
	/// supply if it is told what the argument is.
	/// </summary>
	/// <remarks>
	/// This is the shape of a defect that shipped. A service the server had not registered stopped being
	/// resolved from the container and became an argument for the model to fill: a required property
	/// named 'service', of type object, with no description - because nobody wrote one, since nobody
	/// meant to publish it. Its own contract said so, and nothing was reading it. Every argument written
	/// on purpose here carries a description, so the absence of one is the signature of an argument
	/// nobody meant to publish.
	/// </remarks>
	[TestMethod]
	public async Task EveryPublishedArgumentSaysWhatItIs()
	{
		var described = await _session.CallAsync("tools/list", new { }, CancellationToken);

		foreach (var tool in described.GetProperty("tools").EnumerateArray())
		{
			var name = tool.GetProperty("name").GetString();

			if (!tool.TryGetProperty("inputSchema", out var schema) ||
				!schema.TryGetProperty("properties", out var properties))
			{
				continue;
			}

			foreach (var argument in properties.EnumerateObject())
			{
				IsTrue(argument.Value.TryGetProperty("description", out var text) &&
					!string.IsNullOrWhiteSpace(text.GetString()),
					$"'{name}' publishes an argument '{argument.Name}' without saying what it is, which is " +
					"what an argument nobody meant to publish looks like.");
			}
		}
	}

	/// <summary>The server says which half of itself is available before anything is attempted.</summary>
	[TestMethod]
	public async Task TheServerSaysWhetherItHasAnAccount()
	{
		var described = await _session.ToolAsync("describe_server", new { }, CancellationToken);

		IsFalse(described.GetProperty("hasBroker").GetBoolean(),
			"a server started without credentials reported that it has an account.");

		IsTrue(described.GetProperty("whatNeedsABroker").GetString().Contains("import_history", StringComparison.Ordinal),
			"the server does not say which tools need the account it does not have.");
	}

	private async Task<string> NewProjectAsync()
	{
		var created = await _session.ToolAsync("create_project",
			new { name = "study", operationKey = Guid.NewGuid().ToString("n") }, CancellationToken);

		return created.GetProperty("projectId").GetString();
	}
}
