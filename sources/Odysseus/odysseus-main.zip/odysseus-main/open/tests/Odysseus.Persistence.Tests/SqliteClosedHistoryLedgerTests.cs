namespace Odysseus.Persistence.Tests;

using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Domain;
using Odysseus.Persistence;
using Odysseus.TestKit;

/// <summary>
/// Remembering which closed history has been spent.
/// </summary>
/// <remarks>
/// The closed slice is the one measurement in the product that cannot be taken twice, and a project is
/// the wrong thing to remember that in: a second project over the same dates is a second sitting of the
/// same exam by someone who has read the paper. This is the record that survives the project.
/// </remarks>
[TestClass]
public class SqliteClosedHistoryLedgerTests : OdysseusTestBase
{
	private static readonly DateTime _may = new(2026, 5, 1, 0, 0, 0, DateTimeKind.Utc);

	private string _root;
	private SqliteClosedHistoryLedger _ledger;

	/// <summary>Builds a ledger over temporary storage.</summary>
	[TestInitialize]
	public void CreateLedger()
	{
		_root = Path.Combine(Path.GetTempPath(), "odysseus-tests", Guid.NewGuid().ToString("n"));
		_ledger = new SqliteClosedHistoryLedger(_root);
	}

	/// <summary>Releases storage.</summary>
	[TestCleanup]
	public void DeleteLedger()
	{
		_ledger?.Dispose();

		if (Directory.Exists(_root))
			Directory.Delete(_root, recursive: true);
	}

	/// <summary>Nothing spent, nothing found.</summary>
	[TestMethod]
	public async Task AnUntouchedStretchIsFree()
	{
		var found = await _ledger.FindOverlappingAsync("NVDA", _may, _may.AddDays(30), CancellationToken);

		AreEqual(0, found.Count);
	}

	/// <summary>The same stretch asked for twice is found the second time, with who spent it.</summary>
	[TestMethod]
	public async Task ASpentStretchIsFoundAgain()
	{
		var spent = Window("NVDA", _may, _may.AddDays(30));

		await _ledger.RecordAsync(spent, CancellationToken);

		var found = await _ledger.FindOverlappingAsync("NVDA", _may, _may.AddDays(30), CancellationToken);

		AreEqual(1, found.Count);
		AreEqual(spent.Project, found[0].Project);
		AreEqual(spent.Candidate, found[0].Candidate);
		AreEqual(spent.From, found[0].From);
		AreEqual(spent.To, found[0].To);
	}

	/// <summary>
	/// A stretch that shares a single day with a spent one is found. Importing a day more or a day less
	/// is the obvious way round a rule that only recognised an exact match, and it would work.
	/// </summary>
	[TestMethod]
	public async Task AStretchThatMerelyOverlapsIsFound()
	{
		await _ledger.RecordAsync(Window("NVDA", _may, _may.AddDays(30)), CancellationToken);

		var later = await _ledger.FindOverlappingAsync("NVDA", _may.AddDays(29), _may.AddDays(60), CancellationToken);
		var earlier = await _ledger.FindOverlappingAsync("NVDA", _may.AddDays(-30), _may.AddDays(1), CancellationToken);
		var inside = await _ledger.FindOverlappingAsync("NVDA", _may.AddDays(10), _may.AddDays(20), CancellationToken);
		var around = await _ledger.FindOverlappingAsync("NVDA", _may.AddDays(-10), _may.AddDays(40), CancellationToken);

		IsTrue(later.Count == 1, "a stretch starting inside a spent one was treated as untouched.");
		IsTrue(earlier.Count == 1, "a stretch ending inside a spent one was treated as untouched.");
		IsTrue(inside.Count == 1, "a stretch inside a spent one was treated as untouched.");
		IsTrue(around.Count == 1, "a stretch containing a spent one was treated as untouched.");
	}

	/// <summary>Stretches that merely touch end to end do not overlap: the end is exclusive.</summary>
	[TestMethod]
	public async Task StretchesThatOnlyTouchAreSeparate()
	{
		await _ledger.RecordAsync(Window("NVDA", _may, _may.AddDays(30)), CancellationToken);

		var after = await _ledger.FindOverlappingAsync("NVDA", _may.AddDays(30), _may.AddDays(60), CancellationToken);
		var before = await _ledger.FindOverlappingAsync("NVDA", _may.AddDays(-30), _may, CancellationToken);

		AreEqual(0, after.Count, "the stretch starting where the spent one ended was refused.");
		AreEqual(0, before.Count, "the stretch ending where the spent one began was refused.");
	}

	/// <summary>Another instrument over the same dates is another exam.</summary>
	[TestMethod]
	public async Task AnotherSymbolOverTheSameDatesIsFree()
	{
		await _ledger.RecordAsync(Window("NVDA", _may, _may.AddDays(30)), CancellationToken);

		var found = await _ledger.FindOverlappingAsync("AAPL", _may, _may.AddDays(30), CancellationToken);

		AreEqual(0, found.Count);
	}

	/// <summary>A symbol is the same symbol however it was typed.</summary>
	[TestMethod]
	public async Task CaseDoesNotMakeANewExam()
	{
		await _ledger.RecordAsync(Window("NVDA", _may, _may.AddDays(30)), CancellationToken);

		var found = await _ledger.FindOverlappingAsync("nvda", _may, _may.AddDays(30), CancellationToken);

		AreEqual(1, found.Count, "the same symbol in another case was treated as a different instrument.");
	}

	/// <summary>The record outlives the process that wrote it, or it protects nothing.</summary>
	[TestMethod]
	public async Task WhatWasSpentSurvivesAReopening()
	{
		await _ledger.RecordAsync(Window("NVDA", _may, _may.AddDays(30)), CancellationToken);

		_ledger.Dispose();
		_ledger = new SqliteClosedHistoryLedger(_root);

		var found = await _ledger.FindOverlappingAsync("NVDA", _may, _may.AddDays(30), CancellationToken);

		AreEqual(1, found.Count, "reopening the ledger forgot what had been spent.");
	}

	/// <summary>Disposing ledgers for other roots cannot invalidate a ledger that is still in use.</summary>
	[TestMethod]
	public async Task OtherLedgerPoolsAreIsolated()
	{
		const int records = 32;
		var survivorRoot = Path.Combine(Path.GetTempPath(), "odysseus-tests", Guid.NewGuid().ToString("n"));
		var survivor = new SqliteClosedHistoryLedger(survivorRoot);

		try
		{
			var writing = Task.Run(async () =>
			{
				for (var index = 0; index < records; index++)
					await survivor.RecordAsync(Window("NVDA", _may, _may.AddDays(30)), CancellationToken);
			});

			var disposing = Enumerable.Range(0, records).Select(async _ =>
			{
				var root = Path.Combine(Path.GetTempPath(), "odysseus-tests", Guid.NewGuid().ToString("n"));
				var transient = new SqliteClosedHistoryLedger(root);

				try
				{
					await transient.RecordAsync(Window("AAPL", _may, _may.AddDays(30)), CancellationToken);
				}
				finally
				{
					transient.Dispose();

					if (Directory.Exists(root))
						Directory.Delete(root, recursive: true);
				}
			});

			await Task.WhenAll(disposing.Append(writing));

			var found = await survivor.FindOverlappingAsync("NVDA", _may, _may.AddDays(30), CancellationToken);

			AreEqual(records, found.Count, "disposing another ledger interrupted the surviving connection.");
		}
		finally
		{
			survivor.Dispose();

			if (Directory.Exists(survivorRoot))
				Directory.Delete(survivorRoot, recursive: true);
		}
	}

	/// <summary>Everything that overlaps comes back, newest first.</summary>
	[TestMethod]
	public async Task EverythingThatOverlapsComesBack()
	{
		await _ledger.RecordAsync(Window("NVDA", _may, _may.AddDays(30)), CancellationToken);
		await _ledger.RecordAsync(Window("NVDA", _may.AddDays(10), _may.AddDays(40)), CancellationToken);

		var found = await _ledger.FindOverlappingAsync("NVDA", _may.AddDays(20), _may.AddDays(25), CancellationToken);

		AreEqual(2, found.Count);
		IsTrue(found[0].From > found[1].From, "the newest was not first.");
	}

	private static SpentWindow Window(string symbol, DateTime from, DateTime to)
		=> new(
			ProjectId.New(),
			CandidateId.New(),
			symbol,
			TimeSpan.FromMinutes(5),
			from,
			to,
			DateTime.UtcNow);
}
