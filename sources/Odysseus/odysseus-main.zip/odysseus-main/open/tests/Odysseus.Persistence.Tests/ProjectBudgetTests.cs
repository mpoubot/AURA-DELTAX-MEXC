namespace Odysseus.Persistence.Tests;

using System;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Domain;
using Odysseus.Persistence;
using Odysseus.TestKit;

/// <summary>
/// Spending a project's allowance.
/// </summary>
/// <remarks>
/// The allowance is the only thing that stops the agent's loop, and the loop is exactly when several
/// calls arrive at once. Read the figure, add to it and write it back, and two calls arriving together
/// read the same number and write the same number: the second spends nothing, and the ceiling stops
/// counting precisely when it is most needed.
/// </remarks>
[TestClass]
public class ProjectBudgetTests : OdysseusTestBase
{
	private string _root;
	private SqliteProjectStore _store;

	/// <summary>Builds a store over temporary storage.</summary>
	[TestInitialize]
	public void CreateStore()
	{
		_root = Path.Combine(Path.GetTempPath(), "odysseus-tests", Guid.NewGuid().ToString("n"));
		_store = new SqliteProjectStore(_root);
	}

	/// <summary>Releases storage.</summary>
	[TestCleanup]
	public void DeleteStore()
	{
		_store?.Dispose();

		if (Directory.Exists(_root))
			Directory.Delete(_root, recursive: true);
	}

	/// <summary>A claim is taken, and what is left says so.</summary>
	[TestMethod]
	public async Task AClaimIsTaken()
	{
		var project = await NewProjectAsync(backtests: 10);

		IsTrue(await _store.TryClaimAsync(project, 3, 0, CancellationToken), "the claim was refused.");

		var budget = ResearchBudget.Restore((await _store.OpenAsync(project, CancellationToken)).Budget);

		AreEqual(7, budget.RemainingBacktests);
	}

	/// <summary>Claims arriving together each cost what they claim.</summary>
	[TestMethod]
	public async Task ClaimsThatArriveTogetherEachCost()
	{
		var project = await NewProjectAsync(backtests: 100);

		var claims = Enumerable.Range(0, 20)
			.Select(_ => _store.TryClaimAsync(project, 1, 0, CancellationToken).AsTask())
			.ToArray();

		await Task.WhenAll(claims);

		IsTrue(claims.All(c => c.Result), "a claim well inside the allowance was refused.");

		var budget = ResearchBudget.Restore((await _store.OpenAsync(project, CancellationToken)).Budget);

		AreEqual(80, budget.RemainingBacktests, "twenty claims did not cost twenty.");
	}

	/// <summary>A claim larger than what is left is refused whole rather than granted in part.</summary>
	[TestMethod]
	public async Task AClaimBeyondTheAllowanceIsRefusedWhole()
	{
		var project = await NewProjectAsync(backtests: 10);

		IsFalse(await _store.TryClaimAsync(project, 11, 0, CancellationToken), "a claim beyond the ceiling was granted.");

		var budget = ResearchBudget.Restore((await _store.OpenAsync(project, CancellationToken)).Budget);

		AreEqual(10, budget.RemainingBacktests, "a refused claim spent part of the allowance.");
	}

	/// <summary>Saving a project does not write back an allowance the caller read a moment ago.</summary>
	[TestMethod]
	public async Task SavingAProjectDoesNotUndoAClaim()
	{
		var project = await NewProjectAsync(backtests: 10);

		var stale = await _store.OpenAsync(project, CancellationToken);

		await _store.TryClaimAsync(project, 4, 0, CancellationToken);

		await _store.UpdateAsync(stale with { UpdatedAt = DateTime.UtcNow }, CancellationToken);

		var budget = ResearchBudget.Restore((await _store.OpenAsync(project, CancellationToken)).Budget);

		AreEqual(6, budget.RemainingBacktests, "saving the project handed the allowance back.");
	}

	/// <summary>Time is spent by work that finished, and it runs out.</summary>
	[TestMethod]
	public async Task TimeIsChargedAndRunsOut()
	{
		var project = await NewProjectAsync(backtests: 100, wallClock: TimeSpan.FromMinutes(10));

		await _store.ChargeTimeAsync(project, TimeSpan.FromMinutes(4), CancellationToken);

		var half = ResearchBudget.Restore((await _store.OpenAsync(project, CancellationToken)).Budget);

		AreEqual(TimeSpan.FromMinutes(6), half.RemainingWallClock);
		IsTrue(await _store.TryClaimAsync(project, 1, 0, CancellationToken), "time was left and the claim was refused.");

		await _store.ChargeTimeAsync(project, TimeSpan.FromMinutes(6), CancellationToken);

		var spent = ResearchBudget.Restore((await _store.OpenAsync(project, CancellationToken)).Budget);

		AreEqual(TimeSpan.Zero, spent.RemainingWallClock);
		IsTrue(spent.IsExhausted, "a project with no machine time left says it has allowance.");

		IsFalse(await _store.TryClaimAsync(project, 1, 0, CancellationToken),
			"work was started on a project that has spent its machine time.");
	}

	/// <summary>Candidates are counted apart from backtests.</summary>
	[TestMethod]
	public async Task CandidatesAreCountedApart()
	{
		var project = await NewProjectAsync(backtests: 10, candidates: 2);

		IsTrue(await _store.TryClaimAsync(project, 0, 1, CancellationToken));
		IsTrue(await _store.TryClaimAsync(project, 0, 1, CancellationToken));
		IsFalse(await _store.TryClaimAsync(project, 0, 1, CancellationToken), "a third candidate was granted out of two.");

		var budget = ResearchBudget.Restore((await _store.OpenAsync(project, CancellationToken)).Budget);

		AreEqual(10, budget.RemainingBacktests, "claiming candidates cost backtests.");
	}

	private async Task<ProjectId> NewProjectAsync(
		int backtests = 100,
		int candidates = 40,
		TimeSpan wallClock = default)
	{
		var project = ResearchProject.Create(
			"allowance",
			new ResearchBudget(
				backtests,
				candidates,
				wallClock == default ? TimeSpan.FromHours(1) : wallClock).ToState(),
			DateTime.UtcNow);

		await _store.CreateAsync(project, CancellationToken);

		return project.Id;
	}
}
