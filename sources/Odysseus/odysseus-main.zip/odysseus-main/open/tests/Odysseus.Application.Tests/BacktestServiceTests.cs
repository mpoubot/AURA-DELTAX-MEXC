namespace Odysseus.Application.Tests;

using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Domain;
using Odysseus.Persistence;
using Odysseus.Spec;
using Odysseus.TestKit;

/// <summary>
/// What a run costs, and what it costs when it does not happen.
/// </summary>
/// <remarks>
/// The allowance is the only thing standing between a search and an unbounded one, so it has to be
/// counted exactly: charged for work that was done, and not charged for work that was abandoned. A
/// client that drops a connection is ordinary - it happens on a timeout, on a restart, on a person
/// pressing a key - and if each of those quietly costs a backtest, the ceiling arrives sooner than the
/// count of results explains and nobody can say why.
/// </remarks>
[TestClass]
public class BacktestServiceTests : OdysseusTestBase
{
	private static readonly DateTime _open = new(2026, 3, 2, 14, 30, 0, DateTimeKind.Utc);

	/// <summary>A builder that hands back something assembly-shaped, since nothing here runs it.</summary>
	private sealed class Builder : IStrategyBuilder
	{
		public BuiltStrategy Build(StrategySpec spec)
			=> new("Generated", $"// source of {spec.Name}", $"source-{spec.Name}", [1, 2, 3], $"assembly-{spec.Name}", "1.0.0");
	}

	/// <summary>A runner that can be told to give up the way a dropped client makes it give up.</summary>
	private sealed class Runner : IBacktestRunner
	{
		public bool Cancel { get; set; }

		public bool Fail { get; set; }

		public int Runs { get; private set; }

		public Task<BacktestOutcome> RunAsync(BacktestRequest request, CancellationToken cancellationToken)
		{
			Runs++;

			if (Cancel)
				throw new OperationCanceledException();

			if (Fail)
				throw new InvalidOperationException("the strategy threw on its first bar");

			var trades = new List<ExecutedTrade>();
			var equity = new List<EquityPoint>();
			var money = 100_000m;

			for (var i = 0; i < 20; i++)
			{
				var entry = request.Bars[0].OpenTime.AddHours(i);

				trades.Add(new($"t{i}", request.Symbol, TradeDirections.Long, entry, 100m, entry.AddMinutes(25),
					101m, 10m, 0.5m, 0.5m));

				money += 10m;
				equity.Add(new(entry.AddMinutes(25), money));
			}

			return Task.FromResult(new BacktestOutcome(trades, equity, request.Bars.Count, 0, 40));
		}
	}

	private string _root;
	private SqliteProjectStore _store;
	private SqliteOperationLog _operations;
	private FileArtifactStore _artifacts;
	private FileDatasetStore _datasets;
	private FileSpecStore _specs;
	private Runner _runner;
	private ProjectService _projects;
	private CandidateService _candidates;
	private BacktestService _service;

	/// <summary>Builds the services over temporary storage.</summary>
	[TestInitialize]
	public void CreateService()
	{
		_root = Path.Combine(Path.GetTempPath(), "odysseus-tests", Guid.NewGuid().ToString("n"));
		_store = new SqliteProjectStore(_root);
		_operations = new SqliteOperationLog(_root);
		_artifacts = new FileArtifactStore(_root);
		_datasets = new FileDatasetStore(_root, _artifacts);
		_specs = new FileSpecStore(_root);
		_runner = new Runner();

		var clock = new SystemClock();
		var budget = new ResearchBudget(20, 5, TimeSpan.FromMinutes(45)).ToState();

		_projects = new ProjectService(_store, _store, _operations, clock, ServerModes.Local, budget);
		_candidates = new CandidateService(_store, _specs, _store, _artifacts, new Builder(), _store, _operations, clock);

		_service = new BacktestService(
			_store, _store, _specs, _datasets, _store, _artifacts, _runner, _store, _operations, clock);
	}

	/// <summary>Releases storage.</summary>
	[TestCleanup]
	public void DeleteService()
	{
		_store?.Dispose();
		_operations?.Dispose();

		if (Directory.Exists(_root))
			Directory.Delete(_root, recursive: true);
	}

	/// <summary>A run that finished is charged once.</summary>
	[TestMethod]
	public async Task AFinishedRunCostsOne()
	{
		var (project, candidate) = await ReadyAsync();

		var before = await RemainingAsync(project);

		await _service.RunAsync(
			project, candidate, DataSlices.Development, RunWindow.Whole, "NVDA", CostScenario.Baseline,
			null, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken);

		AreEqual(before - 1, await RemainingAsync(project));
	}

	/// <summary>
	/// A run the caller gave up on costs nothing, because nothing was measured.
	/// </summary>
	/// <remarks>
	/// The allowance is claimed before the work, which is right - two runs arriving together must cost
	/// two - but a claim taken for work that never happened has to be given back, or a dropped connection
	/// is a silent charge and the ceiling arrives early for no reason anyone can see.
	/// </remarks>
	[TestMethod]
	public async Task AnAbandonedRunCostsNothing()
	{
		var (project, candidate) = await ReadyAsync();

		var before = await RemainingAsync(project);

		_runner.Cancel = true;

		await ThrowsAsync<OperationCanceledException>(() => _service.RunAsync(
			project, candidate, DataSlices.Development, RunWindow.Whole, "NVDA", CostScenario.Baseline,
			null, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken).AsTask());

		AreEqual(before, await RemainingAsync(project),
			"the abandoned run was charged to the allowance.");
	}

	/// <summary>
	/// Asking again after giving up costs one, not two: the abandoned attempt left nothing behind, so
	/// the retry is the first run of that measurement rather than the second.
	/// </summary>
	[TestMethod]
	public async Task RetryingAfterGivingUpCostsOne()
	{
		var (project, candidate) = await ReadyAsync();

		var before = await RemainingAsync(project);
		var key = Guid.NewGuid().ToString("n");

		_runner.Cancel = true;

		await ThrowsAsync<OperationCanceledException>(() => _service.RunAsync(
			project, candidate, DataSlices.Development, RunWindow.Whole, "NVDA", CostScenario.Baseline,
			null, key, Actors.Agent, CancellationToken).AsTask());

		_runner.Cancel = false;

		await _service.RunAsync(
			project, candidate, DataSlices.Development, RunWindow.Whole, "NVDA", CostScenario.Baseline,
			null, key, Actors.Agent, CancellationToken);

		AreEqual(before - 1, await RemainingAsync(project),
			"the measurement cost two backtests although only one of them ran.");
	}

	/// <summary>A run that failed for a reason of its own is charged, because it is a result.</summary>
	/// <remarks>
	/// This is the line the release must not cross. A candidate that cannot be run has been answered,
	/// and the attempt is evidence; only work the caller walked away from is given back.
	/// </remarks>
	[TestMethod]
	public async Task ARunThatFailedIsStillCharged()
	{
		var (project, candidate) = await ReadyAsync();

		var before = await RemainingAsync(project);

		_runner.Fail = true;

		var (run, _) = await _service.RunAsync(
			project, candidate, DataSlices.Development, RunWindow.Whole, "NVDA", CostScenario.Baseline,
			null, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken);

		AreEqual(RunStatuses.Failed, run.Status);
		AreEqual(before - 1, await RemainingAsync(project), "a failed run is a result and is charged.");
	}

	private async Task<int> RemainingAsync(ProjectId project)
	{
		var existing = await _store.OpenAsync(project, CancellationToken);

		return ResearchBudget.Restore(existing.Budget).RemainingBacktests;
	}

	private async Task<(ProjectId Project, CandidateId Candidate)> ReadyAsync()
	{
		var project = (await _projects.CreateProjectAsync(
			"budget", Guid.NewGuid().ToString("n"), Actors.User, CancellationToken)).Id;

		var bars = new Dictionary<string, IReadOnlyList<Candle>> { ["NVDA"] = Bars() };
		var imported = DatasetBuilder.Build(bars, TimeSpan.FromMinutes(5), "test", isSynthetic: true);

		await _datasets.SaveAsync(project, imported, CancellationToken);

		var opened = await _store.OpenAsync(project, CancellationToken);

		await _store.UpdateAsync(opened.WithDataset(imported.Manifest.Id, DateTime.UtcNow), CancellationToken);

		var spec = await _specs.AddAsync(project, Spec(), Actors.Agent, DateTime.UtcNow, CancellationToken);

		var built = await _candidates.BuildAsync(
			project, spec.Id, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken);

		return (project, built.Id);
	}

	private static IReadOnlyList<Candle> Bars()
	{
		var bars = new List<Candle>();
		var time = _open;

		for (var i = 0; i < 2_000; i++)
		{
			var wave = (decimal)Math.Sin(i * 2 * Math.PI / 60);
			var close = 100m + Math.Round(5m * wave, 2);
			var open = bars.Count == 0 ? close : bars[^1].Close;

			bars.Add(new(time, open, Math.Max(open, close) + 0.05m, Math.Min(open, close) - 0.05m, close, 10_000m));

			time = time.AddMinutes(5);

			if (time.TimeOfDay >= TimeSpan.FromHours(21))
				time = time.Date.AddDays(time.DayOfWeek == DayOfWeek.Friday ? 3 : 1).Add(_open.TimeOfDay);
		}

		return bars;
	}

	private static string Spec()
		=> $$"""
		{
		  "name": "Above its average {{Guid.NewGuid().ToString("n")[..8]}}",
		  "thesis": "A price above its own recent average keeps going for a few bars.",
		  "allowLong": true,
		  "allowShort": false,
		  "timeFrame": "00:05:00",
		  "warmupBars": 45,
		  "entries": [
		    { "id": "e1", "direction": "Long", "condition": {
		        "kind": "Compare",
		        "left": { "kind": "Field", "field": "Close" },
		        "operator": "GreaterThan",
		        "right": { "kind": "Indicator", "name": "sma", "length": { "kind": "Constant", "value": 20 }, "source": "Close" } } }
		  ],
		  "exits": [ { "id": "x1", "kind": "TimeExit", "direction": "Long", "length": { "kind": "Constant", "value": 5 } } ],
		  "parameters": [],
		  "risk": { "maxPositionPercent": 0.10, "maxDailyLossPercent": 0.02 }
		}
		""";
}
