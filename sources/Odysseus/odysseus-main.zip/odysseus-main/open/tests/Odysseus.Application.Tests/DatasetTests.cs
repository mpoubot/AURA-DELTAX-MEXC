namespace Odysseus.Application.Tests;

using System;
using System.Collections.Generic;
using System.Linq;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Domain;
using Odysseus.TestKit;

/// <summary>
/// Building an immutable dataset, and dividing it so that part of it stays unseen.
/// </summary>
[TestClass]
public class DatasetTests : OdysseusTestBase
{
	private static readonly DateTime _start = new(2025, 1, 2, 14, 30, 0, DateTimeKind.Utc);

	private static readonly TimeSpan _frame = TimeSpan.FromMinutes(5);

	/// <summary>The same bars produce the same identity, whenever they are imported.</summary>
	[TestMethod]
	public void IdenticalDataHashesIdentically()
	{
		var first = DatasetBuilder.Build(Bars(), _frame, "test", isSynthetic: true);
		var second = DatasetBuilder.Build(Bars(), _frame, "test", isSynthetic: true);

		AreEqual(first.Manifest.ContentHash, second.Manifest.ContentHash);
		AreNotEqual(first.Manifest.Id, second.Manifest.Id, "identity of the version is not the hash of its content.");
	}

	/// <summary>A single changed price is a different dataset.</summary>
	[TestMethod]
	public void AChangedBarChangesTheHash()
	{
		var original = DatasetBuilder.Build(Bars(), _frame, "test", isSynthetic: true);

		var altered = Bars();
		var candles = altered["AAA"].ToList();
		candles[10] = candles[10] with { Close = candles[10].Close + 0.01m };
		altered["AAA"] = candles;

		var second = DatasetBuilder.Build(altered, _frame, "test", isSynthetic: true);

		AreNotEqual(original.Manifest.ContentHash, second.Manifest.ContentHash);
	}

	/// <summary>The order bars arrive in does not change what they are.</summary>
	[TestMethod]
	public void ArrivalOrderDoesNotMatter()
	{
		var ordered = DatasetBuilder.Build(Bars(), _frame, "test", isSynthetic: true);

		var shuffled = Bars();
		shuffled["AAA"] = [.. shuffled["AAA"].Reverse()];

		var second = DatasetBuilder.Build(shuffled, _frame, "test", isSynthetic: true);

		AreEqual(ordered.Manifest.ContentHash, second.Manifest.ContentHash);
	}

	/// <summary>
	/// A bar whose prices cannot describe a real bar is dropped rather than repaired: a guessed price is
	/// indistinguishable from an observed one afterwards.
	/// </summary>
	[TestMethod]
	public void MalformedBarsAreDroppedAndCounted()
	{
		var bars = Bars();
		var candles = bars["AAA"].ToList();

		candles[5] = candles[5] with { Low = candles[5].High + 5m };
		candles[6] = candles[6] with { Volume = -1m };
		bars["AAA"] = candles;

		var dataset = DatasetBuilder.Build(bars, _frame, "test", isSynthetic: true);
		var quality = dataset.Manifest.Quality.Single(q => q.Symbol == "AAA");

		AreEqual(2, quality.Invalid);
		AreEqual(candles.Count - 2, quality.Records);
		IsFalse(dataset.Bars["AAA"].Any(c => !c.IsWellFormed), "a malformed bar survived into the dataset.");
	}

	/// <summary>Two bars claiming the same moment cannot both be right, so the later one is dropped.</summary>
	[TestMethod]
	public void DuplicateMomentsAreDroppedAndCounted()
	{
		var bars = Bars();
		var candles = bars["AAA"].ToList();

		// A well-formed bar claiming a moment that is already taken: the volume differs, so the two
		// disagree about the same moment without either being malformed on its own.
		candles.Add(candles[3] with { Volume = candles[3].Volume + 1m });
		bars["AAA"] = candles;

		var quality = DatasetBuilder
			.Build(bars, _frame, "test", isSynthetic: true)
			.Manifest.Quality.Single(q => q.Symbol == "AAA");

		AreEqual(1, quality.Duplicates);
	}

	/// <summary>Missing bars are reported rather than filled in.</summary>
	[TestMethod]
	public void GapsAreCounted()
	{
		var bars = Bars();
		var candles = bars["AAA"].ToList();

		candles.RemoveRange(50, 3);
		bars["AAA"] = candles;

		var quality = DatasetBuilder
			.Build(bars, _frame, "test", isSynthetic: true)
			.Manifest.Quality.Single(q => q.Symbol == "AAA");

		AreEqual(1, quality.Gaps);
		AreEqual(candles.Count, quality.Records, "a gap must be reported, not filled.");
	}

	/// <summary>
	/// Too little data is refused outright, and the refusal says how much was usable and why the rest
	/// was not — the caller has to be able to act on it.
	/// </summary>
	[TestMethod]
	public void TooLittleDataIsRefusedWithNumbers()
	{
		var bars = new Dictionary<string, IReadOnlyList<Candle>>(StringComparer.Ordinal)
		{
			["AAA"] = [.. Generate(10)],
		};

		var error = Throws<ArgumentException>(() => DatasetBuilder.Build(bars, _frame, "test", isSynthetic: true));

		IsTrue(error.Message.Contains("10 usable bars", StringComparison.Ordinal), "the refusal must say how much was usable.");
		IsTrue(error.Message.Contains(DatasetBuilder.MinimumBarsPerSymbol.ToString(), StringComparison.Ordinal),
			"the refusal must say how much is needed.");
	}

	/// <summary>Generated data stays marked as generated wherever it goes.</summary>
	[TestMethod]
	public void SyntheticDataIsMarked()
	{
		IsTrue(DemoDataset.Build(barsPerSymbol: 500).Manifest.IsSynthetic,
			"a dataset of invented prices must say so, or a plausible equity curve over it reads as evidence.");
	}

	/// <summary>The demo dataset is reproducible from its seed.</summary>
	[TestMethod]
	public void DemoDataIsReproducible()
	{
		AreEqual(
			DemoDataset.Build(seed: 7, barsPerSymbol: 300).Manifest.ContentHash,
			DemoDataset.Build(seed: 7, barsPerSymbol: 300).Manifest.ContentHash);

		AreNotEqual(
			DemoDataset.Build(seed: 7, barsPerSymbol: 300).Manifest.ContentHash,
			DemoDataset.Build(seed: 8, barsPerSymbol: 300).Manifest.ContentHash);
	}

	/// <summary>The slices are contiguous, ordered in time, and none of them is empty.</summary>
	[TestMethod]
	public void SlicesTileTheRangeInOrder()
	{
		var split = DatasetSplit.Create(_start, _start.AddDays(100), 0.6, 0.2);

		var development = split.BoundsOf(DataSlices.Development);
		var validation = split.BoundsOf(DataSlices.Validation);
		var final = split.BoundsOf(DataSlices.Final);

		AreEqual(development.To, validation.From, "the slices must be contiguous.");
		AreEqual(validation.To, final.From, "the slices must be contiguous.");

		IsTrue(development.From < development.To);
		IsTrue(validation.From < validation.To);
		IsTrue(final.From < final.To);

		AreEqual(DataSlices.Development, split.SliceOf(_start));
		AreEqual(DataSlices.Validation, split.SliceOf(development.To));
		AreEqual(DataSlices.Final, split.SliceOf(validation.To));
	}

	/// <summary>A split that keeps nothing closed is refused, and the refusal says why it matters.</summary>
	[TestMethod]
	public void ASplitMustKeepSomethingClosed()
	{
		var error = Throws<ArgumentOutOfRangeException>(
			() => DatasetSplit.Create(_start, _start.AddDays(10), 0.8, 0.2));

		IsTrue(error.Message.Contains("closed", StringComparison.Ordinal));
	}

	/// <summary>
	/// The disclosed division must not let the closed slice be recovered. Its start is the end of
	/// validation, so the end of the dataset must not appear anywhere alongside it.
	/// </summary>
	[TestMethod]
	public void DisclosureCannotRevealTheClosedSlice()
	{
		var split = DatasetSplit.Create(_start, _start.AddDays(100), 0.6, 0.2);
		var disclosed = split.Disclose(consumed: false);

		AreEqual(split.From, disclosed.DevelopmentFrom);
		AreEqual(split.DevelopmentTo, disclosed.DevelopmentTo);

		IsTrue(disclosed.HasSealedSlice, "the caller may know that a closed slice exists.");

		var text = disclosed.ToString();

		IsFalse(text.Contains(split.To.ToString("O"), StringComparison.Ordinal),
			"the end of the dataset must not be disclosed: it is the end of the closed slice.");

		IsFalse(text.Contains(split.ValidationTo.ToString("O"), StringComparison.Ordinal),
			"the end of validation must not be disclosed: it is where the closed slice begins, which is the " +
			"half of the boundary worth knowing.");
	}

	/// <summary>A moment outside the data belongs to no slice, rather than to the nearest one.</summary>
	[TestMethod]
	public void MomentsOutsideTheDataBelongNowhere()
	{
		var split = DatasetSplit.Create(_start, _start.AddDays(100), 0.6, 0.2);

		Throws<ArgumentOutOfRangeException>(() => split.SliceOf(_start.AddDays(-1)));
		Throws<ArgumentOutOfRangeException>(() => split.SliceOf(_start.AddDays(100)));
	}

	/// <summary>
	/// Nothing an agent is shown may let the closed slice be worked out. A last bar time or a total count
	/// is enough: put either next to the end of validation and the closed slice is one subtraction away.
	/// </summary>
	[TestMethod]
	public void TheDisclosedViewCannotBeUsedToLocateTheClosedSlice()
	{
		var dataset = DatasetBuilder.Build(Bars(), _frame, "test", isSynthetic: true);
		var split = dataset.Manifest.Split;

		foreach (var quality in dataset.Manifest.DisclosedQuality)
		{
			IsTrue(quality.To < split.ValidationTo,
				$"the last disclosed bar of '{quality.Symbol}' lies at or past the end of validation, which places the closed slice.");
		}

		IsTrue(dataset.Manifest.DisclosedRecords < dataset.Manifest.Records,
			"the disclosed count must exclude the closed slice, or it dates the end of the data.");

		// The strongest form of the check: walking forward from the start by the disclosed number of bars
		// must not reach the end of the data, which is what a count plus a timeframe would otherwise give.
		var reachable = split.From + _frame * dataset.Manifest.DisclosedQuality[0].Records;

		IsTrue(reachable < split.To, "the disclosed count and the timeframe together reach the end of the data.");
	}

	/// <summary>The full picture is still kept, because the server itself needs it to measure at all.</summary>
	[TestMethod]
	public void TheServerStillKnowsTheWholeDataset()
	{
		var dataset = DatasetBuilder.Build(Bars(), _frame, "test", isSynthetic: true);

		AreEqual(
			dataset.Bars.Values.Sum(b => b.Count),
			dataset.Manifest.Records,
			"the manifest must account for every bar that was kept.");
	}

	private static Dictionary<string, IReadOnlyList<Candle>> Bars()
		=> new(StringComparer.Ordinal)
		{
			["AAA"] = [.. Generate(300)],
			["BBB"] = [.. Generate(300, 50m)],
		};

	private static IEnumerable<Candle> Generate(int count, decimal start = 100m)
	{
		var price = start;
		var time = _start;

		for (var i = 0; i < count; i++)
		{
			var close = price + (i % 7 - 3) * 0.1m;

			yield return new(time, price, Math.Max(price, close) + 0.2m, Math.Min(price, close) - 0.2m, close, 1000 + i);

			price = close;
			time += _frame;
		}
	}
}
