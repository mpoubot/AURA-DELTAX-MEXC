namespace Odysseus.Application.Tests;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Domain;
using Odysseus.Persistence;
using Odysseus.Spec;
using Odysseus.TestKit;

/// <summary>
/// Putting a candidate on the paper account.
/// </summary>
/// <remarks>
/// This is where research stops being free. Everything before it happens against frozen bars; here a
/// strategy places orders on an account, and the rules about which candidate may do that, with which
/// numbers, and how many at once are the whole of what stands between research and a mess.
///
/// The broker is a stand-in, so these say nothing about whether Alpaca fills anything. They say what is
/// allowed to reach it.
/// </remarks>
[TestClass]
public class DeploymentServiceTests : OdysseusTestBase
{
	/// <summary>A builder that hands back something assembly-shaped, since nothing here runs it.</summary>
	private sealed class Builder : IStrategyBuilder
	{
		public BuiltStrategy Build(StrategySpec spec)
			=> new(
				"Generated",
				$"// source of {spec.Name}",

				// Distinct per specification, because a candidate is recognised by the source it came from
				// and two specifications hashing the same are one candidate.
				$"source-{spec.Name}",
				[1, 2, 3],
				$"assembly-{spec.Name}",
				"1.0.0");
	}

	/// <summary>A broker that accepts everything and reports whatever it is told to.</summary>
	private sealed class Broker : IPaperTrader
	{
		public string Name => "stand-in";

		public PaperRequest Started { get; private set; }

		public Session Last { get; private set; }

		public Task<IPaperSession> StartAsync(PaperRequest request, CancellationToken cancellationToken)
		{
			Started = request;
			Last = new Session();

			return Task.FromResult<IPaperSession>(Last);
		}
	}

	private sealed class Session : IPaperSession
	{
		public bool IsRunning { get; set; } = true;

		public int OrdersPlaced { get; set; }

		public int Trades { get; set; }

		public decimal RealizedProfit { get; set; }

		public decimal Position { get; set; }

		public string Error { get; set; }

		public bool WasAskedToClose { get; private set; }

		public bool WasStopped { get; private set; }

		public Task StopAsync(bool closePosition, CancellationToken cancellationToken)
		{
			WasStopped = true;
			WasAskedToClose = closePosition;
			IsRunning = false;

			return Task.CompletedTask;
		}

		public ValueTask DisposeAsync() => default;
	}

	private string _root;
	private SqliteProjectStore _store;
	private SqliteOperationLog _operations;
	private FileDatasetStore _datasets;
	private FileSpecStore _specs;
	private FileArtifactStore _artifacts;
	private Broker _broker;
	private ProjectService _projects;
	private DatasetService _dataset;
	private CandidateService _candidates;
	private DeploymentService _service;

	/// <summary>Builds the services over temporary storage.</summary>
	[TestInitialize]
	public void CreateService()
	{
		_root = Path.Combine(Path.GetTempPath(), "odysseus-tests", Guid.NewGuid().ToString("n"));
		_store = new SqliteProjectStore(_root);
		_operations = new SqliteOperationLog(_root);
		_artifacts = new FileArtifactStore(_root);
		_datasets = new FileDatasetStore(_root, _artifacts);
		_specs = new FileSpecStore(_root);
		_broker = new Broker();

		var clock = new SystemClock();
		var budget = new ResearchBudget(400, 40, TimeSpan.FromMinutes(45)).ToState();

		_projects = new ProjectService(_store, _store, _operations, clock, ServerModes.Local, budget);
		_dataset = new DatasetService(_store, _datasets, _store, _store, _operations, clock);

		_candidates = new CandidateService(
			_store, _specs, _store, _artifacts, new Builder(), _store, _operations, clock);

		_service = new DeploymentService(
			_store, _store, _specs, _datasets, _artifacts, _store, _store, _broker, _store, clock);
	}

	/// <summary>Releases storage.</summary>
	[TestCleanup]
	public void DeleteService()
	{
		_store?.Dispose();
		_operations?.Dispose();

		if (Directory.Exists(_root))
			Directory.Delete(_root, recursive: true);
	}

	/// <summary>
	/// A candidate the closed data has never seen cannot be put on an account. Paper is where a backtest
	/// gets contradicted, and there is nothing to contradict until something has been claimed.
	/// </summary>
	[TestMethod]
	public async Task ACandidateWithoutClosedDataIsRefused()
	{
		var (project, candidate) = await ReadyAsync();

		var refusal = await ThrowsAsync<InvalidOperationException>(
			() => _service.StartAsync(project, candidate, Actors.Agent, CancellationToken).AsTask());

		IsTrue(refusal.Message.Contains("measure_on_closed_data", StringComparison.OrdinalIgnoreCase),
			$"the refusal does not say what is missing: {refusal.Message}");
	}

	/// <summary>A finished candidate runs, and the account trades the symbol it was measured on.</summary>
	[TestMethod]
	public async Task AFinishedCandidateReachesTheBroker()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		var deployment = await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		AreEqual(DeploymentStatuses.Running, deployment.Status);
		IsTrue(deployment.Volume > 0, "a deployment was started with nothing to trade.");

		IsNotNull(_broker.Started, "the broker was never asked to run anything.");
		AreEqual(deployment.Symbol, _broker.Started.Symbol, "the broker was pointed at a different symbol.");

		var frozen = await _dataset.GetManifestAsync(project, CancellationToken);

		IsTrue(frozen.Symbols.Contains(deployment.Symbol, StringComparer.Ordinal),
			$"it is trading '{deployment.Symbol}', which the project holds no data for.");

		var reopened = await _store.GetAsync(project, candidate, CancellationToken);

		AreEqual(CandidateStatuses.PaperRunning, reopened.Status, "the candidate does not say it is running.");
	}

	/// <summary>
	/// One at a time. Two strategies on one account hold each other's positions and neither result can be
	/// read afterwards.
	/// </summary>
	[TestMethod]
	public async Task ASecondDeploymentIsRefusedWhileOneRuns()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		var second = await ReadyAsync(CandidateStatuses.Completed, project);

		var refusal = await ThrowsAsync<InvalidOperationException>(
			() => _service.StartAsync(project, second.Candidate, Actors.Agent, CancellationToken).AsTask());

		IsTrue(refusal.Message.Contains("already running", StringComparison.OrdinalIgnoreCase),
			$"the refusal does not say why: {refusal.Message}");
	}

	/// <summary>What the broker reports is what the deployment reports; nothing here is the strategy's own view.</summary>
	[TestMethod]
	public async Task WhatTheBrokerReportsIsWhatIsReported()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		var deployment = await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		_broker.Last.OrdersPlaced = 7;
		_broker.Last.Trades = 3;
		_broker.Last.RealizedProfit = 12.5m;
		_broker.Last.Position = 2m;

		var report = await _service.GetAsync(project, deployment.Id, CancellationToken);

		AreEqual(7, report.Deployment.OrdersPlaced);
		AreEqual(3, report.Deployment.Trades);
		AreEqual(12.5m, report.Deployment.RealizedProfit);
		AreEqual(2m, report.Deployment.Position);
	}

	/// <summary>Stopping says what to do with the position, and the broker is told exactly that.</summary>
	[TestMethod]
	public async Task StoppingCarriesTheDecisionAboutThePosition()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		var deployment = await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		_broker.Last.Position = 5m;

		var stopped = await _service.StopAsync(project, deployment.Id, closePosition: true, Actors.Agent, CancellationToken);

		AreEqual(DeploymentStatuses.Stopped, stopped.Status);
		IsTrue(_broker.Last.WasStopped, "the broker was never told to stop.");
		IsTrue(_broker.Last.WasAskedToClose, "the position was left open despite being told to close it.");

		var reopened = await _store.GetAsync(project, candidate, CancellationToken);

		AreEqual(CandidateStatuses.Stopped, reopened.Status);
	}

	/// <summary>
	/// A strategy that stopped by itself is reported as failed rather than as running, and carries the
	/// reason. A caller told it is running will not look, and it is not.
	/// </summary>
	[TestMethod]
	public async Task AStrategyThatStoppedItselfSaysSo()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		var deployment = await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		_broker.Last.IsRunning = false;
		_broker.Last.Error = "the venue rejected every order";

		var report = await _service.GetAsync(project, deployment.Id, CancellationToken);

		AreEqual(DeploymentStatuses.Failed, report.Deployment.Status);
		AreEqual("the venue rejected every order", report.Deployment.Note);
	}

	/// <summary>
	/// A deployment recorded as running by a server that no longer exists is reported as interrupted, so
	/// nobody is told a strategy is trading when nothing is.
	/// </summary>
	[TestMethod]
	public async Task ADeploymentLeftByADeadServerIsInterrupted()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		var deployment = await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		var report = await Restarted().GetAsync(project, deployment.Id, CancellationToken);

		AreEqual(DeploymentStatuses.Interrupted, report.EffectiveStatus);
		IsFalse(report.SessionLive, "a deployment with no session behind it was reported as live.");
	}

	/// <summary>
	/// Reading does not stop anything. What the row says is what the server that wrote it said; a reader
	/// that rewrote it would be deciding, on its own, that the deployment is over.
	/// </summary>
	/// <remarks>
	/// It also destroyed the only path out. The read wrote Interrupted, stop_deployment then returned
	/// early because the row was no longer Running, and the candidate was left at PaperRunning for good:
	/// it could not be stopped, could not be redeployed, and the tool the refusal pointed at refused it
	/// too. Whether a deployment is over is decided by stopping it.
	/// </remarks>
	[TestMethod]
	public async Task ReadingADeploymentDoesNotEndIt()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		var deployment = await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		var restarted = Restarted();

		await restarted.GetAsync(project, deployment.Id, CancellationToken);
		await restarted.ListAsync(project, CancellationToken);

		var stored = await _store.GetAsync(project, deployment.Id, CancellationToken);

		AreEqual(DeploymentStatuses.Running, stored.Status,
			"reading the deployment wrote to it.");

		var built = await _store.GetAsync(project, candidate, CancellationToken);

		AreEqual(CandidateStatuses.PaperRunning, built.Status);
	}

	/// <summary>
	/// Stopping what a dead server left behind still ends it properly: the row becomes terminal, the
	/// candidate is released, and the permanent record says it happened.
	/// </summary>
	[TestMethod]
	public async Task StoppingAfterTheServerWentAwayReleasesTheCandidate()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		var deployment = await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		var restarted = Restarted();

		// The order a person actually takes: look first, then stop.
		await restarted.ListAsync(project, CancellationToken);

		var stopped = await restarted.StopAsync(project, deployment.Id, closePosition: false, Actors.Agent, CancellationToken);

		AreEqual(DeploymentStatuses.Interrupted, stopped.Status);

		var built = await _store.GetAsync(project, candidate, CancellationToken);

		AreEqual(CandidateStatuses.Stopped, built.Status,
			"the candidate was left running on paper although its deployment is over.");

		var audited = await _store.ReadAsync(project, CancellationToken);

		IsTrue(audited.Any(e => e.Type == AuditEventTypes.PaperStopped),
			"nothing in the permanent record says the deployment ended.");
	}

	/// <summary>
	/// What the deployment did is measured over the time it was watched, not over the time the server
	/// was away.
	/// </summary>
	/// <remarks>
	/// Elapsed ran to the moment somebody happened to look, so a deployment that traded five times in
	/// half an hour and was found the next morning reported a rate over twenty-four hours. That is the
	/// one comparison this report exists to make - what it does against what was measured of it - and it
	/// was off by whatever the outage lasted.
	/// </remarks>
	[TestMethod]
	public async Task TheRateIsMeasuredOverTheTimeItWasWatched()
	{
		var (project, candidate) = await ReadyAsync(CandidateStatuses.Completed);

		var deployment = await _service.StartAsync(project, candidate, Actors.Agent, CancellationToken);

		_broker.Last.Trades = 5;

		// Watched for a while, and then the server goes away.
		await _service.GetAsync(project, deployment.Id, CancellationToken);

		var watched = await _store.GetAsync(project, deployment.Id, CancellationToken);

		IsNotNull(watched.LastObservedAt, "nothing recorded when the deployment was last watched.");

		// Backdated: the deployment ran for an hour and nobody has looked since.
		await _store.UpdateAsync(project, watched with
		{
			StartedAt = watched.StartedAt.AddHours(-25),
			LastObservedAt = watched.StartedAt.AddHours(-24),
		}, CancellationToken);

		var report = await Restarted().GetAsync(project, deployment.Id, CancellationToken);

		IsTrue(report.TradingDays < 0.2m,
			$"the rate was measured over {report.TradingDays:F2} trading days, which is the outage rather " +
			"than the time anybody watched it.");
	}

	// A new service over the same storage is what a restarted server amounts to.
	private DeploymentService Restarted()
		=> new(_store, _store, _specs, _datasets, _artifacts, _store, _store, _broker, _store, new SystemClock());

	private async Task<(ProjectId Project, CandidateId Candidate)> ReadyAsync(
		CandidateStatuses status = CandidateStatuses.Compiled,
		ProjectId project = default)
	{
		if (project.IsEmpty)
		{
			var created = await _projects.CreateProjectAsync("paper", Guid.NewGuid().ToString("n"), Actors.User, CancellationToken);

			project = created.Id;

			await _dataset.ImportDemoAsync(project, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken);
		}

		var spec = await _specs.AddAsync(project, Spec(Guid.NewGuid().ToString("n")[..8]), Actors.Agent, DateTime.UtcNow, CancellationToken);

		var built = await _candidates.BuildAsync(project, spec.Id, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken);

		// The lifecycle refuses a jump, so a candidate that is to arrive at a later stage walks there.
		if (status != CandidateStatuses.Compiled)
		{
			CandidateStatuses[] road =
			[
				CandidateStatuses.Backtested,
				CandidateStatuses.Validated,
				CandidateStatuses.StressTested,
				CandidateStatuses.FinalChecked,
				status,
			];

			foreach (var stage in road)
			{
				built = built.WithStatus(stage, DateTime.UtcNow);

				await _store.UpdateAsync(project, built, CancellationToken);
			}
		}

		return (project, built.Id);
	}

	// A distinct name each time, so two calls produce two candidates rather than one twice.
	private static string Spec(string name)
		=> $$"""
		{
		  "name": "Above its average {{{name}}}",
		  "thesis": "A price above its own recent average keeps going for a few bars.",
		  "allowLong": true,
		  "allowShort": false,
		  "timeFrame": "00:05:00",
		  "warmupBars": 45,
		  "entries": [
		    { "id": "e1", "direction": "Long", "condition": {
		        "kind": "Compare",
		        "left": { "kind": "Field", "field": "Close" },
		        "operator": "GreaterThan",
		        "right": { "kind": "Indicator", "name": "sma", "length": { "kind": "Constant", "value": 20 }, "source": "Close" } } }
		  ],
		  "exits": [ { "id": "x1", "kind": "TimeExit", "direction": "Long", "length": { "kind": "Constant", "value": 5 } } ],
		  "parameters": [],
		  "risk": { "maxPositionPercent": 0.10, "maxDailyLossPercent": 0.02 }
		}
		""";
}
