namespace Odysseus.Application.Tests;

using System;
using System.IO;
using System.Linq;
using System.Text.Json;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Domain;
using Odysseus.TestKit;

/// <summary>
/// What an agent is told when a call fails.
/// </summary>
/// <remarks>
/// These assertions are deliberately about the text. The message is not a log line, it is the next
/// prompt: an agent told only that something went wrong has nothing to aim at and burns its remaining
/// attempts guessing. So the tests check that a refusal names what was wrong and what a correct value
/// would look like, not merely that a refusal happened.
/// </remarks>
[TestClass]
public class ToolErrorTests : OdysseusTestBase
{
	private const string Correlation = "abc123";

	/// <summary>
	/// The category vocabulary is published, and an agent branches on it. A value that exists on one
	/// side only is either a branch that never runs or a message nobody can interpret.
	/// </summary>
	[TestMethod]
	public void CategoriesMatchThePublishedContract()
	{
		var schema = Path.Combine(RepositoryRoot, "schemas", "error.schema.json");

		using var document = JsonDocument.Parse(File.ReadAllText(schema));

		var published = document.RootElement
			.GetProperty("properties")
			.GetProperty("category")
			.GetProperty("enum")
			.EnumerateArray()
			.Select(v => v.GetString())
			.ToArray();

		var declared = Enum.GetNames<ToolErrorCategories>();

		CollectionAssert.AreEquivalent(published, declared,
			"the error categories of the contract and of the code have drifted apart.");
	}

	/// <summary>
	/// A refused specification arrives as a category of its own, with every problem and a pointer at the
	/// tool that reports the same list for free.
	/// </summary>
	[TestMethod]
	public void ARefusedSpecificationListsEveryProblem()
	{
		var described = ToolErrors.Describe(
			new InvalidSpecException(
			[
				new Odysseus.Spec.SpecProblem("entries.e1.condition", "refers to 'Undeclared'", "declare it"),
				new Odysseus.Spec.SpecProblem("exits", "never closes a position", "add an exit"),
			]),
			Correlation);

		AreEqual(ToolErrorCategories.SpecValidation, described.Category);

		IsTrue(described.Message.Contains("entries.e1.condition", StringComparison.Ordinal),
			"the place of each problem must survive the mapping.");

		IsTrue(described.Message.Contains("exits", StringComparison.Ordinal),
			"every problem must survive, not only the first: a caller should fix them in one attempt.");

		IsTrue(described.Remediation.Contains("validate_spec", StringComparison.Ordinal),
			"the caller must be pointed at the tool that reports the same list without recording anything.");
	}

	/// <summary>
	/// Source that will not compile is our defect, not the caller's, and the answer has to say so along
	/// with the code that failed.
	/// </summary>
	/// <remarks>
	/// The agent never wrote this C#; the translator did. Reported as an unspecified internal failure it
	/// reads as something to retry, and there is nothing to retry — the same specification will emit the
	/// same broken source forever. What the agent can do is report it, so the answer carries the compiler
	/// identifier, the line and the text, and says whose fault it is.
	/// </remarks>
	[TestMethod]
	public void SourceThatWillNotCompileNamesTheCodeAndTheCulprit()
	{
		var described = ToolErrors.Describe(
			new StrategyBuildException(
			[
				new BuildProblem("CS0103", "The name 'Atr' does not exist in the current context", 42),
				new BuildProblem("CS1002", "; expected", 57),
			]),
			Correlation);

		AreEqual(ToolErrorCategories.CompilationFailed, described.Category);

		IsTrue(described.Message.Contains("CS0103", StringComparison.Ordinal) &&
			described.Message.Contains("CS1002", StringComparison.Ordinal),
			$"every diagnostic must survive the mapping: {described.Message}");

		IsTrue(described.Message.Contains("42", StringComparison.Ordinal),
			$"the line of the generated source must survive: {described.Message}");

		IsTrue(described.Remediation.Contains(Correlation, StringComparison.Ordinal),
			"a defect of ours needs the correlation id to be reportable.");

		IsTrue(described.Remediation.Contains("translator", StringComparison.Ordinal),
			$"the caller must be told it did not write this code: {described.Remediation}");
	}

	/// <summary>
	/// A rule of our own that the generated code broke is reported apart from a compiler error, because
	/// they are read differently: one is code that cannot run, the other is code that must not.
	/// </summary>
	[TestMethod]
	public void ABrokenAnalyzerRuleIsNotACompilerError()
	{
		var described = ToolErrors.Describe(
			new StrategyBuildException([new BuildProblem("ODSTR0004", "A strategy may not read the clock", 12)]),
			Correlation);

		AreEqual(ToolErrorCategories.AnalyzerViolation, described.Category);

		IsTrue(described.Message.Contains("ODSTR0004", StringComparison.Ordinal),
			$"the rule that was broken must survive: {described.Message}");
	}

	/// <summary>
	/// Asking for something that needs a broker on a server started without one is a configuration
	/// answer, not a defect and not a bad request.
	/// </summary>
	[TestMethod]
	public void AMissingBrokerIsAConfigurationAnswer()
	{
		var described = ToolErrors.Describe(
			new BrokerNotConfiguredException("Downloading history"), Correlation);

		AreEqual(ToolErrorCategories.ConfigurationInvalid, described.Category);

		IsTrue(described.Message.Contains("broker account", StringComparison.Ordinal),
			$"the answer must say what is missing: {described.Message}");

		IsTrue(described.Remediation.Contains("ODYSSEUS_ALPACA_KEYS", StringComparison.Ordinal),
			$"the answer must say how to supply it: {described.Remediation}");
		IsTrue(described.Remediation.Contains("ODYSSEUS_BINANCE_KEYS", StringComparison.Ordinal),
			$"the answer must say how to supply Binance Testnet: {described.Remediation}");

		IsTrue(described.Remediation.Contains("import_demo_dataset", StringComparison.Ordinal),
			$"the caller must be told what it can still do without an account: {described.Remediation}");
	}

	/// <summary>
	/// Every failure this product raises on purpose is answered on purpose. Anything left unmapped falls
	/// through to Internal and reads as a defect of the server, which sends an agent to report a bug when
	/// what it actually did was ask for something that is not there.
	/// </summary>
	/// <remarks>
	/// The reflection half is what keeps this true. Three of these had been declared, thrown and never
	/// mapped, and nothing said so: each one only looked wrong from the far end of a tool call.
	/// </remarks>
	[TestMethod]
	public void EveryFailureWeRaiseOnPurposeIsAnsweredOnPurpose()
	{
		Exception[] ours =
		[
			new ProjectNotFoundException(ProjectId.New()),
			new SpecNotFoundException(SpecId.New()),
			new DatasetNotFoundException(DatasetVersionId.New()),
			new CandidateNotFoundException(CandidateId.New()),
			new RunNotFoundException(RunId.New()),
			new DeploymentNotFoundException(DeploymentId.New()),
			new ArtifactNotFoundException(ArtifactId.FromContent("x"u8)),
			new ArtifactCorruptedException(ArtifactId.FromContent("x"u8), "deadbeef"),
			new InvalidSpecException([new Odysseus.Spec.SpecProblem("where", "what", "fix")]),
			new ResearchBudgetExhaustedException("spent"),
			new StrategyBuildException([new BuildProblem("CS0103", "no such name", 3)]),
			new BrokerNotConfiguredException("Downloading history"),
		];

		foreach (var failure in ours)
		{
			var described = ToolErrors.Describe(failure, Correlation);

			AreNotEqual(ToolErrorCategories.Internal, described.Category,
				$"{failure.GetType().Name} is reported as a defect of the server rather than as what it is.");

			IsFalse(string.IsNullOrWhiteSpace(described.Remediation),
				$"{failure.GetType().Name} is answered without saying what to do next.");
		}

		// The list above has to keep up with the code. An exception type we declare and forget to map is
		// exactly the defect this test exists for, so the two are compared rather than trusted.
		var declared = typeof(ToolErrors).Assembly
			.GetTypes()
			.Where(type => type.IsSubclassOf(typeof(Exception)) && type.IsPublic)
			.Select(type => type.Name)
			.OrderBy(name => name, StringComparer.Ordinal)
			.ToArray();

		var covered = ours.Select(f => f.GetType().Name).Distinct().ToArray();

		var missed = declared.Except(covered, StringComparer.Ordinal).ToArray();

		AreEqual(0, missed.Length,
			$"declared but never checked against the error contract: {string.Join(", ", missed)}.");
	}

	/// <summary>A missing project says how to find one that exists.</summary>
	[TestMethod]
	public void MissingProjectPointsAtHowToFindOne()
	{
		var described = ToolErrors.Describe(new ProjectNotFoundException(ProjectId.New()), Correlation);

		AreEqual(ToolErrorCategories.NotFound, described.Category);
		IsTrue(described.Remediation.Contains("list_projects", StringComparison.Ordinal),
			"the remediation must name the tool that produces a valid identifier.");
	}

	/// <summary>A malformed argument keeps the message that says what a correct one looks like.</summary>
	[TestMethod]
	public void MalformedArgumentKeepsItsExplanation()
	{
		var described = ToolErrors.Describe(
			new ArgumentException("'not-an-id' is not a project identifier. Identifiers start with 'prj_'."),
			Correlation);

		AreEqual(ToolErrorCategories.InvalidRequest, described.Category);
		IsTrue(described.Message.Contains("prj_", StringComparison.Ordinal),
			"the explanation of what a correct value looks like must survive the mapping.");
	}

	/// <summary>A corrupted artifact says what it means for results that reference it.</summary>
	[TestMethod]
	public void CorruptionExplainsTheConsequence()
	{
		var described = ToolErrors.Describe(
			new ArtifactCorruptedException(ArtifactId.FromContent("x"u8), "deadbeef"),
			Correlation);

		AreEqual(ToolErrorCategories.IntegrityViolation, described.Category);
		IsTrue(described.Remediation.Contains("reproduced", StringComparison.Ordinal),
			"the caller must be told that results referencing the artifact are no longer reproducible.");
	}

	/// <summary>
	/// An unexpected defect is ours, and its message stays in the log: it can carry a path or a value
	/// the caller has no business seeing.
	/// </summary>
	[TestMethod]
	public void UnexpectedFailuresRevealNothing()
	{
		var secret = @"C:\Users\someone\projects\private\key.txt";
		var described = ToolErrors.Describe(new IOException($"could not read {secret}"), Correlation);

		AreEqual(ToolErrorCategories.Internal, described.Category);
		IsFalse(described.Message.Contains(secret, StringComparison.Ordinal),
			"an internal failure must not leak the machine's contents to the caller.");
		IsFalse(described.Remediation.Contains(secret, StringComparison.Ordinal));
		IsTrue(described.Remediation.Contains(Correlation, StringComparison.Ordinal),
			"the caller needs the correlation id to report the defect.");
	}

	/// <summary>
	/// Spending the allowance is a refusal, not a defect. Reported as a server fault it reads as
	/// something to retry, and an agent that retries a ceiling burns whatever is left of it.
	/// </summary>
	[TestMethod]
	public void SpendingTheAllowanceIsNotADefect()
	{
		var described = ToolErrors.Describe(
			new ResearchBudgetExhaustedException("A search evaluates up to 50 settings and this project has 12 left."),
			Correlation);

		AreEqual(ToolErrorCategories.BudgetExhausted, described.Category);

		IsTrue(described.Message.Contains("50 settings", StringComparison.Ordinal),
			"the refusal must carry the numbers behind it.");

		IsTrue(described.Remediation.Contains("ceiling", StringComparison.Ordinal),
			$"the caller must be told the limit will not move: {described.Remediation}");
	}

	/// <summary>Cancellation is not a defect and must not read like one.</summary>
	[TestMethod]
	public void CancellationIsNotADefect()
	{
		var described = ToolErrors.Describe(new OperationCanceledException(), Correlation);

		AreEqual(ToolErrorCategories.Cancelled, described.Category);
		IsTrue(described.Remediation.Contains("half-written", StringComparison.Ordinal),
			"the caller must be told nothing was left in an intermediate state.");
	}

	/// <summary>Every failure carries the identifier that ties it to the server logs.</summary>
	[TestMethod]
	public void EveryFailureCarriesACorrelationId()
	{
		Exception[] failures =
		[
			new ProjectNotFoundException(ProjectId.New()),
			new ArgumentException("bad"),
			new InvalidOperationException("wrong state"),
			new OperationCanceledException(),
			new IOException("disk"),
		];

		foreach (var failure in failures)
			AreEqual(Correlation, ToolErrors.Describe(failure, Correlation).CorrelationId);
	}
}
