namespace Odysseus.Application.Tests;

using System;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.TestKit;

/// <summary>Market assumptions follow the dataset source.</summary>
[TestClass]
public class BrokerVenueTests : OdysseusTestBase
{
	/// <summary>Binance data uses UTC, fractional quantities, and percentage costs.</summary>
	[TestMethod]
	public void BinanceConventionsAreExplicit()
	{
		var venue = BrokerVenue.ForSource("binance-spot");

		AreEqual(BrokerKinds.Binance, venue.Kind);
		AreEqual("UTC", venue.TimeZoneId);
		IsTrue(venue.VolumeStep < 1m);
		AreEqual(0.15m, venue.Costs.Percent);
	}

	/// <summary>Binance Spot does not pretend a short order can be executed.</summary>
	[TestMethod]
	public void SpotRefusesShortStrategies()
		=> Throws<InvalidOperationException>(() => BrokerVenue.Binance.EnsureStrategySupported(allowsShort: true));

	/// <summary>Existing demo datasets retain the established equity assumptions.</summary>
	[TestMethod]
	public void DemoRemainsAnEquityVenue()
		=> AreEqual(BrokerKinds.Alpaca, BrokerVenue.ForSource("demo").Kind);
}
