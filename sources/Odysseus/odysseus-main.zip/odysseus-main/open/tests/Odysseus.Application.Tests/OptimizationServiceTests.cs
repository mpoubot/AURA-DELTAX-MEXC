namespace Odysseus.Application.Tests;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Domain;
using Odysseus.Persistence;
using Odysseus.Spec;
using Odysseus.TestKit;

/// <summary>
/// What a search costs, and what asking for the same one twice costs.
/// </summary>
/// <remarks>
/// A search is the most expensive thing an agent can ask this server for: it claims the whole ceiling
/// of what it could evaluate before it starts, because an abandoned search would otherwise be free. That
/// makes the retry the dangerous case. Every other tool answers a repeated operation key from the first
/// result; this one declared the log, assigned it and never called it, so a client that timed out and
/// asked again bought a second search out of the same allowance and neither answer said so.
/// </remarks>
[TestClass]
public class OptimizationServiceTests : OdysseusTestBase
{
	private static readonly DateTime _open = new(2026, 3, 2, 14, 30, 0, DateTimeKind.Utc);

	/// <summary>A builder that hands back something assembly-shaped, since nothing here runs it.</summary>
	private sealed class Builder : IStrategyBuilder
	{
		public BuiltStrategy Build(StrategySpec spec)
			=> new("Generated", $"// source of {spec.Name}", $"source-{spec.Name}", [1, 2, 3], $"assembly-{spec.Name}", "1.0.0");
	}

	/// <summary>A runner that reports the same modest run whatever it is handed.</summary>
	private sealed class Runner : IBacktestRunner
	{
		public Task<BacktestOutcome> RunAsync(BacktestRequest request, CancellationToken cancellationToken)
		{
			var trades = new List<ExecutedTrade>();
			var equity = new List<EquityPoint>();
			var money = 100_000m;

			for (var i = 0; i < 20; i++)
			{
				var entry = request.Bars[0].OpenTime.AddHours(i);

				trades.Add(new($"t{i}", request.Symbol, TradeDirections.Long, entry, 100m, entry.AddMinutes(25),
					101m, 10m, 0.5m, 0.5m));

				money += 10m;
				equity.Add(new(entry.AddMinutes(25), money));
			}

			return Task.FromResult(new BacktestOutcome(trades, equity, request.Bars.Count, 0, 40));
		}
	}

	/// <summary>A search that reports a fixed table and counts how often it was asked.</summary>
	private sealed class Optimizer : IStrategyOptimizer
	{
		public int Searches { get; private set; }

		public Task<IReadOnlyList<OptimizationTrial>> SearchAsync(
			OptimizationRequest request,
			CancellationToken cancellationToken)
		{
			Searches++;

			IReadOnlyList<OptimizationTrial> trials =
			[
				new(new Dictionary<string, decimal>(StringComparer.Ordinal) { ["length"] = 20m }, 3m, 300m, 1m, 40),
				new(new Dictionary<string, decimal>(StringComparer.Ordinal) { ["length"] = 30m }, 1m, 100m, 2m, 30),
			];

			return Task.FromResult(trials);
		}
	}

	private string _root;
	private SqliteProjectStore _store;
	private SqliteOperationLog _operations;
	private FileArtifactStore _artifacts;
	private FileDatasetStore _datasets;
	private FileSpecStore _specs;
	private Optimizer _optimizer;
	private ProjectService _projects;
	private CandidateService _candidates;
	private OptimizationService _service;

	/// <summary>Builds the services over temporary storage.</summary>
	[TestInitialize]
	public void CreateService()
	{
		_root = Path.Combine(Path.GetTempPath(), "odysseus-tests", Guid.NewGuid().ToString("n"));
		_store = new SqliteProjectStore(_root);
		_operations = new SqliteOperationLog(_root);
		_artifacts = new FileArtifactStore(_root);
		_datasets = new FileDatasetStore(_root, _artifacts);
		_specs = new FileSpecStore(_root);
		_optimizer = new Optimizer();

		var clock = new SystemClock();
		var budget = new ResearchBudget(400, 5, TimeSpan.FromMinutes(45)).ToState();

		_projects = new ProjectService(_store, _store, _operations, clock, ServerModes.Local, budget);
		_candidates = new CandidateService(_store, _specs, _store, _artifacts, new Builder(), _store, _operations, clock);

		var backtests = new BacktestService(
			_store, _store, _specs, _datasets, _store, _artifacts, new Runner(), _store, _operations, clock);

		_service = new OptimizationService(
			_store, _store, _specs, _datasets, _artifacts, _optimizer, backtests, _store, _operations, clock);
	}

	/// <summary>Releases storage.</summary>
	[TestCleanup]
	public void DeleteService()
	{
		_store?.Dispose();
		_operations?.Dispose();

		if (Directory.Exists(_root))
			Directory.Delete(_root, recursive: true);
	}

	/// <summary>The same request twice is one search and one charge.</summary>
	[TestMethod]
	public async Task TheSameRequestTwiceIsOneSearch()
	{
		var (project, candidate) = await ReadyAsync();

		var key = Guid.NewGuid().ToString("n");

		var first = await _service.SearchAsync(project, candidate, "NVDA", 7, key, Actors.Agent, CancellationToken);

		var spent = await SpentAsync(project);

		var second = await _service.SearchAsync(project, candidate, "NVDA", 7, key, Actors.Agent, CancellationToken);

		AreEqual(1, _optimizer.Searches, "the repeated request bought a second search.");
		AreEqual(spent, await SpentAsync(project), "the repeated request was charged again.");

		IsFalse(first.WasAlreadySearched);
		IsTrue(second.WasAlreadySearched, "the replay does not say that it is one.");

		AreEqual(first.Run.Id, second.Run.Id, "the replay points at a different run than the search it repeats.");
	}

	/// <summary>A different key is a different search and is charged as one.</summary>
	[TestMethod]
	public async Task ADifferentRequestIsChargedAgain()
	{
		var (project, candidate) = await ReadyAsync();

		await _service.SearchAsync(
			project, candidate, "NVDA", 7, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken);

		var spent = await SpentAsync(project);

		await _service.SearchAsync(
			project, candidate, "NVDA", 8, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken);

		AreEqual(2, _optimizer.Searches);
		IsTrue(await SpentAsync(project) > spent, "a second search was not charged.");
	}

	private async Task<int> SpentAsync(ProjectId project)
	{
		var existing = await _store.OpenAsync(project, CancellationToken);
		var budget = ResearchBudget.Restore(existing.Budget);

		return existing.Budget.MaxBacktests - budget.RemainingBacktests;
	}

	private async Task<(ProjectId Project, CandidateId Candidate)> ReadyAsync()
	{
		var project = (await _projects.CreateProjectAsync(
			"search", Guid.NewGuid().ToString("n"), Actors.User, CancellationToken)).Id;

		var bars = new Dictionary<string, IReadOnlyList<Candle>> { ["NVDA"] = Bars() };
		var imported = DatasetBuilder.Build(bars, TimeSpan.FromMinutes(5), "test", isSynthetic: true);

		await _datasets.SaveAsync(project, imported, CancellationToken);

		var opened = await _store.OpenAsync(project, CancellationToken);

		await _store.UpdateAsync(opened.WithDataset(imported.Manifest.Id, DateTime.UtcNow), CancellationToken);

		var spec = await _specs.AddAsync(project, Spec(), Actors.Agent, DateTime.UtcNow, CancellationToken);

		var built = await _candidates.BuildAsync(
			project, spec.Id, Guid.NewGuid().ToString("n"), Actors.Agent, CancellationToken);

		return (project, built.Id);
	}

	private static IReadOnlyList<Candle> Bars()
	{
		var bars = new List<Candle>();
		var time = _open;

		for (var i = 0; i < 2_000; i++)
		{
			var wave = (decimal)Math.Sin(i * 2 * Math.PI / 60);
			var close = 100m + Math.Round(5m * wave, 2);
			var open = bars.Count == 0 ? close : bars[^1].Close;

			bars.Add(new(time, open, Math.Max(open, close) + 0.05m, Math.Min(open, close) - 0.05m, close, 10_000m));

			time = time.AddMinutes(5);

			if (time.TimeOfDay >= TimeSpan.FromHours(21))
				time = time.Date.AddDays(time.DayOfWeek == DayOfWeek.Friday ? 3 : 1).Add(_open.TimeOfDay);
		}

		return bars;
	}

	private static string Spec()
		=> $$"""
		{
		  "name": "Above its average {{Guid.NewGuid().ToString("n")[..8]}}",
		  "thesis": "A price above its own recent average keeps going for a few bars.",
		  "allowLong": true,
		  "allowShort": false,
		  "timeFrame": "00:05:00",
		  "warmupBars": 45,
		  "entries": [
		    { "id": "e1", "direction": "Long", "condition": {
		        "kind": "Compare",
		        "left": { "kind": "Field", "field": "Close" },
		        "operator": "GreaterThan",
		        "right": { "kind": "Indicator", "name": "sma", "length": { "kind": "Parameter", "name": "length" }, "source": "Close" } } }
		  ],
		  "exits": [ { "id": "x1", "kind": "TimeExit", "direction": "Long", "length": { "kind": "Constant", "value": 5 } } ],
		  "parameters": [ { "name": "length", "min": 10, "max": 40, "step": 5, "default": 20 } ],
		  "risk": { "maxPositionPercent": 0.10, "maxDailyLossPercent": 0.02 }
		}
		""";
}
