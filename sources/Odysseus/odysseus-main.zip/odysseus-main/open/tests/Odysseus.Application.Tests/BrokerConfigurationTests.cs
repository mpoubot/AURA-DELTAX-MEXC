namespace Odysseus.Application.Tests;

using System;
using System.IO;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.TestKit;

/// <summary>Broker selection and secret-file handling.</summary>
[TestClass]
public class BrokerConfigurationTests : OdysseusTestBase
{
	private string _directory;

	/// <summary>Creates an isolated directory for key files.</summary>
	[TestInitialize]
	public void CreateDirectory()
	{
		_directory = Path.Combine(Path.GetTempPath(), $"odysseus-broker-{Guid.NewGuid():N}");
		Directory.CreateDirectory(_directory);
	}

	/// <summary>Removes the isolated key files.</summary>
	[TestCleanup]
	public void RemoveDirectory()
	{
		if (Directory.Exists(_directory))
			Directory.Delete(_directory, recursive: true);
	}

	/// <summary>A single usable key file selects its broker without another setting.</summary>
	[TestMethod]
	public void OneBrokerIsInferred()
	{
		var path = KeyFile("binance.txt", "bin-key", "bin-secret");

		var credentials = BrokerCredentials.Read(null, null, path);

		AreEqual(BrokerKinds.Binance, credentials.Kind);
		AreEqual("bin-key", credentials.KeyId);
		AreEqual("bin-secret", credentials.Secret);
	}

	/// <summary>Two accounts are never resolved by an arbitrary precedence rule.</summary>
	[TestMethod]
	public void TwoBrokersNeedAnExplicitSelection()
	{
		var alpaca = KeyFile("alpaca.txt", "alpaca-key", "alpaca-secret");
		var binance = KeyFile("binance.txt", "binance-key", "binance-secret");

		var error = Throws<InvalidOperationException>(() => BrokerCredentials.Read(null, alpaca, binance));

		IsFalse(error.Message.Contains("alpaca-secret", StringComparison.Ordinal));
		IsFalse(error.Message.Contains("binance-secret", StringComparison.Ordinal));
	}

	/// <summary>An explicit selection reads only the requested account.</summary>
	[TestMethod]
	public void ExplicitSelectionWins()
	{
		var alpaca = KeyFile("alpaca.txt", "alpaca-key", "alpaca-secret");
		var binance = KeyFile("binance.txt", "binance-key", "binance-secret");

		var credentials = BrokerCredentials.Read("binance", alpaca, binance);

		AreEqual(BrokerKinds.Binance, credentials.Kind);
		AreEqual("binance-key", credentials.KeyId);
	}

	/// <summary>An unknown broker name is refused.</summary>
	[TestMethod]
	public void UnknownBrokerIsRefused()
		=> Throws<ArgumentException>(() => BrokerCredentials.Read("production", null, null));

	/// <summary>A numeric enum value cannot bypass the two published broker names.</summary>
	[TestMethod]
	public void NumericBrokerIsRefused()
		=> Throws<ArgumentException>(() => BrokerCredentials.Read("99", null, null));

	private string KeyFile(string name, string key, string secret)
	{
		var path = Path.Combine(_directory, name);
		File.WriteAllText(path, $"key: {key}{Environment.NewLine}secret: {secret}{Environment.NewLine}");
		return path;
	}
}
