namespace Odysseus.Application.Tests;

using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

using Waiting = System.Threading.Timeout;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Domain;
using Odysseus.Persistence;
using Odysseus.TestKit;

/// <summary>
/// Downloading history from a broker.
/// </summary>
/// <remarks>
/// A broker that answers slowly and a broker that never answers look the same from here. The second one
/// is the dangerous one: the agent that asked is left holding a call that will not return, with no error
/// to read and nothing to decide from, and the project it was working on cannot go on without it.
/// </remarks>
[TestClass]
public class HistoryServiceTests : OdysseusTestBase
{
	/// <summary>A source that accepts the request and then says nothing at all.</summary>
	private sealed class SilentSource : IHistorySource
	{
		public string Name => "silent";

		public async Task<IReadOnlyList<Candle>> GetBarsAsync(
			string symbol,
			TimeSpan timeFrame,
			DateTime from,
			DateTime to,
			CancellationToken cancellationToken)
		{
			await Task.Delay(Waiting.InfiniteTimeSpan, cancellationToken);
			throw new InvalidOperationException("unreachable");
		}
	}

	private string _root;
	private SqliteProjectStore _store;
	private SqliteOperationLog _operations;
	private FileDatasetStore _datasets;
	private ProjectService _projects;

	/// <summary>Builds the services over temporary storage.</summary>
	[TestInitialize]
	public void CreateService()
	{
		_root = Path.Combine(Path.GetTempPath(), "odysseus-tests", Guid.NewGuid().ToString("n"));
		_store = new SqliteProjectStore(_root);
		_operations = new SqliteOperationLog(_root);
		_datasets = new FileDatasetStore(_root, new FileArtifactStore(_root));

		var budget = new ResearchBudget(60, 40, TimeSpan.FromMinutes(45)).ToState();

		_projects = new ProjectService(_store, _store, _operations, new SystemClock(), ServerModes.Local, budget);
	}

	/// <summary>Releases storage.</summary>
	[TestCleanup]
	public void DeleteService()
	{
		_store?.Dispose();
		_operations?.Dispose();

		if (Directory.Exists(_root))
			Directory.Delete(_root, recursive: true);
	}

	/// <summary>A broker that goes quiet ends the import with an error rather than never ending it.</summary>
	[TestMethod]
	public async Task ADownloadThatNeverAnswersGivesUp()
	{
		var project = await _projects.CreateProjectAsync("silent broker", "new-1", Actors.Agent, CancellationToken);

		var service = new HistoryService(
			_store,
			_datasets,
			new SilentSource(),
			_store,
			_operations,
			new SystemClock())
		{
			Patience = TimeSpan.FromSeconds(2),
		};

		var refusal = await ThrowsAsync<TimeoutException>(() => service.ImportAsync(
			project.Id,
			["NVDA"],
			TimeSpan.FromMinutes(5),
			new(2026, 5, 1, 0, 0, 0, DateTimeKind.Utc),
			new(2026, 8, 1, 0, 0, 0, DateTimeKind.Utc),
			"import-1",
			Actors.Agent,
			CancellationToken).AsTask());

		IsTrue(refusal.Message.Contains("NVDA", StringComparison.Ordinal),
			$"the refusal does not say which symbol went quiet: {refusal.Message}");
	}
}
