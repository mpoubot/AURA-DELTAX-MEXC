namespace Odysseus.Engine.Tests;

using System;
using System.Linq;
using System.Reflection;

using Ecng.Common;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using StockSharp.Binance;
using StockSharp.Messages;

using Odysseus.Application;
using Odysseus.Engine;
using Odysseus.TestKit;

/// <summary>Safety invariants of the Binance connector.</summary>
[TestClass]
public class BinanceConnectorTests : OdysseusTestBase
{
	/// <summary>Trading is pinned to Spot Testnet and cannot be switched to production.</summary>
	[TestMethod]
	public void PaperTradingUsesSpotTestnet()
	{
		var trader = new BinancePaperTrader("test-key", "test-secret");
		var factory = typeof(BinancePaperTrader).GetMethod(
			"CreateAdapter",
			BindingFlags.Instance | BindingFlags.NonPublic);

		using var adapter = (BinanceMessageAdapter)factory.Invoke(trader, [new IncrementalIdGenerator()]);

		IsTrue(adapter.IsDemo, "the paper trader is not pinned to the testnet endpoint.");
		AreEqual(1, adapter.Sections.Count());
		IsTrue(adapter.Sections.Contains(BinanceSections.Spot));
	}

	/// <summary>Crypto emulation uses the Binance board and fractional quantity step.</summary>
	[TestMethod]
	public void CryptoSecurityCarriesVenueConventions()
	{
		var security = EmulationSetup.CreateSecurity("BTCUSDT", BrokerVenue.Binance.PriceStep, BrokerVenue.Binance);

		AreEqual(BrokerVenue.Binance.BoardCode, security.Board.Code);
		AreEqual(SecurityTypes.CryptoCurrency, security.Type);
		AreEqual(BrokerVenue.Binance.VolumeStep, security.VolumeStep.Value);
	}

	/// <summary>The source name becomes the dataset's venue marker.</summary>
	[TestMethod]
	public void HistorySourceNamesSpot()
		=> AreEqual("binance-spot", new BinanceHistorySource("test-key", "test-secret").Name);
}
