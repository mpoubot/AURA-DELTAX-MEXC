namespace Odysseus.Engine.Tests;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Engine;
using Odysseus.TestKit;

/// <summary>
/// Which market a named symbol is fetched from.
/// </summary>
/// <remarks>
/// The server is a routine executor: it is handed a symbol and gets its history. What that symbol is —
/// a share, a listed contract — is the caller's business, and needs no telling, because the name itself
/// says which market answers for it. These checks need no broker, which is why they are not in the
/// suite that does.
/// </remarks>
[TestClass]
public class SymbolMarketTests : OdysseusTestBase
{
	/// <summary>
	/// The caller names a symbol and the source follows it. A share and a listed contract are quoted on
	/// different markets, and which one a name belongs to is readable from the name itself — so nothing
	/// has to be told, configured or asked.
	/// </summary>
	[TestMethod]
	[DataRow("NVDA", "NASDAQ")]
	[DataRow("AAPL", "NASDAQ")]
	[DataRow("BRK.B", "NASDAQ")]
	[DataRow("NVDA260828C00050000", "OPRA")]
	[DataRow("SPY250613P00700000", "OPRA")]
	[DataRow("A240119C00100000", "OPRA")]
	public void TheMarketFollowsTheSymbol(string symbol, string board)
		=> AreEqual(board, AlpacaHistorySource.BoardOf(symbol));


	/// <summary>
	/// A name that merely ends in digits is still a share. Read too loosely, an ordinary ticker would be
	/// sent to the option tape and come back empty for no stated reason.
	/// </summary>
	[TestMethod]
	[DataRow("BRK260828X00050000")]
	[DataRow("NVDA26082C00050000")]
	[DataRow("C00050000")]
	public void ANameThatOnlyLooksLikeAContractIsNotOne(string symbol)
		=> AreEqual("NASDAQ", AlpacaHistorySource.BoardOf(symbol));
}
