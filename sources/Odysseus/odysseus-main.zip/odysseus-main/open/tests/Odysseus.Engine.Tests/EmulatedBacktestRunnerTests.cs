namespace Odysseus.Engine.Tests;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Compiler;
using Odysseus.Domain;
using Odysseus.Evaluation;
using Odysseus.Spec;
using Odysseus.TestKit;

/// <summary>
/// Running a generated strategy through the market emulator.
/// </summary>
/// <remarks>
/// This is the only place where the whole chain is exercised at once: a specification becomes C#,
/// the C# becomes an assembly, the assembly becomes a strategy the engine drives over bars, and what
/// comes back becomes trades and an account value. Everything upstream can be right while this is
/// wrong, and the failure would look like a strategy that simply never traded.
///
/// The bars are made rather than downloaded, and made so the answer is known: a price that walks up
/// and back down on a fixed period crosses its own average a countable number of times.
/// </remarks>
[TestClass]
public class EmulatedBacktestRunnerTests : OdysseusTestBase
{
	private static readonly DateTime _open = new(2026, 3, 2, 14, 0, 0, DateTimeKind.Utc);

	private static BacktestRequest Request(StrategySpec spec, IReadOnlyList<Candle> bars, ExecutionCosts costs)
	{
		var built = new StrategyBuilder(EngineAssemblies.Paths()).Build(spec);

		return new(
			built.Assembly,
			built.ClassName,
			new Dictionary<string, decimal>(StringComparer.Ordinal),
			"DEMO",
			TimeSpan.FromMinutes(5),
			bars,
			StartingEquity: 100_000m,
			Volume: 10m,
			PriceStep: 0.01m,
			costs);
	}

	/// <summary>
	/// A strategy whose rules are met really trades, and what it did comes back as trades rather than
	/// as a number nobody can look into.
	/// </summary>
	[TestMethod]
	public async Task AStrategyWhoseRulesAreMetTrades()
	{
		var outcome = await new EmulatedBacktestRunner().RunAsync(
			Request(Oscillating(), Waves(600), ExecutionCosts.Default),
			CancellationToken);

		IsTrue(outcome.BarsProcessed > 500, $"the strategy saw only {outcome.BarsProcessed} of 600 bars.");
		IsTrue(outcome.Trades.Count > 0, "the rules were met repeatedly and the strategy never traded.");
		AreEqual(0, outcome.ExecutionErrorCount, "orders were refused during the run.");

		foreach (var trade in outcome.Trades)
		{
			AreEqual(TradeDirections.Long, trade.Direction);
			AreEqual(10m, trade.Volume);
			IsTrue(trade.ExitTime > trade.EntryTime, "a trade closed before it opened.");
		}
	}

	/// <summary>
	/// Nothing fills on the bar the decision was made on. A market order sent after a candle closed can
	/// only be filled by what came after it, and a run that filled on the closing bar would be reading a
	/// price it already knew — which is the one flaw that makes every other number here worthless.
	/// </summary>
	[TestMethod]
	public async Task NothingFillsOnTheBarTheDecisionWasMadeOn()
	{
		var bars = Waves(600);

		var outcome = await new EmulatedBacktestRunner().RunAsync(
			Request(Oscillating(), bars, ExecutionCosts.Default),
			CancellationToken);

		IsTrue(outcome.Trades.Count > 0);

		foreach (var trade in outcome.Trades)
		{
			var decision = bars.Last(b => b.OpenTime < trade.EntryTime);
			var fillBar = bars.First(b => b.OpenTime >= trade.EntryTime);

			IsTrue(fillBar.OpenTime > decision.OpenTime,
				$"trade {trade.Id} filled on the very bar its rule was evaluated on.");

			IsTrue(trade.EntryPrice >= fillBar.Low && trade.EntryPrice <= fillBar.High,
				$"trade {trade.Id} filled at {trade.EntryPrice}, outside the range of the bar it filled on.");
		}
	}

	/// <summary>
	/// Trading is not free. The same strategy over the same bars keeps less of the result once the
	/// spread widens, which is what makes a stressed-cost run mean anything.
	/// </summary>
	[TestMethod]
	public async Task AWiderSpreadCostsTheRunMore()
	{
		var bars = Waves(600);
		var runner = new EmulatedBacktestRunner();

		var cheap = await runner.RunAsync(Request(Oscillating(), bars, ExecutionCosts.Default), CancellationToken);

		var dear = await runner.RunAsync(
			Request(Oscillating(), bars, ExecutionCosts.Default.Scaled(10m)),
			CancellationToken);

		var cheapNet = cheap.Trades.Sum(t => t.Net);
		var dearNet = dear.Trades.Sum(t => t.Net);

		IsTrue(cheap.Trades.Count > 0 && dear.Trades.Count > 0);
		IsTrue(dearNet < cheapNet, $"costs ten times higher left the run no worse off: {dearNet} against {cheapNet}.");

		AreEqual(cheap.Trades.Count, dear.Trades.Count,
			"raising the costs changed which trades were taken, so the two runs are not comparable.");
	}

	/// <summary>
	/// What the spread took is reported apart from what the fees took. A candidate that is marginal is
	/// marginal for one of those two reasons, and only one of them can be traded around.
	/// </summary>
	[TestMethod]
	public async Task TheSpreadAndTheFeesAreReportedApart()
	{
		var outcome = await new EmulatedBacktestRunner().RunAsync(
			Request(Oscillating(), Waves(600), new ExecutionCosts(Fees: 0.0002m, HalfSpread: 0.01m)),
			CancellationToken);

		IsTrue(outcome.Trades.Count > 0);

		foreach (var trade in outcome.Trades)
		{
			// Twenty units changed hands over the two ends of the trade, at a cent of spread each.
			AreEqual(0.2m, Math.Round(trade.Slippage, 6), $"trade {trade.Id} was charged {trade.Slippage} of spread.");
			AreEqual(0.004m, Math.Round(trade.Commission, 6), $"trade {trade.Id} was charged {trade.Commission} of fees.");
		}
	}

	/// <summary>Percentage fees and spread are charged from notional value for crypto venues.</summary>
	[TestMethod]
	public async Task PercentageCostsAreChargedAndSeparated()
	{
		var outcome = await new EmulatedBacktestRunner().RunAsync(
			Request(Oscillating(), Waves(600), BrokerVenue.Binance.Costs),
			CancellationToken);

		IsTrue(outcome.Trades.Count > 0);
		IsTrue(outcome.Trades.All(t => t.Commission > 0m));
		IsTrue(outcome.Trades.All(t => t.Slippage > 0m));

		foreach (var trade in outcome.Trades)
		{
			var ratio = trade.Commission / trade.Slippage;
			IsTrue(Math.Abs(ratio - 2m) < 0.0001m,
				$"the 0.10% fee and 0.05% half-spread were split at {ratio} instead of 2:1.");
		}
	}

	/// <summary>The same run twice gives the same trades, or nothing measured on it means anything.</summary>
	[TestMethod]
	public async Task TheSameRunTwiceGivesTheSameTrades()
	{
		var bars = Waves(400);
		var runner = new EmulatedBacktestRunner();

		var first = await runner.RunAsync(Request(Oscillating(), bars, ExecutionCosts.Default), CancellationToken);
		var second = await runner.RunAsync(Request(Oscillating(), bars, ExecutionCosts.Default), CancellationToken);

		AreEqual(first.Trades.Count, second.Trades.Count);

		foreach (var (a, b) in first.Trades.Zip(second.Trades))
			AreEqual(a, b, "the same candidate over the same bars produced a different trade.");
	}

	/// <summary>A strategy whose rules are never met trades nothing, and says so rather than failing.</summary>
	[TestMethod]
	public async Task AStrategyWhoseRulesAreNeverMetTradesNothing()
	{
		var unreachable = Oscillating() with
		{
			Entries =
			[
				new("e1", TradeDirections.Long,
					new Compare(new Field(CandleFields.Close), ComparisonOperators.GreaterThan, new Constant(1_000_000))),
			],
		};

		var outcome = await new EmulatedBacktestRunner().RunAsync(
			Request(unreachable, Waves(300), ExecutionCosts.Default),
			CancellationToken);

		AreEqual(0, outcome.Trades.Count);
		IsTrue(outcome.Equity.Count > 0, "a run with no trades still has a starting account value.");
	}

	/// <summary>What the runner produces is what the metrics are computed from, without a step in between.</summary>
	[TestMethod]
	public async Task TheOutcomeCanBeMeasuredDirectly()
	{
		var bars = Waves(600);

		var outcome = await new EmulatedBacktestRunner().RunAsync(
			Request(Oscillating(), bars, ExecutionCosts.Default),
			CancellationToken);

		var metrics = RunMetricsCalculator.Measure(
			outcome.Trades,
			outcome.Equity,
			100_000m,
			bars[^1].OpenTime - bars[0].OpenTime,
			outcome.ExecutionErrorCount);

		AreEqual(outcome.Trades.Count, metrics.Trades.Count);
		AreEqual(outcome.Trades.Sum(t => t.Net), metrics.Net.Profit);
		IsTrue(metrics.Costs.Total > 0, "a run that traded was charged nothing at all.");
		IsTrue(metrics.Activity.ExposurePercent > 0);
	}

	/// <summary>A run with no bars is refused rather than reported as a strategy that did nothing.</summary>
	[TestMethod]
	public async Task ARunWithoutBarsIsRefused()
		=> await ThrowsAsync<ArgumentException>(
			() => new EmulatedBacktestRunner().RunAsync(Request(Oscillating(), [], ExecutionCosts.Default), CancellationToken));

	/// <summary>
	/// Bars that walk up and back down on a fixed period, inside one American session per day so the
	/// board is open for every one of them.
	/// </summary>
	private static IReadOnlyList<Candle> Waves(int count)
	{
		var bars = new List<Candle>(count);
		var time = _open;

		for (var i = 0; i < count; i++)
		{
			// Sixty bars to a full cycle: long enough that a ten-bar average lags the price by enough to
			// cross it, rather than tracking it too closely to ever be crossed.
			var wave = (decimal)Math.Sin(i * 2 * Math.PI / 60);
			var close = 100m + Math.Round(5m * wave, 2);
			var open = i == 0 ? close : bars[^1].Close;

			bars.Add(new(
				time,
				open,
				Math.Max(open, close) + 0.05m,
				Math.Min(open, close) - 0.05m,
				close,
				1_000m));

			time = time.AddMinutes(5);

			// The American session runs to twenty hundred UTC; the next bar after it opens the next day.
			if (time.TimeOfDay >= TimeSpan.FromHours(20))
				time = time.Date.AddDays(time.DayOfWeek == DayOfWeek.Friday ? 3 : 1).Add(_open.TimeOfDay);
		}

		return bars;
	}

	/// <summary>Buy when the price is above its own average, and let go five bars later.</summary>
	private static StrategySpec Oscillating()
		=> new()
		{
			Name = "Above its average",
			Thesis = "A price above its own recent average keeps going for a few bars.",
			AllowLong = true,
			AllowShort = false,
			TimeFrame = TimeSpan.FromMinutes(5),
			WarmupBars = 15,
			Entries =
			[
				new("e1", TradeDirections.Long,
					new Compare(
						new Field(CandleFields.Close),
						ComparisonOperators.GreaterThan,
						new IndicatorRef("sma", new Constant(10), CandleFields.Close))),
			],
			Exits = [new("x1", ExitKinds.TimeExit, TradeDirections.Long, Length: new Constant(5))],
			Parameters = [],
			Risk = new(0.10m, 0.02m),
		};
}
