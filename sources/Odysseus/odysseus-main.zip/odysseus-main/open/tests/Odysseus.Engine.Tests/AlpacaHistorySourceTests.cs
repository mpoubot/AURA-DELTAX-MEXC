namespace Odysseus.Engine.Tests;

using System;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Engine;
using Odysseus.TestKit;

/// <summary>
/// Downloading history through the StockSharp connector, against the real broker.
/// </summary>
/// <remarks>
/// There is nothing worth stubbing here: the whole point of using the connector is that it talks to the
/// broker for us, and a stub would only confirm that our own call sequence matches our own expectation.
/// The suite declares itself inapplicable without credentials.
/// </remarks>
[TestClass]
public class AlpacaHistorySourceTests : OdysseusTestBase
{
	private const string KeysVariable = "ODYSSEUS_ALPACA_KEYS";

	private IHistorySource _source;

	/// <summary>Loads credentials, or declares the suite inapplicable.</summary>
	[TestInitialize]
	public void Connect()
	{
		var path = Environment.GetEnvironmentVariable(KeysVariable);

		if (string.IsNullOrWhiteSpace(path) || !System.IO.File.Exists(path))
			Assert.Inconclusive($"No broker credentials. Point {KeysVariable} at a file holding 'key' and 'secret'.");

		var text = System.IO.File.ReadAllText(path);

		_source = new AlpacaHistorySource(Read(text, "key"), Read(text, "secret"));
	}

	/// <summary>
	/// A bounded range downloads, finishes on its own, and comes back usable.
	/// </summary>
	/// <remarks>
	/// Finishing on its own is half the check. A subscription that never ends leaves the caller holding a
	/// call that returns neither bars nor an error, which is worse than a refusal because nothing about it
	/// says anything is wrong.
	/// </remarks>
	[TestMethod]
	public async Task ABoundedRangeDownloadsAndFinishes()
	{
		var to = DateTime.SpecifyKind(DateTime.UtcNow.Date.AddDays(-1), DateTimeKind.Utc);
		var from = to.AddDays(-20);

		var candles = await _source.GetBarsAsync("NVDA", TimeSpan.FromMinutes(5), from, to, CancellationToken);

		IsTrue(candles.Count > 500, $"a fortnight of five-minute bars should be hundreds; got {candles.Count}.");

		IsTrue(candles.All(c => c.OpenTime.Kind == DateTimeKind.Utc), "a bar came back without a zone.");
		IsTrue(candles.All(c => c.IsWellFormed), "a bar came back whose prices cannot describe a real bar.");

		IsTrue(candles.Zip(candles.Skip(1)).All(p => p.First.OpenTime < p.Second.OpenTime),
			"the bars are not in order.");

		IsTrue(candles.All(c => c.OpenTime >= from && c.OpenTime <= to),
			"a bar came back from outside the range that was asked for.");
	}

	/// <summary>
	/// The feed must be the consolidated one. Asking for paper trading also switches the feed to a single
	/// exchange unless the feed is set afterwards, and on that feed the volumes are a small fraction of
	/// the market — which would quietly invalidate every volume-based measurement downstream.
	/// </summary>
	[TestMethod]
	public async Task TheConsolidatedFeedIsUsed()
	{
		var to = DateTime.SpecifyKind(DateTime.UtcNow.Date.AddDays(-1), DateTimeKind.Utc);
		var from = to.AddDays(-5);

		var candles = await _source.GetBarsAsync("NVDA", TimeSpan.FromMinutes(5), from, to, CancellationToken);

		var busiest = candles.Max(c => c.Volume);

		IsTrue(busiest > 1_000_000m,
			$"the busiest five-minute bar carried {busiest} shares, which is a single-exchange feed rather than " +
			"the consolidated one.");
	}

	/// <summary>The source names itself, so a dataset records which feed its bars came from.</summary>
	[TestMethod]
	public void TheSourceNamesItsFeed()
		=> AreEqual("alpaca-sip", _source.Name);

	/// <summary>
	/// Measuring a real instrument end to end: download, take the development slice, and check that the
	/// numbers that come out are the size a real instrument produces.
	/// </summary>
	[TestMethod]
	public async Task ARealInstrumentMeasuresPlausibly()
	{
		var to = DateTime.SpecifyKind(DateTime.UtcNow.Date.AddDays(-1), DateTimeKind.Utc);
		var candles = await _source.GetBarsAsync("NVDA", TimeSpan.FromMinutes(5), to.AddDays(-40), to, CancellationToken);

		// Only the development slice is ever profiled, exactly as the server does it.
		var development = candles.Take((int)(candles.Count * 0.6)).ToArray();
		var profile = MarketProfiler.Measure("NVDA", development, TimeSpan.FromMinutes(5));

		IsTrue(profile.Movement.AnnualisedVolatilityPercent is > 5m and < 200m,
			$"annualised volatility of {profile.Movement.AnnualisedVolatilityPercent}% is outside anything a listed stock does.");

		IsTrue(profile.Persistence.VarianceRatio5 is > 0.2m and < 5m,
			$"a variance ratio of {profile.Persistence.VarianceRatio5} means the calculation is wrong, not that the stock is strange.");

		var opening = profile.Session.Single(b => b.Bucket == "first 30 minutes");

		IsTrue(opening.ShareOfVolume > 2m,
			$"the opening half hour carries {opening.ShareOfVolume}% of volume, so the active session was located " +
			"somewhere the instrument does not actually trade.");
	}

	private static string Read(string text, string key)
	{
		var match = Regex.Match(text, $@"^\s*{key}\s*[:=]\s*(\S+)\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);

		return match.Success ? match.Groups[1].Value : throw new InvalidOperationException($"No '{key}' in the file.");
	}
}
