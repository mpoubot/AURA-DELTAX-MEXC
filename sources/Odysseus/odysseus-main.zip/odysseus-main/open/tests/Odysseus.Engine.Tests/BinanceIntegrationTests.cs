namespace Odysseus.Engine.Tests;

using System;
using System.IO;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Application;
using Odysseus.Engine;
using Odysseus.TestKit;

/// <summary>Real Binance public-data and Spot Testnet connection checks.</summary>
[TestCategory("Integration")]
[TestClass]
public class BinanceIntegrationTests : OdysseusTestBase
{
	private const string KeysVariable = "ODYSSEUS_BINANCE_KEYS";

	/// <inheritdoc />
	protected override TimeSpan Timeout => TimeSpan.FromMinutes(6);

	private string _key;
	private string _secret;

	/// <summary>Loads Spot Testnet credentials, or declares the checks inapplicable.</summary>
	[TestInitialize]
	public void LoadCredentials()
	{
		var path = Environment.GetEnvironmentVariable(KeysVariable);

		if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
			Assert.Inconclusive($"No Binance Spot Testnet credentials. Point {KeysVariable} at a key file.");

		var text = File.ReadAllText(path);
		_key = Read(text, "key");
		_secret = Read(text, "secret");
	}

	/// <summary>A bounded production-market history request returns finished UTC candles.</summary>
	[TestMethod]
	public async Task PublicSpotHistoryDownloads()
	{
		var to = DateTime.SpecifyKind(DateTime.UtcNow.Date, DateTimeKind.Utc);
		var from = to.AddDays(-3);
		var source = new BinanceHistorySource(_key, _secret);

		var candles = await source.GetBarsAsync("BTCUSDT", TimeSpan.FromHours(1), from, to, CancellationToken);

		IsTrue(candles.Count >= 48, $"three days of hourly BTCUSDT bars returned only {candles.Count} candles.");
		IsTrue(candles.All(c => c.OpenTime.Kind == DateTimeKind.Utc && c.IsWellFormed));
	}

	/// <summary>The Spot Testnet account can be read without placing any order.</summary>
	[TestMethod]
	public async Task TestnetAccountCanBeRead()
	{
		var state = await new BinancePaperTrader(_key, _secret).ReadAsync(CancellationToken);

		AreEqual("binance-spot-testnet", state.Broker);
		IsTrue(state.ObservedAt.Kind == DateTimeKind.Utc);
	}

	private static string Read(string text, string name)
	{
		var match = Regex.Match(text, $@"^\s*{name}\s*[:=]\s*(?<value>\S+)\s*$", RegexOptions.Multiline | RegexOptions.IgnoreCase);

		if (!match.Success)
			Assert.Inconclusive($"The credentials file holds no '{name}'.");

		return match.Groups["value"].Value;
	}
}
