namespace Odysseus.Spec.Tests;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Nodes;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.TestKit;

/// <summary>
/// Rules that hold across the whole schema family rather than inside one file. JSON Schema can only
/// describe one document at a time, so every invariant that spans two files lives here. A rule stated
/// only in a description is a rule nobody enforces.
/// </summary>
[TestClass]
public class SchemaContractTests : OdysseusTestBase
{
	private static string SchemaDirectory => Path.Combine(RepositoryRoot, "schemas");

	private static IReadOnlyDictionary<string, JsonNode> Schemas => _schemas ??= LoadSchemas();

	private static IReadOnlyDictionary<string, JsonNode> _schemas;

	private static IReadOnlyDictionary<string, JsonNode> LoadSchemas()
	{
		var result = new Dictionary<string, JsonNode>(StringComparer.Ordinal);

		foreach (var file in Directory.EnumerateFiles(SchemaDirectory, "*.schema.json"))
			result.Add(Path.GetFileName(file), JsonNode.Parse(File.ReadAllText(file)));

		return result;
	}

	/// <summary>
	/// Each file must load on its own. A reference to another document's identifier makes the schema
	/// unusable to anyone who does not pre-register the whole family first.
	/// </summary>
	[TestMethod]
	public void EverySchemaIsSelfContained()
	{
		foreach (var (name, root) in Schemas)
		{
			foreach (var (path, value) in Walk(root))
			{
				if (!path.EndsWith("/$ref", StringComparison.Ordinal))
					continue;

				var reference = value.GetValue<string>();

				IsTrue(reference.StartsWith("#/", StringComparison.Ordinal),
					$"{name} at {path} references {reference}; every reference must be local to the file.");
			}
		}
	}

	/// <summary>
	/// The error and diagnostic shapes are duplicated on purpose so that each file stays self-contained.
	/// Duplication is only safe while the copies stay identical.
	/// </summary>
	[TestMethod]
	public void DuplicatedDefinitionsStayIdentical()
	{
		AssertDefinitionIsUniform("error");
		AssertDefinitionIsUniform("diagnostic");
	}

	/// <summary>
	/// The catalog is the declared source of truth for indicator names, so a specification must not be
	/// able to name an indicator the catalog cannot describe.
	/// </summary>
	[TestMethod]
	public void IndicatorNamesAreASubsetOfTheCatalog()
	{
		var catalog = CollectEnumValues("indicator-catalog.schema.json", "name");
		var used = CollectEnumValues("strategy-spec.schema.json", "name");

		// The specification also names rules and parameters through "name"; only the values that look
		// like indicators are compared, and every one of them must exist in the catalog.
		var unknown = used.Where(v => catalog.Count > 0 && LooksLikeIndicator(v) && !catalog.Contains(v)).ToArray();

		IsTrue(unknown.Length == 0,
			$"strategy-spec names indicators absent from the catalog: {string.Join(", ", unknown)}.");
	}

	/// <summary>
	/// Candle field names must read the same way on both sides, otherwise the binding the catalog
	/// describes cannot be checked by comparing strings.
	/// </summary>
	[TestMethod]
	public void CandleFieldVocabularyIsUniform()
	{
		var catalog = CollectEnumValues("indicator-catalog.schema.json", "acceptedFields")
			.Concat(CollectEnumValues("indicator-catalog.schema.json", "defaultField"))
			.ToHashSet(StringComparer.Ordinal);

		var spec = CollectEnumValues("strategy-spec.schema.json", "source")
			.Concat(CollectEnumValues("strategy-spec.schema.json", "field"))
			.ToHashSet(StringComparer.Ordinal);

		foreach (var value in spec)
		{
			IsTrue(catalog.Count == 0 || catalog.Contains(value),
				$"strategy-spec uses candle field '{value}' which the catalog does not declare.");
		}
	}

	/// <summary>
	/// One error vocabulary. A category named anywhere else must exist in the authoritative list.
	/// </summary>
	[TestMethod]
	public void ErrorCategoriesMatchTheAuthority()
	{
		var authority = CollectEnumValues("error.schema.json", "category");

		IsTrue(authority.Count > 0, "error.schema.json declares no category enum.");

		foreach (var (name, _) in Schemas)
		{
			if (name == "error.schema.json")
				continue;

			foreach (var value in CollectEnumValues(name, "category"))
			{
				IsTrue(authority.Contains(value),
					$"{name} declares error category '{value}' which error.schema.json does not.");
			}
		}
	}

	/// <summary>
	/// The contracts are read by people and agents outside this project, so their prose is English and
	/// stays inside ASCII.
	/// </summary>
	[TestMethod]
	public void ProseIsAscii()
	{
		string[] proseKeys = ["title", "description", "$comment"];

		foreach (var (name, root) in Schemas)
		{
			foreach (var (path, value) in Walk(root))
			{
				var key = path[(path.LastIndexOf('/') + 1)..];

				if (!proseKeys.Contains(key) || value is not JsonValue)
					continue;

				if (value.GetValueKind() != JsonValueKind.String)
					continue;

				var text = value.GetValue<string>();
				var offending = text.FirstOrDefault(c => c > '');

				IsTrue(offending == default,
					$"{name} at {path} contains the non-ASCII character '{offending}'.");
			}
		}
	}

	/// <summary>
	/// One artifact carries one identifier, so every contract that references a resource must accept the
	/// same shape. Two conventions mean no reference is valid everywhere.
	/// </summary>
	[TestMethod]
	public void ResourceUriConventionIsUniform()
	{
		var patterns = new HashSet<string>(StringComparer.Ordinal);

		foreach (var (name, root) in Schemas)
		{
			foreach (var (path, value) in Walk(root))
			{
				if (!path.EndsWith("/pattern", StringComparison.Ordinal) || value.GetValueKind() != JsonValueKind.String)
					continue;

				var pattern = value.GetValue<string>();

				if (pattern.Contains("odysseus://", StringComparison.Ordinal))
					patterns.Add(pattern);
			}
		}

		IsTrue(patterns.Count <= 1,
			$"resource identifiers follow {patterns.Count} different conventions:{Environment.NewLine}{string.Join(Environment.NewLine, patterns)}");
	}

	/// <summary>
	/// Every knob the catalog advertises must be one a specification can actually turn. A catalog free
	/// to name a parameter the expression tree has no slot for describes a strategy that can be built
	/// structurally and never configured.
	/// </summary>
	[TestMethod]
	public void EveryCatalogParameterHasASlotInTheSpecification()
	{
		var advertised = CollectEnumValues("indicator-catalog.schema.json", "name")
			.Where(v => !CollectEnumValues("indicator-catalog.schema.json", "acceptedFields").Contains(v))
			.ToHashSet(StringComparer.Ordinal);

		var slots = new HashSet<string>(StringComparer.Ordinal);

		foreach (var (path, value) in Walk(Schemas["strategy-spec.schema.json"]))
		{
			if (!path.Contains("indicatorNode", StringComparison.Ordinal) ||
				!path.EndsWith("/properties", StringComparison.Ordinal) ||
				value is not JsonObject properties)
				continue;

			foreach (var property in properties)
				slots.Add(property.Key);
		}

		IsTrue(slots.Count > 0, "the specification declares no indicator reference properties at all.");

		var parameterNames = CollectEnumValues("indicator-catalog.schema.json", "name")
			.Where(v => slots.Contains(v) || v == "length")
			.ToArray();

		IsTrue(parameterNames.Contains("length"),
			"the catalog no longer advertises the window parameter the expression tree offers.");

		foreach (var name in advertised.Where(n => slots.Contains(n)))
		{
			IsTrue(slots.Contains(name),
				$"the catalog advertises parameter '{name}' which an indicator reference cannot carry.");
		}
	}

	/// <summary>
	/// One identifier shape across the family. The same project identifier travels through most of
	/// these contracts, so a value accepted by one and refused by another cannot be used at all.
	/// </summary>
	[TestMethod]
	public void IdentifierConventionIsUniform()
	{
		var shapes = new Dictionary<string, List<string>>(StringComparer.Ordinal);

		foreach (var (name, root) in Schemas)
		{
			if (root is not JsonObject obj ||
				!obj.TryGetPropertyValue("$defs", out var defs) ||
				defs is not JsonObject definitions ||
				!definitions.TryGetPropertyValue("identifier", out var identifier))
				continue;

			var shape = Canonicalize(identifier);

			if (!shapes.TryGetValue(shape, out var owners))
				shapes[shape] = owners = [];

			owners.Add(name);
		}

		IsTrue(shapes.Count <= 1,
			"identifiers follow more than one convention: " +
			string.Join("; ", shapes.Select(s => $"[{string.Join(", ", s.Value)}] -> {s.Key}")));
	}

	/// <summary>
	/// A resource identifier must never be able to carry a filesystem path, because a host path in a
	/// tool response leaks the layout of the machine the server runs on.
	/// </summary>
	[TestMethod]
	public void ResourceIdentifiersCannotCarryFilesystemPaths()
	{
		foreach (var (name, root) in Schemas)
		{
			foreach (var (path, value) in Walk(root))
			{
				var key = path[(path.LastIndexOf('/') + 1)..];

				if (!key.EndsWith("ResourceUri", StringComparison.OrdinalIgnoreCase) &&
					!key.Equals("resourceUri", StringComparison.OrdinalIgnoreCase))
					continue;

				if (value is not JsonObject definition)
					continue;

				var constrained = definition.ContainsKey("pattern") ||
					definition.ContainsKey("not") ||
					definition.ContainsKey("$ref") ||
					definition.ContainsKey("allOf");

				IsTrue(constrained,
					$"{name} at {path} accepts any string as a resource identifier, so a file:// path validates.");
			}
		}
	}

	/// <summary>
	/// The closed part of the history must stay unnameable. Capping it in one document is not enough:
	/// a sibling contract that carries an uncapped range over the same dataset reveals it by subtraction.
	/// </summary>
	[TestMethod]
	public void NoContractCarriesAnUncappedRangeOverTheDataset()
	{
		foreach (var (name, root) in Schemas)
		{
			if (name == "dataset-manifest.schema.json")
				continue;

			foreach (var (path, value) in Walk(root))
			{
				if (value is not JsonObject definition)
					continue;

				if (!definition.TryGetPropertyValue("required", out var required) || required is not JsonArray fields)
					continue;

				var names = fields.Select(f => f.GetValue<string>()).ToHashSet(StringComparer.Ordinal);

				var carriesRange = names.Contains("from") && names.Contains("to");
				var carriesDataset = names.Contains("datasetVersionId") || names.Contains("datasetId");

				IsFalse(carriesRange && carriesDataset,
					$"{name} at {path} requires a dataset identifier together with a free from/to range: " +
					"subtracting it from the disclosed validation boundary reveals the closed slice.");
			}
		}
	}

	/// <summary>
	/// A report over the closed slice may only exist once that slice has been consumed, and the guard
	/// must be part of the document rather than a promise in its description.
	/// </summary>
	[TestMethod]
	public void ReportsOverTheClosedSliceAreGated()
	{
		foreach (var name in new[] { "segment-report.schema.json", "run-result.schema.json", "evaluation.schema.json" })
		{
			if (!Schemas.TryGetValue(name, out var root))
				continue;

			var mentionsHoldout = CollectEnumValues(name, "sliceKind").Any(v => v.Contains("holdout", StringComparison.OrdinalIgnoreCase));

			if (!mentionsHoldout)
				continue;

			var text = root.ToJsonString();

			IsTrue(text.Contains("finalHoldoutUsed", StringComparison.Ordinal) &&
				(text.Contains("\"if\"", StringComparison.Ordinal) || text.Contains("\"allOf\"", StringComparison.Ordinal)),
				$"{name} admits a holdout slice without gating it on the slice having been consumed.");
		}
	}

	private static bool LooksLikeIndicator(string value)
		=> value.Length > 1 &&
			char.IsLower(value[0]) &&
			!value.Contains('-') &&
			!value.Contains(' ');

	private static void AssertDefinitionIsUniform(string definitionName)
	{
		var seen = new Dictionary<string, string>(StringComparer.Ordinal);

		foreach (var (name, root) in Schemas)
		{
			if (root is not JsonObject obj ||
				!obj.TryGetPropertyValue("$defs", out var defs) ||
				defs is not JsonObject definitions ||
				!definitions.TryGetPropertyValue(definitionName, out var definition))
				continue;

			seen.Add(name, Canonicalize(definition));
		}

		if (seen.Count < 2)
			return;

		var reference = seen.First();

		foreach (var (name, canonical) in seen.Skip(1))
		{
			AreEqual(reference.Value, canonical,
				$"the '{definitionName}' definition differs between {reference.Key} and {name}; the copies must stay identical.");
		}
	}

	private static string Canonicalize(JsonNode node)
	{
		switch (node)
		{
			case JsonObject obj:
			{
				var parts = obj
					.Where(p => p.Key != "description" && p.Key != "title" && p.Key != "$comment")
					.OrderBy(p => p.Key, StringComparer.Ordinal)
					.Select(p => $"\"{p.Key}\":{Canonicalize(p.Value)}");

				return $"{{{string.Join(",", parts)}}}";
			}
			case JsonArray array:
				return $"[{string.Join(",", array.Select(Canonicalize))}]";
			default:
				return node?.ToJsonString() ?? "null";
		}
	}

	private static HashSet<string> CollectEnumValues(string schemaName, string propertyName)
	{
		var result = new HashSet<string>(StringComparer.Ordinal);

		if (!Schemas.TryGetValue(schemaName, out var root))
			return result;

		foreach (var (path, value) in Walk(root))
		{
			if (value is not JsonObject definition)
				continue;

			var key = path[(path.LastIndexOf('/') + 1)..];

			if (key != propertyName)
				continue;

			foreach (var item in EnumValuesOf(definition))
				result.Add(item);
		}

		return result;
	}

	private static IEnumerable<string> EnumValuesOf(JsonObject definition)
	{
		if (definition.TryGetPropertyValue("enum", out var direct) && direct is JsonArray values)
		{
			foreach (var value in values)
			{
				if (value?.GetValueKind() == JsonValueKind.String)
					yield return value.GetValue<string>();
			}
		}

		foreach (var key in new[] { "items", "oneOf", "anyOf", "allOf" })
		{
			if (!definition.TryGetPropertyValue(key, out var nested) || nested is null)
				continue;

			var branches = nested is JsonArray array ? array.AsEnumerable() : [nested];

			foreach (var branch in branches)
			{
				if (branch is JsonObject branchObject)
				{
					foreach (var value in EnumValuesOf(branchObject))
						yield return value;
				}
			}
		}
	}

	private static IEnumerable<(string Path, JsonNode Node)> Walk(JsonNode node, string path = "")
	{
		if (node is null)
			yield break;

		yield return (path, node);

		switch (node)
		{
			case JsonObject obj:
			{
				foreach (var property in obj)
				{
					foreach (var item in Walk(property.Value, $"{path}/{property.Key}"))
						yield return item;
				}

				break;
			}
			case JsonArray array:
			{
				for (var i = 0; i < array.Count; i++)
				{
					foreach (var item in Walk(array[i], $"{path}/{i}"))
						yield return item;
				}

				break;
			}
		}
	}
}
