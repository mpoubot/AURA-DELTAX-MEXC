namespace Odysseus.Compiler.Tests;

using System;
using System.Linq;
using System.Collections.Generic;
using System.IO;
using System.Reflection;

using StockSharp.Algo.Strategies;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.CodeGen;
using Odysseus.Compiler;
using Odysseus.Spec;
using Odysseus.TestKit;

using Odysseus.Domain;

/// <summary>
/// The translator and the compiler together.
/// </summary>
/// <remarks>
/// This is where the translator is really tested. Every other test of it compares strings; this one
/// asks the C# compiler whether what came out is a program, which is the only opinion that counts.
/// </remarks>
[TestClass]
public class CompiledStrategyTests : OdysseusTestBase
{
	// Everything a generated strategy is written against: the engine, its message and entity types, and
	// the base library they are built on.
	private static StrategyCompiler Compiler => new(EngineAssemblies());

	private static IReadOnlyList<string> EngineAssemblies()
	{
		var directory = Path.GetDirectoryName(typeof(Strategy).Assembly.Location);

		return [.. Directory.EnumerateFiles(directory, "*.dll")
			.Where(f =>
			{
				var name = Path.GetFileNameWithoutExtension(f);

				return name.StartsWith("StockSharp.", StringComparison.Ordinal) ||
					name.StartsWith("Ecng.", StringComparison.Ordinal);
			})];
	}

	/// <summary>A translated specification compiles.</summary>
	[TestMethod]
	public void ATranslatedSpecificationCompiles()
	{
		var translated = StrategyTranslator.Translate(Breakout());
		var outcome = Compiler.Compile(translated.Source, "candidate");

		IsTrue(outcome.Succeeded, Describe(outcome, translated.Source));
	}

	/// <summary>Nothing the translator emits produces so much as a warning.</summary>
	[TestMethod]
	public void TranslatedSourceIsClean()
	{
		var translated = StrategyTranslator.Translate(Breakout());
		var outcome = Compiler.Compile(translated.Source, "candidate");

		AreEqual(0, outcome.Messages.Count,
			$"the generated source is not clean: {string.Join(" | ", outcome.Messages.Select(m => $"{m.Id} {m.Message}"))}");
	}

	/// <summary>
	/// Every shape the specification language allows must compile, not only the one in the fixture. A
	/// node that translates to something the compiler rejects would be discovered by an agent, at the
	/// cost of one of its attempts.
	/// </summary>
	[TestMethod]
	public void EveryExpressionShapeCompiles()
	{
		Expression[] conditions =
		[
			new AllOf([new PositionIs(PositionStates.Flat), new Not(new PositionIs(PositionStates.Long))]),
			new AnyOf([new Compare(new Field(CandleFields.Close), ComparisonOperators.LessOrEqual, new Constant(10))]),
			new Compare(
				new Arithmetic(ArithmeticOperators.Add, [new Field(CandleFields.High), new Field(CandleFields.Low)]),
				ComparisonOperators.GreaterThan,
				new Arithmetic(ArithmeticOperators.Multiply, [new Field(CandleFields.Close), new Constant(2)])),
			new Compare(
				new Arithmetic(ArithmeticOperators.Divide, [new Field(CandleFields.Close), new ParameterRef("BreakoutPeriod")]),
				ComparisonOperators.GreaterThan,
				new Constant(1)),
			new Compare(
				new AbsoluteValue(new Arithmetic(ArithmeticOperators.Subtract, [new Field(CandleFields.Close), new Field(CandleFields.Open)])),
				ComparisonOperators.GreaterThan,
				new Constant(1)),
			new Compare(
				new Arithmetic(ArithmeticOperators.Min, [new Field(CandleFields.Close), new Field(CandleFields.Open)]),
				ComparisonOperators.LessThan,
				new Arithmetic(ArithmeticOperators.Max, [new Field(CandleFields.High), new Field(CandleFields.Low)])),
			new Cross(new Field(CandleFields.Close), CrossDirections.Above,
				new IndicatorRef("ema", new Constant(20), CandleFields.Close)),
			new Cross(new IndicatorRef("rsi", new Constant(14), CandleFields.Close), CrossDirections.Below,
				new Constant(70)),
			new SessionWindow("09:50:00", "15:45:00"),
			new Compare(new IndicatorRef("stdDev", new Constant(20), CandleFields.Close),
				ComparisonOperators.GreaterThan, new IndicatorRef("atr", new Constant(14))),
			new Compare(new Field(CandleFields.Volume), ComparisonOperators.GreaterThan,
				new IndicatorRef("volumeSma", new Constant(30))),
			new Compare(new Field(CandleFields.Close, Offset: 3), ComparisonOperators.GreaterThan,
				new IndicatorRef("lowest", new Constant(20), CandleFields.Low, Offset: 2)),
		];

		foreach (var condition in conditions)
		{
			var spec = Breakout() with
			{
				WarmupBars = 200,
				Entries = [new("e1", TradeDirections.Long, condition)],
			};

			var translated = StrategyTranslator.Translate(spec);
			var outcome = Compiler.Compile(translated.Source, "candidate");

			IsTrue(outcome.Succeeded, $"{condition.GetType().Name} did not compile. {Describe(outcome, translated.Source)}");
			AreEqual(0, outcome.Messages.Count, $"{condition.GetType().Name} compiled with warnings.");
		}
	}

	/// <summary>Every exit shape compiles as well.</summary>
	[TestMethod]
	public void EveryExitShapeCompiles()
	{
		ExitRule[] exits =
		[
			new("x", ExitKinds.SessionEnd, TradeDirections.Long),
			new("x", ExitKinds.TimeExit, TradeDirections.Long, Length: new Constant(10)),
			new("x", ExitKinds.AtrStop, TradeDirections.Long, Length: new Constant(14), Multiplier: new Constant(2)),
			new("x", ExitKinds.AtrTarget, TradeDirections.Long, Length: new Constant(14), Multiplier: new Constant(3)),
			new("x", ExitKinds.Condition, TradeDirections.Long,
				Condition: new Compare(new Field(CandleFields.Close), ComparisonOperators.LessThan, new Constant(1))),
		];

		foreach (var exit in exits)
		{
			var translated = StrategyTranslator.Translate(Breakout() with { Exits = [exit] });
			var outcome = Compiler.Compile(translated.Source, "candidate");

			IsTrue(outcome.Succeeded, $"{exit.Kind} did not compile. {Describe(outcome, translated.Source)}");
		}
	}

	/// <summary>
	/// The compiled assembly is a function of the source alone, so a candidate can be identified by its
	/// hash rather than by when it was built.
	/// </summary>
	[TestMethod]
	public void CompilationIsDeterministic()
	{
		var translated = StrategyTranslator.Translate(Breakout());

		var first = Compiler.Compile(translated.Source, "candidate");
		var second = Compiler.Compile(translated.Source, "candidate");

		AreEqual(first.AssemblyHash, second.AssemblyHash,
			"the same source produced two different assemblies, so a candidate is not identified by what it is.");
	}

	/// <summary>The compiled type really is a strategy, and can be created.</summary>
	[TestMethod]
	public void TheCompiledTypeIsAStrategy()
	{
		var translated = StrategyTranslator.Translate(Breakout());
		var outcome = Compiler.Compile(translated.Source, "candidate");

		IsTrue(outcome.Succeeded, Describe(outcome, translated.Source));

		var type = Assembly.Load(outcome.Assembly)
			.GetTypes()
			.Single(t => typeof(Strategy).IsAssignableFrom(t) && !t.IsAbstract);

		AreEqual(translated.ClassName, type.Name);

		IsNotNull(Activator.CreateInstance(type), "the generated strategy cannot be created.");
	}

	/// <summary>
	/// Reaching outside what a strategy is given is refused. This is not protection from a hostile
	/// author — the code belongs to whoever runs it — it is protection of the result: a strategy that
	/// reads the wall clock or draws an unseeded number returns a different answer tomorrow on the same
	/// data, and every metric computed from it becomes a number nobody can check.
	/// </summary>
	[TestMethod]
	public void ReachingOutsideTheContextIsRefused()
	{
		// Two kinds of refusal, and the difference is worth keeping straight. Some of these cannot even be
		// named: the assembly that defines them is not in the reference set, so the compiler stops them
		// and the rules never see them. The rest sit in the same assembly as types a strategy legitimately
		// needs, so no reference set could exclude them and a named rule has to.
		(string Attempt, string Rule)[] attempts =
		[
			("var now = System.DateTime.Now;", "ODSTR012"),
			("var now = System.DateTime.UtcNow;", "ODSTR012"),
			("var id = System.Guid.NewGuid();", "ODSTR013"),
			("var random = new System.Random().Next();", "ODSTR013"),
			("var text = System.IO.File.ReadAllText(\"c:/secrets.txt\");", "ODSTR012"),
			("System.Threading.Thread.Sleep(1);", null),
			("var client = new System.Net.Http.HttpClient();", null),
		];

		foreach (var (attempt, rule) in attempts)
		{
			var source = $$"""
				namespace Odysseus.Generated;

				
				public sealed class Reacher : GeneratedStrategy
				{
					public override StrategySetup Setup(IStrategyContext context)
						=> new(0, new System.Collections.Generic.Dictionary<string, IndicatorRequest>());

					public override void OnBar(IStrategyContext context)
					{
						{{attempt}}
					}
				}
				""";

			var outcome = Compiler.Compile(source, "reacher");

			IsFalse(outcome.Succeeded, $"'{attempt}' compiled, so a strategy can reach outside what it is given.");

			if (rule is null)
				continue;

			var message = outcome.Messages.FirstOrDefault(m => m.Id == rule);

			IsNotNull(message, $"'{attempt}' was refused, but not by {rule}: {string.Join(" | ", outcome.Messages.Select(m => m.Id))}");

			IsTrue(message.Message.Contains("instead", StringComparison.Ordinal),
				"a refusal has to say what to use instead, or the next attempt is a guess.");
		}
	}

	private static string Describe(CompilationOutcome outcome, string source)
	{
		var messages = string.Join(
			Environment.NewLine,
			outcome.Messages.Select(m => $"  {m.Severity} {m.Id} at {m.Line}:{m.Column}: {m.Message}"));

		var numbered = string.Join(
			Environment.NewLine,
			source.Split('\n').Select((line, index) => $"{index + 1,4}: {line}"));

		return $"{Environment.NewLine}{messages}{Environment.NewLine}--- source ---{Environment.NewLine}{numbered}";
	}

	private static StrategySpec Breakout()
		=> new()
		{
			Name = "Volume confirmed breakout",
			Thesis = "A close above a recent high carries on when participation confirms it.",
			AllowLong = true,
			AllowShort = false,
			TimeFrame = TimeSpan.FromMinutes(5),
			WarmupBars = 61,
			Entries =
			[
				new("e1", TradeDirections.Long,
					new Compare(
						new Field(CandleFields.Close),
						ComparisonOperators.GreaterThan,
						new IndicatorRef("highest", new ParameterRef("BreakoutPeriod"), CandleFields.High, Offset: 1))),
			],
			Exits =
			[
				new("x1", ExitKinds.AtrStop, TradeDirections.Long, Length: new Constant(14), Multiplier: new Constant(2)),
				new("x2", ExitKinds.SessionEnd, TradeDirections.Long),
			],
			Parameters = [new("BreakoutPeriod", ParameterTypes.Integer, Default: 20, Minimum: 10, Maximum: 60, Step: 5)],
			Risk = new(0.10m, 0.02m),
		};
}
