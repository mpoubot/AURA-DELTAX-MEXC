namespace Odysseus.Architecture.Tests;

using System;
using System.Collections.Generic;
using System.Linq;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.TestKit;

/// <summary>
/// Enforces the dependency rules of the specification, section 7.3. These are the rules that keep
/// the domain free of infrastructure and keep every third-party API behind exactly one adapter.
/// </summary>
[TestClass]
public class DependencyRulesTests : OdysseusTestBase
{
	private static IReadOnlyDictionary<string, ProjectInfo> Source => _source ??= ProjectGraph.Load(RepositoryRoot, "src");

	private static IReadOnlyDictionary<string, ProjectInfo> _source;

	private static IReadOnlyDictionary<string, ProjectInfo> Tests => _tests ??= ProjectGraph.Load(RepositoryRoot, "tests");

	private static IReadOnlyDictionary<string, ProjectInfo> _tests;

	/// <summary>Rule 1: the domain depends on nothing at all.</summary>
	[TestMethod]
	public void DomainHasNoDependencies()
	{
		var domain = Source["Odysseus.Domain"];

		IsTrue(domain.ProjectReferences.Count == 0,
			$"Odysseus.Domain must not reference other projects, found: {Join(domain.ProjectReferences)}");

		IsTrue(domain.PackageReferences.Count == 0,
			$"Odysseus.Domain must not reference packages, found: {Join(domain.PackageReferences)}");
	}

	/// <summary>Rule 2: the application layer stays free of every concrete technology.</summary>
	[TestMethod]
	public void ApplicationDoesNotDependOnInfrastructure()
	{
		var application = Source["Odysseus.Application"];

		string[] forbidden =
		[
			"Odysseus.Engine",
			"Odysseus.Compiler",
			"Odysseus.Persistence",
			"Odysseus.Alpaca",
			"Odysseus.Binance",
			"Odysseus.Server",
			"Odysseus.Worker",
		];

		foreach (var name in forbidden)
		{
			IsFalse(application.ProjectReferences.Contains(name),
				$"Odysseus.Application must not reference {name}: infrastructure is reached through ports only.");
		}

		AssertNoPackageMatching(application, "Microsoft.CodeAnalysis");
		AssertNoPackageMatching(application, "Microsoft.EntityFrameworkCore");
		AssertNoPackageMatching(application, "StockSharp");
	}

	/// <summary>Rule 3: StockSharp is visible in exactly one project.</summary>
	[TestMethod]
	public void OnlyStockSharpAdapterReferencesStockSharp()
		=> AssertPackagePrefixIsExclusiveTo("StockSharp", "Odysseus.Engine");

	/// <summary>Rule 4: Roslyn is visible in exactly one project.</summary>
	[TestMethod]
	public void OnlyCompilerReferencesRoslyn()
		=> AssertPackagePrefixIsExclusiveTo("Microsoft.CodeAnalysis", "Odysseus.Compiler");

	/// <summary>Rule 5: each concrete broker connector is visible only in the engine adapter.</summary>
	[TestMethod]
	public void OnlyEngineReferencesBrokerConnectors()
	{
		AssertPackagePrefixIsExclusiveTo("StockSharp.Alpaca", "Odysseus.Engine");
		AssertPackagePrefixIsExclusiveTo("StockSharp.Binance", "Odysseus.Engine");
	}

	/// <summary>The database is visible in exactly one project as well.</summary>
	[TestMethod]
	public void OnlyPersistenceReferencesTheDatabase()
	{
		AssertPackagePrefixIsExclusiveTo("Microsoft.Data.Sqlite", "Odysseus.Persistence");
		AssertPackagePrefixIsExclusiveTo("SQLitePCLRaw", "Odysseus.Persistence");
	}

	/// <summary>Rule 6: the processes that face the user never link the process that runs candidates.</summary>
	[TestMethod]
	public void HostsDoNotReferenceWorker()
	{
		foreach (var host in new[] { "Odysseus.Server" })
		{
			IsFalse(Source[host].ProjectReferences.Contains("Odysseus.Worker"),
				$"{host} must not reference Odysseus.Worker: candidate assemblies are never loaded in a host process.");
		}
	}

	/// <summary>
	/// Rule 7: a generated strategy is an ordinary StockSharp strategy, so the engine is referenced by
	/// the one project that adapts to it and by nothing else. A use case that reached the engine
	/// directly would tie the product to it in a place that has no business knowing it is there.
	/// </summary>
	[TestMethod]
	public void OnlyTheAdapterReferencesTheEngine()
	{
		foreach (var (name, project) in Source.Where(p => p.Key != "Odysseus.Engine"))
		{
			IsFalse(project.ProjectReferences.Any(r => r.StartsWith("Algo", StringComparison.Ordinal) ||
					r.StartsWith("Messages", StringComparison.Ordinal) ||
					r is "Alpaca" or "Binance"),
				$"{name} references the trading engine directly; only Odysseus.Engine may.");
		}
	}

	/// <summary>
	/// Nullable reference types are off across the product by convention; a project that turns them
	/// back on locally would silently diverge from the rest of the code base.
	/// </summary>
	[TestMethod]
	public void NoProjectEnablesNullableReferenceTypes()
	{
		foreach (var project in Source.Values.Concat(Tests.Values))
		{
			IsFalse(project.Text.Contains("<Nullable>enable</Nullable>", StringComparison.OrdinalIgnoreCase),
				$"{project.Name} must not enable nullable reference types; the setting is centralised in Directory.Build.props.");
		}
	}

	/// <summary>
	/// Package versions are centralised, so a version pinned inside a project file is a drift that
	/// central package management would otherwise reject only at restore time.
	/// </summary>
	[TestMethod]
	public void NoProjectPinsPackageVersionLocally()
	{
		foreach (var project in Source.Values.Concat(Tests.Values))
		{
			IsFalse(project.Text.Contains("<PackageReference", StringComparison.Ordinal) &&
				project.Text.Contains("Version=", StringComparison.Ordinal),
				$"{project.Name} pins a package version locally; versions belong to Directory.Packages.props.");
		}
	}

	private static void AssertPackagePrefixIsExclusiveTo(string prefix, string owner)
	{
		foreach (var project in Source.Values)
		{
			var matches = project.PackageReferences
				.Where(p => p.StartsWith(prefix, StringComparison.OrdinalIgnoreCase))
				.ToArray();

			if (matches.Length == 0)
				continue;

			IsTrue(project.Name == owner,
				$"{project.Name} references {Join(matches)}; only {owner} may depend on {prefix}.");
		}
	}

	private static void AssertNoPackageMatching(ProjectInfo project, string prefix)
	{
		IsFalse(project.PackageReferences.Any(p => p.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)),
			$"{project.Name} must not reference any {prefix} package.");
	}

	private static string Join(IEnumerable<string> values)
		=> string.Join(", ", values);
}
