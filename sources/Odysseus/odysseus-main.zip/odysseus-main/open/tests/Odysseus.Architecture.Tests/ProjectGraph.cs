namespace Odysseus.Architecture.Tests;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Xml.Linq;

/// <summary>
/// One project of the solution as it is declared on disk, not as it is loaded at runtime:
/// the dependency rules must hold before anything is compiled.
/// </summary>
public sealed class ProjectInfo
{
	/// <summary>Assembly name, for example <c>Odysseus.Domain</c>.</summary>
	public string Name { get; init; }

	/// <summary>Absolute path of the project file.</summary>
	public string Path { get; init; }

	/// <summary>Names of the projects referenced directly.</summary>
	public IReadOnlyCollection<string> ProjectReferences { get; init; }

	/// <summary>Package identifiers referenced directly.</summary>
	public IReadOnlyCollection<string> PackageReferences { get; init; }

	/// <summary>Raw text of the project file, for property assertions.</summary>
	public string Text { get; init; }
}

/// <summary>
/// Reads every project of the solution so that dependency rules can be asserted against the
/// declared graph.
/// </summary>
public static class ProjectGraph
{
	/// <summary>
	/// Loads the projects under the given repository-relative folder.
	/// </summary>
	/// <param name="repositoryRoot">Directory holding <c>Odysseus.slnx</c>.</param>
	/// <param name="folder">Folder to scan, for example <c>src</c>.</param>
	/// <returns>Projects keyed by assembly name.</returns>
	public static IReadOnlyDictionary<string, ProjectInfo> Load(string repositoryRoot, string folder)
	{
		if (repositoryRoot is null)
			throw new ArgumentNullException(nameof(repositoryRoot));

		if (folder is null)
			throw new ArgumentNullException(nameof(folder));

		var root = System.IO.Path.Combine(repositoryRoot, folder);
		var result = new Dictionary<string, ProjectInfo>(StringComparer.OrdinalIgnoreCase);

		foreach (var file in Directory.EnumerateFiles(root, "*.csproj", SearchOption.AllDirectories))
		{
			var document = XDocument.Load(file);

			var projectRefs = document
				.Descendants("ProjectReference")
				.Select(e => (string)e.Attribute("Include"))
				.Where(v => !string.IsNullOrEmpty(v))
				.Select(v => System.IO.Path.GetFileNameWithoutExtension(v.Replace('\\', '/')))
				.ToArray();

			var packageRefs = document
				.Descendants("PackageReference")
				.Select(e => (string)e.Attribute("Include"))
				.Where(v => !string.IsNullOrEmpty(v))
				.ToArray();

			var name = System.IO.Path.GetFileNameWithoutExtension(file);

			result.Add(name, new ProjectInfo
			{
				Name = name,
				Path = file,
				ProjectReferences = projectRefs,
				PackageReferences = packageRefs,
				Text = File.ReadAllText(file),
			});
		}

		return result;
	}
}
