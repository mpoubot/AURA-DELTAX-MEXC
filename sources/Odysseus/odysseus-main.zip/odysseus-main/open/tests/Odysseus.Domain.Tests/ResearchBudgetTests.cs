namespace Odysseus.Domain.Tests;

using System;
using System.Threading;
using System.Threading.Tasks;

using Microsoft.VisualStudio.TestTools.UnitTesting;

using Odysseus.Domain;
using Odysseus.TestKit;

/// <summary>
/// The research budget of requirements O-RCH-004 and O-RCH-005. The loop is driven by an autonomous
/// agent that will not stop itself, so the limit has to be held by the server, and it has to be
/// claimed before the expensive work starts rather than counted after it finishes.
/// </summary>
[TestClass]
public class ResearchBudgetTests : OdysseusTestBase
{
	private static ResearchBudget Small()
		=> new(maxBacktests: 3, maxCandidates: 2, maxWallClock: TimeSpan.FromMinutes(45));

	/// <summary>A claim consumes the allowance it was granted.</summary>
	[TestMethod]
	public void ClaimingConsumesAllowance()
	{
		var budget = Small();

		AreEqual(3, budget.RemainingBacktests);

		IsTrue(budget.TryClaimBacktest());
		AreEqual(2, budget.RemainingBacktests);
	}

	/// <summary>
	/// The limit is a wall, not a suggestion: past it the claim fails instead of the counter going
	/// negative or the operation running anyway.
	/// </summary>
	[TestMethod]
	public void ClaimFailsOnceExhausted()
	{
		var budget = Small();

		for (var i = 0; i < 3; i++)
			IsTrue(budget.TryClaimBacktest(), $"claim {i + 1} of 3 must succeed.");

		IsFalse(budget.TryClaimBacktest(), "the fourth backtest exceeds a budget of three.");
		AreEqual(0, budget.RemainingBacktests);
		IsTrue(budget.IsExhausted);
	}

	/// <summary>
	/// A claim that was taken but whose work never ran must be returned, otherwise a crashed worker
	/// silently shrinks the budget of the project it crashed in.
	/// </summary>
	[TestMethod]
	public void AbandonedClaimIsReturned()
	{
		var budget = Small();

		IsTrue(budget.TryClaimBacktest());
		AreEqual(2, budget.RemainingBacktests);

		budget.ReleaseBacktest();
		AreEqual(3, budget.RemainingBacktests);
	}

	/// <summary>Releasing more than was claimed would invent allowance out of nothing.</summary>
	[TestMethod]
	public void ReleaseCannotExceedWhatWasClaimed()
	{
		var budget = Small();

		Throws<InvalidOperationException>(() => budget.ReleaseBacktest());
	}

	/// <summary>Candidates are limited separately from runs, and one does not consume the other.</summary>
	[TestMethod]
	public void CandidateAndBacktestAllowancesAreIndependent()
	{
		var budget = Small();

		IsTrue(budget.TryClaimCandidate());
		AreEqual(3, budget.RemainingBacktests, "claiming a candidate must not consume a backtest.");

		IsTrue(budget.TryClaimBacktest());
		AreEqual(1, budget.RemainingCandidates, "claiming a backtest must not consume a candidate.");
	}

	/// <summary>
	/// Restoring after a restart must reproduce the state the counters had, or a crash becomes a way to
	/// obtain more budget than the project was granted (O-RCH-005).
	/// </summary>
	[TestMethod]
	public void StateSurvivesRoundTrip()
	{
		var budget = Small();

		budget.TryClaimBacktest();
		budget.TryClaimCandidate();

		var restored = ResearchBudget.Restore(budget.ToState());

		AreEqual(budget.RemainingBacktests, restored.RemainingBacktests);
		AreEqual(budget.RemainingCandidates, restored.RemainingCandidates);
		AreEqual(budget.MaxWallClock, restored.MaxWallClock);
	}

	/// <summary>A budget that permits nothing is a configuration error, not a valid budget.</summary>
	[TestMethod]
	public void LimitsMustBePositive()
	{
		Throws<ArgumentOutOfRangeException>(
			() => new ResearchBudget(maxBacktests: 0, maxCandidates: 1, maxWallClock: TimeSpan.FromMinutes(1)));

		Throws<ArgumentOutOfRangeException>(
			() => new ResearchBudget(maxBacktests: 1, maxCandidates: 1, maxWallClock: TimeSpan.Zero));
	}

	/// <summary>
	/// Claims arrive from several worker slots at once, so the counter must never hand out more than
	/// the limit no matter how the calls interleave.
	/// </summary>
	[TestMethod]
	public void ConcurrentClaimsNeverExceedTheLimit()
	{
		const int limit = 50;
		const int attempts = 500;

		var budget = new ResearchBudget(maxBacktests: limit, maxCandidates: limit, maxWallClock: TimeSpan.FromHours(1));
		var granted = 0;

		Parallel.For(0, attempts, _ =>
		{
			if (budget.TryClaimBacktest())
				Interlocked.Increment(ref granted);
		});

		AreEqual(limit, granted, "the number of granted claims must equal the limit exactly.");
		AreEqual(0, budget.RemainingBacktests);
	}
}
