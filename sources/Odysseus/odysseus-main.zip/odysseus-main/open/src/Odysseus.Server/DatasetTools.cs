namespace Odysseus.Server;

using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using ModelContextProtocol.Server;

using Odysseus.Application;
using Odysseus.Domain;

/// <summary>
/// The dataset tools an agent sees over MCP.
/// </summary>
[McpServerToolType]
public static class DatasetTools
{
	/// <summary>
	/// Imports the bundled generated dataset.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Dataset use cases.</param>
	/// <param name="projectId">Project to import into.</param>
	/// <param name="operationKey">Key that makes a repeated call return the first result.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The description of what was imported.</returns>
	[McpServerTool(Name = "import_demo_dataset")]
	[Description("Import the bundled dataset and freeze it for this project, so the whole pipeline can run " +
		"without a broker account. These bars are generated, not observed: use them to prove the machinery " +
		"works, never to judge whether a strategy is any good. Every report over them says so.")]
	public static Task<object> ImportDemoDataset(
		ToolGuard guard,
		DatasetService service,
		[Description("Identifier of the project to import into.")] string projectId,
		[Description("Caller-generated key identifying this request, reused on retries of the same intent.")] string operationKey,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(ImportDemoDataset), async ()
			=> Describe(await service.ImportDemoAsync(Ids.Project(projectId), operationKey, Actors.Agent, cancellationToken)));

	/// <summary>
	/// Reports what is in the dataset a project works against.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Dataset use cases.</param>
	/// <param name="projectId">Project to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The description of the dataset.</returns>
	[McpServerTool(Name = "get_dataset_report")]
	[Description("Report the dataset this project is frozen against: symbols, timeframe, how many bars each " +
		"symbol kept, and what was rejected — malformed bars, repeated moments, missing bars. Bad bars are " +
		"dropped rather than repaired, so a gap here is a gap in what any result can be based on.")]
	public static Task<object> GetDatasetReport(
		ToolGuard guard,
		DatasetService service,
		[Description("Identifier of the project whose dataset to describe.")] string projectId,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(GetDatasetReport), async ()
			=> Describe(await service.GetManifestAsync(Ids.Project(projectId), cancellationToken)));

	/// <summary>
	/// Describes how the data is divided in time.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Dataset use cases.</param>
	/// <param name="projectId">Project to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The disclosed part of the division.</returns>
	[McpServerTool(Name = "describe_split")]
	[Description("Describe how the history is divided: where the data starts and where development ends. " +
		"Two further slices exist, validation and a closed one, and neither boundary is disclosed - the " +
		"end of validation is where the closed slice begins, and knowing where it begins is knowing which " +
		"period to avoid fitting. Measure on validation through run_backtest; the closed slice is measured " +
		"once, for the finalist only.")]
	public static Task<object> DescribeSplit(
		ToolGuard guard,
		DatasetService service,
		[Description("Identifier of the project whose split to describe.")] string projectId,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(DescribeSplit), async () =>
		{
			var split = await service.DescribeSplitAsync(Ids.Project(projectId), cancellationToken);

			return new
			{
				developmentFrom = split.DevelopmentFrom,
				developmentTo = split.DevelopmentTo,
				sealedSlice = new
				{
					exists = split.HasSealedSlice,
					consumed = split.SealedSliceConsumed,
					note = "Boundaries are withheld until the closed slice is measured, which happens once.",
				},
			};
		});

	private static object Describe(DatasetManifest manifest)
		=> new
		{
			datasetId = manifest.Id.Value,
			source = manifest.Source,
			isSynthetic = manifest.IsSynthetic,
			warning = manifest.IsSynthetic
				? "These bars are generated. Results measured on them say nothing about any market."
				: null,
			symbols = manifest.Symbols,
			timeFrame = manifest.TimeFrame,
			records = manifest.DisclosedRecords,
			contentHash = manifest.ContentHash,
			quality = manifest.DisclosedQuality.Select(q => new
			{
				symbol = q.Symbol,
				records = q.Records,
				from = q.From,
				to = q.To,
				gaps = q.Gaps,
				duplicates = q.Duplicates,
				invalid = q.Invalid,
			}).ToArray(),
			note = "Counts and bar times cover the open part of the history only. The closed slice is " +
				"deliberately absent: stated next to the end of validation, it would be a subtraction away.",
		};
}
