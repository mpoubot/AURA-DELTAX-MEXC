namespace Odysseus.Server;

using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using ModelContextProtocol.Server;

using Odysseus.Application;
using Odysseus.Domain;

/// <summary>
/// The tools that run an accepted candidate against the paper account.
/// </summary>
[McpServerToolType]
public static class PaperTools
{
	/// <summary>
	/// Starts an accepted candidate against the paper account.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Deployment use cases.</param>
	/// <param name="projectId">Project the candidate belongs to.</param>
	/// <param name="candidateId">Candidate to deploy.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The deployment.</returns>
	[McpServerTool(Name = "deploy_candidate")]
	[Description("Run a candidate the final check accepted against the live paper account, with the same " +
		"numbers it was accepted with and a position sized by the same rule the backtests used. This is " +
		"the first thing that can contradict a backtest: a fill that never comes, a spread wider than the " +
		"one that was charged, a bar that arrives late. None of it shows up in history. The deployment " +
		"lives inside this server process and nowhere else - there is no supervisor and no restart, so if " +
		"the server stops the strategy stops with it and whatever it holds at the broker is left as it " +
		"stands. One deployment per project: two strategies on one account trade against each other's " +
		"positions and neither result means anything afterwards.")]
	public static Task<object> DeployCandidate(
		ToolGuard guard,
		DeploymentService service,
		[Description("Identifier of the project.")] string projectId,
		[Description("Identifier of the candidate.")] string candidateId,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(DeployCandidate), async () =>
		{
			var deployment = await service.StartAsync(
				Ids.Project(projectId),
				Ids.Candidate(candidateId),
				Actors.Agent,
				cancellationToken);

			return new
			{
				deploymentId = deployment.Id.Value,
				candidateId,
				symbol = deployment.Symbol,
				volume = deployment.Volume,
				status = deployment.Status.ToString(),
				startedAt = deployment.StartedAt,
				howToRead = "It is trading now. Ask get_deployment for what it has done against what was " +
					"measured of it, and stop_deployment when you have seen enough. A handful of trades " +
					"confirms nothing either way - the point is whether the two disagree, not by how much.",
			};
		});

	/// <summary>
	/// Reports what a deployment has done, next to what was measured of it.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Deployment use cases.</param>
	/// <param name="projectId">Project the deployment belongs to.</param>
	/// <param name="deploymentId">Deployment to report on.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The report.</returns>
	[McpServerTool(Name = "get_deployment")]
	[Description("What a deployment has done against the broker, next to what the accepted run said it " +
		"would do. Rates are per trading day on both sides, so a deployment up for an hour can be read " +
		"against a run measured over months. Watch two things above all: whether it trades at the rate it " +
		"was supposed to, and whether one trade comes to what one trade came to in the backtest. A " +
		"strategy that trades far less than expected is not being filled; one whose average trade is far " +
		"worse is paying costs the backtest did not charge.")]
	public static Task<object> GetDeployment(
		ToolGuard guard,
		DeploymentService service,
		[Description("Identifier of the project.")] string projectId,
		[Description("Identifier of the deployment.")] string deploymentId,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(GetDeployment), async () =>
		{
			var report = await service.GetAsync(Ids.Project(projectId), Ids.Deployment(deploymentId), cancellationToken);

			return Describe(report);
		});

	/// <summary>
	/// Lists the deployments of a project.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Deployment use cases.</param>
	/// <param name="projectId">Project to list.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The deployments, newest first.</returns>
	[McpServerTool(Name = "list_deployments")]
	[Description("Every deployment this project has had, newest first. Two things are reported about " +
		"each: what the server that started it recorded, and whether this process is actually running it. " +
		"A deployment recorded as running with no session behind it belonged to a server that went away - " +
		"nothing was stopped in an orderly fashion, so read the account for anything it left open, and " +
		"call stop_deployment to end it properly. Reading this list changes nothing.")]
	public static Task<object> ListDeployments(
		ToolGuard guard,
		DeploymentService service,
		[Description("Identifier of the project.")] string projectId,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(ListDeployments), async () =>
		{
			var deployments = await service.ListAsync(Ids.Project(projectId), cancellationToken);

			return new
			{
				deployments = deployments.Select(view => new
				{
					deploymentId = view.Deployment.Id.Value,
					candidateId = view.Deployment.Candidate.Value,
					symbol = view.Deployment.Symbol,
					recordedStatus = view.Deployment.Status.ToString(),
					status = view.EffectiveStatus.ToString(),
					session = view.SessionLive ? "live" : "absent",
					startedAt = view.Deployment.StartedAt,
					stoppedAt = view.Deployment.StoppedAt,
					lastObservedAt = view.Deployment.LastObservedAt,
					trades = view.Deployment.Trades,
					realizedProfit = view.Deployment.RealizedProfit,
					position = view.Deployment.Position,
					note = view.Deployment.Note,
				}).ToArray(),
			};
		});

	/// <summary>
	/// Stops a deployment.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Deployment use cases.</param>
	/// <param name="projectId">Project the deployment belongs to.</param>
	/// <param name="deploymentId">Deployment to stop.</param>
	/// <param name="closePosition">Whether to close what it is holding.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The deployment as it ended.</returns>
	[McpServerTool(Name = "stop_deployment")]
	[Description("Stop a deployment. Say what to do with any position it is holding: closing one places " +
		"a trade on your behalf, and leaving one open keeps money at risk with nothing watching it. " +
		"There is no safe default, which is why this asks.")]
	public static Task<object> StopDeployment(
		ToolGuard guard,
		DeploymentService service,
		[Description("Identifier of the project.")] string projectId,
		[Description("Identifier of the deployment.")] string deploymentId,
		[Description("True to close what it is holding, false to leave the position open at the broker.")] bool closePosition,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(StopDeployment), async () =>
		{
			var deployment = await service.StopAsync(
				Ids.Project(projectId),
				Ids.Deployment(deploymentId),
				closePosition,
				Actors.Agent,
				cancellationToken);

			return new
			{
				deploymentId = deployment.Id.Value,
				status = deployment.Status.ToString(),
				stoppedAt = deployment.StoppedAt,
				trades = deployment.Trades,
				realizedProfit = deployment.RealizedProfit,
				position = deployment.Position,
				note = deployment.Note,
			};
		});

	/// <summary>
	/// Reads what the paper account itself holds.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="account">The account, as the broker reports it.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The account, its holdings and its live orders.</returns>
	[McpServerTool(Name = "get_paper_account_state")]
	[Description("Read the paper account itself: whether it may trade, what it can buy with, everything " +
		"it is holding and every order it has live. This is the broker talking, not this server - every " +
		"other number about a deployment is what this product recorded while it was watching, and a " +
		"deployment left by a server that went away has been recording nothing since. Read this before " +
		"starting anything, and after anything ends unexpectedly. It only reads; closing a position is " +
		"not something this server does on your behalf.")]
	public static Task<object> GetPaperAccountState(
		ToolGuard guard,
		IPaperAccount account,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(GetPaperAccountState), async () =>
		{
			var state = await account.ReadAsync(cancellationToken);

			return new
			{
				schemaVersion = 1,
				observedAt = state.ObservedAt,
				broker = state.Broker,
				paperOnly = true,
				account = new
				{
					isAccountActive = state.Account.IsAccountActive,
					isTradingBlocked = state.Account.IsTradingBlocked,
					buyingPower = state.Account.BuyingPower,
					currency = state.Account.Currency,
				},
				positions = state.Positions.Select(p => new
				{
					symbol = p.Symbol,
					quantity = p.Quantity,
					averageEntryPrice = p.AverageEntryPrice,
					marketValue = p.MarketValue,
					unrealizedProfit = p.UnrealizedProfit,
				}).ToArray(),
				orders = state.Orders.Select(o => new
				{
					clientOrderId = o.ClientOrderId,
					brokerOrderId = o.BrokerOrderId,
					symbol = o.Symbol,
					side = o.Side,
					orderType = o.OrderType,
					quantity = o.Quantity,
					filledQuantity = o.FilledQuantity,
					limitPrice = o.LimitPrice,
					timeInForce = o.TimeInForce,
					status = o.Status,
					submittedAt = o.SubmittedAt,
					filledAveragePrice = o.FilledAveragePrice,
				}).ToArray(),
			};
		});

	private static object Describe(DeploymentReport report)
	{
		var d = report.Deployment;

		return new
		{
			deploymentId = d.Id.Value,
			candidateId = d.Candidate.Value,
			symbol = d.Symbol,
			volume = d.Volume,
			sizedAgainstEquity = BacktestService.StartingEquity,
			recordedStatus = d.Status.ToString(),
			status = report.EffectiveStatus.ToString(),
			session = report.SessionLive ? "live" : "absent",
			startedAt = d.StartedAt,
			stoppedAt = d.StoppedAt,
			lastObservedAt = d.LastObservedAt,
			tradingDays = report.TradingDays,
			observed = new
			{
				ordersPlaced = d.OrdersPlaced,
				trades = d.Trades,
				realizedProfit = d.RealizedProfit,
				position = d.Position,
				tradesPerDay = report.ObservedTradesPerDay,
				averageTrade = report.ObservedAverageTrade,
			},
			expected = new
			{
				tradesPerDay = report.ExpectedTradesPerDay,
				averageTrade = report.ExpectedAverageTrade,
			},
			note = d.Note,
			howToRead = "Expected comes from the run on the closed data, per trading day of market it " +
				"covered. Observed is what the broker reported, counted over the time something was " +
				"watching it rather than over the wall clock - 'lastObservedAt' says when that was. Read " +
				"the rates before the money: a deployment that has not traded yet says nothing at all, and " +
				"one trade says nothing much. The size was worked out against " +
				"'sizedAgainstEquity', which is the equity every backtest of this product assumes; if the " +
				"account holds less, the position is a larger share of it than the specification asked for.",
		};
	}
}
