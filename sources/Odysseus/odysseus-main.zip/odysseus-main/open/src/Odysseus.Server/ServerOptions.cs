namespace Odysseus.Server;

using System;
using System.IO;
using System.Linq;

using Odysseus.Application;

/// <summary>
/// How this instance was started.
/// </summary>
/// <param name="Mode">Local on the user's machine, or hosted for strangers.</param>
/// <param name="ProjectsRoot">Directory the projects live in.</param>
/// <param name="Broker">Broker credentials, when any were supplied.</param>
public sealed record ServerOptions(ServerModes Mode, string ProjectsRoot, BrokerCredentials Broker)
{
	private const string RootVariable = "ODYSSEUS_PROJECTS_ROOT";

	/// <summary>Whether a broker is configured at all.</summary>
	public bool HasBroker => Broker is not null;

	/// <summary>
	/// Reads the options from the command line and the environment.
	/// </summary>
	/// <param name="args">Command line arguments.</param>
	/// <returns>The options.</returns>
	public static ServerOptions Read(string[] args)
	{
		ArgumentNullException.ThrowIfNull(args);

		// The mode decides what the server will accept, so it is a start-up decision and deliberately
		// not reachable from any tool: an agent cannot talk its way into the permissive profile.
		var mode = args.Contains("--hosted", StringComparer.OrdinalIgnoreCase)
			? ServerModes.Hosted
			: ServerModes.Local;

		var root = Environment.GetEnvironmentVariable(RootVariable);

		if (string.IsNullOrWhiteSpace(root))
			root = Path.Combine(Directory.GetCurrentDirectory(), "projects");

		return new(mode, Path.GetFullPath(root), BrokerCredentials.ReadEnvironment());
	}
}
