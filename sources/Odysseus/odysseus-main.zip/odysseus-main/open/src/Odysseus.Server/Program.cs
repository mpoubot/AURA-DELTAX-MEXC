namespace Odysseus.Server;

using System;
using System.Threading.Tasks;

using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

using Odysseus.Application;
using Odysseus.Compiler;
using Odysseus.Domain;
using Odysseus.Engine;
using Odysseus.Persistence;

/// <summary>
/// Entry point of the Odysseus MCP server.
/// </summary>
public static class Program
{
	/// <summary>
	/// Starts the server and serves until the client disconnects.
	/// </summary>
	/// <param name="args">Command line arguments.</param>
	/// <returns>Process exit code.</returns>
	public static async Task<int> Main(string[] args)
	{
		var options = ServerOptions.Read(args);

		var builder = Host.CreateApplicationBuilder(args);

		// Standard output carries MCP protocol frames, so every human-readable line goes to standard
		// error. A single stray write to stdout corrupts the session for good.
		builder.Logging.ClearProviders();
		builder.Logging.AddConsole(console => console.LogToStandardErrorThreshold = LogLevel.Trace);

		builder.Services.AddSingleton(options);
		builder.Services.AddSingleton<ToolGuard>();
		builder.Services.AddSingleton<IClock, SystemClock>();
		builder.Services.AddSingleton(_ => new SqliteProjectStore(options.ProjectsRoot));
		builder.Services.AddSingleton<IProjectStore>(services => services.GetRequiredService<SqliteProjectStore>());
		builder.Services.AddSingleton<IAuditLog>(services => services.GetRequiredService<SqliteProjectStore>());
		builder.Services.AddSingleton<IOperationLog>(_ => new SqliteOperationLog(options.ProjectsRoot));

		// Beside the projects rather than inside one: a project cannot be the keeper of a rule whose only
		// way round is to start another project.
		builder.Services.AddSingleton<IClosedHistoryLedger>(_ => new SqliteClosedHistoryLedger(options.ProjectsRoot));
		builder.Services.AddSingleton<IArtifactStore>(_ => new FileArtifactStore(options.ProjectsRoot));
		builder.Services.AddSingleton<IDatasetStore>(services => new FileDatasetStore(
			options.ProjectsRoot,
			services.GetRequiredService<IArtifactStore>()));
		builder.Services.AddSingleton<ISpecStore>(_ => new FileSpecStore(options.ProjectsRoot));
		builder.Services.AddSingleton<ICompletedStore>(_ => new FileCompletedStore(options.ProjectsRoot));
		builder.Services.AddSingleton<ICandidateStore>(services => services.GetRequiredService<SqliteProjectStore>());
		builder.Services.AddSingleton<IRunStore>(services => services.GetRequiredService<SqliteProjectStore>());
		builder.Services.AddSingleton<IEvaluationStore>(services => services.GetRequiredService<SqliteProjectStore>());
		builder.Services.AddSingleton<IBacktestRunner, EmulatedBacktestRunner>();
		builder.Services.AddSingleton<IStrategyOptimizer, GeneticStrategyOptimizer>();

		// The engine names the assemblies a strategy is written against; the compiler is told, so that it
		// never has to know which engine is in use.
		builder.Services.AddSingleton<IStrategyBuilder>(_ => new StrategyBuilder(EngineAssemblies.Paths()));

		// The broker is optional, and the services that hold one are built either way. Registering them
		// only when credentials exist looks tidier and is worse: the tools that take them then fail while
		// their arguments are being bound, before any code of ours runs, and the agent is told only that
		// something went wrong invoking a tool. With a stand-in the call reaches our code, which answers
		// that this server has no account and says what still works without one.
		if (options.Broker is not null)
		{
			if (options.Broker.Kind == BrokerKinds.Alpaca)
			{
				builder.Services.AddSingleton<IHistorySource>(_ => new AlpacaHistorySource(
					options.Broker.KeyId,
					options.Broker.Secret));

				// The single-exchange feed for the live session: the consolidated stream is sold apart from
				// the history and an account without it never finishes connecting.
				builder.Services.AddSingleton(_ => new AlpacaPaperTrader(
					options.Broker.KeyId,
					options.Broker.Secret));

				builder.Services.AddSingleton<IPaperTrader>(services => services.GetRequiredService<AlpacaPaperTrader>());
				builder.Services.AddSingleton<IPaperAccount>(services => services.GetRequiredService<AlpacaPaperTrader>());
			}
			else
			{
				builder.Services.AddSingleton<IHistorySource>(_ => new BinanceHistorySource(
					options.Broker.KeyId,
					options.Broker.Secret));
				builder.Services.AddSingleton(_ => new BinancePaperTrader(
					options.Broker.KeyId,
					options.Broker.Secret));
				builder.Services.AddSingleton<IPaperTrader>(services => services.GetRequiredService<BinancePaperTrader>());
				builder.Services.AddSingleton<IPaperAccount>(services => services.GetRequiredService<BinancePaperTrader>());
			}
		}
		else
		{
			builder.Services.AddSingleton(new BrokerNotConfigured());
			builder.Services.AddSingleton<IHistorySource>(services => services.GetRequiredService<BrokerNotConfigured>());
			builder.Services.AddSingleton<IPaperTrader>(services => services.GetRequiredService<BrokerNotConfigured>());
			builder.Services.AddSingleton<IPaperAccount>(services => services.GetRequiredService<BrokerNotConfigured>());
		}

		builder.Services.AddSingleton(services => new HistoryService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<IDatasetStore>(),
			services.GetRequiredService<IHistorySource>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IOperationLog>(),
			services.GetRequiredService<IClock>()));

		builder.Services.AddSingleton<IDeploymentStore>(services => services.GetRequiredService<SqliteProjectStore>());

		builder.Services.AddSingleton(services => new DeploymentService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<ICandidateStore>(),
			services.GetRequiredService<ISpecStore>(),
			services.GetRequiredService<IDatasetStore>(),
			services.GetRequiredService<IArtifactStore>(),
			services.GetRequiredService<IRunStore>(),
			services.GetRequiredService<IDeploymentStore>(),
			services.GetRequiredService<IPaperTrader>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IClock>()));

		builder.Services.AddSingleton(services => new ProjectService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IOperationLog>(),
			services.GetRequiredService<IClock>(),
			options.Mode,
			DefaultBudget));
		builder.Services.AddSingleton(services => new DatasetService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<IDatasetStore>(),
			services.GetRequiredService<IRunStore>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IOperationLog>(),
			services.GetRequiredService<IClock>()));
		builder.Services.AddSingleton(services => new CandidateService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<ISpecStore>(),
			services.GetRequiredService<ICandidateStore>(),
			services.GetRequiredService<IArtifactStore>(),
			services.GetRequiredService<IStrategyBuilder>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IOperationLog>(),
			services.GetRequiredService<IClock>()));
		builder.Services.AddSingleton(services => new BacktestService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<ICandidateStore>(),
			services.GetRequiredService<ISpecStore>(),
			services.GetRequiredService<IDatasetStore>(),
			services.GetRequiredService<IRunStore>(),
			services.GetRequiredService<IArtifactStore>(),
			services.GetRequiredService<IBacktestRunner>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IOperationLog>(),
			services.GetRequiredService<IClock>()));
		builder.Services.AddSingleton(services => new OptimizationService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<ICandidateStore>(),
			services.GetRequiredService<ISpecStore>(),
			services.GetRequiredService<IDatasetStore>(),
			services.GetRequiredService<IArtifactStore>(),
			services.GetRequiredService<IStrategyOptimizer>(),
			services.GetRequiredService<BacktestService>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IOperationLog>(),
			services.GetRequiredService<IClock>()));
		builder.Services.AddSingleton(services => new EvaluationService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<ICandidateStore>(),
			services.GetRequiredService<ISpecStore>(),
			services.GetRequiredService<IEvaluationStore>(),
			services.GetRequiredService<BacktestService>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IClock>()));
		builder.Services.AddSingleton(services => new ClosedDataService(
			services.GetRequiredService<ICandidateStore>(),
			services.GetRequiredService<ISpecStore>(),
			services.GetRequiredService<IRunStore>(),
			services.GetRequiredService<IEvaluationStore>(),
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<IDatasetStore>(),
			services.GetRequiredService<IClosedHistoryLedger>(),
			services.GetRequiredService<BacktestService>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IClock>()));
		builder.Services.AddSingleton(services => new CompletionService(
			services.GetRequiredService<ICandidateStore>(),
			services.GetRequiredService<ISpecStore>(),
			services.GetRequiredService<IRunStore>(),
			services.GetRequiredService<IEvaluationStore>(),
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<IDatasetStore>(),
			services.GetRequiredService<IArtifactStore>(),
			services.GetRequiredService<ICompletedStore>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IClock>()));
		builder.Services.AddSingleton(services => new SpecService(
			services.GetRequiredService<IProjectStore>(),
			services.GetRequiredService<ISpecStore>(),
			services.GetRequiredService<IAuditLog>(),
			services.GetRequiredService<IOperationLog>(),
			services.GetRequiredService<IClock>()));

		builder.Services
			.AddMcpServer()
			.WithStdioServerTransport()
			.WithToolsFromAssembly();

		Console.Error.WriteLine(
			$"Odysseus {ServerVersion.Current} [{options.Mode}] projects at {options.ProjectsRoot}, " +
			(options.HasBroker
				? $"{options.Broker.Kind} configured (paper/testnet trading only)"
				: "no broker: downloading and paper trading are unavailable"));

		await builder.Build().RunAsync();

		return 0;
	}

	// The ceiling a project starts with. It is held by the server because the research loop is driven by
	// an agent, and an agent has no reason to stop on its own.
	//
	// The count of backtests is what it is because a parameter search is one step that costs fifty of
	// them. A handful of candidates, each searched and then put through the six runs a verdict needs,
	// is what this allows — and then it stops.
	private static ResearchBudgetState DefaultBudget
		=> new ResearchBudget(maxBacktests: 400, maxCandidates: 40, maxWallClock: TimeSpan.FromMinutes(45)).ToState();
}
