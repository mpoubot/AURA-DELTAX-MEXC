namespace Odysseus.Server;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using ModelContextProtocol.Server;

using Odysseus.Application;
using Odysseus.Domain;

/// <summary>
/// The project tools an agent sees over MCP.
/// </summary>
/// <remarks>
/// This layer only translates arguments and shapes answers. Everything worth testing lives in
/// <see cref="ProjectService"/>, so the behaviour can be exercised without a transport, and a tool
/// stays short enough to read in one go.
/// </remarks>
[McpServerToolType]
public static class ProjectTools
{
	/// <summary>
	/// Reports what the server is and what it will accept.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Project use cases.</param>
	/// <param name="options">How this instance was started.</param>
	/// <returns>The description of the running server.</returns>
	[McpServerTool(Name = "describe_server")]
	[Description("Report the server version, the mode it runs in, whether a broker account is configured, " +
		"whether hand-written source is accepted, whether the security analyzers are enforced, and the " +
		"largest response any tool returns inline. Call this first: what the server accepts depends on " +
		"how it was started, not on what you ask for.")]
	public static Task<object> DescribeServer(ToolGuard guard, ProjectService service, ServerOptions options)
		=> guard.Run(nameof(DescribeServer), () =>
	{
		var description = service.Describe(ServerVersion.Current);

		return (object)new
		{
			product = description.Product,
			version = description.Version,
			mode = description.Mode.ToString(),

			// Which half of the product is available. Without it the only way to find out is to be
			// refused by a tool, which is a discovery an agent makes after choosing a plan around it.
			hasBroker = options.HasBroker,
			broker = options.Broker?.Kind.ToString().ToLowerInvariant(),
			paperOnly = true,
			whatNeedsABroker = "import_history downloads real history; deploy_candidate and " +
				"get_paper_account_state reach the account. Everything else - import_demo_dataset, " +
				"analyze_market, the backtests, evaluate_candidate, measure_on_closed_data, " +
				"complete_strategy - works on history that is already frozen.",
			acceptsHandWrittenSource = description.AcceptsHandWrittenSource,
			securityAnalyzersEnforced = description.SecurityAnalyzersEnforced,
			maxResponseBytes = description.MaxResponseBytes,
		};
	});

	/// <summary>
	/// Creates a research project.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Project use cases.</param>
	/// <param name="name">Name for the project.</param>
	/// <param name="operationKey">Key that makes a repeated call return the first result.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The created project.</returns>
	[McpServerTool(Name = "create_project")]
	[Description("Create a research project. Pass an operationKey you generate once per intent: repeating a " +
		"call with the same key returns the project the first call created instead of making a second one, " +
		"which is what makes a retry after a dropped connection safe.")]
	public static Task<object> CreateProject(
		ToolGuard guard,
		ProjectService service,
		[Description("Name for the project, as a person would write it.")] string name,
		[Description("Caller-generated key identifying this request, reused on retries of the same intent.")] string operationKey,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(CreateProject), async ()
			=> Describe(await service.CreateProjectAsync(name, operationKey, Actors.Agent, cancellationToken)));

	/// <summary>
	/// Lists the projects on this server.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Project use cases.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The projects, most recently changed first.</returns>
	[McpServerTool(Name = "list_projects")]
	[Description("List the research projects on this server, most recently changed first.")]
	public static Task<object> ListProjects(ToolGuard guard, ProjectService service, CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(ListProjects), async () =>
		{
			var projects = await service.ListProjectsAsync(cancellationToken);

			return new { projects = projects.Select(Describe).ToArray() };
		});

	/// <summary>
	/// Reads the state of one project.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Project use cases.</param>
	/// <param name="projectId">Project to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The project.</returns>
	[McpServerTool(Name = "get_project_state")]
	[Description("Read one project: its name, status, frozen dataset if any, and how much of its research " +
		"budget is left. The budget is a server-side ceiling, so check it before planning a long search.")]
	public static Task<object> GetProjectState(
		ToolGuard guard,
		ProjectService service,
		[Description("Identifier returned by create_project or list_projects.")] string projectId,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(GetProjectState), async ()
			=> Describe(await service.OpenProjectAsync(Ids.Project(projectId), cancellationToken)));

	/// <summary>
	/// Renames a project.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Project use cases.</param>
	/// <param name="projectId">Project to rename.</param>
	/// <param name="name">New name.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The renamed project.</returns>
	[McpServerTool(Name = "rename_project")]
	[Description("Rename a project. The previous name is kept in the audit trail.")]
	public static Task<object> RenameProject(
		ToolGuard guard,
		ProjectService service,
		[Description("Identifier of the project to rename.")] string projectId,
		[Description("New name for the project.")] string name,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(RenameProject), async ()
			=> Describe(await service.RenameProjectAsync(Ids.Project(projectId), name, Actors.Agent, cancellationToken)));

	/// <summary>
	/// Reads the permanent record of a project.
	/// </summary>
	/// <param name="guard">Turns a failure into the published error shape.</param>
	/// <param name="service">Project use cases.</param>
	/// <param name="projectId">Project to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The audit entries, oldest first.</returns>
	[McpServerTool(Name = "get_audit_log")]
	[Description("Read the permanent record of a project: what happened, who caused it — user, agent or the " +
		"server itself — and when. Entries are append-only and their sequence has no gaps, so a missing " +
		"step is visible.")]
	public static Task<object> GetAuditLog(
		ToolGuard guard,
		ProjectService service,
		[Description("Identifier of the project whose record to read.")] string projectId,
		CancellationToken cancellationToken)
		=> guard.RunAsync(nameof(GetAuditLog), async () =>
		{
			var trail = await service.ReadAuditAsync(Ids.Project(projectId), cancellationToken);

			return new
			{
				events = trail.Select(e => new
				{
					sequence = e.Sequence,
					type = e.Type.ToString(),
					actor = e.Actor.ToString(),
					occurredAt = e.OccurredAt,
					detail = e.Detail,
					payloadHash = e.PayloadHash,
				}).ToArray(),
			};
		});

	private static object Describe(ResearchProject project)
		=> new
		{
			projectId = project.Id.Value,
			name = project.Name,
			status = project.Status.ToString(),
			createdAt = project.CreatedAt,
			updatedAt = project.UpdatedAt,
			dataset = project.Dataset.IsEmpty ? null : project.Dataset.Value,
			budget = new
			{
				backtestsRemaining = project.Budget.MaxBacktests - project.Budget.ClaimedBacktests,
				backtestsTotal = project.Budget.MaxBacktests,
				candidatesRemaining = project.Budget.MaxCandidates - project.Budget.ClaimedCandidates,
				candidatesTotal = project.Budget.MaxCandidates,
			},
		};
}
