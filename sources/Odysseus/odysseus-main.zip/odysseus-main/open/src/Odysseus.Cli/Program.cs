namespace Odysseus.Cli;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Application;
using Odysseus.Cli.Console;
using Odysseus.Domain;
using Odysseus.Spec;

using Con = System.Console;

/// <summary>
/// The command line over the same research the MCP server exposes.
/// </summary>
/// <remarks>
/// One set of services, two ways in. The MCP server answers an agent in JSON; this answers a person in
/// columns. Nothing here computes anything of its own - a number printed by a command is the number the
/// same call would return over the protocol, which is what makes the two worth having side by side.
/// </remarks>
public static class Program
{
	/// <summary>
	/// Runs one command.
	/// </summary>
	/// <param name="args">Command and its arguments.</param>
	/// <returns>Process exit code.</returns>
	public static async Task<int> Main(string[] args)
	{
		Con.OutputEncoding = System.Text.Encoding.UTF8;

		Ui.UseColour(Environment.GetEnvironmentVariable("NO_COLOR") is null);

		if (args.Length == 0 || args[0] is "help" or "--help" or "-h")
		{
			Usage();
			return 0;
		}

		using var workspace = Workspace.Open();

		try
		{
			return args[0] switch
			{
				"projects" => await Projects(workspace),
				"new" => await New(workspace, Rest(args)),
				"import" => await Import(workspace, Rest(args)),
				"demo" => await Demo(workspace),
				"analyze" => await Analyze(workspace, Rest(args)),
				"propose" => await Propose(workspace, Rest(args)),
				"build" => await Build(workspace, Rest(args)),
				"backtest" => await Backtest(workspace, Rest(args)),
				"explain" => await Explain(workspace, Rest(args)),
				"runs" => await Runs(workspace, Rest(args)),
				"measure" => await Measure(workspace, Rest(args)),
				"closed" => await Closed(workspace),
				"complete" => await Complete(workspace, Rest(args)),
				"completed" => await CompletedList(workspace),
				_ => Unknown(args[0]),
			};
		}
		catch (Exception error)
		{
			Ui.Blank();
			Ui.Refuse(error.Message);
			Ui.Blank();

			return 1;
		}
	}

	private static string[] Rest(string[] args) => [.. args.Skip(1)];

	private static int Unknown(string command)
	{
		Ui.Refuse($"There is no command '{command}'.");
		Usage();

		return 1;
	}

	private static void Usage()
	{
		Ui.Title("odysseus", "research from the command line");
		Ui.Blank();

		Ui.Table(
			["command", "what it does"],
			[
				["projects", "list the projects on this machine"],
				["new <name>", "start a project"],
				["import <symbol> [days] [tf]", "download real history and freeze it"],
				["analyze [symbol]", "measure what the history holds"],
				["propose <file.json>", "record a hypothesis"],
				["build", "turn it into a StockSharp strategy and compile"],
				["backtest [symbol]", "run it and measure"],
				["explain [run]", "cut the result apart"],
				["runs", "list what has been run"],
				["measure [symbol]", "the six runs, reported side by side"],
				["closed", "spend the one measurement on the closed history"],
				["complete <why>", "call it finished and keep it"],
				["completed", "what this project has been finished with"],
			]);

		Ui.Blank();
		Ui.Aside("  A project is remembered between commands, so the symbol and the identifiers are optional.");
		Ui.Aside("  ODYSSEUS_PROJECTS_ROOT locates projects; ODYSSEUS_BROKER selects alpaca or binance.");
		Ui.Aside("  Point ODYSSEUS_ALPACA_KEYS or ODYSSEUS_BINANCE_KEYS at the matching key file.");
		Ui.Blank();
	}

	private static async Task<int> Projects(Workspace workspace)
	{
		var projects = await workspace.Projects.ListProjectsAsync(CancellationToken.None);

		Ui.Title("projects", workspace.Root);

		if (projects.Count == 0)
		{
			Ui.Blank();
			Ui.Aside("  Nothing here yet. Start one with: odysseus new \"my study\"");
			Ui.Blank();

			return 0;
		}

		Ui.Blank();
		Ui.Table(
			["id", "name", "status", "changed"],
			[.. projects.Select(p => new[]
			{
				p.Id.Value,
				p.Name,
				p.Status.ToString(),
				p.UpdatedAt.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture),
			})]);

		Ui.Blank();

		return 0;
	}

	private static async Task<int> New(Workspace workspace, string[] args)
	{
		var name = args.Length > 0 ? string.Join(' ', args) : "study";

		var project = await workspace.Projects.CreateProjectAsync(
			name, Guid.NewGuid().ToString("n"), Actors.User, CancellationToken.None);

		workspace.Remember(project.Id);

		Ui.Title("project", project.Id.Value);
		Ui.Blank();
		Ui.Figures(
			("name", project.Name),
			("status", project.Status.ToString()),
			("backtests", project.Budget.MaxBacktests.ToString(CultureInfo.InvariantCulture)),
			("candidates", project.Budget.MaxCandidates.ToString(CultureInfo.InvariantCulture)));
		Ui.Blank();

		return 0;
	}

	private static async Task<int> Import(Workspace workspace, string[] args)
	{
		var symbol = args.Length > 0 ? args[0] : throw new ArgumentException("Name a symbol: odysseus import NVDA");
		var days = args.Length > 1 ? int.Parse(args[1], CultureInfo.InvariantCulture) : 90;
		var frame = args.Length > 2 ? Frame(args[2]) : TimeSpan.FromMinutes(5);

		var project = workspace.Current();
		var to = DateTime.SpecifyKind(DateTime.UtcNow.Date.AddDays(-1), DateTimeKind.Utc);

		Ui.Title("import", $"{symbol} · {frame:hh\\:mm} · {days} days");
		Ui.Blank();
		Ui.Aside("  asking the broker…");

		var manifest = await workspace.HistoryService.ImportAsync(
			project, [symbol], frame, to.AddDays(-days), to,
			Guid.NewGuid().ToString("n"), Actors.User, CancellationToken.None);

		var quality = manifest.DisclosedQuality[0];

		Ui.Blank();
		Ui.Table(
			["symbol", "bars", "from", "to", "gaps", "duplicates", "malformed"],
			[[
				quality.Symbol,
				quality.Records.ToString("N0", CultureInfo.InvariantCulture),
				quality.From.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
				quality.To.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
				quality.Gaps.ToString(CultureInfo.InvariantCulture),
				quality.Duplicates.ToString(CultureInfo.InvariantCulture),
				quality.Invalid.ToString(CultureInfo.InvariantCulture),
			]],
			1, 4, 5, 6);

		Ui.Blank();
		Ui.Aside($"  frozen as {manifest.Id.Value}  ·  content {manifest.ContentHash[..16]}…  ·  from {manifest.Source}");
		Ui.Aside("  The bars are kept exactly as they arrived, so every later run sees the same data.");
		Ui.Blank();

		return 0;
	}

	private static async Task<int> Demo(Workspace workspace)
	{
		var project = workspace.Current();

		var manifest = await workspace.Datasets.ImportDemoAsync(
			project, Guid.NewGuid().ToString("n"), Actors.User, CancellationToken.None);

		Ui.Title("demo data", "generated, not observed");
		Ui.Blank();

		Ui.Table(
			["symbol", "bars", "from", "to", "gaps"],
			[.. manifest.DisclosedQuality.Select(q => new[]
			{
				q.Symbol,
				q.Records.ToString("N0", CultureInfo.InvariantCulture),
				q.From.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
				q.To.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
				q.Gaps.ToString(CultureInfo.InvariantCulture),
			})],
			1, 4);

		Ui.Blank();
		Ui.Aside("  ! These bars were generated. A result measured on them says nothing about any market.");
		Ui.Blank();

		return 0;
	}

	private static async Task<int> Analyze(Workspace workspace, string[] args)
	{
		var project = workspace.Current();
		var profile = await workspace.HistoryService.AnalyseAsync(
			project, args.Length > 0 ? args[0] : null, CancellationToken.None);

		var c = profile.Coverage;
		var m = profile.Movement;
		var p = profile.Persistence;
		var e = profile.Edge;

		Ui.Title("market", $"{c.Symbol} · {c.Bars:N0} bars · {c.Sessions} sessions");
		Ui.Blank();

		Ui.Figures(
			("bar range, median", Ui.Number(m.MedianBarRangePercent) + " %"),
			("day range, median", Ui.Number(m.MedianDailyRangePercent) + " %"),
			("volatility, annual", Ui.Number(m.AnnualisedVolatilityPercent) + " %"),
			("volume, median bar", c.MedianVolume.ToString("N0", CultureInfo.InvariantCulture)));

		Ui.Blank();
		Ui.Say("  does it keep going, or come back?");
		Ui.Blank();

		Ui.Table(
			["measure", "value", "reads as"],
			[
				["variance ratio, 5 bars", Ui.Number(p.VarianceRatio5), Reads(p.VarianceRatio5)],
				["variance ratio, 20 bars", Ui.Number(p.VarianceRatio20), Reads(p.VarianceRatio20)],
				["autocorrelation, 1 bar", Ui.Number(p.Autocorrelation1, 3), "how much one bar says about the next"],
				["directional days", Ui.Number(p.DirectionalDayShare, 1) + " %", "days that went one way and stayed"],
			],
			1);

		Ui.Blank();
		Ui.Say("  what followed the events");
		Ui.Blank();

		Ui.Table(
			["event", "times", "next 5 bars", "still up after"],
			[
				["breakout", e.BreakoutCount.ToString(CultureInfo.InvariantCulture), Ui.Signed(e.BreakoutFollowThroughPercent) + " %", Ui.Number(e.BreakoutPositiveShare, 1) + " %"],
				["breakdown", e.BreakdownCount.ToString(CultureInfo.InvariantCulture), Ui.Signed(e.BreakdownFollowThroughPercent) + " %", ""],
				["stretched past 2σ", e.StretchCount.ToString(CultureInfo.InvariantCulture), Ui.Signed(e.StretchReversionPercent) + " %", ""],
			],
			1, 2, 3);

		Ui.Blank();
		Ui.Say("  where the session sits");
		Ui.Blank();

		Ui.Table(
			["part", "of the range", "of the volume", "average move"],
			[.. profile.Session.Select(s => new[]
			{
				s.Bucket,
				Ui.Number(s.ShareOfRange, 1) + " %",
				Ui.Number(s.ShareOfVolume, 1) + " %",
				Ui.Signed(s.AverageReturnPercent) + " %",
			})],
			1, 2, 3);

		if (profile.Caveats.Count > 0)
		{
			Ui.Blank();

			foreach (var caveat in profile.Caveats)
				Ui.Aside("  ! " + caveat);
		}

		Ui.Blank();
		Ui.Aside("  Numbers only. What they mean about a hypothesis is not this program's to say.");
		Ui.Blank();

		return 0;
	}

	// A run with no losing trade has no ratio to report, which is a fact rather than a blank.
	private static string Factor(decimal? factor)
		=> factor is null ? "no losses" : Ui.Number(factor.Value);

	private static string Reads(decimal ratio)
		=> ratio > 1.05m ? "moves extend" : ratio < 0.95m ? "moves come back" : "no memory at this horizon";

	private static async Task<int> Propose(Workspace workspace, string[] args)
	{
		if (args.Length == 0)
			throw new ArgumentException("Name a file: odysseus propose hypothesis.json");

		var json = await File.ReadAllTextAsync(args[0], CancellationToken.None);
		var project = workspace.Current();

		var check = SpecValidator.Validate(SpecJson.Read(json));

		if (!check.IsValid)
		{
			Ui.Title("hypothesis", "refused");
			Ui.Blank();
			Ui.Table(
				["where", "what is wrong", "what would fix it"],
				[.. check.Problems.Select(p => new[] { p.Path, p.Message, p.Remedy })]);
			Ui.Blank();

			return 1;
		}

		var revision = await workspace.Specs.ProposeAsync(
			project, json, Guid.NewGuid().ToString("n"), Actors.User, CancellationToken.None);

		workspace.RememberSpec(revision.Id);

		Ui.Title("hypothesis", $"revision {revision.Revision}");
		Ui.Blank();
		Ui.Figures(("id", revision.Id.Value), ("hash", revision.Hash[..16] + "…"));
		Ui.Blank();

		return 0;
	}

	private static async Task<int> Build(Workspace workspace, string[] args)
	{
		var project = workspace.Current();
		var spec = args.Length > 0 ? SpecId.Parse(args[0]) : workspace.CurrentSpec();

		Ui.Title("build", "translating and compiling");

		var candidate = await workspace.Candidates.BuildAsync(
			project, spec, Guid.NewGuid().ToString("n"), Actors.User, CancellationToken.None);

		workspace.RememberCandidate(candidate.Id);

		Ui.Blank();
		Ui.Figures(
			("class", candidate.ClassName),
			("status", candidate.Status.ToString()),
			("translator", candidate.TranslatorVersion),
			("source", candidate.SourceHash[..12] + "…"));

		Ui.Blank();
		Ui.Aside("  An ordinary StockSharp strategy: odysseus source shows the C# it compiled.");
		Ui.Blank();

		return 0;
	}

	private static async Task<int> Backtest(Workspace workspace, string[] args)
	{
		var project = workspace.Current();
		var candidate = workspace.CurrentCandidate();
		var symbol = args.Length > 0 ? args[0] : null;

		Ui.Title("backtest", "development slice, baseline costs");
		Ui.Blank();
		Ui.Aside("  running…");

		var (run, _) = await workspace.Backtests.RunAsync(
			project, candidate, DataSlices.Development, RunWindow.Whole, symbol, CostScenario.Baseline,
			null, Guid.NewGuid().ToString("n"), Actors.User, CancellationToken.None);

		workspace.RememberRun(run.Id);

		if (run.Status != RunStatuses.Completed)
		{
			Ui.Blank();
			Ui.Refuse(run.Error);
			Ui.Blank();

			return 1;
		}

		var m = run.Metrics;

		Ui.Blank();
		Ui.Figures(
			("bars", run.BarsProcessed.ToString("N0", CultureInfo.InvariantCulture)),
			("trades", m.Trades.Count.ToString(CultureInfo.InvariantCulture)),
			("won", Ui.Number(m.Trades.WinRatePercent, 1) + " %"),
			("held, average", Ui.Number(m.Trades.AverageHoldingMinutes, 0) + " min"));

		Ui.Blank();
		Ui.Table(
			["", "before costs", "after costs"],
			[
				["profit", Ui.Signed(m.Gross.Profit), Ui.Signed(m.Net.Profit)],
				["return", Ui.Signed(m.Gross.ReturnPercent) + " %", Ui.Signed(m.Net.ReturnPercent) + " %"],
				["profit factor", Factor(m.Gross.ProfitFactor), Factor(m.Net.ProfitFactor)],
				["one trade, average", Ui.Signed(m.Gross.AverageTrade), Ui.Signed(m.Net.AverageTrade)],
			],
			1, 2);

		Ui.Blank();
		Ui.Table(
			["charged", "amount", "what it is"],
			[
				["commission", Ui.Signed(-m.Costs.Commission), "fees, which follow the volume"],
				["spread", Ui.Signed(-m.Costs.Slippage), "crossing, which holding longer pays less often"],
			],
			1);

		Ui.Blank();

		var equity = await workspace.Backtests.ReadEquityAsync(project, run.Id, CancellationToken.None);

		Ui.Say("  account through the run");
		Ui.Blank();
		Ui.Chart([.. equity.Select(p => p.Equity)], 96, 9, BacktestService.StartingEquity);

		Ui.Blank();
		Ui.Figures(
			("drawdown, deepest", Ui.Number(m.Risk.MaxDrawdownPercent, 2) + " %"),
			("in the market", Ui.Number(m.Activity.ExposurePercent, 1) + " %"),
			("biggest trade's share", Ui.Number(m.Concentration.LargestTradeProfitSharePercent, 1) + " %"));

		if (run.Diagnosis is { Length: > 0 })
		{
			Ui.Blank();
			Ui.Aside("  " + run.Diagnosis);
		}

		Ui.Blank();
		Ui.Aside($"  {run.Id.Value}   ·   odysseus explain   cuts this apart");
		Ui.Blank();

		return 0;
	}

	private static async Task<int> Measure(Workspace workspace, string[] args)
	{
		var project = workspace.Current();
		var candidate = workspace.CurrentCandidate();
		var symbol = args.Length > 0 ? args[0] : "";

		Ui.Title("measure", "six runs: development, held out, held out under heavier costs, three windows");
		Ui.Blank();
		Ui.Aside("  running…");

		var result = await workspace.Evaluations.MeasureAsync(
			project, candidate, symbol, null, Guid.NewGuid().ToString("n"), Actors.User, CancellationToken.None);

		Ui.Blank();
		Report(result.Measurement);

		Ui.Blank();
		Ui.Aside($"  measured {result.TimesMeasured} time(s) on the open data.");
		Ui.Aside("  These are numbers, not a verdict. What they are worth is yours to decide.");
		Ui.Blank();

		return 0;
	}

	private static async Task<int> Closed(Workspace workspace)
	{
		var project = workspace.Current();
		var candidate = workspace.CurrentCandidate();

		Ui.Title("closed", "the one measurement that cannot be taken twice");
		Ui.Blank();
		Ui.Aside("  running…");

		var result = await workspace.Closed.MeasureAsync(
			project, candidate, Guid.NewGuid().ToString("n"), Actors.User, CancellationToken.None);

		var open = result.OnOpenData;
		var closed = result.Measurement;

		Ui.Blank();
		Ui.Table(
			["", "on data it saw", "on data it did not"],
			[
				["profit", Ui.Signed(open.HeldOut.Net.Profit), Ui.Signed(closed.HeldOut.Net.Profit)],
				["return", Ui.Signed(open.HeldOut.Net.ReturnPercent) + " %", Ui.Signed(closed.HeldOut.Net.ReturnPercent) + " %"],
				["deepest fall", Ui.Number(open.HeldOut.Risk.MaxDrawdownPercent, 2) + " %", Ui.Number(closed.HeldOut.Risk.MaxDrawdownPercent, 2) + " %"],
				["trades", open.HeldOut.Trades.Count.ToString(CultureInfo.InvariantCulture), closed.HeldOut.Trades.Count.ToString(CultureInfo.InvariantCulture)],
				["won", Ui.Number(open.HeldOut.Trades.WinRatePercent, 1) + " %", Ui.Number(closed.HeldOut.Trades.WinRatePercent, 1) + " %"],
				["under heavier costs", Ui.Signed(open.HeldOutStressed.Net.Profit), Ui.Signed(closed.HeldOutStressed.Net.Profit)],
			],
			1, 2);

		Ui.Blank();
		Ui.Figures(
			("windows up", $"{closed.PositiveWindows} of {closed.WalkForwardReturns.Count}"),
			("asked of the open data", result.TimesMeasuredOnOpenData.ToString(CultureInfo.InvariantCulture) + " time(s)"),
			("candidates before it", result.EarlierCandidates.ToString(CultureInfo.InvariantCulture)));

		Ui.Blank();
		Ui.Aside("  That slice is spent now. Nothing measured on it afterwards was chosen in ignorance of it.");
		Ui.Aside("  If this is the strategy, say so: odysseus complete \"why you believe it\"");
		Ui.Blank();

		return 0;
	}

	private static async Task<int> Complete(Workspace workspace, string[] args)
	{
		if (args.Length == 0 || string.IsNullOrWhiteSpace(args[0]))
		{
			Ui.Refuse("Say why you consider it finished: odysseus complete \"held up on the closed slice\"");

			return 1;
		}

		var project = workspace.Current();
		var candidate = workspace.CurrentCandidate();

		var completion = await workspace.Completions.CompleteAsync(
			project, candidate, string.Join(' ', args), Actors.User, CancellationToken.None);

		var kept = completion.Strategy;

		Ui.Title("complete", kept.Name);
		Ui.Blank();

		Ui.Figures(
			("class", kept.ClassName),
			("symbol", kept.Symbol),
			("candle", kept.TimeFrame.ToString()),
			("runs kept", kept.Runs.Count.ToString(CultureInfo.InvariantCulture)));

		Ui.Blank();
		Ui.Table(
			["kept", "what it is"],
			[
				[$"{kept.ClassName}.cs", "the strategy, as it was compiled and run"],
				["spec.json", "the hypothesis it was translated from"],
				["strategy.json", "the instrument, the numbers, the data and every run"],
			]);

		Ui.Blank();
		Ui.Say("  " + completion.Folder);
		Ui.Blank();
		Ui.Aside("  \"" + kept.Notes + "\"");
		Ui.Blank();

		return 0;
	}

	private static async Task<int> CompletedList(Workspace workspace)
	{
		var project = workspace.Current();
		var found = await workspace.Completions.ListAsync(project, CancellationToken.None);

		Ui.Title("completed", workspace.Completions.FolderOf(project));

		if (found.Count == 0)
		{
			Ui.Blank();
			Ui.Aside("  Nothing finished yet in this project.");
			Ui.Blank();

			return 0;
		}

		Ui.Blank();
		Ui.Table(
			["strategy", "symbol", "on data it did not see", "trades", "when", "why"],
			[.. found.Select(s => new[]
			{
				s.ClassName,
				s.Symbol,
				Ui.Signed(s.OnClosedData.HeldOut.Net.Profit),
				s.OnClosedData.HeldOut.Trades.Count.ToString(CultureInfo.InvariantCulture),
				s.CompletedAt.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture),
				Short(s.Notes),
			})],
			2, 3);

		Ui.Blank();

		return 0;
	}

	// A reason can be a paragraph; a column cannot.
	private static string Short(string text)
		=> text.Length <= 64 ? text : text[..63].TrimEnd() + "…";

	// The same four blocks the tool returns, laid out for a person instead of a parser.
	private static void Report(Measurement measurement)
	{
		Ui.Table(
			["", "formed on", "held out", "held out, heavier costs"],
			[
				[
					"profit",
					Ui.Signed(measurement.Development.Net.Profit),
					Ui.Signed(measurement.HeldOut.Net.Profit),
					Ui.Signed(measurement.HeldOutStressed.Net.Profit),
				],
				[
					"return",
					Ui.Signed(measurement.Development.Net.ReturnPercent) + " %",
					Ui.Signed(measurement.HeldOut.Net.ReturnPercent) + " %",
					Ui.Signed(measurement.HeldOutStressed.Net.ReturnPercent) + " %",
				],
				[
					"deepest fall",
					Ui.Number(measurement.Development.Risk.MaxDrawdownPercent, 2) + " %",
					Ui.Number(measurement.HeldOut.Risk.MaxDrawdownPercent, 2) + " %",
					Ui.Number(measurement.HeldOutStressed.Risk.MaxDrawdownPercent, 2) + " %",
				],
				[
					"trades",
					measurement.Development.Trades.Count.ToString(CultureInfo.InvariantCulture),
					measurement.HeldOut.Trades.Count.ToString(CultureInfo.InvariantCulture),
					measurement.HeldOutStressed.Trades.Count.ToString(CultureInfo.InvariantCulture),
				],
				[
					"won",
					Ui.Number(measurement.Development.Trades.WinRatePercent, 1) + " %",
					Ui.Number(measurement.HeldOut.Trades.WinRatePercent, 1) + " %",
					Ui.Number(measurement.HeldOutStressed.Trades.WinRatePercent, 1) + " %",
				],
			],
			1, 2, 3);

		Ui.Blank();
		Ui.Say("  in consecutive stretches of the part it was formed on");
		Ui.Blank();

		Ui.Table(
			["stretch", "return"],
			[.. measurement.WalkForwardReturns.Select((r, i) =>
				new[] { (i + 1).ToString(CultureInfo.InvariantCulture), Ui.Signed(r) + " %" })],
			1);

		Ui.Blank();
		Ui.Figures(
			("windows up", $"{measurement.PositiveWindows} of {measurement.WalkForwardReturns.Count}"),
			("spread between them", Ui.Number(measurement.WalkForwardSpread, 2) + " %"),
			("return per unit of fall", Ui.Number(measurement.ReturnOverDrawdown, 2)),
			("what heavier costs left", measurement.CostResilience is { } share
				? Ui.Number(share * 100m, 0) + " %"
				: "nothing to keep"));
	}

	private static async Task<int> Explain(Workspace workspace, string[] args)
	{
		var project = workspace.Current();
		var run = args.Length > 0 ? RunId.Parse(args[0]) : workspace.CurrentRun();

		var breakdown = await workspace.Backtests.ExplainAsync(project, run, CancellationToken.None);

		Ui.Title("explain", run.Value);

		Cut("month by month", breakdown.ByMonth);
		Cut("by part of the session", breakdown.ByPartOfSession);
		Cut("by how long it was held", breakdown.ByHoldingTime);
		Cut("by direction", breakdown.ByDirection);

		Ui.Blank();
		Ui.Figures(
			("without its best month", Ui.Signed(breakdown.NetWithoutBestMonth)),
			("months traded", breakdown.MonthsTraded.ToString(CultureInfo.InvariantCulture)),
			("of those, in profit", breakdown.MonthsInProfit.ToString(CultureInfo.InvariantCulture)));

		Ui.Blank();
		Ui.Aside("  Every cut is of the same trades, so each adds back up to the run.");
		Ui.Blank();

		return 0;
	}

	private static void Cut(string title, IReadOnlyList<RunSegment> segments)
	{
		if (segments.Count == 0)
			return;

		Ui.Blank();
		Ui.Say("  " + title);
		Ui.Blank();

		Ui.Table(
			["", "trades", "result", "won", "share"],
			[.. segments.Select(s => new[]
			{
				s.Name,
				s.Trades.ToString(CultureInfo.InvariantCulture),
				Ui.Signed(s.Net),
				Ui.Number(s.WinRatePercent, 1) + " %",
				s.ShareOfNetPercent == 0 ? "" : Ui.Signed(s.ShareOfNetPercent) + " %",
			})],
			1, 2, 3, 4);
	}

	private static async Task<int> Runs(Workspace workspace, string[] args)
	{
		var project = workspace.Current();
		var runs = await workspace.Backtests.ListAsync(project, default, CancellationToken.None);

		Ui.Title("runs", $"{runs.Count} recorded");
		Ui.Blank();

		if (runs.Count == 0)
		{
			Ui.Aside("  Nothing yet.");
			Ui.Blank();

			return 0;
		}

		Ui.Table(
			["id", "slice", "symbol", "costs", "trades", "net", "finished"],
			[.. runs.Select(r => new[]
			{
				r.Id.Value,
				r.Slice.ToString(),
				r.Symbol,
				r.Scenario,
				r.Metrics?.Trades.Count.ToString(CultureInfo.InvariantCulture) ?? "—",
				r.Metrics is null ? "—" : Ui.Signed(r.Metrics.Net.Profit),
				r.FinishedAt.ToString("HH:mm:ss", CultureInfo.InvariantCulture),
			})],
			4, 5);

		Ui.Blank();

		return 0;
	}

	private static TimeSpan Frame(string text)
		=> text switch
		{
			"1m" => TimeSpan.FromMinutes(1),
			"5m" => TimeSpan.FromMinutes(5),
			"15m" => TimeSpan.FromMinutes(15),
			"1h" => TimeSpan.FromHours(1),
			"1d" => TimeSpan.FromDays(1),
			_ => TimeSpan.Parse(text, CultureInfo.InvariantCulture),
		};
}
