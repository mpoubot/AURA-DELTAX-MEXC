namespace Odysseus.Cli;

using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Application;
using Odysseus.Compiler;
using Odysseus.Domain;
using Odysseus.Engine;
using Odysseus.Persistence;

/// <summary>
/// Everything a command needs, built once.
/// </summary>
/// <remarks>
/// The same stores and services the MCP server builds, assembled here without the protocol around them.
/// One command is one process, so what a person is working on is remembered in a small file beside the
/// projects rather than held in memory: without it every command would have to be told the project, the
/// candidate and the run it means.
/// </remarks>
public sealed class Workspace : IDisposable
{
	private const string CurrentFileName = "current.txt";

	private readonly string _root;
	private readonly SqliteProjectStore _store;
	private readonly SqliteOperationLog _operations;
	private readonly SqliteClosedHistoryLedger _ledger;

	private Workspace(string root)
	{
		_root = root;
		_store = new SqliteProjectStore(root);
		_operations = new SqliteOperationLog(root);
		_ledger = new SqliteClosedHistoryLedger(root);

		var artifacts = new FileArtifactStore(root);
		var datasets = new FileDatasetStore(root, artifacts);
		var specs = new FileSpecStore(root);
		var clock = new SystemClock();

		var budget = new ResearchBudget(400, 40, TimeSpan.FromHours(4)).ToState();

		Projects = new ProjectService(_store, _store, _operations, clock, ServerModes.Local, budget);

		Candidates = new CandidateService(
			_store, specs, _store, artifacts, new StrategyBuilder(EngineAssemblies.Paths()),
			_store, _operations, clock);

		Backtests = new BacktestService(
			_store, _store, specs, datasets, _store, artifacts,
			new EmulatedBacktestRunner(), _store, _operations, clock);

		Specs = new SpecService(_store, specs, _store, _operations, clock);
		Datasets = new DatasetService(_store, datasets, _store, _store, _operations, clock);

		Evaluations = new EvaluationService(_store, _store, specs, _store, Backtests, _store, clock);

		Closed = new ClosedDataService(
			_store, specs, _store, _store, _store, datasets, _ledger, Backtests, _store, clock);

		Completions = new CompletionService(
			_store, specs, _store, _store, _store, datasets, artifacts,
			new FileCompletedStore(root), _store, clock);

		var broker = BrokerCredentials.ReadEnvironment();

		// Measuring what is already frozen needs no broker, so the service exists either way and only
		// downloading refuses. Built only with credentials, every command that reads a dataset would fail
		// on a machine that has none - which is most machines trying this out.
		History = broker?.Kind switch
		{
			BrokerKinds.Alpaca => new AlpacaHistorySource(broker.KeyId, broker.Secret),
			BrokerKinds.Binance => new BinanceHistorySource(broker.KeyId, broker.Secret),
			_ => new BrokerNotConfigured(),
		};

		HasBroker = broker is not null;
		HistoryService = new HistoryService(_store, datasets, History, _store, _operations, clock);
	}

	/// <summary>Where the projects live.</summary>
	public string Root => _root;

	/// <summary>Project use cases.</summary>
	public ProjectService Projects { get; }

	/// <summary>Candidate use cases.</summary>
	public CandidateService Candidates { get; }

	/// <summary>Backtest use cases.</summary>
	public BacktestService Backtests { get; }

	/// <summary>Specification use cases.</summary>
	public SpecService Specs { get; }

	/// <summary>Dataset use cases.</summary>
	public DatasetService Datasets { get; }

	/// <summary>The fixed set of runs, and what they came to.</summary>
	public EvaluationService Evaluations { get; }

	/// <summary>The one measurement against the closed history.</summary>
	public ClosedDataService Closed { get; }

	/// <summary>Declaring a strategy finished and keeping it.</summary>
	public CompletionService Completions { get; }

	/// <summary>Where history comes from.</summary>
	public IHistorySource History { get; }

	/// <summary>Whether a broker was configured at all.</summary>
	public bool HasBroker { get; }

	/// <summary>History use cases.</summary>
	public HistoryService HistoryService { get; }

	/// <summary>
	/// Opens the workspace the environment points at.
	/// </summary>
	/// <returns>The workspace.</returns>
	public static Workspace Open()
	{
		var root = Environment.GetEnvironmentVariable("ODYSSEUS_PROJECTS_ROOT");

		if (string.IsNullOrWhiteSpace(root))
			root = Path.Combine(Directory.GetCurrentDirectory(), "projects");

		return new(Path.GetFullPath(root));
	}

	/// <summary>
	/// The project the last commands worked on.
	/// </summary>
	/// <returns>The project.</returns>
	/// <exception cref="InvalidOperationException">Nothing has been started yet.</exception>
	public ProjectId Current()
		=> Read(0) is { Length: > 0 } value
			? ProjectId.Parse(value)
			: throw new InvalidOperationException("No project yet. Start one: odysseus new \"my study\"");

	/// <summary>The specification last proposed.</summary>
	/// <returns>The specification.</returns>
	public SpecId CurrentSpec()
		=> Read(1) is { Length: > 0 } value
			? SpecId.Parse(value)
			: throw new InvalidOperationException("No hypothesis yet: odysseus propose hypothesis.json");

	/// <summary>The candidate last built.</summary>
	/// <returns>The candidate.</returns>
	public CandidateId CurrentCandidate()
		=> Read(2) is { Length: > 0 } value
			? CandidateId.Parse(value)
			: throw new InvalidOperationException("Nothing built yet: odysseus build");

	/// <summary>The run last measured.</summary>
	/// <returns>The run.</returns>
	public RunId CurrentRun()
		=> Read(3) is { Length: > 0 } value
			? RunId.Parse(value)
			: throw new InvalidOperationException("Nothing run yet: odysseus backtest");

	/// <summary>Remembers the project, forgetting what belonged to the last one.</summary>
	/// <param name="project">Project to remember.</param>
	public void Remember(ProjectId project) => Write(project.Value, "", "", "");

	/// <summary>Remembers the specification.</summary>
	/// <param name="spec">Specification to remember.</param>
	public void RememberSpec(SpecId spec) => Write(Read(0), spec.Value, "", "");

	/// <summary>Remembers the candidate.</summary>
	/// <param name="candidate">Candidate to remember.</param>
	public void RememberCandidate(CandidateId candidate) => Write(Read(0), Read(1), candidate.Value, "");

	/// <summary>Remembers the run.</summary>
	/// <param name="run">Run to remember.</param>
	public void RememberRun(RunId run) => Write(Read(0), Read(1), Read(2), run.Value);

	/// <inheritdoc />
	public void Dispose()
	{
		_store.Dispose();
		_operations.Dispose();
		_ledger.Dispose();
	}

	private string Read(int line)
	{
		var path = Path.Combine(_root, CurrentFileName);

		if (!File.Exists(path))
			return "";

		var lines = File.ReadAllLines(path);

		return line < lines.Length ? lines[line].Trim() : "";
	}

	private void Write(params string[] lines)
	{
		Directory.CreateDirectory(_root);

		File.WriteAllLines(Path.Combine(_root, CurrentFileName), lines);
	}
}
