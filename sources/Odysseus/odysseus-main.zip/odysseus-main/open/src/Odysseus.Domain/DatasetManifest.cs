namespace Odysseus.Domain;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;

/// <summary>
/// An immutable description of the data a piece of research was run against.
/// </summary>
/// <remarks>
/// A result is only reproducible if the data behind it can be shown to be the same data. The hash is
/// computed over the description and the bars themselves, never over the moment of creation, so
/// importing the same data twice produces the same manifest and a changed bar produces a different one.
/// </remarks>
public sealed record DatasetManifest
{
	/// <summary>Identity of this version of the data.</summary>
	public required DatasetVersionId Id { get; init; }

	/// <summary>Symbols the data covers.</summary>
	public required IReadOnlyList<string> Symbols { get; init; }

	/// <summary>Length of one candle.</summary>
	public required TimeSpan TimeFrame { get; init; }

	/// <summary>Where the data came from, for example a market data feed or the bundled demo set.</summary>
	public required string Source { get; init; }

	/// <summary>
	/// Whether the data was generated rather than observed.
	/// </summary>
	/// <remarks>
	/// Generated data is for proving that the machinery runs, never for judging a strategy, and every
	/// report over such a dataset has to say so. Recording it here rather than in a comment is what makes
	/// that possible.
	/// </remarks>
	public required bool IsSynthetic { get; init; }

	/// <summary>
	/// What was found in the bars of each symbol, over the whole dataset.
	/// </summary>
	/// <remarks>
	/// This covers the closed slice too, so it stays on the server. Anything shown to an agent comes from
	/// <see cref="DisclosedQuality"/> instead: a last bar time or a total count, next to the end of
	/// validation, states the closed slice as a subtraction.
	/// </remarks>
	public required IReadOnlyList<SymbolQuality> Quality { get; init; }

	/// <summary>What was found in the part of the data an agent may know about.</summary>
	public required IReadOnlyList<SymbolQuality> DisclosedQuality { get; init; }

	/// <summary>How the data is divided in time.</summary>
	public required DatasetSplit Split { get; init; }

	/// <summary>Hash over the description and the bars.</summary>
	public required string ContentHash { get; init; }

	/// <summary>Total bars kept, across every symbol, including the closed slice.</summary>
	public int Records => Quality.Sum(q => q.Records);

	/// <summary>Bars an agent may know about, across every symbol.</summary>
	public int DisclosedRecords => DisclosedQuality.Sum(q => q.Records);

	/// <summary>
	/// Computes the hash that identifies a dataset.
	/// </summary>
	/// <param name="symbols">Symbols the data covers.</param>
	/// <param name="timeFrame">Length of one candle.</param>
	/// <param name="source">Where the data came from.</param>
	/// <param name="bars">The bars themselves, by symbol.</param>
	/// <returns>The hash, in lowercase hexadecimal.</returns>
	public static string ComputeHash(
		IReadOnlyList<string> symbols,
		TimeSpan timeFrame,
		string source,
		IReadOnlyDictionary<string, IReadOnlyList<Candle>> bars)
	{
		ArgumentNullException.ThrowIfNull(symbols);
		ArgumentNullException.ThrowIfNull(bars);
		ArgumentException.ThrowIfNullOrWhiteSpace(source);

		var text = new StringBuilder();

		text.Append(source).Append('\n');
		text.Append(timeFrame.Ticks).Append('\n');

		// Ordered, so that the same data imported in a different order is recognised as the same data.
		foreach (var symbol in symbols.OrderBy(s => s, StringComparer.Ordinal))
		{
			text.Append(symbol).Append('\n');

			if (!bars.TryGetValue(symbol, out var candles))
				continue;

			foreach (var candle in candles)
			{
				text
					.Append(candle.OpenTime.Ticks).Append(';')
					.Append(candle.Open.ToString(CultureInfo.InvariantCulture)).Append(';')
					.Append(candle.High.ToString(CultureInfo.InvariantCulture)).Append(';')
					.Append(candle.Low.ToString(CultureInfo.InvariantCulture)).Append(';')
					.Append(candle.Close.ToString(CultureInfo.InvariantCulture)).Append(';')
					.Append(candle.Volume.ToString(CultureInfo.InvariantCulture)).Append('\n');
			}
		}

		return Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(text.ToString())));
	}
}
