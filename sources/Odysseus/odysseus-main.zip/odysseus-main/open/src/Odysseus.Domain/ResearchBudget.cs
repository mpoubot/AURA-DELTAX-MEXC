namespace Odysseus.Domain;

using System;
using System.Threading;

/// <summary>
/// Persistable state of a <see cref="ResearchBudget"/>.
/// </summary>
/// <param name="MaxBacktests">Total backtests the project was granted.</param>
/// <param name="MaxCandidates">Total candidates the project was granted.</param>
/// <param name="MaxWallClock">Total machine time the project was granted.</param>
/// <param name="ClaimedBacktests">Backtests claimed so far.</param>
/// <param name="ClaimedCandidates">Candidates claimed so far.</param>
/// <param name="ClaimedWallClock">Machine time spent so far.</param>
public sealed record ResearchBudgetState(
	int MaxBacktests,
	int MaxCandidates,
	TimeSpan MaxWallClock,
	int ClaimedBacktests,
	int ClaimedCandidates,
	TimeSpan ClaimedWallClock);

/// <summary>
/// The hard ceiling on one project's research, from requirements O-RCH-004 and O-RCH-005.
/// </summary>
/// <remarks>
/// The loop is driven by the user's agent, which has no reason to stop on its own, so the ceiling is
/// held here rather than asked of the caller. Allowance is claimed before the expensive work starts:
/// counting afterwards would let a crash between the work and the count hand the budget back for free.
/// </remarks>
public sealed class ResearchBudget
{
	private readonly Lock _sync = new();

	private int _claimedBacktests;
	private int _claimedCandidates;
	private TimeSpan _claimedWallClock;

	/// <summary>
	/// Creates a budget.
	/// </summary>
	/// <param name="maxBacktests">Backtests the project may run.</param>
	/// <param name="maxCandidates">Candidates the project may create.</param>
	/// <param name="maxWallClock">Machine time the project may consume.</param>
	/// <exception cref="ArgumentOutOfRangeException">A limit permits nothing.</exception>
	public ResearchBudget(int maxBacktests, int maxCandidates, TimeSpan maxWallClock)
	{
		ArgumentOutOfRangeException.ThrowIfLessThan(maxBacktests, 1);
		ArgumentOutOfRangeException.ThrowIfLessThan(maxCandidates, 1);

		if (maxWallClock <= TimeSpan.Zero)
			throw new ArgumentOutOfRangeException(nameof(maxWallClock), maxWallClock, "A budget must permit some time.");

		MaxBacktests = maxBacktests;
		MaxCandidates = maxCandidates;
		MaxWallClock = maxWallClock;
	}

	/// <summary>Backtests the project was granted.</summary>
	public int MaxBacktests { get; }

	/// <summary>Candidates the project was granted.</summary>
	public int MaxCandidates { get; }

	/// <summary>Machine time the project was granted.</summary>
	public TimeSpan MaxWallClock { get; }

	/// <summary>Backtests still available.</summary>
	public int RemainingBacktests
	{
		get
		{
			using (_sync.EnterScope())
				return MaxBacktests - _claimedBacktests;
		}
	}

	/// <summary>Candidates still available.</summary>
	public int RemainingCandidates
	{
		get
		{
			using (_sync.EnterScope())
				return MaxCandidates - _claimedCandidates;
		}
	}

	/// <summary>Machine time still available.</summary>
	public TimeSpan RemainingWallClock
	{
		get
		{
			using (_sync.EnterScope())
			{
				var left = MaxWallClock - _claimedWallClock;

				return left > TimeSpan.Zero ? left : TimeSpan.Zero;
			}
		}
	}

	/// <summary>Whether any allowance is left at all.</summary>
	public bool IsExhausted
		=> RemainingBacktests == 0 || RemainingCandidates == 0 || RemainingWallClock == TimeSpan.Zero;

	/// <summary>
	/// Restores a budget from persisted state.
	/// </summary>
	/// <param name="state">State previously produced by <see cref="ToState"/>.</param>
	/// <returns>The restored budget.</returns>
	public static ResearchBudget Restore(ResearchBudgetState state)
	{
		ArgumentNullException.ThrowIfNull(state);

		var budget = new ResearchBudget(state.MaxBacktests, state.MaxCandidates, state.MaxWallClock)
		{
			_claimedBacktests = state.ClaimedBacktests,
			_claimedCandidates = state.ClaimedCandidates,
			_claimedWallClock = state.ClaimedWallClock,
		};

		return budget;
	}

	/// <summary>
	/// Claims one backtest.
	/// </summary>
	/// <returns><see langword="true"/> when the claim was granted.</returns>
	public bool TryClaimBacktest()
	{
		using (_sync.EnterScope())
		{
			if (_claimedBacktests >= MaxBacktests)
				return false;

			_claimedBacktests++;
			return true;
		}
	}

	/// <summary>
	/// Claims one candidate.
	/// </summary>
	/// <returns><see langword="true"/> when the claim was granted.</returns>
	public bool TryClaimCandidate()
	{
		using (_sync.EnterScope())
		{
			if (_claimedCandidates >= MaxCandidates)
				return false;

			_claimedCandidates++;
			return true;
		}
	}

	/// <summary>
	/// Returns a backtest claim whose work never ran.
	/// </summary>
	/// <exception cref="InvalidOperationException">Nothing was claimed.</exception>
	public void ReleaseBacktest()
	{
		using (_sync.EnterScope())
		{
			if (_claimedBacktests == 0)
				throw new InvalidOperationException("No backtest claim is outstanding.");

			_claimedBacktests--;
		}
	}

	/// <summary>
	/// Returns a candidate claim whose work never ran.
	/// </summary>
	/// <exception cref="InvalidOperationException">Nothing was claimed.</exception>
	public void ReleaseCandidate()
	{
		using (_sync.EnterScope())
		{
			if (_claimedCandidates == 0)
				throw new InvalidOperationException("No candidate claim is outstanding.");

			_claimedCandidates--;
		}
	}

	/// <summary>
	/// Captures the state so that a restart resumes with the allowance already spent.
	/// </summary>
	/// <returns>The persistable state.</returns>
	public ResearchBudgetState ToState()
	{
		using (_sync.EnterScope())
			return new(MaxBacktests, MaxCandidates, MaxWallClock, _claimedBacktests, _claimedCandidates, _claimedWallClock);
	}
}
