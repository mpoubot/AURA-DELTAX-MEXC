namespace Odysseus.Domain;

/// <summary>
/// States a research project passes through.
/// </summary>
public enum ProjectStatuses
{
	/// <summary>Created; no dataset has been frozen yet, so nothing can be measured.</summary>
	Draft,

	/// <summary>A dataset is frozen and research can start.</summary>
	Ready,

	/// <summary>Research is under way.</summary>
	Researching,

	/// <summary>Research finished, with a verdict either way.</summary>
	Completed,

	/// <summary>Kept for the record and read-only.</summary>
	Archived,
}
