namespace Odysseus.Domain;

using System;

/// <summary>
/// What became of a paper deployment.
/// </summary>
public enum DeploymentStatuses
{
	/// <summary>The strategy is running against the broker right now.</summary>
	Running,

	/// <summary>It was stopped on purpose.</summary>
	Stopped,

	/// <summary>
	/// The server it was running inside went away. Nothing was stopped in an orderly fashion, so whatever
	/// the strategy had open at the broker was left as it stood.
	/// </summary>
	Interrupted,

	/// <summary>It stopped itself because something went wrong.</summary>
	Failed,
}

/// <summary>
/// One run of an accepted candidate against a live paper account.
/// </summary>
/// <param name="Id">Identifier of the deployment.</param>
/// <param name="Candidate">Candidate that was deployed.</param>
/// <param name="Symbol">Symbol it trades.</param>
/// <param name="Volume">Size of one position, fixed for the life of the deployment.</param>
/// <param name="Status">Where it stands.</param>
/// <param name="StartedAt">When it started, in UTC.</param>
/// <param name="StoppedAt">When it stopped, in UTC, or null while it runs.</param>
/// <param name="OrdersPlaced">Orders the strategy sent.</param>
/// <param name="Trades">Positions it opened and closed.</param>
/// <param name="RealizedProfit">What those came to, as the broker reports it.</param>
/// <param name="Position">What it was holding when last looked at.</param>
/// <param name="LastObservedAt">
/// When the numbers above were last read from a live session, in UTC, or null while none ever was.
/// </param>
/// <param name="Note">Why it stopped, when that needs saying.</param>
/// <remarks>
/// A deployment lives inside the server process. That is the whole of its lifetime: it is not a service
/// that survives a restart, and a deployment found in <see cref="DeploymentStatuses.Running"/> when the
/// server starts belongs to a process that no longer exists.
/// </remarks>
public sealed record Deployment(
	DeploymentId Id,
	CandidateId Candidate,
	string Symbol,
	decimal Volume,
	DeploymentStatuses Status,
	DateTime StartedAt,
	DateTime? StoppedAt,
	int OrdersPlaced,
	int Trades,
	decimal RealizedProfit,
	decimal Position,
	DateTime? LastObservedAt,
	string Note)
{
	/// <summary>How long it has been running, or ran.</summary>
	public TimeSpan Elapsed => (StoppedAt ?? DateTime.UtcNow) - StartedAt;

	/// <summary>
	/// How long anybody was actually watching it.
	/// </summary>
	/// <remarks>
	/// Not the same as <see cref="Elapsed"/>, and the difference is an outage. A deployment that traded
	/// for half an hour and was found the next morning ran for half an hour; measuring its rate over the
	/// twenty-four hours nobody was there makes it look forty-eight times quieter than it was, and the
	/// rate is the one comparison the report exists to make.
	/// </remarks>
	public TimeSpan Watched => (LastObservedAt ?? StoppedAt ?? DateTime.UtcNow) - StartedAt;
}
