namespace Odysseus.Domain;

using System;

/// <summary>
/// What an agent is allowed to know about how a dataset is divided.
/// </summary>
/// <param name="DevelopmentFrom">Start of the development slice, in UTC.</param>
/// <param name="DevelopmentTo">End of the development slice, exclusive, in UTC.</param>
/// <param name="HasSealedSlice">Whether a closed slice exists at all.</param>
/// <param name="SealedSliceConsumed">Whether the closed slice has already been used.</param>
/// <remarks>
/// Whether it has been used is not a property of the data. The manifest is frozen and hashed the moment
/// it is imported, so it cannot learn anything afterwards; what has been measured against the closed
/// slice is read from the runs, and this value is supplied by whoever assembles the disclosure.
/// </remarks>
/// <remarks>
/// The closed slice has no boundaries here, and that omission is the whole design. Knowing where it
/// starts is knowing which period to avoid fitting, which is most of the benefit of not seeing it.
///
/// The end of validation is the start of the closed slice, so it is not here either. Publishing it
/// beside a sentence promising to withhold the boundary would disclose the boundary and claim
/// otherwise in the same breath.
/// </remarks>
public sealed record DisclosedSplit(
	DateTime DevelopmentFrom,
	DateTime DevelopmentTo,
	bool HasSealedSlice,
	bool SealedSliceConsumed);

/// <summary>
/// How a dataset is divided in time.
/// </summary>
/// <remarks>
/// The division is by time and never by sampling: a strategy is judged on what came after what it was
/// built on, which is the only order that exists when it runs for real.
/// </remarks>
public sealed record DatasetSplit
{
	/// <summary>Start of the whole dataset, in UTC.</summary>
	public required DateTime From { get; init; }

	/// <summary>End of the development slice, exclusive, in UTC.</summary>
	public required DateTime DevelopmentTo { get; init; }

	/// <summary>End of the validation slice, exclusive, in UTC.</summary>
	public required DateTime ValidationTo { get; init; }

	/// <summary>End of the whole dataset, exclusive, in UTC. Also the end of the closed slice.</summary>
	public required DateTime To { get; init; }

	/// <summary>
	/// Divides a range by time.
	/// </summary>
	/// <param name="from">Start of the data, in UTC.</param>
	/// <param name="to">End of the data, exclusive, in UTC.</param>
	/// <param name="developmentFraction">Share of the range used for development.</param>
	/// <param name="validationFraction">Share of the range used for validation.</param>
	/// <returns>The division.</returns>
	/// <exception cref="ArgumentException">The range is empty or the fractions leave no closed slice.</exception>
	public static DatasetSplit Create(DateTime from, DateTime to, double developmentFraction, double validationFraction)
	{
		if (from.Kind != DateTimeKind.Utc || to.Kind != DateTimeKind.Utc)
			throw new ArgumentException("A split is defined over UTC moments.", nameof(from));

		if (to <= from)
			throw new ArgumentException("A split needs a range that contains something.", nameof(to));

		if (developmentFraction <= 0 || validationFraction <= 0)
			throw new ArgumentOutOfRangeException(nameof(developmentFraction), "Every slice must contain something.");

		if (developmentFraction + validationFraction >= 1)
			throw new ArgumentOutOfRangeException(nameof(validationFraction),
				"The fractions leave nothing closed, and a split without a closed slice cannot answer the only question that matters.");

		var span = to - from;

		return new()
		{
			From = from,
			DevelopmentTo = from + span * developmentFraction,
			ValidationTo = from + span * (developmentFraction + validationFraction),
			To = to,
		};
	}

	/// <summary>
	/// Which slice a moment belongs to.
	/// </summary>
	/// <param name="moment">Moment to place, in UTC.</param>
	/// <returns>The slice.</returns>
	/// <exception cref="ArgumentOutOfRangeException">The moment lies outside the dataset.</exception>
	public DataSlices SliceOf(DateTime moment)
	{
		if (moment < From || moment >= To)
			throw new ArgumentOutOfRangeException(nameof(moment), moment, "The moment lies outside the dataset.");

		if (moment < DevelopmentTo)
			return DataSlices.Development;

		return moment < ValidationTo ? DataSlices.Validation : DataSlices.Final;
	}

	/// <summary>
	/// The bounds of a slice.
	/// </summary>
	/// <param name="slice">Slice to bound.</param>
	/// <returns>Start, and end exclusive, in UTC.</returns>
	public (DateTime From, DateTime To) BoundsOf(DataSlices slice)
		=> slice switch
		{
			DataSlices.Development => (From, DevelopmentTo),
			DataSlices.Validation => (DevelopmentTo, ValidationTo),
			DataSlices.Final => (ValidationTo, To),
			_ => throw new ArgumentOutOfRangeException(nameof(slice), slice, "Unknown slice."),
		};

	/// <summary>
	/// What may be told to an agent.
	/// </summary>
	/// <param name="consumed">Whether the closed slice has already been measured, read from the runs.</param>
	/// <returns>The disclosed part of the division.</returns>
	/// <remarks>
	/// The closed slice contributes only two booleans: that it exists, and whether it has been spent.
	/// Neither its start nor the end of the dataset appears, because the end of validation together with
	/// the end of the dataset is the closed slice, stated as a subtraction.
	/// </remarks>
	public DisclosedSplit Disclose(bool consumed)
		=> new(From, DevelopmentTo, HasSealedSlice: true, consumed);
}
