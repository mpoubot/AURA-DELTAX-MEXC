namespace Odysseus.Compiler;

using System;
using System.Collections.Generic;
using System.Linq;

using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

/// <summary>
/// Rules a strategy has to obey that the reference set cannot enforce.
/// </summary>
/// <remarks>
/// Not everything worth forbidding can be kept out by choosing which assemblies to reference. The
/// clock is the clearest case: <c>DateTime.Now</c> lives beside every type a strategy legitimately
/// needs, so no reference set can exclude one without excluding the other.
///
/// None of this is protection against a hostile author — the code belongs to whoever runs it. It is
/// protection of the result. A strategy that reads the wall clock, or draws a number nobody seeded,
/// returns a different answer tomorrow on the same data, and every metric computed from it becomes a
/// number that cannot be checked. The rules are named after the requirements they come from, so a
/// refusal can be looked up.
/// </remarks>
public static class StrategyRules
{
	private static readonly IReadOnlyDictionary<string, (string Rule, string Why)> _forbiddenMembers =
		new Dictionary<string, (string, string)>(StringComparer.Ordinal)
		{
			["System.DateTime.Now"] = ("ODSTR012", "reads the machine clock, so the same data would produce a different result tomorrow"),
			["System.DateTime.UtcNow"] = ("ODSTR012", "reads the machine clock, so the same data would produce a different result tomorrow"),
			["System.DateTime.Today"] = ("ODSTR012", "reads the machine clock, so the same data would produce a different result tomorrow"),
			["System.DateTimeOffset.Now"] = ("ODSTR012", "reads the machine clock, so the same data would produce a different result tomorrow"),
			["System.DateTimeOffset.UtcNow"] = ("ODSTR012", "reads the machine clock, so the same data would produce a different result tomorrow"),
			["System.Guid.NewGuid"] = ("ODSTR013", "produces a value nobody seeded, so a re-run cannot reproduce it"),
			["System.Environment.TickCount"] = ("ODSTR012", "reads the machine clock"),
			["System.Environment.TickCount64"] = ("ODSTR012", "reads the machine clock"),
		};

	// Whole areas of the framework that put a run at the mercy of something outside the data. They cannot
	// be excluded by choosing references: in the current reference assemblies these types sit beside the
	// ones a strategy legitimately needs, so the boundary has to be drawn here.
	private static readonly IReadOnlyDictionary<string, (string Rule, string Why)> _forbiddenNamespaces =
		new Dictionary<string, (string, string)>(StringComparer.Ordinal)
		{
			["System.IO"] = ("ODSTR012", "reads or writes the machine, so the same data would not produce the same result elsewhere"),
			["System.Net"] = ("ODSTR012", "depends on something outside the data, which no re-run can reproduce"),
			["System.Diagnostics"] = ("ODSTR012", "observes the process rather than the market"),
			["System.Threading"] = ("ODSTR012", "makes the order of work, and therefore the result, depend on timing"),
			["System.Reflection"] = ("ODSTR012", "reaches past what a strategy is given"),
			["System.Runtime.InteropServices"] = ("ODSTR012", "leaves the managed world, where nothing can be checked"),
		};

	private static readonly IReadOnlyDictionary<string, (string Rule, string Why)> _forbiddenTypes =
		new Dictionary<string, (string, string)>(StringComparer.Ordinal)
		{
			["System.Random"] = ("ODSTR013", "draws numbers nobody seeded, so a re-run cannot reproduce the result"),
			["System.Environment"] = ("ODSTR012", "exposes the machine the run happens to be on"),
		};

	/// <summary>
	/// Checks compiled source against the rules.
	/// </summary>
	/// <param name="compilation">Compilation the source belongs to.</param>
	/// <param name="tree">Source to check.</param>
	/// <returns>Everything that breaks a rule.</returns>
	public static IReadOnlyList<CompilerMessage> Inspect(Compilation compilation, SyntaxTree tree)
	{
		ArgumentNullException.ThrowIfNull(compilation);
		ArgumentNullException.ThrowIfNull(tree);

		var model = compilation.GetSemanticModel(tree);
		var messages = new List<CompilerMessage>();

		foreach (var node in tree.GetRoot().DescendantNodes())
		{
			switch (node)
			{
				case MemberAccessExpressionSyntax access:
				{
					var symbol = model.GetSymbolInfo(access).Symbol;

					if (symbol is null)
						continue;

					var containing = symbol.ContainingType;
					var full = $"{containing?.ToDisplayString()}.{symbol.Name}";

					if (_forbiddenMembers.TryGetValue(full, out var member))
					{
						messages.Add(Describe(access, member.Rule, $"'{full}' {member.Why}."));
						break;
					}

					if (containing is not null && Forbidden(containing, out var area))
						messages.Add(Describe(access, area.Rule, $"'{containing.ToDisplayString()}' {area.Why}."));

					break;
				}

				case ObjectCreationExpressionSyntax creation:
				{
					var type = model.GetTypeInfo(creation).Type;

					if (type is null)
						break;

					if (_forbiddenTypes.TryGetValue(type.ToDisplayString(), out var forbidden))
					{
						messages.Add(Describe(creation, forbidden.Rule, $"'{type.ToDisplayString()}' {forbidden.Why}."));
						break;
					}

					if (Forbidden(type, out var namespaceRule))
						messages.Add(Describe(creation, namespaceRule.Rule, $"'{type.ToDisplayString()}' {namespaceRule.Why}."));

					break;
				}
			}
		}

		return messages;
	}

	private static bool Forbidden(ITypeSymbol type, out (string Rule, string Why) rule)
	{
		var name = type.ContainingNamespace?.ToDisplayString();

		while (!string.IsNullOrEmpty(name))
		{
			if (_forbiddenNamespaces.TryGetValue(name, out rule))
				return true;

			var separator = name.LastIndexOf('.');

			name = separator < 0 ? null : name[..separator];
		}

		rule = default;
		return false;
	}

	private static CompilerMessage Describe(SyntaxNode node, string rule, string message)
	{
		var position = node.GetLocation().GetLineSpan().StartLinePosition;

		return new(
			rule,
			DiagnosticSeverity.Error.ToString(),
			message + " Use what the context provides instead: it is the same on every run.",
			position.Line + 1,
			position.Character + 1);
	}
}
