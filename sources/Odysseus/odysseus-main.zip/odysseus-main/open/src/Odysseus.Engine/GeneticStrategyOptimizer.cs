namespace Odysseus.Engine;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Ecng.Common;
using Ecng.IO;

using StockSharp.Algo;
using StockSharp.Algo.Commissions;
using StockSharp.Algo.Strategies;
using StockSharp.Algo.Strategies.Optimization;
using StockSharp.Messages;

using Odysseus.Application;

/// <summary>
/// Searches a candidate's declared numbers with the genetic optimizer StockSharp already carries.
/// </summary>
/// <remarks>
/// Genetic once there is a space worth searching: eight numbers with twenty steps each is more settings
/// than a project's whole allowance, and walking all of them would mean the allowance runs out long
/// before the interesting region is reached. With a single number to vary there is no space and nothing
/// to breed — a genetic search cannot even form a chromosome from one gene — so its declared range is
/// simply walked end to end, which is both exact and cheap.
///
/// The search is seeded. A genetic search left to its own randomness lands somewhere different every
/// time it is asked, and a chosen setting nobody can arrive at twice is not a result — it is a number
/// that happened. The seed is part of what identifies the search, so the same project re-run picks the
/// same setting.
///
/// What comes back is every setting that was evaluated, not a verdict. The caller takes the best one
/// through the ordinary run and the ordinary gates: a search that judged its own work would be marking
/// its own paper.
/// </remarks>
public sealed class GeneticStrategyOptimizer : IStrategyOptimizer
{
	/// <inheritdoc />
	public async Task<IReadOnlyList<OptimizationTrial>> SearchAsync(
		OptimizationRequest request,
		CancellationToken cancellationToken)
	{
		ArgumentNullException.ThrowIfNull(request);

		if (request.Bars.Count == 0)
			throw new ArgumentException("There are no bars to search over.", nameof(request));

		var venue = request.Venue ?? BrokerVenue.Alpaca;
		var security = EmulationSetup.CreateSecurity(request.Symbol, request.PriceStep, venue);
		var portfolio = EmulationSetup.CreatePortfolio(request.StartingEquity);
		var storage = await EmulationSetup.FreezeAsync(security, request.TimeFrame, request.Bars, cancellationToken);

		var strategy = EmulationSetup.Instantiate(request.Assembly, request.TimeFrame, null, venue);

		strategy.Security = security;
		strategy.Portfolio = portfolio;
		strategy.Volume = request.Volume;
		strategy.WaitRulesOnStop = false;

		// Everything the search does with randomness comes from here, so seeding this one thing makes the
		// whole search repeat.
		strategy.RandomProvider = new SeededRandomProvider(request.Seed);

		var declared = strategy.Parameters.Values.Where(p => p.CanOptimize).ToArray();

		// What the search will actually vary, which is narrower than what is merely marked as varyable:
		// a parameter without bounds has nothing to be searched between and is dropped here rather than
		// counted and then silently discarded further in.
		var genes = declared.Length == 0 ? [] : strategy.ToGeneticParameters(declared);

		if (genes.Length == 0)
		{
			throw new ArgumentException(
				"This candidate declares no number the search may vary, so there is nothing to search.",
				nameof(request));
		}

		var securities = new CollectionSecurityProvider([security]);
		var portfolios = new CollectionPortfolioProvider([portfolio]);

		var from = request.Bars[0].OpenTime;
		var to = request.Bars[^1].OpenTime + request.TimeFrame;

		var trials = new List<OptimizationTrial>();

		if (genes.Length == 1)
		{
			using var exhaustive = new BruteForceOptimizer(securities, portfolios, storage);

			Charge(exhaustive.EmulationSettings, request);

			var settings = strategy.ToBruteForce([.. genes.Select(g => g.param)], out _, out _);

			await foreach (var (tried, parameters) in exhaustive
				.RunAsync(from, to, settings, cancellationToken)
				.WithCancellation(cancellationToken))
			{
				trials.Add(Describe(tried, parameters));
			}
		}
		else
		{
			using var genetic = new GeneticOptimizer(securities, portfolios, storage, new MemoryFileSystem());

			Charge(genetic.EmulationSettings, request);

			genetic.Settings.Population = request.Population;
			genetic.Settings.PopulationMax = request.Population;
			genetic.Settings.GenerationsMax = request.Generations;

			await foreach (var (tried, parameters) in genetic
				.RunAsync(from, to, strategy, genes, Fitness, cancellationToken: cancellationToken)
				.WithCancellation(cancellationToken))
			{
				trials.Add(Describe(tried, parameters));
			}
		}

		return [.. trials.OrderByDescending(t => t.Fitness)];
	}

	// The same charge every ordinary run pays, so a setting that only works untaxed cannot win here
	// and then fail the moment it is measured properly.
	private static void Charge(OptimizerSettings settings, OptimizationRequest request)
		=> settings.CommissionRules = EmulatedBacktestRunner.CommissionRules(request.Costs);

	/// <summary>
	/// What the search is looking for.
	/// </summary>
	/// <param name="strategy">The setting being scored, after its run.</param>
	/// <returns>The score.</returns>
	/// <remarks>
	/// Profit against the drawdown it cost, rather than profit alone. A search rewarded for profit alone
	/// walks straight to the setting that made the most money once and sat through a fall nobody would
	/// have held through, and it does so reliably, because that setting is always in the space.
	///
	/// A setting with too few trades scores nothing at all. Two trades can produce any ratio you like,
	/// and a search that could win by trading twice will find the pair that did.
	/// </remarks>
	private static decimal Fitness(Strategy strategy)
	{
		var trades = Statistic(strategy, StatisticParameterTypes.TradeCount);

		if (trades < MinimumTrades)
			return 0;

		var profit = Statistic(strategy, StatisticParameterTypes.NetProfit);

		if (profit <= 0)
			return 0;

		// A run that never declined divides by the smallest fall worth speaking of rather than by nothing.
		var drawdown = Math.Max(Math.Abs(Statistic(strategy, StatisticParameterTypes.MaxDrawdown)), 1m);

		return profit / drawdown;
	}

	/// <summary>
	/// Below this a result is a handful of observations, and the search must not be able to win with it.
	/// It is the same floor the hard gates apply, so the search is not aiming at something the gates
	/// will refuse.
	/// </summary>
	private const int MinimumTrades = 30;

	private static OptimizationTrial Describe(Strategy strategy, IStrategyParam[] parameters)
		=> new(
			parameters.ToDictionary(p => p.Id, p => p.Value.To<decimal>(), StringComparer.Ordinal),
			Fitness(strategy),
			Statistic(strategy, StatisticParameterTypes.NetProfit),
			DrawdownPercent(strategy),
			(int)Statistic(strategy, StatisticParameterTypes.TradeCount));

	private static decimal DrawdownPercent(Strategy strategy)
	{
		var begin = strategy.Portfolio?.BeginValue ?? 0m;

		return begin == 0
			? 0
			: Math.Abs(Statistic(strategy, StatisticParameterTypes.MaxDrawdown)) / begin * 100m;
	}

	private static decimal Statistic(Strategy strategy, StatisticParameterTypes type)
	{
		var parameter = strategy.StatisticManager?.Parameters?.FirstOrDefault(p => p.Type == type);

		return parameter?.Value is null ? 0m : parameter.Value.To<decimal>();
	}
}
