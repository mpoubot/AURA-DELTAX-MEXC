namespace Odysseus.Engine;

using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;

using Ecng.Common;
using Ecng.IO;

using StockSharp.Algo;
using StockSharp.Algo.Storages;
using StockSharp.Algo.Strategies;
using StockSharp.BusinessEntities;
using StockSharp.Messages;

using Odysseus.Domain;
using Odysseus.Application;

/// <summary>
/// What a run and a search both need before either can start.
/// </summary>
/// <remarks>
/// A backtest and a parameter search set up the same world — one instrument, one simulated account,
/// the frozen bars in memory, and a strategy built out of a compiled candidate. Only what they do with
/// it differs, so the setting up lives here and neither owns a private copy of it that could drift.
/// </remarks>
static class EmulationSetup
{
	/// <summary>
	/// The instrument the run trades.
	/// </summary>
	/// <param name="symbol">Symbol to trade.</param>
	/// <param name="priceStep">Smallest price movement.</param>
	/// <param name="venue">Market conventions for the dataset.</param>
	/// <returns>The security.</returns>
	public static Security CreateSecurity(string symbol, decimal priceStep, BrokerVenue venue = null)
	{
		venue ??= BrokerVenue.Alpaca;
		var contract = ContractSymbol.IsContract(symbol);
		var board = venue.IsCrypto ? ExchangeBoard.Binance : ExchangeBoard.Nasdaq;

		// One board for both, because what the emulator reads from it is the trading day, and a listed
		// contract keeps the hours of the market underneath it.
		return new()
		{
			Id = $"{symbol}@{board.Code}",
			Code = symbol,
			Board = board,
			PriceStep = priceStep,
			VolumeStep = venue.VolumeStep,

			// A contract is a hundred shares, so a cent of price is a dollar of result. Left at one, the
			// engine's own account value disagrees with every trade measured out of the same run.
			Multiplier = ContractSymbol.SizeOf(symbol),
			Type = venue.IsCrypto ? SecurityTypes.CryptoCurrency : contract ? SecurityTypes.Option : SecurityTypes.Stock,
		};
	}

	/// <summary>
	/// The simulated account the run trades on.
	/// </summary>
	/// <param name="startingEquity">Money the account starts with.</param>
	/// <returns>The portfolio.</returns>
	public static Portfolio CreatePortfolio(decimal startingEquity)
	{
		var portfolio = Portfolio.CreateSimulator();

		portfolio.BeginValue = startingEquity;
		portfolio.CurrentValue = startingEquity;

		return portfolio;
	}

	/// <summary>
	/// Puts the bars where the engine can read them.
	/// </summary>
	/// <param name="security">Instrument the bars belong to.</param>
	/// <param name="timeFrame">Length of one candle.</param>
	/// <param name="bars">The bars, oldest first.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>Storage holding exactly those bars and nothing else.</returns>
	/// <remarks>
	/// In memory rather than on disk. A run is a measurement, and a measurement that leaves files behind
	/// is one the next measurement can be contaminated by; it also means a search of a thousand settings
	/// does not turn into a thousand folders nobody deletes.
	/// </remarks>
	public static async Task<IStorageRegistry> FreezeAsync(
		Security security,
		TimeSpan timeFrame,
		IReadOnlyList<Candle> bars,
		CancellationToken cancellationToken)
	{
		var files = new MemoryFileSystem();
		const string root = "bars";

		files.CreateDirectory(root);

		var storage = new StorageRegistry { DefaultDrive = new LocalMarketDataDrive(files, root) };
		var securityId = security.ToSecurityId();

		var candles = bars.Select(b => new TimeFrameCandleMessage
		{
			SecurityId = securityId,
			TypedArg = timeFrame,
			DataType = timeFrame.TimeFrame(),
			OpenTime = b.OpenTime,
			CloseTime = b.OpenTime + timeFrame,
			HighTime = b.OpenTime,
			LowTime = b.OpenTime,
			OpenPrice = b.Open,
			HighPrice = b.High,
			LowPrice = b.Low,
			ClosePrice = b.Close,
			TotalVolume = b.Volume,
			State = CandleStates.Finished,
		});

		await storage
			.GetTimeFrameCandleMessageStorage(securityId, timeFrame)
			.SaveAsync(candles, cancellationToken);

		return storage;
	}

	/// <summary>
	/// Builds the strategy out of a compiled candidate.
	/// </summary>
	/// <param name="assembly">The compiled candidate.</param>
	/// <param name="timeFrame">Length of one candle.</param>
	/// <param name="parameters">Values to set, or nothing for the ones the strategy declares.</param>
	/// <param name="venue">Market conventions for the dataset.</param>
	/// <returns>The strategy.</returns>
	public static Strategy Instantiate(
		byte[] assembly,
		TimeSpan timeFrame,
		IReadOnlyDictionary<string, decimal> parameters,
		BrokerVenue venue = null)
	{
		var type = Assembly.Load(assembly)
			.GetTypes()
			.SingleOrDefault(t => typeof(Strategy).IsAssignableFrom(t) && !t.IsAbstract)
			?? throw new ArgumentException("The compiled candidate holds no strategy to run.", nameof(assembly));

		var strategy = (Strategy)Activator.CreateInstance(type);

		// The candles the rules are evaluated on come from the dataset rather than from the default the
		// specification declared: a run over five-minute bars with a strategy asking for fifteen would
		// subscribe to something the engine has never been given and trade nothing at all.
		Set(strategy, "CandleType", timeFrame.TimeFrame());
		venue ??= BrokerVenue.Alpaca;
		SetIfExists(strategy, "MarketTimeZone", venue.TimeZoneId);
		SetIfExists(strategy, "SessionEnd", venue.SessionEnd);

		foreach (var (name, value) in parameters ?? new Dictionary<string, decimal>())
			Set(strategy, name, value);

		return strategy;
	}

	private static void SetIfExists(Strategy strategy, string name, object value)
	{
		var property = strategy.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance);

		if (property is not null)
			property.SetValue(strategy, value.To(property.PropertyType));
	}

	private static void Set(Strategy strategy, string name, object value)
	{
		var property = strategy.GetType().GetProperty(name, BindingFlags.Public | BindingFlags.Instance)
			?? throw new ArgumentException(
				$"The strategy declares no parameter named '{name}'. It declares: " +
				$"{string.Join(", ", strategy.GetType().GetProperties().Select(p => p.Name))}.",
				nameof(name));

		property.SetValue(strategy, value.To(property.PropertyType));
	}
}
