namespace Odysseus.Engine;

using System;
using System.Collections.Generic;
using System.Security;
using System.Threading;
using System.Threading.Tasks;

using Ecng.Common;

using StockSharp.Binance;
using StockSharp.Messages;

using Odysseus.Application;
using Odysseus.Domain;

/// <summary>Downloads finished Binance Spot candles through the StockSharp adapter.</summary>
/// <remarks>
/// History is read from the production public market-data endpoint so research uses the observed
/// market. Trading is a separate adapter and is permanently pinned to Spot Testnet.
/// </remarks>
public sealed class BinanceHistorySource : IHistorySource
{
	private readonly SecureString _key;
	private readonly SecureString _secret;

	/// <summary>Creates the history source.</summary>
	public BinanceHistorySource(string keyId, string secret)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(keyId);
		ArgumentException.ThrowIfNullOrWhiteSpace(secret);

		_key = keyId.Secure();
		_secret = secret.Secure();
	}

	/// <inheritdoc />
	public string Name => "binance-spot";

	/// <inheritdoc />
	public async Task<IReadOnlyList<Candle>> GetBarsAsync(
		string symbol,
		TimeSpan timeFrame,
		DateTime from,
		DateTime to,
		CancellationToken cancellationToken)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(symbol);

		if (from.Kind != DateTimeKind.Utc || to.Kind != DateTimeKind.Utc)
			throw new ArgumentException("History is requested over UTC moments.", nameof(from));

		using var adapter = new BinanceMessageAdapter(new IncrementalIdGenerator())
		{
			Key = _key,
			Secret = _secret,
			Sections = [BinanceSections.Spot],
			IsDemo = false,
		};

		var request = new MarketDataMessage
		{
			DataType2 = timeFrame.TimeFrame(),
			SecurityId = new()
			{
				SecurityCode = symbol.Trim().ToUpperInvariant(),
				BoardCode = BrokerVenue.Binance.BoardCode,
			},
			From = from,
			To = to,
			BuildMode = MarketDataBuildModes.Load,
			IsSubscribe = true,
		};

		var candles = new List<Candle>();

		await foreach (var message in adapter
			.ConnectAndDownloadAsync<CandleMessage>(request)
			.WithCancellation(cancellationToken))
		{
			if (message.State != CandleStates.Finished)
				continue;

			candles.Add(new(
				DateTime.SpecifyKind(message.OpenTime, DateTimeKind.Utc),
				message.OpenPrice,
				message.HighPrice,
				message.LowPrice,
				message.ClosePrice,
				message.TotalVolume));
		}

		return candles;
	}
}
