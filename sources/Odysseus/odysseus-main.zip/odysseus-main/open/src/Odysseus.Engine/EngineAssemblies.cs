namespace Odysseus.Engine;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

using StockSharp.Algo.Strategies;

/// <summary>
/// The assemblies a generated strategy is written against.
/// </summary>
/// <remarks>
/// Named here rather than in the compiler, so that the compiler stays a compiler and the trading engine
/// is known in one place. The list is taken from what is actually loaded rather than from a hard-coded
/// set of names: a strategy compiled against a different build of the engine than the one that will run
/// it produces failures that look like defects in the strategy.
/// </remarks>
public static class EngineAssemblies
{
	/// <summary>
	/// Paths of the assemblies to compile a strategy against.
	/// </summary>
	/// <returns>The paths.</returns>
	public static IReadOnlyList<string> Paths()
	{
		var directory = Path.GetDirectoryName(typeof(Strategy).Assembly.Location);

		return
		[
			.. Directory
				.EnumerateFiles(directory, "*.dll")
				.Where(f => IsEngine(Path.GetFileNameWithoutExtension(f)))
				.OrderBy(f => f, StringComparer.Ordinal),
		];
	}

	private static bool IsEngine(string name)
		=> name.StartsWith("StockSharp.", StringComparison.Ordinal) ||
			name.StartsWith("Ecng.", StringComparison.Ordinal);
}
