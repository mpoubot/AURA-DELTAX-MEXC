namespace Odysseus.Engine;

using System;
using System.Collections.Generic;
using System.Security;
using System.Threading;
using System.Threading.Tasks;

using Ecng.Common;

using StockSharp.Alpaca;
using StockSharp.Messages;

using Odysseus.Application;
using Odysseus.Domain;

/// <summary>
/// History downloaded through the StockSharp Alpaca connector.
/// </summary>
/// <remarks>
/// The connector is used rather than the broker's REST interface directly, because everything that
/// comes after this — live data, orders, option chains — is already implemented in it, and a
/// hand-written client would have to grow all of that again and be wrong in different places.
///
/// The download runs at the adapter level rather than through a <c>Connector</c>. For a bounded range of
/// finished bars there is nothing for the connector's machinery to add: no candle building from ticks,
/// no storage, no reconnect. Skipping it removes the security lookup and the websockets a connector
/// opens on connect, which a download does not need.
/// </remarks>
public sealed class AlpacaHistorySource : IHistorySource
{
	private readonly SecureString _key;
	private readonly SecureString _secret;
	private readonly string _feed;

	/// <summary>
	/// Creates the source.
	/// </summary>
	/// <param name="keyId">Key identifier.</param>
	/// <param name="secret">Key secret.</param>
	/// <param name="feed">Consolidated feed to read: <c>sip</c> for every exchange, <c>iex</c> for one.</param>
	public AlpacaHistorySource(string keyId, string secret, string feed = "sip")
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(keyId);
		ArgumentException.ThrowIfNullOrWhiteSpace(secret);
		ArgumentException.ThrowIfNullOrWhiteSpace(feed);

		_key = keyId.Secure();
		_secret = secret.Secure();
		_feed = feed.ToLowerInvariant();

		Name = $"alpaca-{_feed}";
	}

	/// <inheritdoc />
	public string Name { get; }

	/// <summary>
	/// Which market a symbol is quoted on.
	/// </summary>
	/// <param name="symbol">Symbol the caller named.</param>
	/// <returns>The board code.</returns>
	/// <remarks>
	/// The caller names a symbol and nothing else. Whether it happens to be a share or a listed contract
	/// is not something to be asked about or configured: an option symbol carries its own shape — the
	/// underlying, then six digits of expiry, a side and eight digits of strike — so what it is can be
	/// read off the name, and history for either arrives the same way.
	/// </remarks>
	internal static string BoardOf(string symbol)
		=> IsOptionSymbol(symbol) ? BoardCodes.Opra : BoardCodes.Nasdaq;

	private static bool IsOptionSymbol(string symbol)
	{
		// Root, yyMMdd, C or P, then the strike in thousandths: NVDA260828C00050000.
		const int tail = 15;

		if (symbol is null || symbol.Length <= tail)
			return false;

		var suffix = symbol[^tail..];

		if (suffix[6] is not ('C' or 'P' or 'c' or 'p'))
			return false;

		for (var i = 0; i < tail; i++)
		{
			if (i != 6 && !char.IsAsciiDigit(suffix[i]))
				return false;
		}

		return true;
	}

	/// <inheritdoc />
	public async Task<IReadOnlyList<Candle>> GetBarsAsync(
		string symbol,
		TimeSpan timeFrame,
		DateTime from,
		DateTime to,
		CancellationToken cancellationToken)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(symbol);

		if (from.Kind != DateTimeKind.Utc || to.Kind != DateTimeKind.Utc)
			throw new ArgumentException("History is requested over UTC moments.", nameof(from));

		using var adapter = new AlpacaMessageAdapter(new IncrementalIdGenerator())
		{
			Key = _key,
			Secret = _secret,

			// Paper. Setting it also forces the feed to the single-exchange one, so the feed is assigned
			// afterwards and never before: read in the wrong order this silently downloads a few percent
			// of the real volume and everything measured on it is measured on a fraction of the market.
			IsDemo = true,
		};

		adapter.StockFeed = _feed;
		adapter.Sections = [AlpacaSections.Stock, AlpacaSections.Option];

		var request = new MarketDataMessage
		{
			DataType2 = timeFrame.TimeFrame(),
			SecurityId = new() { SecurityCode = symbol, BoardCode = BoardOf(symbol) },
			From = from,

			// Without an end the subscription runs into live data and never finishes.
			To = to,
			BuildMode = MarketDataBuildModes.Load,
			IsSubscribe = true,
		};

		var candles = new List<Candle>();

		await foreach (var message in adapter
			.ConnectAndDownloadAsync<CandleMessage>(request)
			.WithCancellation(cancellationToken))
		{
			if (message.State != CandleStates.Finished)
				continue;

			candles.Add(new(
				DateTime.SpecifyKind(message.OpenTime, DateTimeKind.Utc),
				message.OpenPrice,
				message.HighPrice,
				message.LowPrice,
				message.ClosePrice,
				message.TotalVolume));
		}

		return candles;
	}
}
