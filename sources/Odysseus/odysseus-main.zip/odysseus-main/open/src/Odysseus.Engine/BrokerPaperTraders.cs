namespace Odysseus.Engine;

using System;
using System.Security;

using Ecng.Common;

using StockSharp.Alpaca;
using StockSharp.Binance;
using StockSharp.Messages;

using Odysseus.Application;

/// <summary>Runs candidates against an Alpaca paper account.</summary>
public sealed class AlpacaPaperTrader : StockSharpPaperTrader
{
	private readonly SecureString _key;
	private readonly SecureString _secret;
	private readonly string _feed;

	/// <summary>Creates an Alpaca paper trader.</summary>
	public AlpacaPaperTrader(string keyId, string secret, string feed = "iex")
		: base(BrokerVenue.Alpaca, $"alpaca-paper-{feed?.ToLowerInvariant()}")
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(keyId);
		ArgumentException.ThrowIfNullOrWhiteSpace(secret);
		ArgumentException.ThrowIfNullOrWhiteSpace(feed);

		if (!feed.Equals("iex", StringComparison.OrdinalIgnoreCase) &&
			!feed.Equals("sip", StringComparison.OrdinalIgnoreCase))
			throw new ArgumentException("The Alpaca stock feed must be 'iex' or 'sip'.", nameof(feed));

		_key = keyId.Secure();
		_secret = secret.Secure();
		_feed = feed.ToLowerInvariant();
	}

	/// <inheritdoc />
	protected override IMessageAdapter CreateAdapter(IdGenerator transactionIdGenerator)
	{
		var adapter = new AlpacaMessageAdapter(transactionIdGenerator)
		{
			Key = _key,
			Secret = _secret,
			IsDemo = true,
			StockFeed = _feed,
			Sections = [AlpacaSections.Stock, AlpacaSections.Option],
		};

		return adapter;
	}

	/// <inheritdoc />
	protected override string BoardOf(string symbol) => AlpacaHistorySource.BoardOf(symbol);
}

/// <summary>
/// Runs candidates against Binance Spot Testnet. There is deliberately no production-trading switch.
/// </summary>
public sealed class BinancePaperTrader : StockSharpPaperTrader
{
	private readonly SecureString _key;
	private readonly SecureString _secret;

	/// <summary>Creates a Binance Spot Testnet trader.</summary>
	public BinancePaperTrader(string keyId, string secret)
		: base(BrokerVenue.Binance, "binance-spot-testnet")
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(keyId);
		ArgumentException.ThrowIfNullOrWhiteSpace(secret);

		_key = keyId.Secure();
		_secret = secret.Secure();
	}

	/// <inheritdoc />
	protected override IMessageAdapter CreateAdapter(IdGenerator transactionIdGenerator)
		=> new BinanceMessageAdapter(transactionIdGenerator)
		{
			Key = _key,
			Secret = _secret,
			Sections = [BinanceSections.Spot],

			// Testnet is an invariant of this type, not a user setting.
			IsDemo = true,
		};

	/// <inheritdoc />
	protected override string NormalizeSymbol(string symbol) => symbol.Trim().ToUpperInvariant();
}
