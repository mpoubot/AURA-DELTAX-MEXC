namespace Odysseus.Application;

using System;
using System.Collections.Generic;
using System.Linq;

using Odysseus.Domain;

/// <summary>How much, and how violently, the instrument moves.</summary>
/// <param name="MedianBarRangePercent">Middle bar's high-to-low range, as a percentage of its close.</param>
/// <param name="UpperBarRangePercent">Range of the widest one bar in ten, as a percentage.</param>
/// <param name="MedianDailyRangePercent">Middle day's high-to-low range, as a percentage.</param>
/// <param name="AnnualisedVolatilityPercent">Standard deviation of daily returns, annualised.</param>
public sealed record MovementProfile(
	decimal MedianBarRangePercent,
	decimal UpperBarRangePercent,
	decimal MedianDailyRangePercent,
	decimal AnnualisedVolatilityPercent);

/// <summary>Whether moves tend to continue or to come back.</summary>
/// <param name="Autocorrelation1">Correlation between a bar's return and the next one's.</param>
/// <param name="Autocorrelation5">The same over five-bar returns.</param>
/// <param name="VarianceRatio5">Variance of five-bar returns against five times the one-bar variance.</param>
/// <param name="VarianceRatio20">The same over twenty bars.</param>
/// <param name="DirectionalDayShare">Share of days that closed near their extreme rather than mid-range.</param>
/// <remarks>
/// The variance ratios are the load-bearing numbers. Above one, moves extend and a breakout has
/// something to work with; below one, they come back and it does not. Around one the instrument is
/// telling you it has no memory at this horizon, which is worth knowing before spending a budget
/// looking for one.
/// </remarks>
public sealed record PersistenceProfile(
	decimal Autocorrelation1,
	decimal Autocorrelation5,
	decimal VarianceRatio5,
	decimal VarianceRatio20,
	decimal DirectionalDayShare);

/// <summary>What actually happened after the events a strategy would trade.</summary>
/// <param name="BreakoutCount">Bars that closed above the prior twenty-bar high.</param>
/// <param name="BreakoutFollowThroughPercent">Average return over the five bars after such a close.</param>
/// <param name="BreakoutPositiveShare">Share of those that were still positive five bars later.</param>
/// <param name="BreakdownCount">Bars that closed below the prior twenty-bar low.</param>
/// <param name="BreakdownFollowThroughPercent">Average return over the five bars after such a close.</param>
/// <param name="StretchCount">Bars that closed more than two standard deviations from the mean.</param>
/// <param name="StretchReversionPercent">Average return over the five bars after such a close, signed towards the mean.</param>
/// <remarks>
/// This section exists because the ratios above are summaries and this is the event itself. A hypothesis
/// that breakouts continue can be checked against the number of breakouts there actually were and what
/// followed them, before a line of code is written.
/// </remarks>
public sealed record EdgeProfile(
	int BreakoutCount,
	decimal BreakoutFollowThroughPercent,
	decimal BreakoutPositiveShare,
	int BreakdownCount,
	decimal BreakdownFollowThroughPercent,
	int StretchCount,
	decimal StretchReversionPercent);

/// <summary>How the day is shaped.</summary>
/// <param name="Bucket">Part of the session.</param>
/// <param name="ShareOfRange">Share of the day's range that happens here.</param>
/// <param name="ShareOfVolume">Share of the day's volume that happens here.</param>
/// <param name="AverageReturnPercent">Average return across this part of the session.</param>
public sealed record SessionBucket(string Bucket, decimal ShareOfRange, decimal ShareOfVolume, decimal AverageReturnPercent);

/// <summary>What the data covers.</summary>
/// <param name="Symbol">Instrument measured.</param>
/// <param name="Bars">Bars the measurements are based on.</param>
/// <param name="From">First bar, in UTC.</param>
/// <param name="To">Last bar, in UTC.</param>
/// <param name="Sessions">Distinct trading days covered.</param>
/// <param name="MedianVolume">Middle bar's volume.</param>
/// <param name="HighVolumeShare">Share of bars whose volume exceeded twice the recent average.</param>
public sealed record CoverageProfile(
	string Symbol,
	int Bars,
	DateTime From,
	DateTime To,
	int Sessions,
	decimal MedianVolume,
	decimal HighVolumeShare);

/// <summary>
/// What was measured in one instrument's history.
/// </summary>
/// <param name="Coverage">What the measurements are based on.</param>
/// <param name="Movement">How much it moves.</param>
/// <param name="Persistence">Whether moves continue or come back.</param>
/// <param name="Edge">What followed the events a strategy would trade.</param>
/// <param name="Session">How the day is shaped.</param>
/// <param name="Caveats">Anything that limits how far these numbers can be trusted.</param>
public sealed record MarketProfile(
	CoverageProfile Coverage,
	MovementProfile Movement,
	PersistenceProfile Persistence,
	EdgeProfile Edge,
	IReadOnlyList<SessionBucket> Session,
	IReadOnlyList<string> Caveats);

/// <summary>
/// Measures what an instrument's history actually contains.
/// </summary>
/// <remarks>
/// This exists so that a hypothesis starts from the instrument rather than from a template. Asked for a
/// strategy with nothing else to go on, any agent will propose a breakout, because breakouts are what
/// the literature is full of — regardless of whether this instrument extends its moves or gives them
/// straight back. Handing over measured numbers first turns the first proposal from a guess into a
/// response to evidence.
///
/// Everything here is measured on the development slice alone. Profiling the validation or the closed
/// slice would mean forming hypotheses on the very data reserved for judging them, which is the same
/// leak as looking at the answers, only harder to notice.
///
/// Nothing here recommends a strategy. These are measurements, and the reasoning is the agent's.
/// </remarks>
public static class MarketProfiler
{
	private const int BreakoutWindow = 20;
	private const int Horizon = 5;

	/// <summary>Fewest bars worth measuring anything on.</summary>
	public const int MinimumBars = 200;

	/// <summary>
	/// Measures one instrument.
	/// </summary>
	/// <param name="symbol">Instrument being measured.</param>
	/// <param name="candles">Bars of the development slice, oldest first.</param>
	/// <param name="timeFrame">Length of one bar.</param>
	/// <returns>What was measured.</returns>
	/// <exception cref="ArgumentException">There are too few bars for the measurements to mean anything.</exception>
	public static MarketProfile Measure(string symbol, IReadOnlyList<Candle> candles, TimeSpan timeFrame)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(symbol);
		ArgumentNullException.ThrowIfNull(candles);

		if (candles.Count < MinimumBars)
		{
			throw new ArgumentException(
				$"'{symbol}' has {candles.Count} bars in the development slice; at least {MinimumBars} are needed " +
				"before an average means anything. Widen the date range or use a shorter timeframe.",
				nameof(candles));
		}

		var returns = Returns(candles);
		var days = candles.GroupBy(c => c.OpenTime.Date).OrderBy(g => g.Key).ToArray();
		var caveats = new List<string>();

		if (days.Length < 20)
			caveats.Add($"Only {days.Length} trading days are covered, so anything measured per day rests on very few observations.");

		if (candles.Count < 1000)
			caveats.Add($"{candles.Count} bars is a small sample; treat the event counts below as indicative rather than settled.");

		return new(
			MeasureCoverage(symbol, candles, days.Length),
			MeasureMovement(candles, days, timeFrame),
			MeasurePersistence(returns, days),
			MeasureEdge(candles, returns),
			MeasureSession(candles),
			caveats);
	}

	private static CoverageProfile MeasureCoverage(string symbol, IReadOnlyList<Candle> candles, int sessions)
	{
		var volumes = candles.Select(c => c.Volume).ToArray();
		var high = 0;

		for (var i = 30; i < candles.Count; i++)
		{
			var average = candles.Skip(i - 30).Take(30).Average(c => c.Volume);

			if (average > 0 && candles[i].Volume > average * 2)
				high++;
		}

		return new(
			symbol,
			candles.Count,
			candles[0].OpenTime,
			candles[^1].OpenTime,
			sessions,
			Median(volumes),
			candles.Count > 30 ? Round((decimal)high / (candles.Count - 30) * 100) : 0);
	}

	private static MovementProfile MeasureMovement(
		IReadOnlyList<Candle> candles,
		IReadOnlyList<IGrouping<DateTime, Candle>> days,
		TimeSpan timeFrame)
	{
		var ranges = candles
			.Where(c => c.Close > 0)
			.Select(c => (c.High - c.Low) / c.Close * 100)
			.OrderBy(r => r)
			.ToArray();

		var dailyRanges = days
			.Select(d => (d.Max(c => c.High) - d.Min(c => c.Low)) / d.Last().Close * 100)
			.OrderBy(r => r)
			.ToArray();

		var dailyReturns = days
			.Zip(days.Skip(1))
			.Where(p => p.First.Last().Close > 0)
			.Select(p => (double)((p.Second.Last().Close - p.First.Last().Close) / p.First.Last().Close))
			.ToArray();

		var annualised = dailyReturns.Length > 1
			? (decimal)(StandardDeviation(dailyReturns) * Math.Sqrt(252) * 100)
			: 0m;

		return new(
			Round(Median(ranges)),
			Round(Percentile(ranges, 0.9)),
			Round(Median(dailyRanges)),
			Round(annualised));
	}

	private static PersistenceProfile MeasurePersistence(
		double[] returns,
		IReadOnlyList<IGrouping<DateTime, Candle>> days)
	{
		var directional = days.Count(d =>
		{
			var range = d.Max(c => c.High) - d.Min(c => c.Low);

			return range > 0 && Math.Abs(d.Last().Close - d.First().Open) / range > 0.6m;
		});

		return new(
			Round((decimal)Autocorrelation(returns, 1)),
			Round((decimal)Autocorrelation(returns, 5)),
			Round((decimal)VarianceRatio(returns, 5)),
			Round((decimal)VarianceRatio(returns, 20)),
			days.Count > 0 ? Round((decimal)directional / days.Count * 100) : 0);
	}

	private static EdgeProfile MeasureEdge(IReadOnlyList<Candle> candles, double[] returns)
	{
		var breakouts = new List<decimal>();
		var breakdowns = new List<decimal>();
		var stretches = new List<decimal>();

		var deviation = (decimal)StandardDeviation(returns);

		for (var i = BreakoutWindow; i < candles.Count - Horizon; i++)
		{
			var window = candles.Skip(i - BreakoutWindow).Take(BreakoutWindow).ToArray();
			var close = candles[i].Close;

			if (close <= 0)
				continue;

			var forward = (candles[i + Horizon].Close - close) / close * 100;

			if (close > window.Max(c => c.High))
				breakouts.Add(forward);

			if (close < window.Min(c => c.Low))
				breakdowns.Add(forward);

			var mean = window.Average(c => c.Close);

			if (mean > 0 && deviation > 0)
			{
				var distance = (close - mean) / mean;

				// Signed towards the mean, so a positive number means the move came back regardless of
				// which side it was stretched to.
				if (Math.Abs(distance) > deviation * 2)
					stretches.Add(distance > 0 ? -forward : forward);
			}
		}

		return new(
			breakouts.Count,
			breakouts.Count > 0 ? Round(breakouts.Average()) : 0,
			breakouts.Count > 0 ? Round((decimal)breakouts.Count(r => r > 0) / breakouts.Count * 100) : 0,
			breakdowns.Count,
			breakdowns.Count > 0 ? Round(breakdowns.Average()) : 0,
			stretches.Count,
			stretches.Count > 0 ? Round(stretches.Average()) : 0);
	}

	private static IReadOnlyList<SessionBucket> MeasureSession(IReadOnlyList<Candle> candles)
	{
		var buckets = new List<SessionBucket>();

		var totalRange = candles.Sum(c => c.High - c.Low);
		var totalVolume = candles.Sum(c => c.Volume);

		foreach (var (name, test) in Buckets(candles))
		{
			var inside = candles.Where(test).ToArray();

			if (inside.Length == 0)
				continue;

			var returns = inside.Where(c => c.Open > 0).Select(c => (c.Close - c.Open) / c.Open * 100).ToArray();

			buckets.Add(new(
				name,
				totalRange > 0 ? Round(inside.Sum(c => c.High - c.Low) / totalRange * 100) : 0,
				totalVolume > 0 ? Round(inside.Sum(c => c.Volume) / totalVolume * 100) : 0,
				returns.Length > 0 ? Round(returns.Average()) : 0));
		}

		return buckets;
	}

	private static IReadOnlyList<(string Name, Func<Candle, bool> Test)> Buckets(IReadOnlyList<Candle> candles)
	{
		var (open, close) = ActiveSession(candles);

		var early = open.Add(TimeSpan.FromMinutes(30));
		var late = close.Subtract(TimeSpan.FromMinutes(30));

		return
		[
			("outside the active session", c => c.OpenTime.TimeOfDay < open || c.OpenTime.TimeOfDay > close),
			("first 30 minutes", c => c.OpenTime.TimeOfDay >= open && c.OpenTime.TimeOfDay < early),
			("middle of the session", c => c.OpenTime.TimeOfDay >= early && c.OpenTime.TimeOfDay < late),
			("last 30 minutes", c => c.OpenTime.TimeOfDay >= late && c.OpenTime.TimeOfDay <= close),
		];
	}

	/// <summary>
	/// Finds the part of the day the instrument actually trades in.
	/// </summary>
	/// <param name="candles">Bars to look at.</param>
	/// <returns>Start and end of the active session, as times of day in UTC.</returns>
	/// <remarks>
	/// Taking the first and last bar of the day would call the session sixteen hours long whenever the
	/// feed includes extended hours, and then report that the opening half hour carries half a percent of
	/// the volume — true of four in the morning, and useless. The session is therefore where the volume
	/// is: the narrowest window of the day holding almost all of it. That also keeps the measurement a
	/// property of the instrument rather than of an exchange schedule written into the code.
	/// </remarks>
	public static (TimeSpan Open, TimeSpan Close) ActiveSession(IReadOnlyList<Candle> candles)
	{
		ArgumentNullException.ThrowIfNull(candles);

		var byMinute = candles
			.GroupBy(c => c.OpenTime.TimeOfDay)
			.ToDictionary(g => g.Key, g => g.Sum(c => c.Volume));

		var times = byMinute.Keys.OrderBy(t => t).ToArray();

		if (times.Length == 0)
			return (TimeSpan.Zero, TimeSpan.FromHours(24));

		var total = byMinute.Values.Sum();

		if (total <= 0)
			return (times[0], times[^1]);

		// Ninety percent, measured rather than guessed. Regular hours on a liquid American equity carry
		// about ninety-five percent of the day's volume, so a higher target forces the window to swallow
		// pre- and post-market to reach it, and the opening half hour then lands at four in the morning.
		var target = total * 0.90m;
		var best = (Start: 0, End: times.Length - 1);
		var narrowest = TimeSpan.MaxValue;
		var running = 0m;
		var start = 0;

		// Smallest window whose volume reaches the target, found by walking one end forward and pulling the
		// other after it.
		for (var end = 0; end < times.Length; end++)
		{
			running += byMinute[times[end]];

			while (running - byMinute[times[start]] >= target && start < end)
			{
				running -= byMinute[times[start]];
				start++;
			}

			if (running < target)
				continue;

			var width = times[end] - times[start];

			if (width >= narrowest)
				continue;

			narrowest = width;
			best = (start, end);
		}

		return (times[best.Start], times[best.End]);
	}

	private static double[] Returns(IReadOnlyList<Candle> candles)
		=> [.. candles
			.Zip(candles.Skip(1))
			.Where(p => p.First.Close > 0)
			.Select(p => (double)((p.Second.Close - p.First.Close) / p.First.Close))];

	private static double Autocorrelation(double[] values, int lag)
	{
		if (values.Length <= lag + 1)
			return 0;

		var mean = values.Average();
		var numerator = 0d;
		var denominator = 0d;

		for (var i = 0; i < values.Length; i++)
		{
			denominator += (values[i] - mean) * (values[i] - mean);

			if (i + lag < values.Length)
				numerator += (values[i] - mean) * (values[i + lag] - mean);
		}

		return denominator == 0 ? 0 : numerator / denominator;
	}

	private static double VarianceRatio(double[] values, int horizon)
	{
		if (values.Length <= horizon * 2)
			return 1;

		var single = Variance(values);

		if (single == 0)
			return 1;

		var aggregated = new List<double>();

		for (var i = 0; i + horizon <= values.Length; i += horizon)
			aggregated.Add(values.Skip(i).Take(horizon).Sum());

		return Variance([.. aggregated]) / (single * horizon);
	}

	private static double Variance(double[] values)
	{
		if (values.Length < 2)
			return 0;

		var mean = values.Average();

		return values.Sum(v => (v - mean) * (v - mean)) / (values.Length - 1);
	}

	private static double StandardDeviation(double[] values)
		=> Math.Sqrt(Variance(values));

	private static decimal Median(decimal[] values)
	{
		if (values.Length == 0)
			return 0;

		var ordered = values.OrderBy(v => v).ToArray();

		return ordered[ordered.Length / 2];
	}

	private static decimal Percentile(decimal[] ordered, double share)
		=> ordered.Length == 0 ? 0 : ordered[Math.Min(ordered.Length - 1, (int)(ordered.Length * share))];

	private static decimal Round(decimal value)
		=> Math.Round(value, 4, MidpointRounding.AwayFromZero);
}
