namespace Odysseus.Application;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Domain;
using Odysseus.Evaluation;
using Odysseus.Spec;

/// <summary>
/// A named set of costs a run can be charged under.
/// </summary>
/// <param name="Name">What the scenario is called, which the report quotes.</param>
/// <param name="Costs">What it charges.</param>
public sealed record CostScenario(string Name, ExecutionCosts Costs)
{
	/// <summary>What a run is charged unless the caller names something else.</summary>
	public static CostScenario Baseline { get; } = new("baseline", ExecutionCosts.Default);

	/// <summary>
	/// Costs half again as high.
	/// </summary>
	/// <remarks>
	/// A result that survives the baseline and not this one rests on the costs being what was assumed,
	/// which is the assumption a live account is most likely to contradict.
	/// </remarks>
	public static CostScenario Stressed { get; } = new("costsX15", ExecutionCosts.Default.Scaled(1.5m));

	/// <summary>
	/// Finds a scenario by name.
	/// </summary>
	/// <param name="name">Name to look for, or empty for the baseline.</param>
	/// <returns>The scenario.</returns>
	/// <exception cref="ArgumentException">There is no scenario by that name.</exception>
	public static CostScenario Parse(string name)
	{
		if (string.IsNullOrWhiteSpace(name))
			return Baseline;

		return All.FirstOrDefault(s => string.Equals(s.Name, name, StringComparison.OrdinalIgnoreCase))
			?? throw new ArgumentException(
				$"'{name}' is not a cost scenario. There are: {string.Join(", ", All.Select(s => s.Name))}.",
				nameof(name));
	}

	/// <summary>Every scenario a run may be charged under.</summary>
	public static IReadOnlyList<CostScenario> All { get; } = [Baseline, Stressed];

	/// <summary>Applies the named stress level to the venue's own baseline assumptions.</summary>
	public CostScenario ForVenue(BrokerVenue venue)
	{
		ArgumentNullException.ThrowIfNull(venue);

		if (string.Equals(Name, Baseline.Name, StringComparison.OrdinalIgnoreCase))
			return new(Name, venue.Costs);

		if (string.Equals(Name, Stressed.Name, StringComparison.OrdinalIgnoreCase))
			return new(Name, venue.Costs.Scaled(1.5m));

		return this;
	}
}

/// <summary>
/// One consecutive part of a slice.
/// </summary>
/// <param name="Index">Which part, counting from one. Zero means the whole slice.</param>
/// <param name="Count">How many parts the slice is cut into.</param>
/// <remarks>
/// Walk-forward asks the same question of consecutive stretches of the same history. A candidate that
/// works in one of them and not in the others was found by the search rather than in the market, and
/// the only way to see that is to measure the stretches apart.
/// </remarks>
public sealed record RunWindow(int Index, int Count)
{
	/// <summary>The whole slice, undivided.</summary>
	public static RunWindow Whole { get; } = new(0, 1);

	/// <summary>Whether this is the whole slice rather than a part of it.</summary>
	public bool IsWhole => Index == 0;

	/// <summary>
	/// Cuts the part this window covers out of a slice.
	/// </summary>
	/// <typeparam name="T">Type of the items.</typeparam>
	/// <param name="items">Items of the whole slice, oldest first.</param>
	/// <returns>The items of this window.</returns>
	public IReadOnlyList<T> Cut<T>(IReadOnlyList<T> items)
	{
		ArgumentNullException.ThrowIfNull(items);

		if (IsWhole)
			return items;

		if (Index < 1 || Index > Count)
			throw new ArgumentOutOfRangeException(nameof(Index), Index, $"There is no window {Index} of {Count}.");

		// The last window takes the remainder, so no bar is left out by the division.
		var size = items.Count / Count;
		var from = (Index - 1) * size;
		var to = Index == Count ? items.Count : from + size;

		return [.. items.Skip(from).Take(to - from)];
	}
}

/// <summary>
/// Running a candidate over a slice of the frozen history, and measuring what it did.
/// </summary>
/// <remarks>
/// A run is the expensive thing a project does, so it is accounted for twice over: the allowance is
/// claimed before the work starts, and a run that has already been done is recognised and returned
/// rather than repeated. What makes two runs the same is stated rather than guessed — the same
/// candidate, the same data, the same slice, the same costs — so an agent that asks again gets the
/// answer instead of the bill.
/// </remarks>
public sealed class BacktestService
{
	private readonly IProjectStore _projects;
	private readonly ICandidateStore _candidates;
	private readonly ISpecStore _specs;
	private readonly IDatasetStore _datasets;
	private readonly IRunStore _runs;
	private readonly IArtifactStore _artifacts;
	private readonly IBacktestRunner _runner;
	private readonly IAuditLog _audit;
	private readonly IOperationLog _operations;
	private readonly IClock _clock;

	/// <summary>
	/// Creates the service.
	/// </summary>
	/// <param name="projects">Where projects are kept.</param>
	/// <param name="candidates">Where candidates are kept.</param>
	/// <param name="specs">Where specifications are kept.</param>
	/// <param name="datasets">Where datasets are kept.</param>
	/// <param name="runs">Where runs are kept.</param>
	/// <param name="artifacts">Where assemblies and result series are kept.</param>
	/// <param name="runner">What runs a candidate over bars.</param>
	/// <param name="audit">Where the permanent record is kept.</param>
	/// <param name="operations">Where operation keys are remembered.</param>
	/// <param name="clock">Source of the current moment.</param>
	public BacktestService(
		IProjectStore projects,
		ICandidateStore candidates,
		ISpecStore specs,
		IDatasetStore datasets,
		IRunStore runs,
		IArtifactStore artifacts,
		IBacktestRunner runner,
		IAuditLog audit,
		IOperationLog operations,
		IClock clock)
	{
		_projects = projects ?? throw new ArgumentNullException(nameof(projects));
		_candidates = candidates ?? throw new ArgumentNullException(nameof(candidates));
		_specs = specs ?? throw new ArgumentNullException(nameof(specs));
		_datasets = datasets ?? throw new ArgumentNullException(nameof(datasets));
		_runs = runs ?? throw new ArgumentNullException(nameof(runs));
		_artifacts = artifacts ?? throw new ArgumentNullException(nameof(artifacts));
		_runner = runner ?? throw new ArgumentNullException(nameof(runner));
		_audit = audit ?? throw new ArgumentNullException(nameof(audit));
		_operations = operations ?? throw new ArgumentNullException(nameof(operations));
		_clock = clock ?? throw new ArgumentNullException(nameof(clock));
	}

	/// <summary>Money a run starts with, which every return is measured against.</summary>
	public const decimal StartingEquity = 100_000m;

	/// <summary>
	/// Smallest price movement of the instruments this server trades. American equities tick in cents
	/// above a dollar, and that is the whole of the market it downloads.
	/// </summary>
	public const decimal PriceStep = 0.01m;

	/// <summary>
	/// Runs a candidate over a slice.
	/// </summary>
	/// <param name="project">Project the candidate belongs to.</param>
	/// <param name="candidate">Candidate to run.</param>
	/// <param name="slice">Slice to run over.</param>
	/// <param name="window">Part of the slice to run over, or the whole of it.</param>
	/// <param name="symbol">Symbol to trade, or null for the first of the dataset.</param>
	/// <param name="scenario">Costs to charge.</param>
	/// <param name="parameters">Values to set on the strategy, or null for the ones it declares.</param>
	/// <param name="operationKey">Key that makes a repeated call return the first result.</param>
	/// <param name="actor">Who is asking.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The run and whether it was already there.</returns>
	public ValueTask<(RunResult Run, bool WasAlreadyRun)> RunAsync(
		ProjectId project,
		CandidateId candidate,
		DataSlices slice,
		RunWindow window,
		string symbol,
		CostScenario scenario,
		IReadOnlyDictionary<string, decimal> parameters,
		string operationKey,
		Actors actor,
		CancellationToken cancellationToken)
	{
		if (slice == DataSlices.Final)
		{
			throw new ArgumentException(
				"The closed part of the history is not run from here. It is used once, for the finalist " +
				"only, through the final check; running it as an ordinary slice is how a held-back result " +
				"stops being held back.",
				nameof(slice));
		}

		return RunCoreAsync(
			project, candidate, slice, window, symbol, scenario, parameters, operationKey, actor, cancellationToken);
	}

	/// <summary>
	/// Runs a candidate over the closed part of the history.
	/// </summary>
	/// <param name="project">Project the candidate belongs to.</param>
	/// <param name="candidate">Candidate to run.</param>
	/// <param name="window">Which part of the closed slice, or the whole of it.</param>
	/// <param name="symbol">Symbol to trade, or null for the first of the dataset.</param>
	/// <param name="scenario">Costs to charge.</param>
	/// <param name="parameters">Values to set on the strategy, or null for the ones it declares.</param>
	/// <param name="operationKey">Key that makes a repeated call return the first result.</param>
	/// <param name="actor">Who is asking.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The run and whether it was already there.</returns>
	/// <remarks>
	/// Internal, and called from exactly one place. The closed slice has one door, and whether a
	/// candidate may go through it is decided by the final check rather than by whoever is asking.
	/// </remarks>
	internal ValueTask<(RunResult Run, bool WasAlreadyRun)> RunClosedAsync(
		ProjectId project,
		CandidateId candidate,
		RunWindow window,
		string symbol,
		CostScenario scenario,
		IReadOnlyDictionary<string, decimal> parameters,
		string operationKey,
		Actors actor,
		CancellationToken cancellationToken)
		=> RunCoreAsync(
			project, candidate, DataSlices.Final, window, symbol, scenario, parameters,
			operationKey, actor, cancellationToken);

	private async ValueTask<(RunResult Run, bool WasAlreadyRun)> RunCoreAsync(
		ProjectId project,
		CandidateId candidate,
		DataSlices slice,
		RunWindow window,
		string symbol,
		CostScenario scenario,
		IReadOnlyDictionary<string, decimal> parameters,
		string operationKey,
		Actors actor,
		CancellationToken cancellationToken)
	{
		ArgumentNullException.ThrowIfNull(window);
		ArgumentNullException.ThrowIfNull(scenario);
		ArgumentException.ThrowIfNullOrWhiteSpace(operationKey);

		var recorded = await _operations.TryGetAsync(project.Value, operationKey, cancellationToken);

		if (recorded is not null)
			return (await _runs.GetAsync(project, RunId.Parse(recorded), cancellationToken), true);

		var existing = await _projects.OpenAsync(project, cancellationToken);

		if (existing.Dataset.IsEmpty)
			throw new InvalidOperationException("This project has no data, so there is nothing to run against.");

		var built = await _candidates.GetAsync(project, candidate, cancellationToken);
		var manifest = await _datasets.GetManifestAsync(project, existing.Dataset, cancellationToken);
		var venue = BrokerVenue.ForSource(manifest.Source);
		scenario = scenario.ForVenue(venue);

		symbol = string.IsNullOrWhiteSpace(symbol) ? manifest.Symbols[0] : symbol.Trim();

		if (!manifest.Symbols.Contains(symbol, StringComparer.Ordinal))
		{
			throw new ArgumentException(
				$"This project holds no '{symbol}'. It covers {string.Join(", ", manifest.Symbols)}.",
				nameof(symbol));
		}

		parameters ??= new Dictionary<string, decimal>(StringComparer.Ordinal);

		var fingerprint = Fingerprint(built, existing.Dataset, slice, window, symbol, scenario, parameters);
		var already = await _runs.FindAsync(project, fingerprint, cancellationToken);

		if (already is not null)
		{
			await _operations.RecordAsync(project.Value, operationKey, already.Id.Value, cancellationToken);

			return (already, true);
		}

		// Claimed where the number is kept rather than in a copy of it, so two runs arriving together
		// cost two. Kept only once the run is on record: see BudgetClaim.
		if (!await _projects.TryClaimAsync(project, backtests: 1, candidates: 0, cancellationToken))
		{
			var budget = ResearchBudget.Restore(existing.Budget);

			throw new ResearchBudgetExhaustedException(
				budget.RemainingWallClock == TimeSpan.Zero
					? $"This project has used the {existing.Budget.MaxWallClock.TotalMinutes:0} minutes of " +
						"machine time it was granted. Read what it measured rather than measuring more."
					: $"This project has already run its {existing.Budget.MaxBacktests} backtests. Read what " +
						"they measured rather than running another; a search that keeps running past its " +
						"allowance is looking for a result rather than testing a hypothesis.");
		}

		await using var claim = new BudgetClaim(_projects, project, backtests: 1, candidates: 0);

		var bars = window.Cut(await _datasets.LoadAsync(project, existing.Dataset, symbol, slice, cancellationToken));

		if (bars.Count == 0)
		{
			throw new InvalidOperationException(
				$"The {slice} slice of '{symbol}' holds no bars. Import more history: the slices are cut by " +
				"time, so a short import leaves the later ones empty.");
		}

		var assembly = await _artifacts.ReadAsync(project, built.Assembly, cancellationToken);
		var spec = SpecJson.Read((await _specs.GetAsync(project, built.Spec, cancellationToken)).Json);
		venue.EnsureStrategySupported(spec.AllowShort);

		// The bar length is part of the hypothesis: an average of twenty five-minute bars and an average
		// of twenty daily ones are different claims. Running the rules over bars of another length
		// measures a strategy nobody wrote, and it used to happen silently.
		if (spec.TimeFrame != manifest.TimeFrame)
		{
			throw new InvalidOperationException(
				$"This candidate was written for {spec.TimeFrame} bars and the project holds " +
				$"{manifest.TimeFrame} ones. Import the history at {spec.TimeFrame}, or propose the " +
				"hypothesis for the bars you have; the rules mean different things at different lengths.");
		}
		var startedAt = _clock.UtcNow;

		var request = new BacktestRequest(
			assembly,
			built.ClassName,
			parameters,
			symbol,
			manifest.TimeFrame,
			bars,
			StartingEquity,
			PositionSize(spec, symbol, bars[0].Open, venue.VolumeStep),
			venue.PriceStep,
			scenario.Costs,
			venue);

		RunResult run;

		try
		{
			var outcome = await _runner.RunAsync(request, cancellationToken);

			var metrics = RunMetricsCalculator.Measure(
				outcome.Trades,
				outcome.Equity,
				StartingEquity,
				bars[^1].OpenTime - bars[0].OpenTime,
				outcome.ExecutionErrorCount);

			var trades = await _artifacts.PutAsync(project, Serialize(outcome.Trades), cancellationToken);
			var equity = await _artifacts.PutAsync(project, Serialize(outcome.Equity), cancellationToken);

			run = new(
				RunId.New(),
				candidate,
				existing.Dataset,
				slice,
				window.Index,
				symbol,
				scenario.Name,
				fingerprint,
				parameters,
				RunStatuses.Completed,
				metrics,
				trades.Id,
				equity.Id,
				outcome.BarsProcessed,
				startedAt,
				_clock.UtcNow,
				null,
				RunDiagnosis.Explain(outcome.OrdersPlaced, outcome.Trades.Count, request.Volume, bars));
		}
		catch (Exception error) when (error is not OperationCanceledException)
		{
			// A failed run still costs the allowance and is still recorded. It is evidence: a candidate
			// that cannot be run is a candidate that has been answered, and hiding the attempt would let
			// the same one be proposed again.
			var empty = await _artifacts.PutAsync(project, Serialize(Array.Empty<ExecutedTrade>()), cancellationToken);

			run = new(
				RunId.New(),
				candidate,
				existing.Dataset,
				slice,
				window.Index,
				symbol,
				scenario.Name,
				fingerprint,
				parameters,
				RunStatuses.Failed,
				null,
				empty.Id,
				empty.Id,
				0,
				startedAt,
				_clock.UtcNow,
				error.Message,
				null);
		}

		var claimed = await _operations.RecordAsync(project.Value, operationKey, run.Id.Value, cancellationToken);

		if (claimed != run.Id.Value)
			return (await _runs.GetAsync(project, RunId.Parse(claimed), cancellationToken), true);

		await _runs.AddAsync(project, run, cancellationToken);

		claim.Keep();

		// Time is charged by work that finished, because nothing knows how long a run will take before it
		// takes it.
		await _projects.ChargeTimeAsync(project, run.Elapsed, cancellationToken);
		await _projects.UpdateAsync(existing with { UpdatedAt = _clock.UtcNow }, cancellationToken);

		await _audit.AppendAsync(
			project,
			run.Status == RunStatuses.Completed ? AuditEventTypes.RunCompleted : AuditEventTypes.RunStarted,
			actor,
			run.Status == RunStatuses.Completed
				? $"Ran {built.ClassName} on {symbol} over {slice} under {scenario.Name}: " +
					$"{run.Metrics.Trades.Count} trades, net {run.Metrics.Net.Profit:F2}."
				: $"Ran {built.ClassName} on {symbol} over {slice} under {scenario.Name} and it failed: {run.Error}",
			fingerprint,
			cancellationToken);

		if (run.Status == RunStatuses.Completed && built.Status == CandidateStatuses.Compiled)
			await _candidates.UpdateAsync(project, built.WithStatus(CandidateStatuses.Backtested, _clock.UtcNow), cancellationToken);

		return (run, false);
	}

	/// <summary>
	/// Reads one run.
	/// </summary>
	/// <param name="project">Project the run belongs to.</param>
	/// <param name="run">Run to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The run.</returns>
	public ValueTask<RunResult> GetAsync(ProjectId project, RunId run, CancellationToken cancellationToken)
		=> _runs.GetAsync(project, run, cancellationToken);

	/// <summary>
	/// Lists the runs of a project.
	/// </summary>
	/// <param name="project">Project to list.</param>
	/// <param name="candidate">Candidate to list the runs of, or the default value for all of them.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The runs, oldest first.</returns>
	public ValueTask<IReadOnlyList<RunResult>> ListAsync(
		ProjectId project,
		CandidateId candidate,
		CancellationToken cancellationToken)
		=> _runs.ListAsync(project, candidate, cancellationToken);

	/// <summary>
	/// Reads the trades of a run.
	/// </summary>
	/// <param name="project">Project the run belongs to.</param>
	/// <param name="run">Run to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The trades.</returns>
	public async ValueTask<IReadOnlyList<ExecutedTrade>> ReadTradesAsync(
		ProjectId project,
		RunId run,
		CancellationToken cancellationToken)
	{
		var existing = await _runs.GetAsync(project, run, cancellationToken);
		var content = await _artifacts.ReadAsync(project, existing.Trades, cancellationToken);

		return JsonSerializer.Deserialize<ExecutedTrade[]>(content);
	}

	/// <summary>
	/// Cuts a run's result apart to see where it came from.
	/// </summary>
	/// <param name="project">Project the run belongs to.</param>
	/// <param name="run">Run to explain.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The result, cut by month, by part of the session, by holding time and by direction.</returns>
	/// <remarks>
	/// Nothing is re-run and nothing is charged: these are the trades the run already recorded, grouped.
	/// </remarks>
	public async ValueTask<RunBreakdown> ExplainAsync(
		ProjectId project,
		RunId run,
		CancellationToken cancellationToken)
	{
		var existing = await _runs.GetAsync(project, run, cancellationToken);
		var content = await _artifacts.ReadAsync(project, existing.Trades, cancellationToken);
		var trades = JsonSerializer.Deserialize<ExecutedTrade[]>(content);

		// The whole slice, not the window the run measured: the bars are read for the hours the instrument
		// trades in, and those are a property of the instrument rather than of one stretch of it.
		var bars = await _datasets.LoadAsync(
			project, existing.Dataset, existing.Symbol, existing.Slice, cancellationToken);

		return RunBreakdownCalculator.Measure(trades, bars);
	}

	/// <summary>
	/// Reads the equity curve of a run.
	/// </summary>
	/// <param name="project">Project the run belongs to.</param>
	/// <param name="run">Run to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The curve.</returns>
	public async ValueTask<IReadOnlyList<EquityPoint>> ReadEquityAsync(
		ProjectId project,
		RunId run,
		CancellationToken cancellationToken)
	{
		var existing = await _runs.GetAsync(project, run, cancellationToken);
		var content = await _artifacts.ReadAsync(project, existing.Equity, cancellationToken);

		return JsonSerializer.Deserialize<EquityPoint[]>(content);
	}

	/// <summary>
	/// How many units one position holds. The specification says what share of the account a position may
	/// take, so the run buys that much of it at the first price of the slice and keeps the size fixed for
	/// the whole run. Fixed rather than compounding, because a size that grows with the account turns a
	/// good first month into most of the result and hides what the rules actually did.
	/// </summary>
	/// <param name="spec">Specification whose risk block says how much of the account a position may take.</param>
	/// <param name="symbol">Symbol to be traded, which says how much one unit of it carries.</param>
	/// <param name="price">Price to size against.</param>
	/// <param name="volumeStep">Smallest quantity the venue accepts.</param>
	/// <returns>Units of the symbol.</returns>
	/// <remarks>
	/// Sized by what a unit carries rather than by what it costs. A contract quoted at 9.05 carries 905
	/// dollars of exposure, so a tenth of a hundred thousand is eleven of them - not the eleven hundred
	/// that dividing by the quoted price would buy, which is a million dollars of exposure on a
	/// hundred-thousand-dollar account.
	/// </remarks>
	internal static decimal PositionSize(StrategySpec spec, string symbol, decimal price, decimal volumeStep = 1m)
	{
		if (price <= 0)
			throw new InvalidOperationException("The first bar of the slice has no price to size a position against.");

		if (volumeStep <= 0)
			throw new ArgumentOutOfRangeException(nameof(volumeStep), "The volume step must be positive.");

		var exposure = price * ContractSymbol.SizeOf(symbol);
		var raw = StartingEquity * spec.Risk.MaxPositionPercent / exposure;

		return Math.Max(volumeStep, Math.Floor(raw / volumeStep) * volumeStep);
	}

	private static byte[] Serialize<T>(IReadOnlyList<T> items)
		=> JsonSerializer.SerializeToUtf8Bytes(items);

	private static string Fingerprint(
		Candidate candidate,
		DatasetVersionId dataset,
		DataSlices slice,
		RunWindow window,
		string symbol,
		CostScenario scenario,
		IReadOnlyDictionary<string, decimal> parameters)
	{
		var settings = string.Join(
			",",
			parameters
				.OrderBy(p => p.Key, StringComparer.Ordinal)
				.Select(p => $"{p.Key}={p.Value.ToString(CultureInfo.InvariantCulture)}"));

		var material =
			$"{candidate.AssemblyHash}|{dataset.Value}|{slice}|{window.Index}/{window.Count}|{symbol}|" +
			$"{scenario.Name}|{scenario.Costs.Fees.ToString(CultureInfo.InvariantCulture)}|" +
			$"{scenario.Costs.HalfSpread.ToString(CultureInfo.InvariantCulture)}|" +
			$"{scenario.Costs.FeePercent.ToString(CultureInfo.InvariantCulture)}|" +
			$"{scenario.Costs.SpreadPercent.ToString(CultureInfo.InvariantCulture)}|{settings}";

		return Convert.ToHexStringLower(SHA256.HashData(Encoding.UTF8.GetBytes(material)));
	}
}

/// <summary>
/// Thrown when a run that was asked for does not exist.
/// </summary>
public sealed class RunNotFoundException : Exception
{
	/// <summary>
	/// Creates the exception.
	/// </summary>
	/// <param name="id">Run that was not found.</param>
	public RunNotFoundException(RunId id)
		: base($"Run {id} does not exist in this project.")
	{
		Id = id;
	}

	/// <summary>Run that was not found.</summary>
	public RunId Id { get; }
}
