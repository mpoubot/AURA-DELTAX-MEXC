namespace Odysseus.Application;

using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Domain;

/// <summary>
/// Keeps datasets and the bars behind them.
/// </summary>
/// <remarks>
/// A saved dataset is never modified. Re-importing produces a new version with its own identity, so a
/// result that names a dataset version can always be re-run against exactly the bars it was measured on.
/// </remarks>
public interface IDatasetStore
{
	/// <summary>
	/// Saves a dataset and its bars.
	/// </summary>
	/// <param name="project">Project the dataset belongs to.</param>
	/// <param name="dataset">Dataset to save.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>A task that completes when the dataset is on disk.</returns>
	ValueTask SaveAsync(ProjectId project, ImportedDataset dataset, CancellationToken cancellationToken);

	/// <summary>
	/// Reads the description of a dataset.
	/// </summary>
	/// <param name="project">Project the dataset belongs to.</param>
	/// <param name="dataset">Dataset to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The manifest.</returns>
	/// <exception cref="DatasetNotFoundException">The dataset does not exist.</exception>
	ValueTask<DatasetManifest> GetManifestAsync(ProjectId project, DatasetVersionId dataset, CancellationToken cancellationToken);

	/// <summary>
	/// Reads the bars of one symbol within one slice.
	/// </summary>
	/// <param name="project">Project the dataset belongs to.</param>
	/// <param name="dataset">Dataset to read.</param>
	/// <param name="symbol">Symbol to read.</param>
	/// <param name="slice">Slice to read.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The bars, oldest first.</returns>
	/// <exception cref="DatasetNotFoundException">The dataset does not exist.</exception>
	ValueTask<IReadOnlyList<Candle>> LoadAsync(
		ProjectId project,
		DatasetVersionId dataset,
		string symbol,
		DataSlices slice,
		CancellationToken cancellationToken);
}
