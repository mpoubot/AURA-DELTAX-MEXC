namespace Odysseus.Application;

using System;
using System.IO;
using System.Text.RegularExpressions;

/// <summary>
/// Brokers supported by this build.
/// </summary>
public enum BrokerKinds
{
	/// <summary>Alpaca's American-equities paper account.</summary>
	Alpaca,

	/// <summary>Binance Spot Testnet.</summary>
	Binance,
}

/// <summary>
/// Credentials for one configured broker.
/// </summary>
/// <param name="Kind">Broker the credentials belong to.</param>
/// <param name="KeyId">API key identifier.</param>
/// <param name="Secret">API secret.</param>
/// <remarks>
/// Secret values are read from a file whose path is named by an environment variable. They are never
/// accepted on the command line, written to a project, or included in a diagnostic message.
/// </remarks>
public sealed record BrokerCredentials(BrokerKinds Kind, string KeyId, string Secret)
{
	/// <summary>Name of the broker-selection environment variable.</summary>
	public const string BrokerVariable = "ODYSSEUS_BROKER";

	/// <summary>Name of the Alpaca key-file environment variable.</summary>
	public const string AlpacaKeysVariable = "ODYSSEUS_ALPACA_KEYS";

	/// <summary>Name of the Binance key-file environment variable.</summary>
	public const string BinanceKeysVariable = "ODYSSEUS_BINANCE_KEYS";

	/// <summary>
	/// Reads the broker selection and credential paths from the process environment.
	/// </summary>
	/// <returns>One unambiguous set of credentials, or null when no broker is configured.</returns>
	public static BrokerCredentials ReadEnvironment()
		=> Read(
			Environment.GetEnvironmentVariable(BrokerVariable),
			Environment.GetEnvironmentVariable(AlpacaKeysVariable),
			Environment.GetEnvironmentVariable(BinanceKeysVariable));

	/// <summary>
	/// Resolves an explicit or inferable broker without ever returning either secret in an error.
	/// </summary>
	/// <param name="broker">Optional broker name.</param>
	/// <param name="alpacaPath">Optional Alpaca key-file path.</param>
	/// <param name="binancePath">Optional Binance key-file path.</param>
	/// <returns>Credentials, or null when neither key file is usable.</returns>
	public static BrokerCredentials Read(string broker, string alpacaPath, string binancePath)
	{
		var selected = ParseKind(broker);

		if (selected is BrokerKinds.Alpaca)
			return ReadFile(BrokerKinds.Alpaca, alpacaPath);

		if (selected is BrokerKinds.Binance)
			return ReadFile(BrokerKinds.Binance, binancePath);

		var alpaca = ReadFile(BrokerKinds.Alpaca, alpacaPath);
		var binance = ReadFile(BrokerKinds.Binance, binancePath);

		if (alpaca is not null && binance is not null)
		{
			throw new InvalidOperationException(
				$"Both broker key files are configured. Set {BrokerVariable} to 'alpaca' or 'binance'.");
		}

		return alpaca ?? binance;
	}

	private static BrokerKinds? ParseKind(string value)
	{
		if (string.IsNullOrWhiteSpace(value))
			return null;

		if (Enum.TryParse<BrokerKinds>(value.Trim(), ignoreCase: true, out var kind) && Enum.IsDefined(kind))
			return kind;

		throw new ArgumentException(
			$"{BrokerVariable} must be 'alpaca' or 'binance'.",
			nameof(value));
	}

	private static BrokerCredentials ReadFile(BrokerKinds kind, string path)
	{
		if (string.IsNullOrWhiteSpace(path) || !File.Exists(path))
			return null;

		var text = File.ReadAllText(path);
		var key = Find(text, "key");
		var secret = Find(text, "secret");

		return key is null || secret is null ? null : new(kind, key, secret);
	}

	private static string Find(string text, string name)
	{
		var match = Regex.Match(
			text,
			$@"^\s*{name}\s*[:=]\s*(\S+)\s*$",
			RegexOptions.Multiline | RegexOptions.IgnoreCase);

		return match.Success ? match.Groups[1].Value : null;
	}
}
