namespace Odysseus.Application;

using System;

/// <summary>
/// A failure, in the shape the published error contract declares.
/// </summary>
/// <param name="Category">Why the call failed.</param>
/// <param name="Message">What went wrong, in the caller's own terms.</param>
/// <param name="Remediation">What to do next.</param>
/// <param name="CorrelationId">Identifier tying this failure to the server logs.</param>
public sealed record ToolError(
	ToolErrorCategories Category,
	string Message,
	string Remediation,
	string CorrelationId);

/// <summary>
/// Turns an exception into the failure an agent receives.
/// </summary>
/// <remarks>
/// The text of a failure is not a log line; it is the next prompt. An agent that is told only that
/// something went wrong has nothing to aim at and spends its remaining attempts guessing, so every
/// mapping here keeps the message that names what was wrong and adds what to do about it. The one
/// exception is an unexpected defect, where the details stay in the log: an internal message could
/// carry a path or a value the caller must not see.
/// </remarks>
public static class ToolErrors
{
	/// <summary>
	/// Maps an exception onto the error contract.
	/// </summary>
	/// <param name="error">Exception to map.</param>
	/// <param name="correlationId">Identifier tying the failure to the server logs.</param>
	/// <returns>The failure to return to the caller.</returns>
	public static ToolError Describe(Exception error, string correlationId)
	{
		ArgumentNullException.ThrowIfNull(error);
		ArgumentException.ThrowIfNullOrWhiteSpace(correlationId);

		return error switch
		{
			InvalidSpecException => new(
				ToolErrorCategories.SpecValidation,
				error.Message,
				"Every problem is listed with its place in the document and what would fix it. Correct them all " +
				"and propose again; validate_spec reports the same list without recording anything, so drafting " +
				"against it costs nothing.",
				correlationId),

			// The agent did not write this C# - the translator did - so a build failure is ours whichever
			// end it came from, and the answer says so rather than inviting a retry that cannot work.
			StrategyBuildException build => new(
				build.IsAnalyzerViolation ? ToolErrorCategories.AnalyzerViolation : ToolErrorCategories.CompilationFailed,
				(build.IsAnalyzerViolation
					? "The generated strategy broke a rule this server enforces on strategy code. "
					: "The generated strategy did not compile. ") + build.Enumerate(),
				"This is a defect in the server's translator rather than in your specification: the same " +
				"specification will emit the same source every time, so retrying will not help. Report it " +
				$"with correlation id {correlationId}. Line numbers are of the generated C#, which " +
				"get_candidate_source prints for any candidate that did build.",
				correlationId),

			BrokerNotConfiguredException => new(
				ToolErrorCategories.ConfigurationInvalid,
				error.Message,
				"Set ODYSSEUS_BROKER to 'alpaca' or 'binance', point the matching ODYSSEUS_ALPACA_KEYS " +
				"or ODYSSEUS_BINANCE_KEYS variable at a file holding 'key' and 'secret', and restart. " +
				"Everything that does not touch an account works without one: import_demo_dataset brings in " +
				"bundled data, and analyze_market, the backtests and measure_on_closed_data all read history " +
				"that is already frozen.",
				correlationId),

			SpecNotFoundException or DatasetNotFoundException => new(
				ToolErrorCategories.NotFound,
				error.Message,
				"Check the identifier against what the project actually holds; list_specs and get_dataset_report " +
				"report what exists.",
				correlationId),

			CandidateNotFoundException => new(
				ToolErrorCategories.NotFound,
				error.Message,
				"list_candidates reports every candidate of the project with its identifier and the stage it " +
				"has reached. A candidate belongs to one project, so an identifier from another will not be " +
				"found here either.",
				correlationId),

			RunNotFoundException => new(
				ToolErrorCategories.NotFound,
				error.Message,
				"list_runs reports every run of the project. A run identifier comes back from run_backtest " +
				"and from the measurements, which name the runs they were computed from.",
				correlationId),

			DeploymentNotFoundException => new(
				ToolErrorCategories.NotFound,
				error.Message,
				"list_deployments reports what this project has put on the paper account, running or stopped.",
				correlationId),

			ProjectNotFoundException => new(
				ToolErrorCategories.NotFound,
				error.Message,
				"Call list_projects to see which projects exist, and pass one of the identifiers it returns.",
				correlationId),

			ArtifactNotFoundException => new(
				ToolErrorCategories.NotFound,
				error.Message,
				"The artifact was never stored, or the project it belongs to was exported without it.",
				correlationId),

			ArtifactCorruptedException => new(
				ToolErrorCategories.IntegrityViolation,
				error.Message,
				"The file was changed outside the product. Restore the project from a backup; results that " +
				"reference this artifact can no longer be reproduced.",
				correlationId),

			FormatException or ArgumentException => new(
				ToolErrorCategories.InvalidRequest,
				error.Message,
				"Correct the argument named in the message and call again. Identifiers are values the server " +
				"issued; echo them back rather than composing them.",
				correlationId),

			ResearchBudgetExhaustedException => new(
				ToolErrorCategories.BudgetExhausted,
				error.Message,
				"The allowance is a ceiling, not a suggestion, and nothing here will raise it. Read what the " +
				"project has already measured and decide from that.",
				correlationId),

			InvalidOperationException => new(
				ToolErrorCategories.PreconditionFailed,
				error.Message,
				"Bring the project into the state this call needs first, then call again.",
				correlationId),

			TimeoutException => new(
				ToolErrorCategories.Timeout,
				error.Message,
				"Nothing was written, so asking again is safe. If it keeps happening, the broker is the " +
				"problem rather than the request; a shorter range is the cheapest way to find out.",
				correlationId),

			OperationCanceledException => new(
				ToolErrorCategories.Cancelled,
				"The operation was cancelled.",
				"Nothing was left half-written. Call again when you want the work done.",
				correlationId),

			// Anything unrecognised is a defect on our side. The message stays in the log, because it can
			// carry a path or a value the caller has no business seeing.
			_ => new(
				ToolErrorCategories.Internal,
				"The server failed to complete the call.",
				$"This is a defect on the server side, not a problem with the request. Quote correlation id " +
				$"{correlationId} when reporting it.",
				correlationId),
		};
	}
}
