namespace Odysseus.Application;

using System;

using Odysseus.Domain;

/// <summary>
/// Thrown when a dataset that was asked for does not exist.
/// </summary>
public sealed class DatasetNotFoundException : Exception
{
	/// <summary>
	/// Creates the exception.
	/// </summary>
	/// <param name="id">Dataset that was not found.</param>
	public DatasetNotFoundException(DatasetVersionId id)
		: base($"Dataset {id} does not exist in this project.")
	{
		Id = id;
	}

	/// <summary>Dataset that was not found.</summary>
	public DatasetVersionId Id { get; }
}
