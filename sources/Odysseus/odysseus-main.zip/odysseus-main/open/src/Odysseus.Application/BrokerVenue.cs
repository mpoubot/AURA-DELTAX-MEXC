namespace Odysseus.Application;

using System;

/// <summary>
/// Market conventions that must travel with a dataset into sizing, emulation, and paper trading.
/// </summary>
/// <param name="Kind">Broker/venue family.</param>
/// <param name="SourcePrefix">Prefix recorded by that venue's history source.</param>
/// <param name="BoardCode">StockSharp board code.</param>
/// <param name="TimeZoneId">Time zone used by generated session rules.</param>
/// <param name="SessionEnd">Default end of the trading session.</param>
/// <param name="PriceStep">Conservative minimum price increment when exchange metadata is unavailable.</param>
/// <param name="VolumeStep">Conservative minimum volume increment when exchange metadata is unavailable.</param>
/// <param name="Currency">Default account currency.</param>
/// <param name="IsCrypto">Whether the instrument is a spot cryptocurrency pair.</param>
/// <param name="AllowsShort">Whether a generated long/short strategy may open a short position.</param>
/// <param name="Costs">Baseline research costs for this venue.</param>
public sealed record BrokerVenue(
	BrokerKinds Kind,
	string SourcePrefix,
	string BoardCode,
	string TimeZoneId,
	TimeSpan SessionEnd,
	decimal PriceStep,
	decimal VolumeStep,
	string Currency,
	bool IsCrypto,
	bool AllowsShort,
	ExecutionCosts Costs)
{
	/// <summary>Alpaca/US-equity conventions retained for existing and demo datasets.</summary>
	public static BrokerVenue Alpaca { get; } = new(
		BrokerKinds.Alpaca,
		"alpaca",
		"NASDAQ",
		"America/New_York",
		new TimeSpan(16, 0, 0),
		0.01m,
		1m,
		"USD",
		IsCrypto: false,
		AllowsShort: true,
		ExecutionCosts.Default);

	/// <summary>
	/// Binance Spot conventions. Costs model a 0.10% taker fee plus a conservative 0.05% half-spread;
	/// they are research assumptions, not an assertion about a user's fee tier.
	/// </summary>
	public static BrokerVenue Binance { get; } = new(
		BrokerKinds.Binance,
		"binance",
		"BNB",
		"UTC",
		// A repeatable UTC day boundary that every supported intraday timeframe reaches. Binance itself
		// is open continuously; this is only for specifications that explicitly request a session exit.
		new TimeSpan(23, 0, 0),
		0.00000001m,
		0.00000001m,
		"USDT",
		IsCrypto: true,
		AllowsShort: false,
		new ExecutionCosts(Fees: 0m, HalfSpread: 0m, FeePercent: 0.10m, SpreadPercent: 0.05m));

	/// <summary>Resolves the venue from a dataset source. Bundled demo data remains US equity.</summary>
	public static BrokerVenue ForSource(string source)
		=> source?.StartsWith(Binance.SourcePrefix, StringComparison.OrdinalIgnoreCase) == true
			? Binance
			: Alpaca;

	/// <summary>Refuses a strategy whose directions the cash venue cannot execute.</summary>
	public void EnsureStrategySupported(bool allowsShort)
	{
		if (allowsShort && !AllowsShort)
		{
			throw new InvalidOperationException(
				$"{Kind} Spot cannot open short positions. Use a long-only specification for this dataset.");
		}
	}
}
