namespace Odysseus.Application;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Domain;

/// <summary>
/// Raised when something that needs a broker account is asked for on a server that has none.
/// </summary>
/// <remarks>
/// Not a defect and not a bad request: the server is running exactly as configured, and most of what it
/// does needs no account at all. It is worth its own type so the answer can say which of the two the
/// caller is looking at, and what to do about it.
/// </remarks>
public sealed class BrokerNotConfiguredException : Exception
{
	/// <summary>
	/// Creates the exception.
	/// </summary>
	/// <param name="what">What was being attempted, in a few words.</param>
	public BrokerNotConfiguredException(string what)
		: base($"{what} needs a broker account, and this server was started without one.")
	{
	}
}

/// <summary>
/// What stands in for the broker when the server was started without credentials.
/// </summary>
/// <remarks>
/// Registered always, so that the services which happen to hold a broker port are built either way.
/// Leaving them unregistered instead looks tidier and is worse: the tools that hold them then fail
/// while their arguments are being bound, before any code of ours runs, and the agent is told only
/// that something went wrong invoking a tool — with no category to branch on and no mention of
/// credentials anywhere.
///
/// It also keeps a real distinction visible. Downloading history needs an account; measuring history
/// that is already frozen does not, and those two live on the same service. With a stand-in here, the
/// second keeps working on a machine that has no keys, which is most machines trying the product out.
/// </remarks>
public sealed class BrokerNotConfigured : IHistorySource, IPaperTrader, IPaperAccount
{
	/// <inheritdoc />
	public string Name => "no-broker";

	/// <inheritdoc />
	public Task<IReadOnlyList<Candle>> GetBarsAsync(
		string symbol,
		TimeSpan timeFrame,
		DateTime from,
		DateTime to,
		CancellationToken cancellationToken)
		=> throw new BrokerNotConfiguredException("Downloading history");

	/// <inheritdoc />
	public Task<IPaperSession> StartAsync(PaperRequest request, CancellationToken cancellationToken)
		=> throw new BrokerNotConfiguredException("Trading on a paper account");

	/// <inheritdoc />
	public ValueTask<PaperAccountState> ReadAsync(CancellationToken cancellationToken)
		=> throw new BrokerNotConfiguredException("Reading a paper account");
}
