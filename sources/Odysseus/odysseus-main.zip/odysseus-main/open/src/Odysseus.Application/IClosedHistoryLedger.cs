namespace Odysseus.Application;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Domain;

/// <summary>
/// Remembers which stretches of closed history have been spent, across every project on this machine.
/// </summary>
/// <remarks>
/// Every other store belongs to a project, so that a project can be zipped and carried elsewhere. This
/// one deliberately does not: a record kept inside a project could be escaped by starting another one,
/// and escaping it is exactly what has to be prevented. The closed slice is the only measurement in the
/// product that cannot be repeated, and a second project over the same dates is a repeat of it by
/// someone who has already seen the answer.
/// </remarks>
public interface IClosedHistoryLedger
{
	/// <summary>
	/// Finds stretches already spent that share time with the one asked about.
	/// </summary>
	/// <param name="symbol">Symbol to be measured.</param>
	/// <param name="from">Start of the closed stretch, in UTC.</param>
	/// <param name="to">End of the closed stretch, exclusive, in UTC.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>What has already been spent over that stretch, newest first.</returns>
	ValueTask<IReadOnlyList<SpentWindow>> FindOverlappingAsync(
		string symbol,
		DateTime from,
		DateTime to,
		CancellationToken cancellationToken);

	/// <summary>
	/// Records a stretch as spent.
	/// </summary>
	/// <param name="window">What was spent.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	ValueTask RecordAsync(SpentWindow window, CancellationToken cancellationToken);
}
