namespace Odysseus.Application;

using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

using Odysseus.Domain;

/// <summary>
/// What came out of importing a set of bars.
/// </summary>
/// <param name="Manifest">The immutable description of what was kept.</param>
/// <param name="Bars">The bars that survived the checks, by symbol.</param>
public sealed record ImportedDataset(
	DatasetManifest Manifest,
	IReadOnlyDictionary<string, IReadOnlyList<Candle>> Bars);

/// <summary>
/// Turns raw bars into an immutable dataset, refusing what cannot be measured honestly.
/// </summary>
/// <remarks>
/// Everything here happens once, before any research starts, because a dataset that can still change is
/// a dataset no result can be reproduced from. Bad bars are dropped rather than repaired: a guessed
/// price is indistinguishable from a real one afterwards, and it would be quoted in a report as though
/// it had been observed.
/// </remarks>
public static class DatasetBuilder
{
	/// <summary>Fewest bars a symbol must contribute for the data to be worth measuring on.</summary>
	public const int MinimumBarsPerSymbol = 100;

	/// <summary>
	/// Builds a dataset from raw bars.
	/// </summary>
	/// <param name="bars">Bars by symbol, in any order.</param>
	/// <param name="timeFrame">Length of one candle.</param>
	/// <param name="source">Where the bars came from.</param>
	/// <param name="isSynthetic">Whether the bars were generated rather than observed.</param>
	/// <returns>The dataset.</returns>
	/// <exception cref="ArgumentException">No symbol contributed enough usable bars.</exception>
	/// <remarks>
	/// Where the slices fall is decided by the data itself rather than by a proportion anybody can look
	/// up. Fixed at three fifths and one fifth, the closed slice begins at a moment anyone who knows the
	/// rule can work out from the start and end of the open part - which is most of the benefit of
	/// closing it, handed back by arithmetic.
	///
	/// Derived from the content of the bars, the same data always divides the same way, so a project
	/// stays reproducible, while nothing outside it can say where the boundary is without the data.
	/// </remarks>
	public static ImportedDataset Build(
		IReadOnlyDictionary<string, IReadOnlyList<Candle>> bars,
		TimeSpan timeFrame,
		string source,
		bool isSynthetic)
	{
		ArgumentNullException.ThrowIfNull(bars);
		ArgumentException.ThrowIfNullOrWhiteSpace(source);

		if (timeFrame <= TimeSpan.Zero)
			throw new ArgumentOutOfRangeException(nameof(timeFrame), timeFrame, "A candle has a positive length.");

		if (bars.Count == 0)
			throw new ArgumentException("A dataset needs at least one symbol.", nameof(bars));

		var kept = new Dictionary<string, IReadOnlyList<Candle>>(StringComparer.Ordinal);
		var quality = new List<SymbolQuality>();

		foreach (var (symbol, raw) in bars.OrderBy(p => p.Key, StringComparer.Ordinal))
		{
			var (candles, report) = Clean(symbol, raw, timeFrame);

			if (candles.Count < MinimumBarsPerSymbol)
			{
				throw new ArgumentException(
					$"Symbol '{symbol}' contributed {candles.Count} usable bars out of {raw.Count}; " +
					$"at least {MinimumBarsPerSymbol} are needed before anything measured on it means much. " +
					$"Rejected: {report.Invalid} malformed, {report.Duplicates} duplicated.",
					nameof(bars));
			}

			kept.Add(symbol, candles);
			quality.Add(report);
		}

		var from = quality.Min(q => q.From);
		var to = quality.Max(q => q.To) + timeFrame;
		var hash = DatasetManifest.ComputeHash([.. kept.Keys], timeFrame, source, kept);
		var (developmentFraction, validationFraction) = Proportions(hash);
		var split = DatasetSplit.Create(from, to, developmentFraction, validationFraction);

		// What an agent may be told is recomputed over the open region only. Reporting the last bar time
		// or the total count of the whole dataset would state the closed slice as a subtraction from the
		// end of validation, which is the one thing the split exists to prevent.
		var disclosed = kept
			.Select(pair => Measure(pair.Key, [.. pair.Value.Where(c => c.OpenTime < split.ValidationTo)], timeFrame))
			.ToList();

		return new(
			new DatasetManifest
			{
				Id = DatasetVersionId.New(),
				Symbols = [.. kept.Keys],
				TimeFrame = timeFrame,
				Source = source,
				IsSynthetic = isSynthetic,
				Quality = quality,
				DisclosedQuality = disclosed,
				Split = split,
				ContentHash = hash,
			},
			kept);
	}

	/// <summary>Narrowest the development slice may be, as a share of the whole range.</summary>
	private const double _leastDevelopment = 0.55;

	/// <summary>Widest it may be.</summary>
	private const double _mostDevelopment = 0.65;

	/// <summary>Narrowest the validation slice may be.</summary>
	private const double _leastValidation = 0.15;

	/// <summary>Widest it may be.</summary>
	private const double _mostValidation = 0.25;

	/// <summary>
	/// Where to divide this particular dataset.
	/// </summary>
	/// <param name="contentHash">Hash of the bars, which is what the division is drawn from.</param>
	/// <returns>The share of the range given to development and to validation.</returns>
	/// <remarks>
	/// Two numbers read out of the hash, each landing somewhere in a band. The bands are public and the
	/// exact figures are not: with the data, the division is reproducible for ever; without it, the
	/// closed slice could begin anywhere across a fifth of the range.
	/// </remarks>
	private static (double Development, double Validation) Proportions(string contentHash)
	{
		var development = Between(contentHash, 0, _leastDevelopment, _mostDevelopment);
		var validation = Between(contentHash, 8, _leastValidation, _mostValidation);

		return (development, validation);
	}

	private static double Between(string contentHash, int offset, double least, double most)
	{
		var digits = contentHash.AsSpan(offset, 8);
		var value = ulong.Parse(digits, NumberStyles.HexNumber, CultureInfo.InvariantCulture);

		return least + (most - least) * (value / (double)uint.MaxValue);
	}

	private static SymbolQuality Measure(string symbol, IReadOnlyList<Candle> candles, TimeSpan timeFrame)
	{
		var gaps = 0;

		for (var i = 1; i < candles.Count; i++)
		{
			if (candles[i].OpenTime > candles[i - 1].OpenTime + timeFrame)
				gaps++;
		}

		return new(
			symbol,
			candles.Count,
			candles.Count > 0 ? candles[0].OpenTime : default,
			candles.Count > 0 ? candles[^1].OpenTime : default,
			gaps,
			Duplicates: 0,
			Invalid: 0);
	}

	private static (IReadOnlyList<Candle> Candles, SymbolQuality Report) Clean(
		string symbol,
		IReadOnlyList<Candle> raw,
		TimeSpan timeFrame)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(symbol);
		ArgumentNullException.ThrowIfNull(raw);

		var seen = new HashSet<DateTime>();
		var kept = new List<Candle>(raw.Count);
		var duplicates = 0;
		var invalid = 0;

		foreach (var candle in raw.OrderBy(c => c.OpenTime))
		{
			if (candle.OpenTime.Kind != DateTimeKind.Utc)
				throw new ArgumentException($"Bar times of '{symbol}' must be UTC.", nameof(raw));

			if (!candle.IsWellFormed)
			{
				invalid++;
				continue;
			}

			// A repeated timestamp means two sources disagree about the same moment, and there is no way
			// to tell which is right, so the later one is dropped rather than silently preferred.
			if (!seen.Add(candle.OpenTime))
			{
				duplicates++;
				continue;
			}

			kept.Add(candle);
		}

		var gaps = 0;

		for (var i = 1; i < kept.Count; i++)
		{
			var expected = kept[i - 1].OpenTime + timeFrame;

			if (kept[i].OpenTime > expected)
				gaps++;
		}

		var report = new SymbolQuality(
			symbol,
			kept.Count,
			kept.Count > 0 ? kept[0].OpenTime : default,
			kept.Count > 0 ? kept[^1].OpenTime : default,
			gaps,
			duplicates,
			invalid);

		return (kept, report);
	}
}
