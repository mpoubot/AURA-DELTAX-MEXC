namespace Odysseus.Application;

/// <summary>
/// How the server was started, which decides what it will accept.
/// </summary>
public enum ServerModes
{
	/// <summary>
	/// On the user's own machine, over standard input and output. The code being researched belongs to
	/// the person running it, so the security analyzers are off unless asked for.
	/// </summary>
	Local,

	/// <summary>
	/// Reachable over the network, where the code being researched belongs to a stranger. Hand-written
	/// source is not accepted at all and the security analyzers cannot be switched off.
	/// </summary>
	Hosted,
}
