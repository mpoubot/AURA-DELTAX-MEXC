namespace Odysseus.Application;

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Domain;
using Odysseus.Spec;

/// <summary>
/// What a deployment has done, next to what the backtest said it would.
/// </summary>
/// <param name="Deployment">The deployment as it is recorded.</param>
/// <param name="SessionLive">Whether this process is actually running it.</param>
/// <param name="ExpectedTradesPerDay">Trades a day the closed-data run made.</param>
/// <param name="ObservedTradesPerDay">Trades a day it has made against the broker.</param>
/// <param name="ExpectedAverageTrade">What one trade came to in the closed-data run.</param>
/// <param name="ObservedAverageTrade">What one trade has come to against the broker.</param>
/// <param name="TradingDays">Trading days the deployment has been up, as a fraction.</param>
public sealed record DeploymentReport(
	Deployment Deployment,
	bool SessionLive,
	decimal ExpectedTradesPerDay,
	decimal ObservedTradesPerDay,
	decimal ExpectedAverageTrade,
	decimal ObservedAverageTrade,
	decimal TradingDays)
{
	/// <summary>What the deployment amounts to now, which is not always what the row says.</summary>
	/// <remarks>
	/// A row saying Running with no session behind it belongs to a process that no longer exists. The row
	/// is left as its own server wrote it - a reader does not decide that a deployment is over - so the
	/// two are reported side by side and this is the one to act on.
	/// </remarks>
	public DeploymentStatuses EffectiveStatus
		=> Deployment.Status == DeploymentStatuses.Running && !SessionLive
			? DeploymentStatuses.Interrupted
			: Deployment.Status;
}

/// <summary>
/// A deployment as it stands, with whether anything is behind it.
/// </summary>
/// <param name="Deployment">The deployment as it is recorded.</param>
/// <param name="SessionLive">Whether this process is actually running it.</param>
public sealed record DeploymentView(Deployment Deployment, bool SessionLive)
{
	/// <summary>What the deployment amounts to now.</summary>
	public DeploymentStatuses EffectiveStatus
		=> Deployment.Status == DeploymentStatuses.Running && !SessionLive
			? DeploymentStatuses.Interrupted
			: Deployment.Status;
}

/// <summary>
/// Running a finished candidate against a live paper account.
/// </summary>
/// <remarks>
/// A backtest is a claim about a strategy; paper is the first thing that can contradict it. What the
/// two disagree about is the whole point — a fill that never comes, a spread wider than the one that was
/// charged, a bar that arrives late — and none of it shows up in history.
///
/// A deployment lives inside this process and nowhere else. There is no supervisor, no restart and no
/// state that outlives the server: if it goes away, the strategy goes with it and whatever it held at
/// the broker is left as it stood. That is a property to be stated rather than hidden, because a caller
/// who believes otherwise leaves positions open in the belief that something is watching them.
/// </remarks>
public sealed class DeploymentService
{
	private readonly IProjectStore _projects;
	private readonly ICandidateStore _candidates;
	private readonly ISpecStore _specs;
	private readonly IDatasetStore _datasets;
	private readonly IArtifactStore _artifacts;
	private readonly IRunStore _runs;
	private readonly IDeploymentStore _deployments;
	private readonly IPaperTrader _trader;
	private readonly IAuditLog _audit;
	private readonly IClock _clock;

	private readonly ConcurrentDictionary<string, IPaperSession> _live = new(StringComparer.Ordinal);

	/// <summary>
	/// Creates the service.
	/// </summary>
	/// <param name="projects">Where projects are kept.</param>
	/// <param name="candidates">Where candidates are kept.</param>
	/// <param name="specs">Where specifications are kept.</param>
	/// <param name="datasets">Where datasets are kept.</param>
	/// <param name="artifacts">Where assemblies are kept.</param>
	/// <param name="runs">Where runs are kept.</param>
	/// <param name="deployments">Where deployments are kept.</param>
	/// <param name="trader">What runs a strategy against the broker.</param>
	/// <param name="audit">Where the permanent record is kept.</param>
	/// <param name="clock">Source of the current moment.</param>
	public DeploymentService(
		IProjectStore projects,
		ICandidateStore candidates,
		ISpecStore specs,
		IDatasetStore datasets,
		IArtifactStore artifacts,
		IRunStore runs,
		IDeploymentStore deployments,
		IPaperTrader trader,
		IAuditLog audit,
		IClock clock)
	{
		_projects = projects ?? throw new ArgumentNullException(nameof(projects));
		_candidates = candidates ?? throw new ArgumentNullException(nameof(candidates));
		_specs = specs ?? throw new ArgumentNullException(nameof(specs));
		_datasets = datasets ?? throw new ArgumentNullException(nameof(datasets));
		_artifacts = artifacts ?? throw new ArgumentNullException(nameof(artifacts));
		_runs = runs ?? throw new ArgumentNullException(nameof(runs));
		_deployments = deployments ?? throw new ArgumentNullException(nameof(deployments));
		_trader = trader ?? throw new ArgumentNullException(nameof(trader));
		_audit = audit ?? throw new ArgumentNullException(nameof(audit));
		_clock = clock ?? throw new ArgumentNullException(nameof(clock));
	}

	/// <summary>
	/// Starts a finished candidate against the paper account.
	/// </summary>
	/// <param name="project">Project the candidate belongs to.</param>
	/// <param name="candidate">Candidate to deploy.</param>
	/// <param name="actor">Who is asking.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The deployment.</returns>
	public async ValueTask<Deployment> StartAsync(
		ProjectId project,
		CandidateId candidate,
		Actors actor,
		CancellationToken cancellationToken)
	{
		var existing = await _projects.OpenAsync(project, cancellationToken);
		var built = await _candidates.GetAsync(project, candidate, cancellationToken);

		// Whether the numbers are good enough is the researcher's call, not this server's. What the server
		// does require is that they exist: a candidate the closed data has never seen has nothing to be
		// contradicted by paper, because nothing has been claimed about it yet.
		if (built.Status is not (CandidateStatuses.FinalChecked or CandidateStatuses.Completed))
		{
			throw new InvalidOperationException(
				$"This candidate is {built.Status}. Paper trading starts from the closed-data measurement: " +
				"run measure_on_closed_data first, read the numbers, and mark the candidate complete if " +
				"they are what you want to trade.");
		}

		var running = (await _deployments.ListAsync(project, cancellationToken))
			.FirstOrDefault(d => d.Status == DeploymentStatuses.Running);

		if (running is not null)
		{
			throw new InvalidOperationException(
				$"{running.Id} is already running {running.Candidate} on this project. Stop it before " +
				"starting another: two strategies on one account trade against each other's positions and " +
				"neither result means anything afterwards.");
		}

		if (existing.Dataset.IsEmpty)
			throw new InvalidOperationException("This project has no data, so there is no symbol to trade.");

		var manifest = await _datasets.GetManifestAsync(project, existing.Dataset, cancellationToken);
		var venue = BrokerVenue.ForSource(manifest.Source);
		var spec = SpecJson.Read((await _specs.GetAsync(project, built.Spec, cancellationToken)).Json);
		venue.EnsureStrategySupported(spec.AllowShort);
		var assembly = await _artifacts.ReadAsync(project, built.Assembly, cancellationToken);

		var measured = OnClosedData(await _runs.ListAsync(project, candidate, cancellationToken));
		var symbol = measured?.Symbol ?? manifest.Symbols[0];

		var bars = await _datasets.LoadAsync(
			project, existing.Dataset, symbol, DataSlices.Development, cancellationToken);

		if (bars.Count == 0)
			throw new InvalidOperationException($"The project holds no bars for '{symbol}' to size a position against.");

		// Sized against the last price the project has seen, by the same rule the backtests used. The size
		// is fixed for the life of the deployment, so what it does can be compared with what was measured.
		var volume = BacktestService.PositionSize(spec, symbol, bars[^1].Close, venue.VolumeStep);

		// The numbers it was measured with, not the ones the specification declares as defaults: the closed
		// data answered one setting, and any other is a strategy nothing has run.
		var parameters = measured?.Parameters is { Count: > 0 } chosen ? chosen : Defaults(spec);

		var session = await _trader.StartAsync(
			new(assembly, built.ClassName, parameters, symbol, manifest.TimeFrame, volume, venue),
			cancellationToken);

		var deployment = new Deployment(
			DeploymentId.New(),
			candidate,
			symbol,
			volume,
			DeploymentStatuses.Running,
			_clock.UtcNow,
			null,
			0,
			0,
			0m,
			0m,
			null,
			null);

		_live[deployment.Id.Value] = session;

		await _deployments.AddAsync(project, deployment, cancellationToken);
		await _candidates.UpdateAsync(project, built.WithStatus(CandidateStatuses.PaperRunning, _clock.UtcNow), cancellationToken);

		await _audit.AppendAsync(
			project,
			AuditEventTypes.PaperStarted,
			actor,
			$"Started {built.ClassName} on {symbol} against {_trader.Name} at {volume} per position.",
			built.SourceHash,
			cancellationToken);

		return deployment;
	}

	/// <summary>
	/// Reports what a deployment has done, next to what was measured of it.
	/// </summary>
	/// <param name="project">Project the deployment belongs to.</param>
	/// <param name="deployment">Deployment to report on.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The report.</returns>
	public async ValueTask<DeploymentReport> GetAsync(
		ProjectId project,
		DeploymentId deployment,
		CancellationToken cancellationToken)
	{
		var (recorded, live) = await Observe(
			project, await _deployments.GetAsync(project, deployment, cancellationToken), cancellationToken);

		var measured = OnClosedData(await _runs.ListAsync(project, recorded.Candidate, cancellationToken));

		// Over the time anybody was watching, not over the time the server was away.
		var days = TradingDays(recorded.Watched);

		var expectedTrades = 0m;
		var expectedAverage = 0m;

		if (measured?.Metrics is { } metrics && metrics.Trades.Count > 0)
		{
			var existing = await _projects.OpenAsync(project, cancellationToken);
			var manifest = await _datasets.GetManifestAsync(project, existing.Dataset, cancellationToken);

			// How much market the run covered, not how long it took to compute: the bars it saw, each
			// worth one time frame of the day.
			var covered = TradingDays(measured.BarsProcessed * manifest.TimeFrame);

			expectedTrades = covered > 0 ? Round(metrics.Trades.Count / covered) : 0m;
			expectedAverage = Round(metrics.Net.Profit / metrics.Trades.Count);
		}

		return new(
			recorded,
			live,
			expectedTrades,
			days > 0 ? Round(recorded.Trades / days) : 0m,
			expectedAverage,
			recorded.Trades > 0 ? Round(recorded.RealizedProfit / recorded.Trades) : 0m,
			Round(days));
	}

	/// <summary>
	/// Lists the deployments of a project, newest first.
	/// </summary>
	/// <param name="project">Project to list.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The deployments, each with whether anything is behind it.</returns>
	public async ValueTask<IReadOnlyList<DeploymentView>> ListAsync(ProjectId project, CancellationToken cancellationToken)
	{
		var listed = await _deployments.ListAsync(project, cancellationToken);
		var seen = new List<DeploymentView>(listed.Count);

		foreach (var deployment in listed)
		{
			var (observed, live) = await Observe(project, deployment, cancellationToken);

			seen.Add(new(observed, live));
		}

		return seen;
	}

	/// <summary>
	/// Stops a deployment.
	/// </summary>
	/// <param name="project">Project the deployment belongs to.</param>
	/// <param name="deployment">Deployment to stop.</param>
	/// <param name="closePosition">Whether to close what it is holding.</param>
	/// <param name="actor">Who is asking.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>The deployment as it ended.</returns>
	public async ValueTask<Deployment> StopAsync(
		ProjectId project,
		DeploymentId deployment,
		bool closePosition,
		Actors actor,
		CancellationToken cancellationToken)
	{
		var recorded = await _deployments.GetAsync(project, deployment, cancellationToken);

		if (_live.TryRemove(deployment.Value, out var session))
		{
			await session.StopAsync(closePosition, cancellationToken);

			recorded = Observed(recorded, session) with
			{
				Status = DeploymentStatuses.Stopped,
				StoppedAt = _clock.UtcNow,
				Note = session.Error,
			};
		}
		else if (recorded.Status == DeploymentStatuses.Running)
		{
			// Recorded as running with nothing behind it: the process that owned it is gone.
			recorded = recorded with
			{
				Status = DeploymentStatuses.Interrupted,
				StoppedAt = _clock.UtcNow,
				Note = "The server that was running this went away, so nothing was stopped in an orderly " +
					"fashion. Check the account for anything it left open.",
			};
		}

		await _deployments.UpdateAsync(project, recorded, cancellationToken);

		// Reached whatever the row said on the way in. A deployment that had already ended - by itself, or
		// with the process that owned it - still leaves a candidate marked as trading on paper, and this
		// is the call that says it is not. Returning early because the row was no longer Running left that
		// candidate with no way out: it could not be stopped, and it could not be deployed again either.
		var built = await _candidates.GetAsync(project, recorded.Candidate, cancellationToken);

		if (built.Status == CandidateStatuses.PaperRunning)
			await _candidates.UpdateAsync(project, built.WithStatus(CandidateStatuses.Stopped, _clock.UtcNow), cancellationToken);

		await _audit.AppendAsync(
			project,
			AuditEventTypes.PaperStopped,
			actor,
			$"Stopped {deployment} after {recorded.Trades} trade(s) and {recorded.RealizedProfit:F2} realized" +
			$"{(closePosition ? ", closing what it held" : string.Empty)}.",
			built.SourceHash,
			cancellationToken);

		return recorded;
	}

	// Reads, and writes only what a live session has just said. It used to write Interrupted for a
	// deployment whose session was gone, which made looking at a deployment end it: stopping then found a
	// row that was no longer Running and returned without releasing the candidate or recording anything.
	// Whether a deployment is over is decided by stopping it, not by somebody reading the list.
	private async ValueTask<(Deployment Deployment, bool SessionLive)> Observe(
		ProjectId project,
		Deployment deployment,
		CancellationToken cancellationToken)
	{
		if (deployment.Status != DeploymentStatuses.Running)
			return (deployment, false);

		if (!_live.TryGetValue(deployment.Id.Value, out var session))
			return (deployment, false);

		var observed = Observed(deployment, session);

		if (!session.IsRunning)
		{
			// It stopped itself, and that is the session's own report rather than an inference from its
			// absence, so it is recorded.
			observed = observed with
			{
				Status = DeploymentStatuses.Failed,
				StoppedAt = _clock.UtcNow,
				Note = session.Error ?? "The strategy stopped by itself.",
			};

			_live.TryRemove(deployment.Id.Value, out _);
		}

		await _deployments.UpdateAsync(project, observed, cancellationToken);

		return (observed, session.IsRunning);
	}

	private Deployment Observed(Deployment deployment, IPaperSession session)
		=> deployment with
		{
			OrdersPlaced = session.OrdersPlaced,
			Trades = session.Trades,
			RealizedProfit = Round(session.RealizedProfit),
			Position = session.Position,

			// Stamped with the numbers it belongs to. Without it, an outage is indistinguishable from a
			// quiet market: both leave the same figures behind, and only one of them means the strategy
			// did nothing.
			LastObservedAt = _clock.UtcNow,
		};

	private static RunResult OnClosedData(IReadOnlyList<RunResult> runs)
		=> runs
			.Where(r => r.Slice == DataSlices.Final && r.Status == RunStatuses.Completed)
			.OrderByDescending(r => r.FinishedAt)
			.FirstOrDefault();

	private static IReadOnlyDictionary<string, decimal> Defaults(StrategySpec spec)
		=> spec.Parameters.ToDictionary(p => p.Name, p => p.Default, StringComparer.Ordinal);

	// An American session holds six and a half hours, and a deployment is measured against the same day.
	private static decimal TradingDays(TimeSpan elapsed)
		=> (decimal)(elapsed.TotalHours / 6.5);

	private static decimal TradingDays(int bars, TimeSpan timeFrame)
		=> TradingDays(timeFrame * bars);

	private static decimal Round(decimal value) => Math.Round(value, 4, MidpointRounding.AwayFromZero);
}
