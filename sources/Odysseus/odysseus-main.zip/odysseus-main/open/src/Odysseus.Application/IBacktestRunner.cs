namespace Odysseus.Application;

using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Domain;

/// <summary>
/// What a run is charged for trading, on entry and again on exit: fixed per unit and/or by notional.
/// </summary>
/// <param name="Fees">
/// What the broker and the regulator take. On an American equity account the commission itself is
/// usually nothing and this is the regulatory fees, which are small but not zero.
/// </param>
/// <param name="HalfSpread">
/// What crossing the spread costs, per unit. A market order pays about half the spread, so a stock
/// quoted two cents wide costs about a cent a share to get into and another to get out of.
/// </param>
/// <param name="FeePercent">Fee as a percentage of notional value.</param>
/// <param name="SpreadPercent">Half-spread as a percentage of notional value.</param>
/// <remarks>
/// Costs are charged rather than folded into the fill price, because of how the run is
/// executed: over candles, a market order fills at the average price of the bar after the one the
/// decision was made on, and no order book is synthesized for it to cross. Nothing in that path
/// charges for the spread, so it is charged here — as a number that is stated and can be varied,
/// rather than as an assumption buried in a fill.
///
/// Neither is zero by default. A candidate that only works without costs is not a candidate, and the
/// cheapest way to discover that is to charge it from the first run rather than the last.
/// </remarks>
public sealed record ExecutionCosts(
	decimal Fees,
	decimal HalfSpread,
	decimal FeePercent = 0m,
	decimal SpreadPercent = 0m)
{
	/// <summary>What one unit costs to trade, both parts together.</summary>
	public decimal PerUnit => Fees + HalfSpread;

	/// <summary>What one trade costs as a percentage of its notional value.</summary>
	public decimal Percent => FeePercent + SpreadPercent;

	/// <summary>
	/// An American equity account on a liquid stock quoted about two cents wide.
	/// </summary>
	public static ExecutionCosts Default { get; } = new(Fees: 0.0002m, HalfSpread: 0.01m);

	/// <summary>
	/// The same costs multiplied, for the scenario that asks whether the edge survives a worse market.
	/// </summary>
	/// <param name="factor">What to multiply by.</param>
	/// <returns>The multiplied costs.</returns>
	public ExecutionCosts Scaled(decimal factor)
	{
		ArgumentOutOfRangeException.ThrowIfNegativeOrZero(factor);

		return new(Fees * factor, HalfSpread * factor, FeePercent * factor, SpreadPercent * factor);
	}
}

/// <summary>
/// One backtest to run.
/// </summary>
/// <param name="Assembly">The compiled candidate.</param>
/// <param name="ClassName">Full name of the strategy type inside it.</param>
/// <param name="Parameters">Values to set on the strategy before it starts.</param>
/// <param name="Symbol">Symbol to trade.</param>
/// <param name="TimeFrame">Length of one candle.</param>
/// <param name="Bars">The bars of the slice, oldest first.</param>
/// <param name="StartingEquity">Money the account starts with.</param>
/// <param name="Volume">Size of one position.</param>
/// <param name="PriceStep">Smallest price movement of the instrument.</param>
/// <param name="Costs">What the run is charged.</param>
/// <param name="Venue">Market conventions belonging to the frozen dataset.</param>
public sealed record BacktestRequest(
	byte[] Assembly,
	string ClassName,
	IReadOnlyDictionary<string, decimal> Parameters,
	string Symbol,
	TimeSpan TimeFrame,
	IReadOnlyList<Candle> Bars,
	decimal StartingEquity,
	decimal Volume,
	decimal PriceStep,
	ExecutionCosts Costs,
	BrokerVenue Venue = null);

/// <summary>
/// What a backtest did, before anything is made of it.
/// </summary>
/// <param name="Trades">Positions that were opened and closed.</param>
/// <param name="Equity">Account value sampled through the run.</param>
/// <param name="BarsProcessed">Candles the strategy saw.</param>
/// <param name="ExecutionErrorCount">Orders the run could not place or fill.</param>
/// <param name="OrdersPlaced">
/// Orders the strategy sent. Counted apart from the trades, because an order larger than the bar it
/// lands on does not fill at all: without this, a run whose orders were too big to fill is
/// indistinguishable from one whose rules never triggered.
/// </param>
public sealed record BacktestOutcome(
	IReadOnlyList<ExecutedTrade> Trades,
	IReadOnlyList<EquityPoint> Equity,
	int BarsProcessed,
	int ExecutionErrorCount,
	int OrdersPlaced);

/// <summary>
/// Runs a compiled candidate over a slice of history.
/// </summary>
/// <remarks>
/// The trading engine sits behind this so that the use cases above it never name it, and so that a run
/// can be replaced by a fixture in a test without an emulator. What comes back is what happened —
/// trades and an equity curve — and not what to make of it; the measuring is a separate step, and
/// keeping them apart is what lets the same measurement be applied to a paper account later.
/// </remarks>
public interface IBacktestRunner
{
	/// <summary>
	/// Runs one backtest.
	/// </summary>
	/// <param name="request">What to run.</param>
	/// <param name="cancellationToken">Cancellation token.</param>
	/// <returns>What happened.</returns>
	Task<BacktestOutcome> RunAsync(BacktestRequest request, CancellationToken cancellationToken);
}
