namespace Odysseus.Persistence;

using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

using Odysseus.Application;
using Odysseus.Domain;

/// <summary>
/// Datasets kept beside their project: the description as a file, the bars in the artifact store.
/// </summary>
/// <remarks>
/// Bars are the largest thing a project holds and the least interesting to query, so they go into the
/// content-addressed store where identical series are stored once and a changed byte is detectable.
/// The description stays readable, because a person looking at a project folder should be able to see
/// what the research was run against without running anything.
/// </remarks>
public sealed class FileDatasetStore : IDatasetStore
{
	private static readonly JsonSerializerOptions _json = new()
	{
		WriteIndented = true,
		DefaultIgnoreCondition = JsonIgnoreCondition.Never,
		Converters = { new TypedIdJsonConverter() },
	};

	private readonly string _root;
	private readonly IArtifactStore _artifacts;

	/// <summary>
	/// Creates the store.
	/// </summary>
	/// <param name="root">Directory the project folders live in. Created if it does not exist.</param>
	/// <param name="artifacts">Where the bars themselves are kept.</param>
	public FileDatasetStore(string root, IArtifactStore artifacts)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(root);

		_artifacts = artifacts ?? throw new ArgumentNullException(nameof(artifacts));

		_root = Path.GetFullPath(root);
	}

	/// <inheritdoc />
	public async ValueTask SaveAsync(ProjectId project, ImportedDataset dataset, CancellationToken cancellationToken)
	{
		ArgumentNullException.ThrowIfNull(dataset);

		var folder = FolderOf(project, dataset.Manifest.Id);

		Directory.CreateDirectory(folder);

		var series = new Dictionary<string, string>(StringComparer.Ordinal);

		foreach (var (symbol, candles) in dataset.Bars)
		{
			var descriptor = await _artifacts.PutAsync(project, CandleSerializer.Serialize(candles), cancellationToken);

			series.Add(symbol, descriptor.Id.Value);
		}

		var stored = new StoredDataset(dataset.Manifest, series);

		await File.WriteAllTextAsync(
			Path.Combine(folder, "manifest.json"),
			JsonSerializer.Serialize(stored, _json),
			cancellationToken);
	}

	/// <inheritdoc />
	public async ValueTask<DatasetManifest> GetManifestAsync(
		ProjectId project,
		DatasetVersionId dataset,
		CancellationToken cancellationToken)
		=> (await ReadAsync(project, dataset, cancellationToken)).Manifest;

	/// <inheritdoc />
	public async ValueTask<IReadOnlyList<Candle>> LoadAsync(
		ProjectId project,
		DatasetVersionId dataset,
		string symbol,
		DataSlices slice,
		CancellationToken cancellationToken)
	{
		ArgumentException.ThrowIfNullOrWhiteSpace(symbol);

		var stored = await ReadAsync(project, dataset, cancellationToken);

		if (!stored.Series.TryGetValue(symbol, out var artifact))
		{
			throw new ArgumentException(
				$"Dataset {dataset} holds no bars for '{symbol}'. It covers {string.Join(", ", stored.Manifest.Symbols)}.",
				nameof(symbol));
		}

		var content = await _artifacts.ReadAsync(project, ArtifactId.Parse(artifact), cancellationToken);
		var candles = CandleSerializer.Deserialize(content);
		var (from, to) = stored.Manifest.Split.BoundsOf(slice);

		return [.. candles.Where(c => c.OpenTime >= from && c.OpenTime < to)];
	}

	private async ValueTask<StoredDataset> ReadAsync(
		ProjectId project,
		DatasetVersionId dataset,
		CancellationToken cancellationToken)
	{
		var path = Path.Combine(FolderOf(project, dataset), "manifest.json");

		if (!File.Exists(path))
			throw new DatasetNotFoundException(dataset);

		var text = await File.ReadAllTextAsync(path, cancellationToken);

		return JsonSerializer.Deserialize<StoredDataset>(text, _json) ?? throw new DatasetNotFoundException(dataset);
	}

	private string FolderOf(ProjectId project, DatasetVersionId dataset)
		=> Path.Combine(_root, project.Value, "datasets", dataset.Value);

	private sealed record StoredDataset(DatasetManifest Manifest, IReadOnlyDictionary<string, string> Series);
}
