namespace Odysseus.Persistence;

using System;
using System.Collections.Generic;
using System.IO;

using Odysseus.Domain;

/// <summary>
/// Writes and reads bars in a fixed binary layout.
/// </summary>
/// <remarks>
/// The layout is deterministic: the same bars always produce the same bytes, which is what lets the
/// series be stored by content hash and lets a later read prove it got back what was written. Prices
/// keep their decimal representation rather than being converted to a floating-point type, because a
/// cent that disappears in a conversion reappears as a difference in a result nobody can explain.
/// </remarks>
public static class CandleSerializer
{
	private const int Version = 1;

	/// <summary>
	/// Writes bars.
	/// </summary>
	/// <param name="candles">Bars to write, oldest first.</param>
	/// <returns>The bytes.</returns>
	public static byte[] Serialize(IReadOnlyList<Candle> candles)
	{
		ArgumentNullException.ThrowIfNull(candles);

		using var stream = new MemoryStream();
		using var writer = new BinaryWriter(stream);

		writer.Write(Version);
		writer.Write(candles.Count);

		foreach (var candle in candles)
		{
			writer.Write(candle.OpenTime.Ticks);
			writer.Write(candle.Open);
			writer.Write(candle.High);
			writer.Write(candle.Low);
			writer.Write(candle.Close);
			writer.Write(candle.Volume);
		}

		writer.Flush();

		return stream.ToArray();
	}

	/// <summary>
	/// Reads bars.
	/// </summary>
	/// <param name="content">Bytes previously produced by <see cref="Serialize"/>.</param>
	/// <returns>The bars, oldest first.</returns>
	/// <exception cref="InvalidDataException">The bytes were written by a layout this build cannot read.</exception>
	public static IReadOnlyList<Candle> Deserialize(byte[] content)
	{
		ArgumentNullException.ThrowIfNull(content);

		using var stream = new MemoryStream(content);
		using var reader = new BinaryReader(stream);

		var version = reader.ReadInt32();

		if (version != Version)
			throw new InvalidDataException($"Bar series layout {version} cannot be read by this build, which writes {Version}.");

		var count = reader.ReadInt32();
		var candles = new List<Candle>(count);

		for (var i = 0; i < count; i++)
		{
			candles.Add(new(
				new DateTime(reader.ReadInt64(), DateTimeKind.Utc),
				reader.ReadDecimal(),
				reader.ReadDecimal(),
				reader.ReadDecimal(),
				reader.ReadDecimal(),
				reader.ReadDecimal()));
		}

		return candles;
	}
}
