# Six-slide pitch deck content

Keep each slide visual and use speaker notes for detail. Target a three-minute pitch plus questions.

## Slide 1 — From a trading idea to a bounded agent

**Headline:** ThetaTrap — a bounded MCP-native AI options agent

**On-slide copy:**

- Earnings can make option premium expensive.
- A four-leg options idea is easy to describe and hard to automate safely.
- ThetaTrap gives AI real judgment while deterministic code owns risk.

**Visual:** Cover image combining an earnings-volatility curve, a four-leg payoff outline, and the Qwen → policy → Alpaca MCP flow.

**Speaker note:** Explain that the project began from the attached YouTube video, then shifted from “find a profitable trade” to “build an inspectable autonomous system.”

## Slide 2 — The strategy in plain English

**Headline:** Start with earnings; adapt transparently when evidence fails

**On-slide copy:**

1. Freeze first-party-verified earnings events.
2. Check volatility term structure, expected move, liquidity, and freshness.
3. Build one symmetric, one-contract iron condor.
4. Let Qwen veto qualitative event risk.
5. Exit the complete position at the frozen profile time.

**Facts:** Seven eligible events; DELL excluded for ambiguous release time; NTAP excluded because required weekly expirations were unavailable. Up to two candidates may be reviewed sequentially, but only one broker entry attempt is allowed per date.

**Sep 3 adaptation:** After 314 rejected earnings evaluations, a separately labeled QQQ/SPY canary uses September 4 expiry, exact `$1` wings, minimum `$0.20` credit, maximum `$80` loss, and a same-day exit. It is not an automatic fallback or proof of alpha.

**Visual:** Four-leg payoff diagram beside the event table.

## Slide 3 — A real tool-using agent, not an AI label

**Headline:** Qwen decides; deterministic policy authorizes

**On-slide copy:**

- Featherless-hosted Qwen calls approved local and official Alpaca MCP tools.
- The model investigates account state, market data, orders, positions, and news.
- It returns a finite veto or the exact pre-authorized `place_option_order` call.
- If every structure fails hard gates, a separate six-read Qwen advisory explains the best rejection without authorizing anything.
- It cannot alter symbol, strikes, expiration, quantity, price, or risk.

**Visual:** Architecture diagram with the AI decision path and deterministic execution path in different colors.

**Speaker note:** Emphasize that every Alpaca read and mutation uses the official MCP server; there is no direct SDK or REST fallback.

## Slide 4 — Failure-aware by design

**Headline:** The system assumes APIs, models, and processes can fail

**On-slide copy:**

- Maximum loss: earnings lower of `$500` or `0.5%` of equity; Sep 3 canary `$80`.
- One contract, one position, one initial broker entry attempt per date.
- Atomic one-shot authorization before dispatch.
- Deterministic client IDs and reconciliation after ambiguous timeouts.
- Restart-safe SQLite state and mandatory profile-timed exit: next morning for earnings, same afternoon for canary.
- Kill switch blocks new exposure but not position-reducing exits.

**Visual:** State timeline from candidate to flat, with timeout/restart branches.

## Slide 5 — Live evidence and official outcome

**Headline:** A live, read-only trail from agent state to account equity

**On-slide copy for the current competition evidence:**

- Integrated release: 316 automated tests passing.
- September 1–2: 314 deterministic evaluations across seven symbols.
- Result through Sep 2: no eligible structure, zero broker attempts/fills, flat at `$100,000`.
- Sep 3: disclose the canary's actual veto, order, fill, exit, and P&L without pre-claiming an outcome.
- The dashboard separates hard-gate rejections from the non-authorizing Qwen advisory and MCP trace.

**Visual:** Sanitized live public-dashboard screenshot beside the evidence cards. After September 3, supplement this interim result with the final filled, unfilled, or veto outcome and flat-account evidence.

**Speaker note:** The September 1–2 no-trade result is real, not a replay or profitability evidence. State September 3's actual result only after broker reconciliation.

## Slide 6 — What this proves, and what comes next

**Headline:** Strong automation evidence; profitability remains an open research question

**On-slide copy:**

- Demonstrates bounded autonomy, MCP integration, explainability, and recovery.
- Uses Alpaca paper trading and Basic indicative data.
- One competition week cannot establish long-run expected value.
- Next: causal multi-event testing, OPRA-quality data, transaction-cost modeling, model-veto evaluation, and stronger monitoring.

**Visual:** Two-column “proven now / still to validate” summary plus repository and live-dashboard QR codes.

**Closing line:** ThetaTrap makes the agent's judgment useful, its authority narrow, and every outcome auditable.
