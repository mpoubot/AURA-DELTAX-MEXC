﻿"""
AlphaSwarm Sovereign: Configuration Module
Handles environment variables, API credentials, and institutional trading parameters.
"""

import os
from pathlib import Path
from dotenv import load_dotenv

# Load .env file from project root
env_path = Path(__file__).resolve().parent / ".env"
load_dotenv(dotenv_path=env_path, override=True)

# Alpaca Credentials & Config
ALPACA_API_KEY = os.getenv("ALPACA_API_KEY", "PKQAT2NLRMRTYWK2SPLH4UURCY")
ALPACA_SECRET_KEY = os.getenv("ALPACA_SECRET_KEY", "9pTsZj7DVZwLniXSVQUWWHQAQ3AY896KzbqVCUncGqTA")
ALPACA_BASE_URL = os.getenv("ALPACA_BASE_URL", "https://paper-api.alpaca.markets")
ALPACA_PAPER = os.getenv("ALPACA_PAPER", "True").lower() in ("true", "1", "yes")

# Google Gemini API Key
GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")

# Institutional Risk Guardrail Defaults
MAX_RISK_PER_TRADE = float(os.getenv("MAX_RISK_PER_TRADE", "0.02"))      # 2.0% of portfolio equity
DEFAULT_STOP_LOSS_PCT = float(os.getenv("DEFAULT_STOP_LOSS_PCT", "0.02")) # 2.0%
DEFAULT_TAKE_PROFIT_PCT = float(os.getenv("DEFAULT_TAKE_PROFIT_PCT", "0.05")) # 5.0%

# Risk Sentinel & Volatility Limits
MIN_CONFIDENCE_THRESHOLD = int(os.getenv("MIN_CONFIDENCE_THRESHOLD", "65")) # 65% minimum confidence
ATR_STOP_LOSS_MULTIPLIER = float(os.getenv("ATR_STOP_LOSS_MULTIPLIER", "1.5"))
ATR_TAKE_PROFIT_MULTIPLIER = float(os.getenv("ATR_TAKE_PROFIT_MULTIPLIER", "3.0"))
MAX_ATR_VOLATILITY_PCT = float(os.getenv("MAX_ATR_VOLATILITY_PCT", "0.08")) # 8.0% institutional ceiling

# Default Watchlist
DEFAULT_WATCHLIST = ["NVDA", "AAPL", "TSLA", "SPY", "MSFT", "AMZN", "META", "GOOGL"]
