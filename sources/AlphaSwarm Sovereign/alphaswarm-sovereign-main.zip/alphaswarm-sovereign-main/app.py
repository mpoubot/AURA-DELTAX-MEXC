﻿"""
AlphaSwarm Sovereign: Autonomous Multi-Agent Consensus Hedge Fund
Premium Glassmorphism Streamlit Dashboard with Real-Time Alpaca Paper Execution.
"""

import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import datetime

# Import AlphaSwarm Subsystems
from config import (
    DEFAULT_WATCHLIST,
    MAX_RISK_PER_TRADE,
    MIN_CONFIDENCE_THRESHOLD,
    ALPACA_PAPER,
)
from alpaca_client import AlpacaEngine
from technical_engine import TechnicalEngine
from debate_core import MultiAgentDebateEngine
from risk_sentinel import RiskSentinel

# -----------------------------------------------------------------------------
# PAGE CONFIG & ULTRA-PREMIUM GLASSMORHPISM STYLING
# -----------------------------------------------------------------------------
st.set_page_config(
    page_title="AlphaSwarm Sovereign | Multi-Agent AI Hedge Fund",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Custom Glassmorphic Dark Cyber Theme
st.markdown(
    """
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@300;400;600;700;800&family=JetBrains+Mono:wght@400;500;700&display=swap');
    
    html, body, [class*="css"] {
        font-family: 'Plus Jakarta Sans', sans-serif;
    }
    
    .stApp {
        background: radial-gradient(circle at 10% 20%, rgba(13, 22, 38, 0.95) 0%, rgba(7, 10, 19, 1) 90%);
        color: #E2E8F0;
    }
    
    /* Glassmorphism Cards */
    .glass-card {
        background: rgba(18, 26, 47, 0.65);
        backdrop-filter: blur(16px);
        -webkit-backdrop-filter: blur(16px);
        border: 1px solid rgba(255, 255, 255, 0.08);
        border-radius: 16px;
        padding: 24px;
        box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.37);
        margin-bottom: 20px;
        transition: transform 0.2s ease, border-color 0.2s ease;
    }
    
    .glass-card:hover {
        border-color: rgba(56, 189, 248, 0.3);
    }
    
    .metric-title {
        font-size: 0.85rem;
        text-transform: uppercase;
        letter-spacing: 0.08em;
        color: #94A3B8;
        margin-bottom: 6px;
    }
    
    .metric-value {
        font-size: 1.85rem;
        font-weight: 800;
        font-family: 'JetBrains Mono', monospace;
        color: #F8FAFC;
    }
    
    .metric-sub {
        font-size: 0.8rem;
        color: #10B981;
        font-weight: 600;
    }
    
    .badge-bull {
        background: rgba(16, 185, 129, 0.15);
        color: #34D399;
        border: 1px solid rgba(16, 185, 129, 0.3);
        padding: 4px 10px;
        border-radius: 8px;
        font-weight: 700;
        font-size: 0.85rem;
    }
    
    .badge-bear {
        background: rgba(239, 68, 68, 0.15);
        color: #F87171;
        border: 1px solid rgba(239, 68, 68, 0.3);
        padding: 4px 10px;
        border-radius: 8px;
        font-weight: 700;
        font-size: 0.85rem;
    }
    
    .badge-pm {
        background: rgba(99, 102, 241, 0.15);
        color: #A5B4FC;
        border: 1px solid rgba(99, 102, 241, 0.3);
        padding: 4px 10px;
        border-radius: 8px;
        font-weight: 700;
        font-size: 0.85rem;
    }
    
    /* Dialogue Bubble */
    .debate-bubble {
        background: rgba(15, 23, 42, 0.7);
        border: 1px solid rgba(255, 255, 255, 0.06);
        border-radius: 12px;
        padding: 14px 18px;
        margin-bottom: 12px;
    }
    
    .debate-speaker {
        font-weight: 700;
        font-size: 0.95rem;
        margin-bottom: 4px;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    
    .debate-text {
        font-size: 0.92rem;
        line-height: 1.5;
        color: #CBD5E1;
    }
    
    /* Sentinel Checklist */
    .sentinel-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px 14px;
        border-radius: 8px;
        background: rgba(15, 23, 42, 0.5);
        border: 1px solid rgba(255, 255, 255, 0.05);
        margin-bottom: 8px;
    }
    
    /* Buttons */
    .stButton>button {
        background: linear-gradient(135deg, #2563EB 0%, #7C3AED 100%);
        color: white;
        border: none;
        border-radius: 10px;
        padding: 12px 24px;
        font-weight: 700;
        font-size: 1rem;
        box-shadow: 0 4px 15px rgba(37, 99, 235, 0.4);
        transition: all 0.2s ease;
        width: 100%;
    }
    .stButton>button:hover {
        background: linear-gradient(135deg, #1D4ED8 0%, #6D28D9 100%);
        box-shadow: 0 6px 20px rgba(37, 99, 235, 0.6);
        transform: translateY(-1px);
    }
    </style>
    """,
    unsafe_allow_html=True,
)

# -----------------------------------------------------------------------------
# INITIALIZE ENGINES & SESSION STATE
# -----------------------------------------------------------------------------
@st.cache_resource
def get_engines():
    alpaca = AlpacaEngine()
    tech = TechnicalEngine(alpaca)
    debate = MultiAgentDebateEngine()
    sentinel = RiskSentinel()
    return alpaca, tech, debate, sentinel

alpaca_engine, tech_engine, debate_engine, risk_sentinel = get_engines()

if "selected_ticker" not in st.session_state:
    st.session_state.selected_ticker = "NVDA"
if "last_execution" not in st.session_state:
    st.session_state.last_execution = None

# -----------------------------------------------------------------------------
# SIDEBAR CONTROLS
# -----------------------------------------------------------------------------
with st.sidebar:
    st.markdown("""
        <div style="display:flex; align-items:center; gap:10px; margin-bottom:15px;">
            <div style="background: linear-gradient(135deg, #06B6D4, #3B82F6); border-radius:12px; width:42px; height:42px; display:flex; align-items:center; justify-content:center; font-size:22px;">⚡</div>
            <div>
                <h2 style="margin:0; font-size:1.3rem; font-weight:800; color:#F8FAFC;">ALPHASWARM</h2>
                <div style="font-size:0.75rem; color:#38BDF8; letter-spacing:0.05em; font-weight:600;">SOVEREIGN HEDGE FUND</div>
            </div>
        </div>
    """, unsafe_allow_html=True)
    
    st.markdown("---")
    
    # Asset Selection
    selected_ticker = st.selectbox(
        "Target Ticker",
        options=DEFAULT_WATCHLIST,
        index=DEFAULT_WATCHLIST.index(st.session_state.selected_ticker) if st.session_state.selected_ticker in DEFAULT_WATCHLIST else 0,
    )
    custom_ticker = st.text_input("Or Enter Custom Symbol", value="").upper().strip()
    if custom_ticker:
        selected_ticker = custom_ticker
    st.session_state.selected_ticker = selected_ticker

    # Strategy & Risk Parameters
    st.markdown("### Institutional Parameters")
    risk_pct = st.slider("Max Equity Risk per Trade (%)", min_value=0.5, max_value=5.0, value=MAX_RISK_PER_TRADE * 100, step=0.5)
    conf_thresh = st.slider("Min Debate Consensus (%)", min_value=50, max_value=90, value=MIN_CONFIDENCE_THRESHOLD, step=5)
    
    risk_sentinel.max_risk_pct = risk_pct / 100.0
    risk_sentinel.min_confidence = int(conf_thresh)

    st.markdown("---")
    
    # Mode Status
    st.markdown(f"""
        <div style="background:rgba(16, 185, 129, 0.1); border:1px solid rgba(16,185,129,0.3); border-radius:10px; padding:12px;">
            <div style="font-size:0.8rem; color:#A7F3D0; font-weight:700;">🟢 ALPACA CONNECTIVITY</div>
            <div style="font-size:0.75rem; color:#94A3B8; margin-top:3px;">
                Mode: <b>{'Paper Trading' if ALPACA_PAPER else 'Live'}</b><br>
                Multi-Agent LLM: <b>{'Gemini Active' if debate_engine.gemini_active else 'Deterministic Quant Core'}</b>
            </div>
        </div>
    """, unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# MAIN HEADER & REAL-TIME PORTFOLIO METRICS
# -----------------------------------------------------------------------------
account_data = alpaca_engine.get_account_summary()
positions_data = alpaca_engine.get_open_positions()
recent_orders = alpaca_engine.get_recent_orders(limit=10)

col1, col2, col3, col4 = st.columns(4)

with col1:
    st.markdown(f"""
        <div class="glass-card">
            <div class="metric-title">Portfolio Equity</div>
            <div class="metric-value">${account_data.get('equity', 100000):,.2f}</div>
            <div class="metric-sub">▲ Live Alpaca Paper Value</div>
        </div>
    """, unsafe_allow_html=True)

with col2:
    st.markdown(f"""
        <div class="glass-card">
            <div class="metric-title">Settled Cash</div>
            <div class="metric-value">${account_data.get('cash', 95000):,.2f}</div>
            <div class="metric-sub" style="color:#38BDF8;">Available for Allocation</div>
        </div>
    """, unsafe_allow_html=True)

with col3:
    st.markdown(f"""
        <div class="glass-card">
            <div class="metric-title">Buying Power</div>
            <div class="metric-value">${account_data.get('buying_power', 190000):,.2f}</div>
            <div class="metric-sub" style="color:#A78BFA;">2.0x Margin Ratio</div>
        </div>
    """, unsafe_allow_html=True)

with col4:
    active_pos_count = len(positions_data)
    st.markdown(f"""
        <div class="glass-card">
            <div class="metric-title">Active Holdings</div>
            <div class="metric-value">{active_pos_count} <span style="font-size:1rem; font-weight:400; color:#94A3B8;">Positions</span></div>
            <div class="metric-sub" style="color:#F59E0B;">Sentinel Protected</div>
        </div>
    """, unsafe_allow_html=True)

# -----------------------------------------------------------------------------
# REAL-TIME QUANT & TECHNICAL ANALYSIS
# -----------------------------------------------------------------------------
tech_summary = tech_engine.generate_technical_summary(selected_ticker)
df_bars = tech_summary.get("df", pd.DataFrame())

st.markdown(f"""
    <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:15px;">
        <h3 style="margin:0; font-size:1.5rem; font-weight:800;">
            📈 Market Intelligence: <span style="color:#38BDF8;">{selected_ticker}</span> 
            <span style="font-size:1.1rem; color:#94A3B8; font-weight:400;">(${tech_summary.get('current_price', 0):.2f})</span>
        </h3>
        <div>
            <span class="badge-bull">RSI: {tech_summary.get('rsi', 50):.1f}</span>
            <span class="badge-pm">Quant Score: {tech_summary.get('quant_score', 0):+.2f}</span>
        </div>
    </div>
""", unsafe_allow_html=True)

# Plotly Candlestick & Technical Overlay
if not df_bars.empty:
    fig = make_subplots(
        rows=2, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.04,
        row_heights=[0.75, 0.25],
    )

    # Candlestick
    fig.add_trace(
        go.Candlestick(
            x=df_bars.index,
            open=df_bars["open"],
            high=df_bars["high"],
            low=df_bars["low"],
            close=df_bars["close"],
            name="OHLC",
            increasing_line_color="#10B981",
            decreasing_line_color="#EF4444",
        ),
        row=1, col=1
    )

    # SMAs
    if "sma_20" in df_bars.columns:
        fig.add_trace(go.Scatter(x=df_bars.index, y=df_bars["sma_20"], name="SMA 20", line=dict(color="#38BDF8", width=1.5)), row=1, col=1)
    if "sma_50" in df_bars.columns:
        fig.add_trace(go.Scatter(x=df_bars.index, y=df_bars["sma_50"], name="SMA 50", line=dict(color="#F59E0B", width=1.5)), row=1, col=1)

    # Bollinger Bands
    if "bb_upper" in df_bars.columns and "bb_lower" in df_bars.columns:
        fig.add_trace(go.Scatter(x=df_bars.index, y=df_bars["bb_upper"], name="BB Upper", line=dict(color="rgba(167, 139, 250, 0.4)", dash="dot")), row=1, col=1)
        fig.add_trace(go.Scatter(x=df_bars.index, y=df_bars["bb_lower"], name="BB Lower", line=dict(color="rgba(167, 139, 250, 0.4)", dash="dot"), fill='tonexty', fillcolor="rgba(167, 139, 250, 0.05)"), row=1, col=1)

    # MACD / Volume
    if "macd" in df_bars.columns:
        fig.add_trace(go.Scatter(x=df_bars.index, y=df_bars["macd"], name="MACD", line=dict(color="#06B6D4", width=1.5)), row=2, col=1)
        fig.add_trace(go.Scatter(x=df_bars.index, y=df_bars["macd_signal"], name="Signal", line=dict(color="#F43F5E", width=1.5)), row=2, col=1)
        colors = ["#10B981" if val >= 0 else "#EF4444" for val in df_bars["macd_hist"]]
        fig.add_trace(go.Bar(x=df_bars.index, y=df_bars["macd_hist"], name="Histogram", marker_color=colors), row=2, col=1)

    fig.update_layout(
        template="plotly_dark",
        paper_bgcolor="rgba(18, 26, 47, 0.4)",
        plot_bgcolor="rgba(15, 23, 42, 0.4)",
        margin=dict(l=10, r=10, t=10, b=10),
        height=450,
        showlegend=True,
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        xaxis_rangeslider_visible=False,
    )
    st.plotly_chart(fig, use_container_width=True)

# -----------------------------------------------------------------------------
# MULTI-AGENT CONSENSUS DEBATE ARENA & RISK SENTINEL
# -----------------------------------------------------------------------------
tab_debate, tab_risk, tab_positions, tab_orders = st.tabs([
    "🏛️ Multi-Agent Debate Arena",
    "🛡️ Risk Sentinel Audit",
    "💼 Portfolio Holdings",
    "📋 Order Audit Trail",
])

# Compute Debate Consensus & Sentinel Validation
consensus = debate_engine.run_debate(tech_summary)
sentinel_res = risk_sentinel.validate_trade(
    account_equity=account_data.get("equity", 100000.0),
    account_cash=account_data.get("cash", 95000.0),
    current_price=tech_summary.get("current_price", 100.0),
    consensus_decision=consensus,
    atr_value=tech_summary.get("atr", 3.0),
)

with tab_debate:
    col_d1, col_d2 = st.columns([1.6, 1])

    with col_d1:
        st.markdown("#### 🎙️ Live Multi-Agent Dialectic Transcript")
        transcript = consensus.get("debate_transcript", [])
        for entry in transcript:
            speaker = entry.get("speaker", "Agent")
            avatar = entry.get("avatar", "🤖")
            text = entry.get("text", "")
            
            badge_class = "badge-bull" if "Bull" in speaker else ("badge-bear" if "Bear" in speaker else "badge-pm")
            
            st.markdown(f"""
                <div class="debate-bubble">
                    <div class="debate-speaker">
                        <span>{avatar}</span> 
                        <span class="{badge_class}">{speaker}</span>
                    </div>
                    <div class="debate-text">{text}</div>
                </div>
            """, unsafe_allow_html=True)

    with col_d2:
        st.markdown("#### ⚖️ Consensus Verdict")
        action = consensus.get("action", "HOLD")
        conf = consensus.get("confidence_score", 50)
        
        action_color = "#10B981" if action == "BUY" else ("#EF4444" if action == "SELL" else "#F59E0B")
        
        st.markdown(f"""
            <div class="glass-card" style="text-align:center; border-top: 4px solid {action_color};">
                <div style="font-size:0.85rem; color:#94A3B8; text-transform:uppercase; letter-spacing:0.1em;">Committee Action</div>
                <div style="font-size:2.4rem; font-weight:900; color:{action_color}; margin: 8px 0;">{action}</div>
                <div style="font-size:0.9rem; color:#CBD5E1; margin-bottom:12px;">Consensus Conviction: <b>{conf}%</b></div>
                <div style="background:rgba(255,255,255,0.06); border-radius:999px; height:8px; width:100%; overflow:hidden;">
                    <div style="background:{action_color}; width:{conf}%; height:100%;"></div>
                </div>
                <div style="font-size:0.85rem; color:#94A3B8; margin-top:14px; text-align:left; font-style:italic;">
                    "{consensus.get('summary_verdict', '')}"
                </div>
            </div>
        """, unsafe_allow_html=True)

        st.markdown("##### 📌 Trade Rationale")
        for rat in consensus.get("rationale", []):
            st.markdown(f"- {rat}")

        # Autonomous Execution CTA
        st.markdown("---")
        if sentinel_res.get("approved", False):
            exec_label = f"🚀 Execute Bracket Order: {sentinel_res.get('recommended_qty')}x {selected_ticker}"
            if st.button(exec_label, key="exec_bracket_btn"):
                with st.spinner("Dispatching Bracket Order to Alpaca Paper Trading API..."):
                    exec_result = alpaca_engine.execute_bracket_order(
                        symbol=selected_ticker,
                        qty=sentinel_res.get("recommended_qty", 1),
                        take_profit_price=sentinel_res.get("take_profit", 0.0),
                        stop_loss_price=sentinel_res.get("stop_loss", 0.0),
                    )
                    st.session_state.last_execution = exec_result
                    if exec_result.get("success"):
                        st.success(f"✅ {exec_result.get('message')}")
                        st.balloons()
                    else:
                        st.error(f"❌ Execution Error: {exec_result.get('message')}")
        else:
            reasons = ", ".join(sentinel_res.get("rejection_reasons", ["Risk criteria not met"]))
            st.button(f"🔒 Execution Locked by Sentinel ({reasons})", disabled=True)

with tab_risk:
    col_r1, col_r2 = st.columns([1.2, 1])

    with col_r1:
        st.markdown("#### 🛡️ Institutional Risk Sentinel Terminal")
        st.markdown("Every agent trade proposal must pass fiduciary constraints before entering the order queue.")

        for item in sentinel_res.get("checklist", []):
            status_icon = "✅" if item["passed"] else "❌"
            status_color = "#10B981" if item["passed"] else "#EF4444"
            st.markdown(f"""
                <div class="sentinel-item">
                    <div>
                        <div style="font-weight:700; font-size:0.92rem;">{item['check']}</div>
                        <div style="font-size:0.8rem; color:#94A3B8; margin-top:2px;">{item['detail']}</div>
                    </div>
                    <div style="font-size:1.2rem; font-weight:800; color:{status_color};">{status_icon}</div>
                </div>
            """, unsafe_allow_html=True)

    with col_r2:
        st.markdown("#### 📐 Mathematical Position Sizing")
        st.markdown(f"""
            <div class="glass-card">
                <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <span style="color:#94A3B8;">Recommended Quantity:</span>
                    <span style="font-weight:700; font-family:'JetBrains Mono'; color:#38BDF8;">{sentinel_res.get('recommended_qty')} shares</span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <span style="color:#94A3B8;">Entry Price:</span>
                    <span style="font-weight:700; font-family:'JetBrains Mono';">${sentinel_res.get('current_price', 0):.2f}</span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <span style="color:#94A3B8;">Dynamic Stop-Loss (1.5x ATR):</span>
                    <span style="font-weight:700; font-family:'JetBrains Mono'; color:#EF4444;">${sentinel_res.get('stop_loss', 0):.2f}</span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <span style="color:#94A3B8;">Take-Profit Target (3.0x ATR):</span>
                    <span style="font-weight:700; font-family:'JetBrains Mono'; color:#10B981;">${sentinel_res.get('take_profit', 0):.2f}</span>
                </div>
                <div style="display:flex; justify-content:space-between; margin-bottom:10px;">
                    <span style="color:#94A3B8;">Risk-to-Reward Ratio:</span>
                    <span style="font-weight:700; font-family:'JetBrains Mono'; color:#A78BFA;">1 : {sentinel_res.get('risk_reward_ratio', 2.0):.2f}</span>
                </div>
                <hr style="border-color:rgba(255,255,255,0.08); margin:12px 0;">
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:#94A3B8;">Max Dollar Risk (2%):</span>
                    <span style="font-weight:700; font-family:'JetBrains Mono'; color:#F87171;">${sentinel_res.get('potential_max_loss', 0):,.2f}</span>
                </div>
                <div style="display:flex; justify-content:space-between;">
                    <span style="color:#94A3B8;">Target Profit:</span>
                    <span style="font-weight:700; font-family:'JetBrains Mono'; color:#34D399;">${sentinel_res.get('potential_max_gain', 0):,.2f}</span>
                </div>
            </div>
        """, unsafe_allow_html=True)

with tab_positions:
    st.markdown("#### 💼 Real-Time Portfolio Holdings")
    if positions_data:
        for p in positions_data:
            pl_color = "#10B981" if p["unrealized_pl"] >= 0 else "#EF4444"
            st.markdown(f"""
                <div class="glass-card" style="padding:16px; margin-bottom:10px; display:flex; justify-content:space-between; align-items:center;">
                    <div>
                        <span style="font-weight:800; font-size:1.2rem; color:#F8FAFC;">{p['symbol']}</span>
                        <span style="font-size:0.85rem; color:#94A3B8; margin-left:8px;">{p['qty']} shares @ ${p['avg_entry_price']:.2f}</span>
                    </div>
                    <div style="text-align:right;">
                        <div style="font-weight:700; font-family:'JetBrains Mono'; font-size:1.1rem; color:#F8FAFC;">${p['market_value']:,.2f}</div>
                        <div style="font-weight:700; font-size:0.9rem; color:{pl_color};">
                            {p['unrealized_pl']:+,.2f} USD ({p['unrealized_pl_pct']:+.2f}%)
                        </div>
                    </div>
                </div>
            """, unsafe_allow_html=True)
    else:
        st.info("No open positions currently active in this Alpaca Paper account.")

with tab_orders:
    st.markdown("#### 📋 Order Execution Audit Trail")
    if recent_orders:
        df_orders = pd.DataFrame(recent_orders)
        st.dataframe(
            df_orders,
            use_container_width=True,
            hide_index=True,
        )
    else:
        st.info("No recent orders recorded.")

# Footer
st.markdown("---")
st.markdown("""
    <div style="display:flex; justify-content:space-between; font-size:0.8rem; color:#64748B;">
        <div>AlphaSwarm Sovereign AI Hedge Fund • Alpaca AI Trading Hackathon</div>
        <div>Fiduciary Multi-Agent Architecture v1.0.0</div>
    </div>
""", unsafe_allow_html=True)
