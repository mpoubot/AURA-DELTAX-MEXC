# ⚡ AlphaSwarm Sovereign
### Autonomous Multi-Agent Consensus Hedge Fund & Institutional FinTech SaaS

[![Python 3.11](https://img.shields.io/badge/Python-3.11+-3776AB?style=for-the-badge&logo=python&logoColor=white)](https://python.org)
[![FastAPI](https://img.shields.io/badge/FastAPI-0.111+-009688?style=for-the-badge&logo=fastapi&logoColor=white)](https://fastapi.tiangolo.com)
[![Next.js 14](https://img.shields.io/badge/Next.js-14_App_Router-000000?style=for-the-badge&logo=next.js&logoColor=white)](https://nextjs.org)
[![Alpaca API](https://img.shields.io/badge/Alpaca-Paper_Trading_API-FFD100?style=for-the-badge&logo=alpaca&logoColor=black)](https://alpaca.markets)
[![Docker](https://img.shields.io/badge/Docker-Compose_Ready-2496ED?style=for-the-badge&logo=docker&logoColor=white)](https://docker.com)
[![Google Gemini](https://img.shields.io/badge/Google_Gemini-1.5_Flash-8E75C2?style=for-the-badge&logo=google&logoColor=white)](https://ai.google.dev)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg?style=for-the-badge)](https://opensource.org/licenses/MIT)

---

## 🏛️ Executive Summary

**AlphaSwarm Sovereign** is a champion-grade, production-ready autonomous multi-agent quantitative hedge fund SaaS engineered for the **Alpaca AI Trading Agents Hackathon**.

AlphaSwarm Sovereign replaces fragile black-box trading bots with an **explainable, fiduciary-governed multi-agent consensus committee**. An aggressive **Bull Researcher** and risk-averse **Bear Skeptic** engage in live, real-time dialectic debate streaming over Server-Sent Events (SSE) with synchronized browser Web Speech audio narration. Every trade is strictly scrutinized by a **Multimodal Vision Pattern Agent**, an **Episodic Trade Memory Loop** (post-mortem trade scarring), a **Macro News Sentiment NLP Engine**, and an institutional **Risk Sentinel** enforcing 1,000-path Monte Carlo 95% Value-at-Risk (VaR) bounds, dynamic ATR brackets (1:2 R:R), and automated fiduciary circuit breakers before live execution via the **Alpaca Paper & Live Trading API**.

---

## 📸 Dashboard & Visual Intelligence

### 1. Institutional Terminal Dashboard
![Dashboard Overview](assets/screenshots/dashboard-overview.svg)
*Real-time glassmorphic terminal featuring live KPI strips, interactive technical charts, Multimodal Vision pattern badges, consensus verdict hero card, and active Alpaca holdings.*

---

### 2. Multi-Agent Adversarial Debate Arena (Web Speech Audio Synthesis)
![Dialectic Debate Arena](assets/screenshots/dialectic-debate.svg)
*Turn-by-turn dialectic streaming over Server-Sent Events (SSE) with synchronized browser Web Speech synthesis, distinct institutional agent voices, and typewriter animation.*

---

### 3. Institutional LP Investment Memorandum (PDF Generator)
![LP Investment Memorandum Preview](assets/screenshots/lp-memo-preview.svg)
*1-Click LP Memorandum generator compiling Fund Headers, Executive Summaries, Multimodal Vision geometry, 1,000-path Monte Carlo 95% VaR, and dialectic transcripts into audit-ready PDF documents.*

---

### 4. Docker Container Topology & Fiduciary Gateway
![Docker Container Architecture](assets/screenshots/docker-health.svg)
*Production multi-container orchestration with FastAPI on port 8000, Next.js on port 3000, and Alpaca Paper Trading Gateway with BYOK AES-256 cryptographic vault.*

---

## 📐 System Architecture

```
                                  +------------------------------------+
                                  |    Institutional Next.js 14 UI     |
                                  | - Real-Time Multi-Agent Debate     |
                                  | - Web Speech Voice Synthesis (TTS) |
                                  | - Interactive Candlestick Chart    |
                                  | - BYOK AES-256 Security Vault      |
                                  | - Natural Language AI Copilot      |
                                  | - 1-Click LP Memo PDF Download     |
                                  +-----------------+------------------+
                                                    | (REST / SSE Stream)
                                                    v
                                  +------------------------------------+
                                  |     FastAPI SaaS Gateway (8000)    |
                                  +--------+------------------+--------+
                                           |                  |
                     +---------------------+                  +---------------------+
                     |                                                              |
                     v                                                              v
   +-----------------------------------+                          +-----------------------------------+
   |     BYOK Security Vault Engine    |                          |   Fiduciary Circuit Breaker &     |
   |  - AES-256 Fernet Cryptography    |                          |   Dynamic Broker Session Gateway  |
   |  - Zero Plaintext Storage         |                          |  - Intraday Drawdown Evaluator    |
   |  - Paper vs Live Mode Switching   |                          |  - Emergency Kill Switch Guard    |
   +-----------------+-----------------+                          +-----------------+-----------------+
                     |                                                              |
                     +-----------------------------+--------------------------------+
                                                   |
                                                   v
   +------------------------------------------------------------------------------------------------+
   |                                QUANTITATIVE & MULTI-AGENT CORE                                 |
   |  +------------------------+  +------------------------+  +----------------------------------+  |
   |  | Multimodal Vision      |  | Bull vs Bear Dialectic |  | Episodic Trade Memory Ledger     |  |
   |  | Pattern Recognition    |  | Consensus Engine       |  | (Post-Mortem Trade Scarring)     |  |
   |  +------------------------+  +------------------------+  +----------------------------------+  |
   |  +------------------------+  +------------------------+  +----------------------------------+  |
   |  | Macro News Sentiment   |  | 1,000-Path Monte Carlo |  | Institutional LP Memorandum      |  |
   |  | NLP VETO Guardrail     |  | 95% VaR Sentinel Gate  |  | PDF Engine (ReportLab)           |  |
   |  +------------------------+  +------------------------+  +----------------------------------+  |
   +-----------------------------------------------+------------------------------------------------+
                                                   |
                                                   v
                                  +------------------------------------+
                                  |      Alpaca Trading Gateway        |
                                  | (Account: PA3YUKHVMBVC / Live Key) |
                                  | - Bracket Orders (SL 1.5x / TP 3x) |
                                  | - Real-Time Portfolio Ledger       |
                                  +------------------------------------+
```

```mermaid
sequenceDiagram
    autonumber
    actor User as Investor / Portfolio Mgr
    participant UI as Next.js Dashboard
    participant API as FastAPI SaaS Gateway
    participant AI as Multi-Agent Committee
    participant Sentinel as Risk Sentinel & VaR
    participant Broker as Alpaca Trading API

    User->>UI: Selects Ticker (e.g. NVDA)
    UI->>API: GET /api/stream-debate/{symbol}
    API->>AI: Trigger Technical Scout, Vision & News Agents
    AI-->>UI: SSE Stream: Bull Thesis -> Bear Rebuttal -> Arbiter Consensus
    Note over UI: Browser Web Speech synthesizes distinct agent voices in real-time
    User->>UI: Clicks "Execute Sentinel Bracket"
    UI->>API: POST /api/execute (Symbol, Qty, SL, TP)
    API->>Sentinel: Pre-flight Fiduciary Check (Max 2% Risk, VaR, Circuit Breaker)
    alt Approved by Sentinel
        Sentinel->>Broker: Submit Bracket Market Order (1.5x ATR Stop, 3.0x ATR Target)
        Broker-->>API: Order Filled & Confirmed
        API-->>UI: 200 OK & Confetti Celebration
    else Rejected / Tripped
        Sentinel-->>UI: 403 Forbidden ("CIRCUIT_BREAKER_TRIPPED" / Rejection Reason)
    end
```

---

## 🌟 Key Breakthrough Capabilities

### 1. 🎙️ Adversarial Multi-Agent Dialectic & Live Voice Synthesis
- **Bull Researcher (🐂)**: Aggressive momentum and growth thesis powered by technical indicators, moving average golden crosses, and catalyst events. Voice: energetic, higher pitch.
- **Bear Skeptic (🐻)**: Skeptical contrarian probing downside tail risk, overhead resistance, overbought RSI, and macro headwinds. Voice: deep, measured tempo.
- **Portfolio Manager Arbiter (🏛️)**: Executive fiduciary weighing risk-adjusted Sharpe potential, assigning an institutional conviction score ($0\text{--}100\%$) and definitive action (`BUY`, `HOLD`, `SELL`).
- **Synchronized Audio**: Browser native `window.speechSynthesis` speaks each argument turn-by-turn with glowing avatar animations.

### 2. 👁️ Multimodal Chart Vision Pattern Recognition Agent
- Analyzes daily and intraday candlestick geometry to detect structural price patterns:
  - *Ascending Channels, Bull Flags, Head & Shoulders, Double Bottoms, Hammer Reversals*.
- Pinpoints dynamic Support/Resistance inflection zones and passes visual evidence directly into the LLM debate prompt.

### 3. 🛡️ Fiduciary Risk Sentinel & 1,000-Path Monte Carlo 95% VaR
- **1,000-Simulation Monte Carlo**: Models geometric Brownian motion asset trajectories over a 30-day horizon to compute the **95% Value at Risk (VaR)** and maximum projected drawdown.
- **Strict 2% Equity Risk Sizing**: Position size is calculated dynamically:
  $$\text{Shares} = \left\lfloor \frac{\text{Equity} \times 0.02}{\text{ATR} \times 1.5} \right\rfloor$$
- **Dynamic 1:2 R:R Brackets**: Automatically enforces a **1.5x ATR Stop-Loss** and **3.0x ATR Take-Profit**.

### 4. 🧠 Episodic Trade Memory Loop (Post-Mortem Trade Scarring)
- Maintains an audit ledger of past trades in a SQLite/PostgreSQL database.
- Synthesizes post-mortem lessons from previous losses and automatically injects historical advisories (e.g. *"Previous breakdown on NVDA occurred near earnings. Tighter stops enforced."*) into future dialectics.

### 5. 📰 Real-Time Macro & News Sentiment Agent (NLP VETO)
- Computes the institutional **Macro Sentiment Index ($-1.0$ to $+1.0$)** from live headline feeds.
- **Macro VETO Guardrail**: If macro sentiment drops below critically bearish levels ($< -0.60$), all buy executions are automatically locked out.

### 6. 📄 1-Click Institutional LP Investment Memorandum (PDF Generator)
- Generates institutional-grade PDF investment reports containing Fund Headers, Committee Verdicts, Dialectic Transcripts, Multimodal Vision Geometry, and Monte Carlo VaR metrics using ReportLab.

### 7. 🔐 BYOK Multi-Tenant Security Vault (AES-256 Fernet)
- Enterprise **Bring-Your-Own-Key (BYOK)** vault encrypting broker API/Secret keys with AES-256. Raw secrets are never stored in plaintext and are only decrypted Just-In-Time (JIT) during execution.
- Includes a 1-click toggle between **Paper Sandbox** and **Live Capital Gateway**.

### 8. 🤖 Natural Language Financial AI Copilot
- Collapsible interactive drawer allowing portfolio managers to query fund exposure, trade rationale, and risk parameters in natural language (e.g. *"What is our current cash allocation and why was NVDA bought?"*).

---

## 🦙 Alpaca Technology Integration

AlphaSwarm Sovereign is built natively on the **Alpaca Developer Ecosystem**:

1. **Alpaca Trading API (`alpaca-py`)**:
   - Manages real-time account balances, equity tracking, buying power, and active positions.
   - Dispatches institutional **Bracket Market Orders** with nested stop-loss and take-profit legs.
2. **Alpaca Market Data API**:
   - Ingests multi-timeframe historical OHLCV bars for technical feature extraction (SMA 20/50, RSI 14, MACD, Bollinger Bands, ATR 14).
3. **Paper Trading Sandbox (Account: `PA3YUKHVMBVC`)**:
   - Validated on the Alpaca Paper Trading environment with live \$100,000 equity portfolio management.
4. **Alpaca MCP Server & CLI Compatibility**:
   - Built with standardized JSON schemas and REST endpoints compatible with the Alpaca Model Context Protocol (MCP) server for autonomous LLM agent execution.

---

## 📂 Project Structure

```
alpha-swarm/
├── docker-compose.yml              # Multi-container orchestration (Backend + Frontend)
├── .env.example                    # Master environment configuration template
├── LICENSE                         # MIT License
├── README.md                       # Institutional documentation
├── assets/
│   └── screenshots/                # Visual intelligence & dashboard screenshots
│       ├── dashboard-overview.svg  # Full terminal UI overview
│       ├── dialectic-debate.svg    # Adversarial debate & voice synthesis
│       ├── lp-memo-preview.svg     # ReportLab LP memorandum document preview
│       └── docker-health.svg       # Docker container topology & service health
├── backend/
│   ├── Dockerfile                  # Python 3.11 backend container
│   ├── requirements.txt            # FastAPI, Alpaca-py, ReportLab, Cryptography
│   ├── main.py                     # FastAPI SaaS Gateway & REST / SSE routes
│   ├── database.py                 # SQLAlchemy engine (PostgreSQL / SQLite)
│   ├── models.py                   # Multi-tenant DB models (Users, Vault, Trades, Logs)
│   ├── security_vault.py           # AES-256 BYOK cryptographic key engine
│   ├── broker_gateway.py           # Dynamic tenant broker sessions & circuit breakers
│   ├── alpaca_client.py            # Alpaca Trading & Historical Market Data engine
│   ├── technical_engine.py         # Quant feature extractor (RSI, MACD, SMA, ATR)
│   ├── debate_core.py              # 3-Agent Consensus Dialectic & SSE turn streamer
│   ├── risk_sentinel.py            # Monte Carlo 95% VaR & 2% risk sizing sentinel
│   ├── vision_engine.py            # Multimodal Chart Geometry Pattern Recognition
│   ├── news_engine.py              # Macro News NLP Sentiment & VETO Guardrail
│   ├── memory_engine.py            # Self-reflective episodic trade memory ledger
│   ├── pdf_memo.py                 # ReportLab institutional PDF memo generator
│   └── copilot.py                  # Conversational Financial AI Copilot
└── frontend/
    ├── Dockerfile                  # Next.js 14 standalone production image
    ├── package.json                # Dependencies (Tailwind, Lucide, Framer Motion, Axios)
    ├── next.config.js              # Next.js App Router configuration
    ├── tailwind.config.js          # Obsidian & neon emerald/cyan palette
    └── src/
        ├── app/
        │   ├── layout.tsx          # Root layout with dark luxury theme
        │   └── page.tsx            # Terminal Dashboard orchestrator
        ├── components/
        │   ├── Navbar.tsx          # Ticker search, Vault settings & Live badge
        │   ├── MetricCards.tsx     # Portfolio equity, cash, and buying power KPIs
        │   ├── MarketChart.tsx     # Candlestick / indicator chart visualizer
        │   ├── NewsSentimentCard.tsx # Real-time macro headline stream & NLP meter
        │   ├── DebateArena.tsx     # Live SSE debate with Web Speech voice synthesis
        │   ├── RiskSentinelPanel.tsx # 1,000-path Monte Carlo VaR & checklist
        │   ├── TradeMemoryRecall.tsx # Episodic post-mortem trade memory cards
        │   ├── PositionsTable.tsx  # Active holdings & order audit ledger
        │   ├── TradeModal.tsx      # 1-click bracket execution modal
        │   ├── VaultSettingsModal.tsx # BYOK key management & kill switch settings
        │   └── CopilotTerminal.tsx # Collapsible natural language AI Copilot drawer
        └── lib/
            └── api.ts              # Type-safe Axios client & SSE streaming helpers
```

---

## ⚡ Quickstart Guide

### Prerequisites
- [Docker](https://www.docker.com/) & Docker Compose (v2+) **OR** Python 3.11+ & Node.js 20+
- An [Alpaca Developer Account](https://alpaca.markets) (Paper API Key & Secret)

---

### Option A: 🐳 Docker Compose (Recommended)

1. **Clone the repository**:
   ```bash
   git clone https://github.com/fokrulanthro16-eng/alphaswarm-sovereign.git
   cd alphaswarm-sovereign
   ```

2. **Configure Environment Variables**:
   ```bash
   cp .env.example .env
   ```
   *Edit `.env` with your Alpaca credentials and optional Google Gemini API key.*

3. **Build and Launch the Stack**:
   ```bash
   docker-compose up --build -d
   ```

4. **Access the Application**:
   - **Frontend Terminal**: [http://localhost:3000](http://localhost:3000)
   - **Backend API & Swagger Docs**: [http://localhost:8000/docs](http://localhost:8000/docs)

---

### Option B: 💻 Local Bare-Metal Setup

#### 1. Backend Setup:
```bash
cd backend
python -m venv venv
# Windows:
.\venv\Scripts\activate
# Linux/macOS:
source venv/bin/activate

pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

#### 2. Frontend Setup:
```bash
cd frontend
npm install
npm run dev
```
*Open [http://localhost:3000](http://localhost:3000) in your browser.*

---

## 🧪 Fiduciary Sentinel Verification Example

When evaluating an order on **NVDA**:
1. **Technical Scout**: Prices \$128.40, RSI 54.2, MACD histogram positive, Golden Cross active.
2. **Multimodal Vision**: Identifies *Ascending Channel Formation* with key support validated at 20-day SMA.
3. **Macro News Sentiment**: Computes score $+0.35$ (*BULLISH*) across semiconductor supply chain headlines.
4. **Episodic Trade Memory**: Checks past win rate ($80\%$) and confirms standard risk parameters.
5. **Debate Committee**: Bull and Bear agents debate; Portfolio Manager issues **`BUY`** at **85% conviction**.
6. **Risk Sentinel**: Verifies ATR is $2.49\%$ ($\le 8.0\%$), sets dynamic Stop-Loss at \$123.60 (1.5x ATR) and Take-Profit at \$138.00 (3.0x ATR), verifying an exact **1:2.00 Risk-to-Reward ratio**.
7. **Execution**: Submits bracket market order through Alpaca API with sub-second confirmation.

---

## 📜 License

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

---

<div align="center">
  <sub>Built with ⚡ for the Alpaca AI Trading Agents Hackathon 2026.</sub>
</div>
