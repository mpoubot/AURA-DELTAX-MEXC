﻿"""
AlphaSwarm Sovereign: Institutional Risk Sentinel
Enforces Wall-Street grade risk guardrails, ATR volatility circuit breakers,
2% portfolio risk budgeting, and dynamic 1:2 Risk/Reward bracket calculation.
"""

from typing import Any, Dict, List, Optional
from config import (
    MAX_RISK_PER_TRADE,
    MIN_CONFIDENCE_THRESHOLD,
    ATR_STOP_LOSS_MULTIPLIER,
    ATR_TAKE_PROFIT_MULTIPLIER,
    MAX_ATR_VOLATILITY_PCT,
)


class RiskSentinel:
    """
    Automated fiduciary compliance and position-sizing guardrail engine.
    """

    def __init__(
        self,
        max_risk_pct: float = MAX_RISK_PER_TRADE,
        min_confidence: int = MIN_CONFIDENCE_THRESHOLD,
        atr_sl_mult: float = ATR_STOP_LOSS_MULTIPLIER,
        atr_tp_mult: float = ATR_TAKE_PROFIT_MULTIPLIER,
        max_volatility_pct: float = MAX_ATR_VOLATILITY_PCT,
    ):
        self.max_risk_pct = max_risk_pct
        self.min_confidence = min_confidence
        self.atr_sl_mult = atr_sl_mult
        self.atr_tp_mult = atr_tp_mult
        self.max_volatility_pct = max_volatility_pct

    def validate_trade(
        self,
        account_equity: float,
        account_cash: float,
        current_price: float,
        consensus_decision: Dict[str, Any],
        atr_value: float,
    ) -> Dict[str, Any]:
        """
        Validates trade approval and calculates mathematically sound position size and brackets.
        """
        checklist: List[Dict[str, Any]] = []
        is_approved = True
        rejection_reasons = []

        action = consensus_decision.get("action", "HOLD").upper()
        confidence = consensus_decision.get("confidence_score", 0)

        # 1. Action Check
        action_pass = action == "BUY"
        checklist.append({
            "check": "Agent Consensus Action is BUY",
            "passed": action_pass,
            "detail": f"Consensus Action: {action}",
        })
        if not action_pass:
            is_approved = False
            rejection_reasons.append(f"Committee voted {action}, not BUY.")

        # 2. Confidence Threshold Check
        conf_pass = confidence >= self.min_confidence
        checklist.append({
            "check": f"Confidence Score >= {self.min_confidence}%",
            "passed": conf_pass,
            "detail": f"Score: {confidence}% (Required: {self.min_confidence}%)",
        })
        if not conf_pass:
            is_approved = False
            rejection_reasons.append(f"Confidence score {confidence}% is below {self.min_confidence}% threshold.")

        # 3. Volatility / Circuit Breaker Check
        atr_safe = atr_value if atr_value > 0 else (current_price * 0.02)
        volatility_ratio = atr_safe / (current_price + 1e-6)
        vol_pass = volatility_ratio <= self.max_volatility_pct
        checklist.append({
            "check": f"ATR Volatility <= {self.max_volatility_pct * 100:.1f}%",
            "passed": vol_pass,
            "detail": f"Asset Volatility: {volatility_ratio * 100:.2f}% (Limit: {self.max_volatility_pct * 100:.1f}%)",
        })
        if not vol_pass:
            is_approved = False
            rejection_reasons.append(f"Circuit Breaker: Volatility ({volatility_ratio * 100:.2f}%) exceeds safety limit.")

        # 4. Bracket Price Computation
        stop_loss_delta = atr_safe * self.atr_sl_mult
        take_profit_delta = atr_safe * self.atr_tp_mult

        min_sl_delta = current_price * 0.01
        stop_loss_delta = max(stop_loss_delta, min_sl_delta)
        take_profit_delta = max(take_profit_delta, stop_loss_delta * 2.0)

        stop_loss_price = round(max(0.01, current_price - stop_loss_delta), 2)
        take_profit_price = round(current_price + take_profit_delta, 2)

        risk_per_share = current_price - stop_loss_price
        reward_per_share = take_profit_price - current_price
        rr_ratio = reward_per_share / (risk_per_share + 1e-6)

        rr_pass = rr_ratio >= 1.95
        checklist.append({
            "check": "Risk-to-Reward Ratio >= 1:2",
            "passed": rr_pass,
            "detail": f"Calculated R:R is 1:{rr_ratio:.2f} (SL: ${stop_loss_price}, TP: ${take_profit_price})",
        })

        # 5. Position Sizing
        max_capital_at_risk = account_equity * self.max_risk_pct
        if risk_per_share > 0:
            risk_based_qty = int(max_capital_at_risk / risk_per_share)
        else:
            risk_based_qty = 0

        max_cash_allocation = account_cash * 0.90
        cash_based_qty = int(max_cash_allocation / current_price) if current_price > 0 else 0

        recommended_qty = max(0, min(risk_based_qty, cash_based_qty))

        qty_pass = recommended_qty >= 1
        checklist.append({
            "check": f"Portfolio Risk <= {self.max_risk_pct * 100:.1f}% (${max_capital_at_risk:,.2f})",
            "passed": qty_pass,
            "detail": f"Recommended Size: {recommended_qty} shares (${recommended_qty * current_price:,.2f} total value)",
        })
        if not qty_pass:
            is_approved = False
            rejection_reasons.append("Insufficient cash or portfolio risk capacity to size at least 1 share.")

        total_position_cost = round(recommended_qty * current_price, 2)
        max_loss_potential = round(recommended_qty * risk_per_share, 2)
        max_gain_potential = round(recommended_qty * reward_per_share, 2)

        return {
            "approved": is_approved,
            "action": action,
            "recommended_qty": recommended_qty if is_approved else 0,
            "current_price": current_price,
            "stop_loss": stop_loss_price,
            "take_profit": take_profit_price,
            "risk_per_share": round(risk_per_share, 2),
            "reward_per_share": round(reward_per_share, 2),
            "risk_reward_ratio": round(rr_ratio, 2),
            "max_capital_at_risk": round(max_capital_at_risk, 2),
            "total_position_cost": total_position_cost if is_approved else 0.0,
            "potential_max_loss": max_loss_potential if is_approved else 0.0,
            "potential_max_gain": max_gain_potential if is_approved else 0.0,
            "checklist": checklist,
            "rejection_reasons": rejection_reasons,
        }
