/** @type {import('tailwindcss').Config} */
module.exports = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        obsidian: {
          950: "#050608",
          900: "#08090C",
          800: "#0F1117",
          700: "#161922",
          600: "#1F2330",
        },
        emerald: {
          neon: "#00F59B",
          glow: "rgba(0, 245, 155, 0.15)",
        },
        cyan: {
          neon: "#00D2FF",
          glow: "rgba(0, 210, 255, 0.15)",
        },
        coral: {
          neon: "#FF4D4D",
          glow: "rgba(255, 77, 77, 0.15)",
        },
        purple: {
          neon: "#8B5CF6",
          glow: "rgba(139, 92, 246, 0.15)",
        },
        gold: {
          neon: "#F59E0B",
          glow: "rgba(245, 158, 11, 0.15)",
        }
      },
      fontFamily: {
        sans: ["var(--font-sans)", "Inter", "sans-serif"],
        mono: ["var(--font-mono)", "JetBrains Mono", "monospace"],
      },
      boxShadow: {
        "glass": "0 8px 32px 0 rgba(0, 0, 0, 0.5)",
        "neon-green": "0 0 25px rgba(0, 245, 155, 0.35)",
        "neon-blue": "0 0 25px rgba(0, 210, 255, 0.35)",
        "neon-purple": "0 0 25px rgba(139, 92, 246, 0.35)",
        "neon-red": "0 0 25px rgba(255, 77, 77, 0.35)",
      },
      animation: {
        "pulse-slow": "pulse 4s cubic-bezier(0.4, 0, 0.6, 1) infinite",
        "glow": "glow 2s ease-in-out infinite alternate",
      },
      keyframes: {
        glow: {
          "0%": { opacity: 0.4 },
          "100%": { opacity: 1 },
        }
      }
    },
  },
  plugins: [],
}
