"use client";

import React, { useState, useEffect, useCallback } from "react";
import { Navbar } from "@/components/Navbar";
import { MetricCards } from "@/components/MetricCards";
import { MarketChart } from "@/components/MarketChart";
import { NewsSentimentCard } from "@/components/NewsSentimentCard";
import { DebateArena } from "@/components/DebateArena";
import { RiskSentinelPanel } from "@/components/RiskSentinelPanel";
import { TradeMemoryRecall } from "@/components/TradeMemoryRecall";
import { PositionsTable } from "@/components/PositionsTable";
import { TradeModal } from "@/components/TradeModal";
import { VaultSettingsModal } from "@/components/VaultSettingsModal";
import { CopilotTerminal } from "@/components/CopilotTerminal";
import {
  api,
  AccountData,
  MarketBar,
  MarketMetrics,
  ConsensusDecision,
  RiskSentinelData,
  MemoryData,
  VisionData,
  NewsSentimentData,
  PositionItem,
  OrderItem,
  VaultStatusData,
} from "@/lib/api";

export default function TerminalDashboard() {
  const [symbol, setSymbol] = useState<string>("NVDA");
  const [account, setAccount] = useState<AccountData | null>(null);
  const [metrics, setMetrics] = useState<MarketMetrics | null>(null);
  const [bars, setBars] = useState<MarketBar[]>([]);
  const [news, setNews] = useState<NewsSentimentData | null>(null);
  const [consensus, setConsensus] = useState<ConsensusDecision | null>(null);
  const [riskSentinel, setRiskSentinel] = useState<RiskSentinelData | null>(null);
  const [memory, setMemory] = useState<MemoryData | null>(null);
  const [vision, setVision] = useState<VisionData | null>(null);
  const [positions, setPositions] = useState<PositionItem[]>([]);
  const [orders, setOrders] = useState<OrderItem[]>([]);
  const [vaultStatus, setVaultStatus] = useState<VaultStatusData | null>(null);
  
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isTradeModalOpen, setIsTradeModalOpen] = useState<boolean>(false);
  const [isVaultModalOpen, setIsVaultModalOpen] = useState<boolean>(false);

  // Hydrate all data for the chosen symbol
  const loadData = useCallback(async (targetSymbol: string) => {
    setIsLoading(true);
    try {
      const [accRes, posRes, ordRes, marketRes, analysisRes, vaultRes] = await Promise.allSettled([
        api.getAccount(),
        api.getPositions(),
        api.getOrders(),
        api.getMarketData(targetSymbol, 60),
        api.runFullAnalysis(targetSymbol, 0.02, 65),
        api.getVaultStatus(),
      ]);

      if (accRes.status === "fulfilled") setAccount(accRes.value);
      if (posRes.status === "fulfilled") setPositions(posRes.value);
      if (ordRes.status === "fulfilled") setOrders(ordRes.value);
      if (vaultRes.status === "fulfilled") setVaultStatus(vaultRes.value);
      if (marketRes.status === "fulfilled") {
        setBars(marketRes.value.bars);
        setMetrics(marketRes.value.metrics);
      }
      if (analysisRes.status === "fulfilled") {
        setConsensus(analysisRes.value.consensus);
        setRiskSentinel(analysisRes.value.risk_sentinel);
        if (analysisRes.value.metrics) setMetrics(analysisRes.value.metrics);
        if (analysisRes.value.news) setNews(analysisRes.value.news);
        if (analysisRes.value.memory) setMemory(analysisRes.value.memory);
        if (analysisRes.value.vision) setVision(analysisRes.value.vision);
      }
    } catch (err) {
      console.error("Dashboard hydration error:", err);
    } finally {
      setIsLoading(false);
    }
  }, []);

  useEffect(() => {
    loadData(symbol);
  }, [symbol, loadData]);

  const handleSelectSymbol = (newSymbol: string) => {
    setSymbol(newSymbol);
  };

  const handleRefresh = () => {
    loadData(symbol);
  };

  const isPaperMode = vaultStatus?.is_paper ?? (account?.mode?.includes("Paper") ?? true);

  return (
    <div className="min-h-screen pb-20">
      {/* 1. Header Navigation Bar */}
      <Navbar
        currentSymbol={symbol}
        onSelectSymbol={handleSelectSymbol}
        onRefresh={handleRefresh}
        onOpenVault={() => setIsVaultModalOpen(true)}
        isLoading={isLoading}
        paperMode={isPaperMode}
      />

      {/* Main Terminal Container */}
      <main className="mx-auto max-w-7xl px-4 pt-6 sm:px-6 lg:px-8 space-y-6">
        
        {/* 2. Top Metric KPI Strip */}
        <MetricCards account={account} positionCount={positions.length} />

        {/* 3. Interactive Candlestick / Technical Analysis Chart */}
        <MarketChart
          symbol={symbol}
          metrics={metrics}
          bars={bars}
          isLoading={isLoading}
        />

        {/* 4. Real-Time Macro & News Sentiment Feed */}
        <NewsSentimentCard news={news} symbol={symbol} />

        {/* 5. Self-Reflective Post-Mortem Trade Memory Loop */}
        <TradeMemoryRecall memory={memory} symbol={symbol} />

        {/* 6. Multi-Agent Consensus Debate Arena with Voice Synthesis & PDF Memo */}
        <DebateArena
          symbol={symbol}
          consensus={consensus}
          riskSentinel={riskSentinel}
          vision={vision}
          isLoading={isLoading}
          onOpenTradeModal={() => setIsTradeModalOpen(true)}
        />

        {/* 7. Institutional Risk Sentinel Terminal with 1,000-Path Monte Carlo VaR */}
        <RiskSentinelPanel symbol={symbol} riskData={riskSentinel} />

        {/* 8. Active Holdings & Orders Audit Table */}
        <PositionsTable positions={positions} orders={orders} />

      </main>

      {/* 9. One-Click Autonomous Bracket Execution Modal */}
      <TradeModal
        isOpen={isTradeModalOpen}
        onClose={() => setIsTradeModalOpen(false)}
        symbol={symbol}
        riskData={riskSentinel}
        onSuccess={() => {
          loadData(symbol);
        }}
      />

      {/* 10. BYOK Cryptographic Vault & Circuit Breaker Settings Modal */}
      <VaultSettingsModal
        isOpen={isVaultModalOpen}
        onClose={() => setIsVaultModalOpen(false)}
        onUpdated={() => {
          loadData(symbol);
        }}
      />

      {/* 11. Collapsible Financial AI Copilot Drawer */}
      <CopilotTerminal currentSymbol={symbol} />

      {/* Footer Branding */}
      <footer className="mt-16 border-t border-white/[0.06] py-6 text-center text-xs text-slate-500 font-mono">
        AlphaSwarm Sovereign SaaS v3.0 • Multi-Tenant BYOK Vault • Fiduciary Circuit Breaker & LP Investment Memorandum
      </footer>
    </div>
  );
}
