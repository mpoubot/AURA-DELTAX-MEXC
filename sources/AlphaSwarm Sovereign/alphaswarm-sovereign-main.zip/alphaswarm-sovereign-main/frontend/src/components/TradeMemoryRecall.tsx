"use client";

import React from "react";
import { Brain, History, AlertCircle, CheckCircle, TrendingDown } from "lucide-react";
import { MemoryData } from "@/lib/api";

interface TradeMemoryRecallProps {
  memory: MemoryData | null;
  symbol: string;
}

export const TradeMemoryRecall: React.FC<TradeMemoryRecallProps> = ({ memory, symbol }) => {
  const totalTrades = memory?.total_trades ?? 0;
  const winRate = memory?.win_rate_pct ?? 100;
  const netPnl = memory?.net_pnl_pct ?? 0;
  const advisory = memory?.advisory ?? `Standard baseline fiduciary protocol active for ${symbol}.`;
  const adjustment = memory?.strategy_adjustment ?? "BASELINE: Default 2% equity risk allocation.";
  const history = memory?.recent_history ?? [];

  return (
    <div className="glass-panel p-6 border-purple-500/20 bg-gradient-to-br from-obsidian-900 via-obsidian-900 to-purple-950/20">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/[0.08] pb-4 mb-4 gap-2">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-purple-500/20 text-purple-400 border border-purple-500/30 shadow-neon-purple">
            <Brain className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-white text-base">Self-Reflective Trade Memory Loop</h3>
              <span className="rounded-full bg-purple-500/10 border border-purple-500/30 px-2 py-0.5 text-[10px] font-bold text-purple-300 font-mono">
                Persistent Episodic Learning
              </span>
            </div>
            <p className="text-xs text-slate-400">Post-Mortem Lessons & Risk Adaptation for {symbol}</p>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs font-mono">
          <div className="rounded-xl bg-obsidian-800/80 px-3 py-1.5 border border-white/[0.06]">
            <span className="text-slate-400">Historical Scars:</span>{" "}
            <span className="font-bold text-white">{totalTrades} Trades</span>
          </div>
          <div className="rounded-xl bg-obsidian-800/80 px-3 py-1.5 border border-white/[0.06]">
            <span className="text-slate-400">Symbol Win Rate:</span>{" "}
            <span className={`font-bold ${winRate >= 60 ? "text-emerald-400" : "text-amber-400"}`}>
              {winRate}%
            </span>
          </div>
        </div>
      </div>

      {/* Main Advisory Banner */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        
        {/* Active Memory Advisory */}
        <div className="lg:col-span-8 rounded-2xl bg-obsidian-800/60 p-4 border border-purple-500/20 flex items-start gap-3">
          <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <AlertCircle className="h-4 w-4" />
          </div>
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-purple-300 mb-1">
              Active Memory Advisory Injected into Committee
            </div>
            <p className="text-xs sm:text-sm text-slate-200 leading-relaxed font-medium">
              "{advisory}"
            </p>
            <div className="mt-2 text-[11px] font-mono font-semibold text-cyan-300">
              ⚡ Fiduciary Sizing Constraint: <span className="text-white">{adjustment}</span>
            </div>
          </div>
        </div>

        {/* Retrospective Summary */}
        <div className="lg:col-span-4 rounded-2xl bg-obsidian-800/60 p-4 border border-white/[0.06] flex flex-col justify-between">
          <div>
            <div className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <History className="h-3.5 w-3.5 text-purple-400" />
              <span>Previous Trade Outcome</span>
            </div>
            {history.length > 0 ? (
              <div className="space-y-1.5 text-xs font-mono">
                <div className="flex justify-between">
                  <span className="text-slate-400">Last Exit:</span>
                  <span className={history[0].pnl_pct >= 0 ? "text-emerald-400 font-bold" : "text-rose-400 font-bold"}>
                    {history[0].outcome} ({history[0].pnl_pct >= 0 ? `+${history[0].pnl_pct}%` : `${history[0].pnl_pct}%`})
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-400">Entry / Exit:</span>
                  <span className="text-white">${history[0].entry_price} / ${history[0].exit_price}</span>
                </div>
                <div className="text-[11px] text-slate-400 line-clamp-2 mt-1 italic">
                  "{history[0].post_mortem}"
                </div>
              </div>
            ) : (
              <p className="text-xs text-slate-400 italic">No prior closed trades on record.</p>
            )}
          </div>
        </div>

      </div>

    </div>
  );
};
