"use client";

import React, { useState } from "react";
import {
  Bot,
  Send,
  Sparkles,
  ChevronUp,
  ChevronDown,
  X,
  Loader2,
  Terminal as TermIcon,
} from "lucide-react";
import { api, CopilotMessage } from "@/lib/api";

interface CopilotTerminalProps {
  currentSymbol: string;
}

export const CopilotTerminal: React.FC<CopilotTerminalProps> = ({ currentSymbol }) => {
  const [isOpen, setIsOpen] = useState(false);
  const [inputVal, setInputVal] = useState("");
  const [messages, setMessages] = useState<CopilotMessage[]>([
    {
      role: "assistant",
      text: `Greetings. I am AlphaSwarm Sovereign's Quantitative AI Copilot. I have real-time visibility into our portfolio ledger, multi-agent dialectic debates, and 1,000-path Monte Carlo VaR models. Ask me anything about ${currentSymbol} or our fund exposure.`,
      timestamp: "Ready",
    },
  ]);
  const [isSending, setIsSending] = useState(false);

  const PROMPT_CHIPS = [
    `What is our current portfolio exposure?`,
    `Why did the committee issue a BUY on ${currentSymbol}?`,
    `Explain our 1:2 R:R dynamic ATR brackets.`,
    `What is the 95% Monte Carlo VaR downside risk?`,
  ];

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || inputVal;
    if (!query.trim() || isSending) return;

    const userMsg: CopilotMessage = {
      role: "user",
      text: query,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    if (!textToSend) setInputVal("");
    setIsSending(true);

    try {
      const res = await api.sendCopilotMessage(query, currentSymbol);
      const assistantMsg: CopilotMessage = {
        role: "assistant",
        text: res.reply || "Analysis complete.",
        timestamp: res.timestamp || new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
        suggested_actions: res.suggested_actions,
      };
      setMessages((prev) => [...prev, assistantMsg]);
    } catch (err: any) {
      setMessages((prev) => [
        ...prev,
        {
          role: "assistant",
          text: "Copilot synthesis error. Please ensure the backend server is reachable.",
          timestamp: "Error",
        },
      ]);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <div className="fixed bottom-4 right-4 z-40 max-w-lg w-[calc(100vw-2rem)] sm:w-[440px]">
      
      {/* Minimized Pill Toggle */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="w-full flex items-center justify-between rounded-2xl bg-gradient-to-r from-purple-600 via-indigo-600 to-cyan-500 p-0.5 shadow-neon-purple transition-all hover:scale-[1.02]"
        >
          <div className="flex w-full items-center justify-between rounded-[14px] bg-obsidian-950/90 px-4 py-3 backdrop-blur-md">
            <div className="flex items-center gap-2.5">
              <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-purple-500/20 text-purple-300 border border-purple-500/30">
                <Bot className="h-4 w-4 animate-pulse" />
              </div>
              <div className="text-left">
                <div className="text-xs font-black text-white flex items-center gap-1.5">
                  <span>AI Financial Copilot</span>
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
                </div>
                <div className="text-[10px] text-slate-400 font-mono">Ask portfolio state & trade rationales</div>
              </div>
            </div>
            <ChevronUp className="h-4 w-4 text-purple-400" />
          </div>
        </button>
      )}

      {/* Expanded Terminal Window */}
      {isOpen && (
        <div className="rounded-3xl border border-white/[0.12] bg-obsidian-950/95 shadow-2xl backdrop-blur-2xl overflow-hidden flex flex-col h-[520px] animate-in slide-in-from-bottom-5">
          
          {/* Header */}
          <div className="flex items-center justify-between border-b border-white/[0.08] px-4 py-3 bg-obsidian-900/60">
            <div className="flex items-center gap-2">
              <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-gradient-to-tr from-cyan-500 to-purple-600 text-white">
                <Bot className="h-4 w-4" />
              </div>
              <div>
                <span className="text-xs font-bold text-white">Quantitative AI Copilot</span>
                <span className="text-[10px] text-cyan-400 font-mono ml-2">● Online</span>
              </div>
            </div>

            <button
              onClick={() => setIsOpen(false)}
              className="rounded-lg p-1 text-slate-400 hover:bg-white/[0.05] hover:text-white"
            >
              <ChevronDown className="h-4 w-4" />
            </button>
          </div>

          {/* Prompt Chips */}
          <div className="p-3 border-b border-white/[0.06] bg-obsidian-900/30 overflow-x-auto flex gap-1.5 no-scrollbar">
            {PROMPT_CHIPS.map((chip, idx) => (
              <button
                key={idx}
                onClick={() => handleSend(chip)}
                className="shrink-0 rounded-lg bg-obsidian-800/80 border border-white/[0.06] px-2.5 py-1 text-[10px] text-slate-300 font-mono transition-all hover:border-cyan-500/40 hover:text-cyan-300"
              >
                {chip}
              </button>
            ))}
          </div>

          {/* Messages Log */}
          <div className="flex-1 overflow-y-auto p-4 space-y-3 font-sans">
            {messages.map((m, i) => (
              <div
                key={i}
                className={`flex flex-col ${m.role === "user" ? "items-end" : "items-start"}`}
              >
                <div
                  className={`max-w-[88%] rounded-2xl p-3 text-xs leading-relaxed ${
                    m.role === "user"
                      ? "bg-gradient-to-r from-cyan-600 to-blue-600 text-white font-medium shadow-sm"
                      : "bg-obsidian-850 border border-white/[0.08] text-slate-200"
                  }`}
                >
                  <p className="whitespace-pre-wrap">{m.text}</p>

                  {/* Suggested actions if any */}
                  {m.suggested_actions && (
                    <div className="mt-2 pt-2 border-t border-white/[0.06] flex flex-wrap gap-1">
                      {m.suggested_actions.map((act, aIdx) => (
                        <button
                          key={aIdx}
                          onClick={() => handleSend(act)}
                          className="rounded-md bg-purple-500/15 border border-purple-500/30 px-2 py-0.5 text-[9px] font-mono font-bold text-purple-300 hover:bg-purple-500/25"
                        >
                          → {act}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <span className="text-[9px] font-mono text-slate-500 mt-0.5 px-1">{m.timestamp}</span>
              </div>
            ))}

            {isSending && (
              <div className="flex items-center gap-2 text-xs text-purple-400 font-mono bg-obsidian-900/60 p-2.5 rounded-xl border border-purple-500/20 max-w-[75%]">
                <Loader2 className="h-3.5 w-3.5 animate-spin" />
                <span>Synthesizing portfolio intelligence...</span>
              </div>
            )}
          </div>

          {/* Input Box */}
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend();
            }}
            className="p-3 border-t border-white/[0.08] bg-obsidian-900/60 flex items-center gap-2"
          >
            <input
              type="text"
              placeholder={`Ask Copilot about ${currentSymbol}...`}
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              className="flex-1 rounded-xl border border-white/[0.1] bg-obsidian-800 px-3.5 py-2 text-xs text-white placeholder-slate-500 focus:border-cyan-500 focus:outline-none"
            />
            <button
              type="submit"
              disabled={isSending || !inputVal.trim()}
              className="flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 text-white shadow-neon-blue transition-all disabled:opacity-40"
            >
              <Send className="h-3.5 w-3.5" />
            </button>
          </form>

        </div>
      )}

    </div>
  );
};
