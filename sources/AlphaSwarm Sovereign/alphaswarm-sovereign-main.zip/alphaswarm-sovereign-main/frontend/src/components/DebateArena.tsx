"use client";

import React, { useState, useEffect } from "react";
import {
  Sparkles,
  MessageSquare,
  Award,
  ArrowUpRight,
  ArrowDownRight,
  PauseCircle,
  Shield,
  Eye,
  Radio,
  Loader2,
  Volume2,
  VolumeX,
  FileDown,
} from "lucide-react";
import { ConsensusDecision, RiskSentinelData, VisionData, api } from "@/lib/api";

interface DebateArenaProps {
  symbol: string;
  consensus: ConsensusDecision | null;
  riskSentinel: RiskSentinelData | null;
  vision: VisionData | null;
  isLoading: boolean;
  onOpenTradeModal: () => void;
}

export const DebateArena: React.FC<DebateArenaProps> = ({
  symbol,
  consensus,
  riskSentinel,
  vision,
  isLoading,
  onOpenTradeModal,
}) => {
  const [isStreaming, setIsStreaming] = useState(false);
  const [streamTranscript, setStreamTranscript] = useState<any[]>([]);
  const [activeSpeaker, setActiveSpeaker] = useState<string | null>(null);
  const [liveConfidence, setLiveConfidence] = useState<number>(consensus?.confidence_score ?? 50);
  const [isVoiceEnabled, setIsVoiceEnabled] = useState<boolean>(false);
  const [isDownloadingPdf, setIsDownloadingPdf] = useState<boolean>(false);

  // Sync initial consensus when symbol changes
  useEffect(() => {
    if (consensus?.debate_transcript) {
      setStreamTranscript(consensus.debate_transcript);
      setLiveConfidence(consensus.confidence_score);
    }
  }, [consensus]);

  // Clean speech synthesis on unmount
  useEffect(() => {
    return () => {
      if (typeof window !== "undefined" && "speechSynthesis" in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Multi-Agent Web Speech Synthesis Engine
  const speakTurn = (speaker: string, text: string) => {
    if (typeof window === "undefined" || !("speechSynthesis" in window) || !isVoiceEnabled) {
      return;
    }

    try {
      window.speechSynthesis.cancel();
      const utterance = new SpeechSynthesisUtterance(text);
      const isBull = speaker.toLowerCase().includes("bull");
      const isBear = speaker.toLowerCase().includes("bear");
      const isPM = speaker.toLowerCase().includes("portfolio") || speaker.toLowerCase().includes("consensus");

      if (isBull) {
        utterance.pitch = 1.15;
        utterance.rate = 1.05;
      } else if (isBear) {
        utterance.pitch = 0.82;
        utterance.rate = 0.92;
      } else if (isPM) {
        utterance.pitch = 1.0;
        utterance.rate = 0.98;
      }

      window.speechSynthesis.speak(utterance);
    } catch (err) {
      console.warn("Speech synthesis error:", err);
    }
  };

  // SSE Stream Trigger
  const handleStartSSEStream = () => {
    setIsStreaming(true);
    setStreamTranscript([]);
    setActiveSpeaker("Technical Scout");

    const eventSource = new EventSource(api.getStreamDebateUrl(symbol));

    eventSource.onmessage = (event) => {
      try {
        const data = JSON.parse(event.data);
        if (data.type === "scout") {
          setActiveSpeaker("Technical Scout");
        } else if (data.type === "turn") {
          setActiveSpeaker(data.speaker);
          setLiveConfidence(data.partial_confidence || 60);
          
          setStreamTranscript((prev) => [
            ...prev,
            {
              speaker: data.speaker,
              avatar: data.avatar,
              text: data.text,
            },
          ]);

          speakTurn(data.speaker, data.text);
        } else if (data.type === "consensus") {
          setActiveSpeaker("Portfolio Manager (Consensus)");
          setLiveConfidence(data.confidence_score);
        } else if (data.type === "done") {
          setIsStreaming(false);
          setActiveSpeaker(null);
          eventSource.close();
        }
      } catch (err) {
        console.error("SSE parse error:", err);
      }
    };

    eventSource.onerror = () => {
      setIsStreaming(false);
      setActiveSpeaker(null);
      eventSource.close();
    };
  };

  const toggleVoice = () => {
    if (isVoiceEnabled && typeof window !== "undefined" && "speechSynthesis" in window) {
      window.speechSynthesis.cancel();
    }
    setIsVoiceEnabled(!isVoiceEnabled);
  };

  const handleDownloadPdf = () => {
    setIsDownloadingPdf(true);
    const memoUrl = api.getDownloadMemoUrl(symbol);
    window.open(memoUrl, "_blank");
    setTimeout(() => setIsDownloadingPdf(false), 1500);
  };

  const action = consensus?.action ?? "HOLD";
  const confidence = isStreaming ? liveConfidence : (consensus?.confidence_score ?? 50);
  const transcript = streamTranscript.length > 0 ? streamTranscript : (consensus?.debate_transcript ?? []);
  const rationale = consensus?.rationale ?? [];
  const verdict = consensus?.summary_verdict ?? "Awaiting multi-agent consensus debate...";
  const isApproved = riskSentinel?.approved ?? false;

  const getActionColor = () => {
    switch (action) {
      case "BUY":
        return {
          bg: "bg-emerald-500/15",
          border: "border-emerald-500/40",
          text: "text-emerald-400",
          glow: "glow-emerald",
          bar: "bg-emerald-400",
        };
      case "SELL":
        return {
          bg: "bg-rose-500/15",
          border: "border-rose-500/40",
          text: "text-rose-400",
          glow: "glow-coral",
          bar: "bg-rose-400",
        };
      default:
        return {
          bg: "bg-amber-500/15",
          border: "border-amber-500/40",
          text: "text-amber-400",
          glow: "",
          bar: "bg-amber-400",
        };
    }
  };

  const colors = getActionColor();

  return (
    <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
      
      {/* Left 7 Cols: Multi-Agent Dialectic Transcript Feed */}
      <div className="glass-panel p-6 lg:col-span-7 flex flex-col justify-between">
        <div>
          <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/[0.08] pb-4 mb-4 gap-3">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-500/20 text-purple-400 border border-purple-500/30">
                <MessageSquare className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-base">Multi-Agent Debate Arena</h3>
                <p className="text-xs text-slate-400">Adversarial LLM Dialectic for {symbol}</p>
              </div>
            </div>

            {/* Action Buttons: Voice Toggle & SSE Stream Trigger */}
            <div className="flex items-center gap-2">
              
              {/* Voice Narration Toggle */}
              <button
                onClick={toggleVoice}
                className={`flex items-center gap-1.5 rounded-xl border px-3 py-1.5 text-xs font-bold transition-all ${
                  isVoiceEnabled
                    ? "bg-purple-500/20 text-purple-300 border-purple-500/40 glow-purple"
                    : "bg-obsidian-800 text-slate-400 border-white/[0.08] hover:text-white"
                }`}
                title="Toggle Web Speech Voice Synthesis"
              >
                {isVoiceEnabled ? (
                  <>
                    <Volume2 className="h-3.5 w-3.5 text-purple-400 animate-pulse" />
                    <span>Voice: ON</span>
                  </>
                ) : (
                  <>
                    <VolumeX className="h-3.5 w-3.5" />
                    <span>Voice: OFF</span>
                  </>
                )}
              </button>

              {/* Re-Stream SSE Button */}
              <button
                onClick={handleStartSSEStream}
                disabled={isStreaming}
                className="flex items-center gap-1.5 rounded-xl border border-cyan-500/30 bg-cyan-500/10 px-3 py-1.5 text-xs font-bold text-cyan-300 transition-all hover:bg-cyan-500/20 disabled:opacity-50"
              >
                {isStreaming ? (
                  <>
                    <Loader2 className="h-3.5 w-3.5 animate-spin text-cyan-400" />
                    <span>Streaming Debate...</span>
                  </>
                ) : (
                  <>
                    <Radio className="h-3.5 w-3.5 text-cyan-400" />
                    <span>Re-Stream SSE Debate</span>
                  </>
                )}
              </button>
            </div>
          </div>

          {/* Multimodal Vision Recognition Agent Banner */}
          {vision && (
            <div className="mb-4 rounded-xl border border-cyan-500/20 bg-cyan-950/20 p-3 flex items-start gap-2.5">
              <Eye className="h-4 w-4 text-cyan-400 mt-0.5 shrink-0" />
              <div className="text-xs">
                <span className="font-bold text-cyan-300 font-mono">Vision Agent Detected: </span>
                <span className="text-slate-200 font-semibold">{vision.primary_pattern}</span>
                <span className="text-slate-400"> ({vision.vision_confidence_pct}% Confidence)</span>
                <p className="text-[11px] text-slate-300 mt-0.5">{vision.visual_evidence_text}</p>
              </div>
            </div>
          )}

          {/* Active Speaking Indicator */}
          {isStreaming && activeSpeaker && (
            <div className="mb-3 flex items-center gap-2 text-xs font-mono text-cyan-400 animate-pulse">
              <span className="inline-block h-2 w-2 rounded-full bg-cyan-400" />
              <span>Active Turn: <strong className="text-white">{activeSpeaker}</strong> is synthesizing arguments...</span>
            </div>
          )}

          {/* Chat / Transcript Dialog Feed */}
          <div className="space-y-3 max-h-[380px] overflow-y-auto pr-2">
            {transcript.map((entry, idx) => {
              const isBull = entry.speaker.toLowerCase().includes("bull");
              const isBear = entry.speaker.toLowerCase().includes("bear");

              let badgeStyle = "bg-purple-500/15 text-purple-300 border-purple-500/30";
              let cardGlow = "border-purple-500/20";
              if (isBull) {
                badgeStyle = "bg-emerald-500/15 text-emerald-300 border-emerald-500/30";
                cardGlow = "border-emerald-500/20";
              } else if (isBear) {
                badgeStyle = "bg-rose-500/15 text-rose-300 border-rose-500/30";
                cardGlow = "border-rose-500/20";
              }

              return (
                <div
                  key={idx}
                  className={`rounded-2xl border ${cardGlow} bg-obsidian-800/60 p-4 backdrop-blur-md transition-all hover:bg-obsidian-800/90 animate-in fade-in slide-in-from-bottom-2`}
                >
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{entry.avatar}</span>
                      <span className={`rounded-full border px-2.5 py-0.5 text-xs font-bold ${badgeStyle}`}>
                        {entry.speaker}
                      </span>
                    </div>
                    <span className="text-[10px] font-mono text-slate-500">Step {idx + 1}</span>
                  </div>
                  <p className="text-xs sm:text-sm text-slate-300 leading-relaxed pl-1">
                    {entry.text}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Trade Rationale Bullets */}
        {rationale.length > 0 && (
          <div className="mt-4 pt-4 border-t border-white/[0.08]">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-2 flex items-center gap-1.5">
              <Sparkles className="h-3.5 w-3.5 text-cyan-400" />
              <span>Key Consensus Syntheses</span>
            </h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {rationale.map((rat, rIdx) => (
                <div key={rIdx} className="flex items-start gap-2 text-xs text-slate-300 bg-obsidian-800/40 p-2 rounded-xl border border-white/[0.04]">
                  <span className="text-cyan-400 font-bold mt-0.5">•</span>
                  <span>{rat}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Right 5 Cols: Consensus Hero Card, PDF Download & Autonomous Trigger */}
      <div className="glass-panel p-6 lg:col-span-5 flex flex-col justify-between">
        <div>
          
          <div className="flex items-center justify-between border-b border-white/[0.08] pb-4 mb-4">
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Award className="h-4 w-4" />
              </div>
              <div>
                <h3 className="font-extrabold text-white text-base">Consensus Verdict</h3>
                <p className="text-xs text-slate-400">Institutional Fiduciary Arbiter</p>
              </div>
            </div>

            {/* Download LP Memo PDF Button */}
            <button
              onClick={handleDownloadPdf}
              disabled={isDownloadingPdf}
              className="flex items-center gap-1 rounded-lg border border-white/[0.1] bg-obsidian-800 px-2.5 py-1 text-[11px] font-mono text-slate-300 transition-all hover:bg-white/[0.05] hover:text-white"
              title="Download Institutional LP Investment Memorandum (PDF)"
            >
              <FileDown className="h-3.5 w-3.5 text-cyan-400" />
              <span>LP Memo (PDF)</span>
            </button>
          </div>

          {/* Hero Action Badge Card */}
          <div className={`rounded-2xl border ${colors.border} ${colors.bg} ${colors.glow} p-6 text-center mb-6 transition-all`}>
            <div className="text-xs font-semibold uppercase tracking-widest text-slate-400 mb-1">
              Recommended Asset Action
            </div>
            
            <div className="flex items-center justify-center gap-3 my-2">
              {action === "BUY" && <ArrowUpRight className="h-9 w-9 text-emerald-400" />}
              {action === "SELL" && <ArrowDownRight className="h-9 w-9 text-rose-400" />}
              {action === "HOLD" && <PauseCircle className="h-9 w-9 text-amber-400" />}
              
              <span className={`text-4xl sm:text-5xl font-black tracking-tight ${colors.text}`}>
                {action}
              </span>
            </div>

            {/* Confidence Bar */}
            <div className="mt-4">
              <div className="flex justify-between text-xs font-mono font-semibold mb-1 text-slate-300">
                <span>Conviction Score</span>
                <span className={colors.text}>{confidence}%</span>
              </div>
              <div className="h-2.5 w-full overflow-hidden rounded-full bg-obsidian-950/80 border border-white/[0.08]">
                <div
                  className={`h-full ${colors.bar} transition-all duration-700`}
                  style={{ width: `${confidence}%` }}
                />
              </div>
            </div>

            <p className="mt-4 text-xs italic text-slate-300 bg-obsidian-900/60 p-3 rounded-xl border border-white/[0.06]">
              "{verdict}"
            </p>
          </div>

        </div>

        {/* One-Click Autonomous CTA Button */}
        <div>
          {isApproved ? (
            <button
              onClick={onOpenTradeModal}
              className="w-full relative group overflow-hidden rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 p-0.5 font-bold text-white shadow-neon-green transition-all hover:scale-[1.01]"
            >
              <div className="flex items-center justify-center gap-2 rounded-[10px] bg-obsidian-900/40 px-5 py-3.5 backdrop-blur-md transition-all group-hover:bg-transparent">
                <Shield className="h-5 w-5 text-emerald-300" />
                <span className="text-sm font-extrabold tracking-wide uppercase">
                  Execute Sentinel Bracket: {riskSentinel?.recommended_qty}x {symbol}
                </span>
              </div>
            </button>
          ) : (
            <div className="rounded-xl border border-white/[0.08] bg-obsidian-800/40 p-3 text-center text-xs text-slate-400">
              <div className="font-bold text-slate-300 mb-0.5">🔒 Execution Gated by Sentinel</div>
              <div>{riskSentinel?.rejection_reasons?.join(", ") || "Committee conditions pending validation"}</div>
            </div>
          )}
        </div>

      </div>

    </div>
  );
};
