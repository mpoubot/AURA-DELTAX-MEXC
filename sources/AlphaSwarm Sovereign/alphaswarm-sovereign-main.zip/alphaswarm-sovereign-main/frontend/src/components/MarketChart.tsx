"use client";

import React, { useState } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import { Activity, BarChart2, CheckCircle2, TrendingUp, Sliders } from "lucide-react";
import { MarketBar, MarketMetrics } from "@/lib/api";

interface MarketChartProps {
  symbol: string;
  metrics: MarketMetrics | null;
  bars: MarketBar[];
  isLoading: boolean;
}

export const MarketChart: React.FC<MarketChartProps> = ({
  symbol,
  metrics,
  bars,
  isLoading,
}) => {
  const [showSMA, setShowSMA] = useState(true);
  const [showBB, setShowBB] = useState(true);
  const [showVolume, setShowVolume] = useState(true);

  const price = metrics?.current_price ?? (bars.length ? bars[bars.length - 1].close : 128.5);
  const rsi = metrics?.rsi ?? 55;
  const quantScore = metrics?.quant_score ?? 0.65;
  const trend = metrics?.trend ?? "BULLISH";

  // Min / Max for chart Y domain scaling
  const closes = bars.map((b) => b.close);
  const minPrice = closes.length ? Math.min(...closes) * 0.98 : 100;
  const maxPrice = closes.length ? Math.max(...closes) * 1.02 : 150;

  return (
    <div className="glass-panel p-6">
      {/* Header & Metric Overview */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between border-b border-white/[0.08] pb-4 mb-4">
        
        {/* Ticker & Price */}
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-br from-cyan-500/20 to-blue-600/20 border border-cyan-500/30 text-cyan-400 font-extrabold text-lg">
            {symbol.slice(0, 3)}
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-2xl font-black tracking-tight text-white">{symbol}</h2>
              <span className="rounded-md bg-emerald-500/10 border border-emerald-500/30 px-2 py-0.5 text-xs font-bold text-emerald-400">
                {trend.replace("_", " ")}
              </span>
            </div>
            <div className="flex items-baseline gap-2 mt-0.5">
              <span className="font-mono text-2xl font-black text-white">
                ${price.toFixed(2)}
              </span>
              <span className="text-xs font-mono text-slate-400">USD (Paper Feed)</span>
            </div>
          </div>
        </div>

        {/* Quant Badges & Filter Toggles */}
        <div className="flex flex-wrap items-center gap-2">
          
          {/* RSI Gauge */}
          <div className="flex items-center gap-1.5 rounded-xl bg-obsidian-800/90 border border-white/[0.08] px-3 py-1.5 text-xs">
            <span className="text-slate-400">RSI(14):</span>
            <span
              className={`font-mono font-bold ${
                rsi > 70 ? "text-rose-400" : rsi < 30 ? "text-cyan-400" : "text-emerald-400"
              }`}
            >
              {rsi.toFixed(1)}
            </span>
          </div>

          {/* Quant Momentum Score */}
          <div className="flex items-center gap-1.5 rounded-xl bg-obsidian-800/90 border border-white/[0.08] px-3 py-1.5 text-xs">
            <span className="text-slate-400">Quant Conviction:</span>
            <span
              className={`font-mono font-bold ${
                quantScore >= 0.3 ? "text-emerald-400" : quantScore <= -0.2 ? "text-rose-400" : "text-amber-400"
              }`}
            >
              {quantScore > 0 ? `+${quantScore.toFixed(2)}` : quantScore.toFixed(2)}
            </span>
          </div>

          {/* Indicator Toggles */}
          <div className="flex items-center gap-1 bg-obsidian-800/60 p-1 rounded-xl border border-white/[0.06]">
            <button
              onClick={() => setShowSMA(!showSMA)}
              className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition-all ${
                showSMA ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40" : "text-slate-400 hover:text-white"
              }`}
            >
              SMA 20/50
            </button>
            <button
              onClick={() => setShowBB(!showBB)}
              className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition-all ${
                showBB ? "bg-purple-500/20 text-purple-300 border border-purple-500/40" : "text-slate-400 hover:text-white"
              }`}
            >
              Bollinger
            </button>
            <button
              onClick={() => setShowVolume(!showVolume)}
              className={`rounded-lg px-2.5 py-1 text-xs font-semibold transition-all ${
                showVolume ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40" : "text-slate-400 hover:text-white"
              }`}
            >
              Volume
            </button>
          </div>

        </div>

      </div>

      {/* Chart Canvas */}
      <div className="h-[360px] w-full relative">
        {isLoading && (
          <div className="absolute inset-0 z-10 flex items-center justify-center bg-obsidian-900/60 backdrop-blur-sm rounded-xl">
            <div className="flex items-center gap-2 text-cyan-400 font-medium text-sm">
              <Activity className="h-5 w-5 animate-spin" />
              <span>Fetching High-Resolution Market Feed...</span>
            </div>
          </div>
        )}

        {bars.length > 0 ? (
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={bars} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="priceGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#00D2FF" stopOpacity={0.35} />
                  <stop offset="95%" stopColor="#00D2FF" stopOpacity={0.0} />
                </linearGradient>
                <linearGradient id="bbGlow" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor="#8B5CF6" stopOpacity={0.12} />
                  <stop offset="100%" stopColor="#8B5CF6" stopOpacity={0.02} />
                </linearGradient>
              </defs>

              <CartesianGrid strokeDasharray="3 3" stroke="#ffffff0a" vertical={false} />
              
              <XAxis
                dataKey="date"
                stroke="#64748B"
                fontSize={11}
                tickLine={false}
                axisLine={{ stroke: "#ffffff10" }}
                dy={6}
              />
              
              <YAxis
                domain={[minPrice, maxPrice]}
                stroke="#64748B"
                fontSize={11}
                tickLine={false}
                axisLine={false}
                tickFormatter={(v) => `$${v.toFixed(0)}`}
                orientation="left"
              />

              <Tooltip
                content={({ active, payload }) => {
                  if (active && payload && payload.length) {
                    const data = payload[0].payload as MarketBar;
                    return (
                      <div className="rounded-xl border border-white/[0.12] bg-obsidian-900/95 p-3 shadow-2xl backdrop-blur-xl text-xs font-mono">
                        <div className="text-slate-400 mb-1">{data.date}</div>
                        <div className="text-white font-bold text-sm">
                          Close: <span className="text-cyan-400">${data.close.toFixed(2)}</span>
                        </div>
                        <div className="grid grid-cols-2 gap-x-3 gap-y-0.5 mt-1.5 text-[11px] text-slate-300">
                          <div>High: ${data.high.toFixed(2)}</div>
                          <div>Low: ${data.low.toFixed(2)}</div>
                          {data.sma20 && <div className="text-cyan-300">SMA20: ${data.sma20.toFixed(2)}</div>}
                          {data.sma50 && <div className="text-amber-300">SMA50: ${data.sma50.toFixed(2)}</div>}
                          {data.bb_upper && <div className="text-purple-300">BB-Up: ${data.bb_upper.toFixed(2)}</div>}
                          {data.bb_lower && <div className="text-purple-300">BB-Low: ${data.bb_lower.toFixed(2)}</div>}
                        </div>
                      </div>
                    );
                  }
                  return null;
                }}
              />

              {/* Volume Bars (rendered in background) */}
              {showVolume && (
                <Bar
                  dataKey="volume"
                  fill="#ffffff08"
                  radius={[4, 4, 0, 0]}
                  yAxisId={0}
                />
              )}

              {/* Bollinger Bands */}
              {showBB && (
                <>
                  <Line
                    type="monotone"
                    dataKey="bb_upper"
                    stroke="#8B5CF6"
                    strokeWidth={1}
                    strokeDasharray="4 4"
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="bb_lower"
                    stroke="#8B5CF6"
                    strokeWidth={1}
                    strokeDasharray="4 4"
                    dot={false}
                  />
                </>
              )}

              {/* SMAs */}
              {showSMA && (
                <>
                  <Line
                    type="monotone"
                    dataKey="sma20"
                    stroke="#00D2FF"
                    strokeWidth={1.5}
                    dot={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="sma50"
                    stroke="#F59E0B"
                    strokeWidth={1.5}
                    dot={false}
                  />
                </>
              )}

              {/* Main Price Area */}
              <Area
                type="monotone"
                dataKey="close"
                stroke="#00F59B"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#priceGlow)"
              />
            </ComposedChart>
          </ResponsiveContainer>
        ) : (
          <div className="flex h-full items-center justify-center text-slate-500 text-sm">
            No chart bars loaded.
          </div>
        )}
      </div>

    </div>
  );
};
