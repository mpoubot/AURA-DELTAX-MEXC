"use client";

import React, { useState } from "react";
import {
  ShieldCheck,
  ShieldAlert,
  CheckCircle2,
  XCircle,
  Calculator,
  LineChart,
  Percent,
  TrendingDown,
  Activity,
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid,
} from "recharts";
import { RiskSentinelData } from "@/lib/api";

interface RiskSentinelPanelProps {
  symbol: string;
  riskData: RiskSentinelData | null;
}

export const RiskSentinelPanel: React.FC<RiskSentinelPanelProps> = ({ symbol, riskData }) => {
  const [activeTab, setActiveTab] = useState<"compliance" | "monte_carlo">("compliance");

  const checklist = riskData?.checklist ?? [];
  const approved = riskData?.approved ?? false;
  const mc = riskData?.monte_carlo;
  const distCurve = mc?.distribution_curve ?? [];

  return (
    <div className="glass-panel p-6">
      
      {/* Header with Switcher Tabs */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/[0.08] pb-4 mb-6 gap-3">
        <div className="flex items-center gap-3">
          <div className={`flex h-10 w-10 items-center justify-center rounded-xl border ${
            approved
              ? "bg-emerald-500/20 text-emerald-400 border-emerald-500/30"
              : "bg-rose-500/20 text-rose-400 border-rose-500/30"
          }`}>
            {approved ? <ShieldCheck className="h-5 w-5" /> : <ShieldAlert className="h-5 w-5" />}
          </div>
          <div>
            <h3 className="text-lg font-extrabold text-white">Institutional Risk Sentinel</h3>
            <p className="text-xs text-slate-400">Wall Street Fiduciary Guardrails & 1,000-Path Monte Carlo VaR</p>
          </div>
        </div>

        {/* Tab Selector */}
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-xl bg-obsidian-800/80 p-1 border border-white/[0.06]">
            <button
              onClick={() => setActiveTab("compliance")}
              className={`rounded-lg px-3 py-1 text-xs font-semibold transition-all ${
                activeTab === "compliance"
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              Fiduciary Checklist
            </button>
            <button
              onClick={() => setActiveTab("monte_carlo")}
              className={`rounded-lg px-3 py-1 text-xs font-semibold transition-all ${
                activeTab === "monte_carlo"
                  ? "bg-purple-500/20 text-purple-300 border border-purple-500/40"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              1,000-Path Monte Carlo VaR
            </button>
          </div>

          <span className={`hidden sm:inline-block rounded-full border px-3 py-1 text-xs font-bold uppercase tracking-wider ${
            approved
              ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/30 glow-emerald"
              : "bg-rose-500/10 text-rose-400 border-rose-500/30"
          }`}>
            {approved ? "SENTINEL PASSED" : "TRADE REJECTED"}
          </span>
        </div>
      </div>

      {/* Tab 1: Fiduciary Compliance & Sizing Spec */}
      {activeTab === "compliance" && (
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-12">
          
          {/* Left 7 Cols: Compliance Checklist */}
          <div className="space-y-3 lg:col-span-7">
            <h4 className="text-xs font-bold uppercase tracking-wider text-slate-400 mb-1">
              Automated Fiduciary Rules
            </h4>

            {checklist.map((item, idx) => (
              <div
                key={idx}
                className={`flex items-center justify-between p-3.5 rounded-xl border transition-all ${
                  item.passed
                    ? "bg-obsidian-800/40 border-emerald-500/20 text-slate-200"
                    : "bg-rose-950/20 border-rose-500/30 text-rose-200"
                }`}
              >
                <div className="flex items-start gap-3">
                  <div className="mt-0.5">
                    {item.passed ? (
                      <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                    ) : (
                      <XCircle className="h-4 w-4 text-rose-400" />
                    )}
                  </div>
                  <div>
                    <div className="font-semibold text-xs sm:text-sm text-white">{item.check}</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">{item.detail}</div>
                  </div>
                </div>

                <span className={`text-xs font-bold font-mono px-2 py-0.5 rounded-md ${
                  item.passed ? "text-emerald-400 bg-emerald-500/10" : "text-rose-400 bg-rose-500/10"
                }`}>
                  {item.passed ? "PASS" : "FAIL"}
                </span>
              </div>
            ))}
          </div>

          {/* Right 5 Cols: Mathematical Bracket & Position Sizing Spec */}
          <div className="lg:col-span-5 rounded-2xl bg-obsidian-800/60 p-5 border border-white/[0.08] backdrop-blur-md">
            <div className="flex items-center gap-2 mb-4">
              <Calculator className="h-4 w-4 text-cyan-400" />
              <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                Mathematical Position Sizing
              </h4>
            </div>

            <div className="space-y-3 text-xs font-mono">
              
              <div className="flex justify-between items-center py-1 border-b border-white/[0.04]">
                <span className="text-slate-400">Target Size:</span>
                <span className="font-bold text-cyan-300 text-sm">{riskData?.recommended_qty ?? 0} shares</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-white/[0.04]">
                <span className="text-slate-400">Entry Reference:</span>
                <span className="font-bold text-white">${riskData?.current_price?.toFixed(2) ?? "0.00"}</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-white/[0.04]">
                <span className="text-slate-400">Stop-Loss (1.5x ATR):</span>
                <span className="font-bold text-rose-400">${riskData?.stop_loss?.toFixed(2) ?? "0.00"}</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-white/[0.04]">
                <span className="text-slate-400">Take-Profit (3.0x ATR):</span>
                <span className="font-bold text-emerald-400">${riskData?.take_profit?.toFixed(2) ?? "0.00"}</span>
              </div>

              <div className="flex justify-between items-center py-1 border-b border-white/[0.04]">
                <span className="text-slate-400">Calculated R:R Ratio:</span>
                <span className="font-bold text-purple-300">1 : {riskData?.risk_reward_ratio?.toFixed(2) ?? "2.00"}</span>
              </div>

              <div className="pt-2 flex justify-between items-center">
                <span className="text-slate-400">Max Dollar Risk (2%):</span>
                <span className="font-bold text-rose-400">${riskData?.potential_max_loss?.toLocaleString() ?? "0.00"}</span>
              </div>

              <div className="flex justify-between items-center">
                <span className="text-slate-400">Projected Upside:</span>
                <span className="font-bold text-emerald-400">${riskData?.potential_max_gain?.toLocaleString() ?? "0.00"}</span>
              </div>

            </div>
          </div>

        </div>
      )}

      {/* Tab 2: Monte Carlo Simulation & 95% VaR Visualizer */}
      {activeTab === "monte_carlo" && (
        <div className="space-y-6">
          
          {/* Top 3 Metric Cards */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            
            <div className="rounded-2xl bg-obsidian-800/80 p-4 border border-purple-500/30">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                <span>95% Value at Risk (30D VaR)</span>
                <Percent className="h-4 w-4 text-purple-400" />
              </div>
              <div className="font-mono text-2xl font-black text-purple-300 mt-2">
                {mc?.var_95_pct ?? 4.85}% <span className="text-xs font-sans text-slate-400">(${mc?.var_95_dollar ?? 6.25}/sh)</span>
              </div>
              <p className="text-[11px] text-slate-400 mt-1">95% statistical confidence downside floor</p>
            </div>

            <div className="rounded-2xl bg-obsidian-800/80 p-4 border border-rose-500/30">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                <span>Max Projected Drawdown</span>
                <TrendingDown className="h-4 w-4 text-rose-400" />
              </div>
              <div className="font-mono text-2xl font-black text-rose-400 mt-2">
                -{mc?.max_projected_drawdown_pct ?? 8.40}%
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Worst-case path deviation over 1,000 runs</p>
            </div>

            <div className="rounded-2xl bg-obsidian-800/80 p-4 border border-emerald-500/30">
              <div className="text-xs font-semibold uppercase tracking-wider text-slate-400 flex items-center justify-between">
                <span>Monte Carlo Win Probability</span>
                <Activity className="h-4 w-4 text-emerald-400" />
              </div>
              <div className="font-mono text-2xl font-black text-emerald-400 mt-2">
                {mc?.win_probability_pct ?? 68.5}%
              </div>
              <p className="text-[11px] text-slate-400 mt-1">Terminal price &gt; entry price probability</p>
            </div>

          </div>

          {/* Monte Carlo Terminal Price Distribution Bell Curve */}
          <div className="rounded-2xl bg-obsidian-800/60 p-4 border border-white/[0.06]">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <LineChart className="h-4 w-4 text-cyan-400" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-slate-200">
                  1,000-Path Terminal Price Probability Density (Geometric Brownian Motion)
                </h4>
              </div>
              <span className="text-xs font-mono text-cyan-400">
                Median Expected: ${mc?.expected_median_price ?? riskData?.current_price ?? 130}
              </span>
            </div>

            <div className="h-56 w-full">
              {distCurve.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={distCurve} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <defs>
                      <linearGradient id="mcGlow" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor="#8B5CF6" stopOpacity={0.4} />
                        <stop offset="95%" stopColor="#8B5CF6" stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" stroke="#ffffff0a" vertical={false} />
                    <XAxis
                      dataKey="label"
                      stroke="#64748B"
                      fontSize={10}
                      tickLine={false}
                      axisLine={{ stroke: "#ffffff10" }}
                    />
                    <YAxis
                      stroke="#64748B"
                      fontSize={10}
                      tickLine={false}
                      axisLine={false}
                    />
                    <Tooltip
                      content={({ active, payload }) => {
                        if (active && payload && payload.length) {
                          const data = payload[0].payload;
                          return (
                            <div className="rounded-xl border border-white/[0.12] bg-obsidian-900/95 p-2.5 text-xs font-mono">
                              <div className="text-slate-400">Price Bin: <span className="text-white font-bold">{data.label}</span></div>
                              <div className="text-purple-300 font-bold">Simulations: {data.density} paths</div>
                            </div>
                          );
                        }
                        return null;
                      }}
                    />
                    <Area
                      type="monotone"
                      dataKey="density"
                      stroke="#8B5CF6"
                      strokeWidth={2}
                      fillOpacity={1}
                      fill="url(#mcGlow)"
                    />
                  </AreaChart>
                </ResponsiveContainer>
              ) : (
                <div className="flex h-full items-center justify-center text-xs text-slate-500">
                  Calculating Monte Carlo distribution paths...
                </div>
              )}
            </div>
          </div>

        </div>
      )}

    </div>
  );
};
