"use client";

import React, { useState } from "react";
import { X, ShieldCheck, CheckCircle2, AlertTriangle, Send, Loader2 } from "lucide-react";
import confetti from "canvas-confetti";
import { api, RiskSentinelData } from "@/lib/api";

interface TradeModalProps {
  isOpen: boolean;
  onClose: () => void;
  symbol: string;
  riskData: RiskSentinelData | null;
  onSuccess: () => void;
}

export const TradeModal: React.FC<TradeModalProps> = ({
  isOpen,
  onClose,
  symbol,
  riskData,
  onSuccess,
}) => {
  const [qty, setQty] = useState<number>(riskData?.recommended_qty || 1);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [successMsg, setSuccessMsg] = useState<string | null>(null);

  if (!isOpen) return null;

  const currentPrice = riskData?.current_price || 100;
  const stopLoss = riskData?.stop_loss || currentPrice * 0.98;
  const takeProfit = riskData?.take_profit || currentPrice * 1.04;
  const totalValue = (qty * currentPrice).toFixed(2);

  const handleExecute = async () => {
    setIsSubmitting(true);
    setErrorMsg(null);
    try {
      const payload = {
        symbol,
        qty: Number(qty),
        take_profit: Number(takeProfit),
        stop_loss: Number(stopLoss),
      };
      console.log("Submitting order payload to /api/execute:", payload);

      const res = await api.executeTrade(payload);
      console.log("Order response from backend:", res);

      if (res && (res.success || res.status === "success")) {
        const msg = res.message || res.data?.message || "Bracket Order executed successfully!";
        setSuccessMsg(msg);
        confetti({
          particleCount: 80,
          spread: 70,
          origin: { y: 0.6 },
          colors: ["#00F59B", "#00D2FF", "#8B5CF6"],
        });
        setTimeout(() => {
          onSuccess();
          onClose();
        }, 2200);
      } else {
        setErrorMsg(res?.message || "Exchange rejected order.");
      }
    } catch (err: any) {
      console.error("Execute trade error details:", err);
      const backendError = err?.response?.data?.message || err?.response?.data?.detail || err?.message || "Network Error contacting backend on port 8000.";
      setErrorMsg(backendError);
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xl p-4 animate-in fade-in">
      <div className="relative w-full max-w-lg rounded-3xl border border-white/[0.12] bg-obsidian-900 p-6 shadow-2xl">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-xl p-1.5 text-slate-400 hover:bg-white/[0.05] hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-emerald-500 to-cyan-500 text-obsidian-950 font-black text-xl shadow-neon-green">
            ⚡
          </div>
          <div>
            <h3 className="text-xl font-black text-white">Execute Sentinel Bracket Order</h3>
            <p className="text-xs text-slate-400">Autonomous Alpaca Paper Trading Gateway</p>
          </div>
        </div>

        {/* Success State */}
        {successMsg ? (
          <div className="rounded-2xl border border-emerald-500/30 bg-emerald-500/10 p-6 text-center">
            <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-400 mb-3 animate-bounce" />
            <div className="text-lg font-bold text-emerald-300 mb-1">Bracket Order Filled</div>
            <p className="text-xs text-slate-300 font-mono">{successMsg}</p>
          </div>
        ) : (
          <div className="space-y-4">
            
            {/* Parameters Breakdown */}
            <div className="rounded-2xl bg-obsidian-800/80 p-4 border border-white/[0.06] space-y-2 text-xs font-mono">
              <div className="flex justify-between">
                <span className="text-slate-400">Asset Symbol:</span>
                <span className="font-bold text-white text-sm">{symbol}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Order Side & Type:</span>
                <span className="font-bold text-emerald-400">BUY (MARKET BRACKET)</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Reference Price:</span>
                <span className="text-white">${currentPrice.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Dynamic Stop-Loss:</span>
                <span className="font-bold text-rose-400">${stopLoss.toFixed(2)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-400">Take-Profit Target:</span>
                <span className="font-bold text-emerald-400">${takeProfit.toFixed(2)}</span>
              </div>
              <div className="flex justify-between pt-2 border-t border-white/[0.04]">
                <span className="text-slate-400">Total Position Value:</span>
                <span className="font-bold text-cyan-300 text-sm">${totalValue}</span>
              </div>
            </div>

            {/* Qty Adjustment */}
            <div className="space-y-1">
              <label className="text-xs font-bold uppercase tracking-wider text-slate-400">
                Number of Shares
              </label>
              <div className="flex items-center gap-3">
                <input
                  type="number"
                  min={1}
                  value={qty}
                  onChange={(e) => setQty(Math.max(1, parseInt(e.target.value) || 1))}
                  className="w-full rounded-xl border border-white/[0.1] bg-obsidian-800 px-4 py-2.5 font-mono text-sm text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>
            </div>

            {/* Error message */}
            {errorMsg && (
              <div className="rounded-xl border border-rose-500/30 bg-rose-500/10 p-3 text-xs text-rose-300">
                {errorMsg}
              </div>
            )}

            {/* Action CTA */}
            <div className="pt-2">
              <button
                onClick={handleExecute}
                disabled={isSubmitting}
                className="w-full rounded-xl bg-gradient-to-r from-emerald-500 to-cyan-500 py-3.5 text-center text-sm font-extrabold text-obsidian-950 shadow-neon-green transition-all hover:opacity-95 disabled:opacity-50 flex items-center justify-center gap-2"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin" />
                    <span>Transmitting to Alpaca API...</span>
                  </>
                ) : (
                  <>
                    <Send className="h-4 w-4" />
                    <span>Confirm & Execute Live Paper Order</span>
                  </>
                )}
              </button>
            </div>

          </div>
        )}

      </div>
    </div>
  );
};
