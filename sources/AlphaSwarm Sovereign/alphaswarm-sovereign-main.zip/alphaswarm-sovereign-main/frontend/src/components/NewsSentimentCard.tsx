"use client";

import React from "react";
import { Newspaper, TrendingUp, TrendingDown, AlertOctagon, ExternalLink, Globe } from "lucide-react";
import { NewsSentimentData } from "@/lib/api";

interface NewsSentimentCardProps {
  news: NewsSentimentData | null;
  symbol: string;
}

export const NewsSentimentCard: React.FC<NewsSentimentCardProps> = ({ news, symbol }) => {
  const score = news?.sentiment_score ?? 0.65;
  const bias = news?.macro_bias ?? "BULLISH";
  const headlines = news?.top_headlines ?? [];
  const criticalVeto = news?.critical_veto ?? false;

  const getBiasColor = () => {
    switch (bias) {
      case "BULLISH":
        return {
          bg: "bg-emerald-500/10",
          border: "border-emerald-500/30",
          text: "text-emerald-400",
          badge: "bg-emerald-500/20 text-emerald-300",
        };
      case "BEARISH":
        return {
          bg: "bg-rose-500/10",
          border: "border-rose-500/30",
          text: "text-rose-400",
          badge: "bg-rose-500/20 text-rose-300",
        };
      default:
        return {
          bg: "bg-amber-500/10",
          border: "border-amber-500/30",
          text: "text-amber-400",
          badge: "bg-amber-500/20 text-amber-300",
        };
    }
  };

  const colors = getBiasColor();

  return (
    <div className="glass-panel p-6 border-cyan-500/20 bg-gradient-to-br from-obsidian-900 via-obsidian-900 to-cyan-950/20">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-white/[0.08] pb-4 mb-4 gap-3">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-500/20 text-cyan-400 border border-cyan-500/30 shadow-neon-blue">
            <Newspaper className="h-5 w-5" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h3 className="font-extrabold text-white text-base">Real-Time Macro & News Sentiment</h3>
              <span className="rounded-full bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 text-[10px] font-bold text-cyan-300 font-mono">
                NLP Market Intelligence
              </span>
            </div>
            <p className="text-xs text-slate-400">Institutional Catalyst & Headline Stream for {symbol}</p>
          </div>
        </div>

        {/* Sentiment Index Meter */}
        <div className="flex items-center gap-3">
          <div className={`rounded-xl border ${colors.border} ${colors.bg} px-3 py-1.5 flex items-center gap-2`}>
            <span className="text-xs font-mono text-slate-400">Macro Index:</span>
            <span className={`font-mono text-sm font-black ${colors.text}`}>
              {score > 0 ? `+${score.toFixed(2)}` : score.toFixed(2)}
            </span>
            <span className={`rounded-md px-1.5 py-0.5 text-[10px] font-bold uppercase ${colors.badge}`}>
              {bias}
            </span>
          </div>
        </div>
      </div>

      {/* Critical VETO Alert if sentiment is ultra-bearish */}
      {criticalVeto && (
        <div className="mb-4 rounded-xl border border-rose-500/40 bg-rose-950/30 p-3 flex items-center gap-2.5 text-rose-300 text-xs">
          <AlertOctagon className="h-4 w-4 shrink-0 text-rose-400 animate-pulse" />
          <span className="font-bold">Macro VETO Active:</span>
          <span>{news?.veto_reason || "Severe negative news catalysts detected. Trade execution gated by Sentinel."}</span>
        </div>
      )}

      {/* Headline Stream List */}
      <div className="space-y-2.5 max-h-56 overflow-y-auto pr-1">
        {headlines.map((item, idx) => {
          const isBull = item.sentiment === "BULLISH";
          const isBear = item.sentiment === "BEARISH";
          return (
            <div
              key={idx}
              className="rounded-xl border border-white/[0.06] bg-obsidian-800/50 p-3 hover:bg-obsidian-800/80 transition-all flex flex-col sm:flex-row sm:items-center justify-between gap-2"
            >
              <div className="space-y-1">
                <div className="text-xs sm:text-sm font-semibold text-slate-100 leading-snug">
                  {item.headline}
                </div>
                <div className="flex items-center gap-2 text-[11px] text-slate-400 font-mono">
                  <span className="text-cyan-400 font-medium">{item.source}</span>
                  <span>•</span>
                  <span>{item.published_at}</span>
                  <span>•</span>
                  <span className="text-slate-500">Impact: {item.impact}</span>
                </div>
              </div>

              <div className="shrink-0 flex items-center gap-1.5 self-start sm:self-center">
                <span
                  className={`rounded-md px-2 py-0.5 text-[10px] font-bold font-mono ${
                    isBull
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/30"
                      : isBear
                      ? "bg-rose-500/20 text-rose-300 border border-rose-500/30"
                      : "bg-amber-500/20 text-amber-300 border border-amber-500/30"
                  }`}
                >
                  {item.sentiment} ({item.score > 0 ? `+${item.score}` : item.score})
                </span>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
