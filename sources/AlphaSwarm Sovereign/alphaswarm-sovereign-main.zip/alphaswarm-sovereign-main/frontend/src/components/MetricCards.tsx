"use client";

import React from "react";
import { TrendingUp, Wallet, ShieldAlert, Layers } from "lucide-react";
import { AccountData } from "@/lib/api";

interface MetricCardsProps {
  account: AccountData | null;
  positionCount: number;
}

export const MetricCards: React.FC<MetricCardsProps> = ({ account, positionCount }) => {
  const equity = account?.equity ?? 100000;
  const cash = account?.cash ?? 95400;
  const buyingPower = account?.buying_power ?? 190800;

  return (
    <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
      
      {/* 1. Portfolio Equity */}
      <div className="glass-panel p-5 relative overflow-hidden group hover:border-cyan-500/40">
        <div className="absolute top-0 right-0 h-24 w-24 bg-cyan-500/10 rounded-full blur-2xl group-hover:bg-cyan-500/20 transition-all" />
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Portfolio Equity
          </span>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            <TrendingUp className="h-4 w-4" />
          </div>
        </div>
        <div className="font-mono text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          ${equity.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-xs text-emerald-400 font-medium">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-400 animate-pulse" />
          <span>Real-time Alpaca Paper Ledger</span>
        </div>
      </div>

      {/* 2. Settled Cash */}
      <div className="glass-panel p-5 relative overflow-hidden group hover:border-emerald-500/40">
        <div className="absolute top-0 right-0 h-24 w-24 bg-emerald-500/10 rounded-full blur-2xl group-hover:bg-emerald-500/20 transition-all" />
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Settled Capital
          </span>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            <Wallet className="h-4 w-4" />
          </div>
        </div>
        <div className="font-mono text-2xl sm:text-3xl font-extrabold text-white tracking-tight">
          ${cash.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-xs text-slate-400 font-medium">
          <span>Allocatable Reserves ({( (cash / (equity || 1)) * 100).toFixed(1)}%)</span>
        </div>
      </div>

      {/* 3. Buying Power */}
      <div className="glass-panel p-5 relative overflow-hidden group hover:border-purple-500/40">
        <div className="absolute top-0 right-0 h-24 w-24 bg-purple-500/10 rounded-full blur-2xl group-hover:bg-purple-500/20 transition-all" />
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Buying Power
          </span>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-purple-500/10 text-purple-400 border border-purple-500/20">
            <Layers className="h-4 w-4" />
          </div>
        </div>
        <div className="font-mono text-2xl sm:text-3xl font-extrabold text-purple-300 tracking-tight">
          ${buyingPower.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-xs text-purple-400 font-medium">
          <span>2.0x Dynamic Intraday Margin</span>
        </div>
      </div>

      {/* 4. Active Holdings & Sentinel */}
      <div className="glass-panel p-5 relative overflow-hidden group hover:border-gold-neon/40">
        <div className="absolute top-0 right-0 h-24 w-24 bg-amber-500/10 rounded-full blur-2xl group-hover:bg-amber-500/20 transition-all" />
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-semibold uppercase tracking-wider text-slate-400">
            Active Holdings
          </span>
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-amber-500/10 text-amber-400 border border-amber-500/20">
            <ShieldAlert className="h-4 w-4" />
          </div>
        </div>
        <div className="font-mono text-2xl sm:text-3xl font-extrabold text-white tracking-tight flex items-baseline gap-2">
          <span>{positionCount}</span>
          <span className="text-sm font-sans font-normal text-slate-400">Positions</span>
        </div>
        <div className="mt-2 flex items-center gap-1.5 text-xs text-amber-400 font-medium">
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-amber-400" />
          <span>Fiduciary Circuit Protected</span>
        </div>
      </div>

    </div>
  );
};
