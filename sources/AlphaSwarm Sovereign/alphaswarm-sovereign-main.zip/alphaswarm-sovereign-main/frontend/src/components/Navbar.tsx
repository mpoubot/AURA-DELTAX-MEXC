"use client";

import React, { useState } from "react";
import { Zap, ShieldCheck, RefreshCw, Search, Lock, ShieldAlert } from "lucide-react";

interface NavbarProps {
  currentSymbol: string;
  onSelectSymbol: (sym: string) => void;
  onRefresh: () => void;
  onOpenVault: () => void;
  isLoading: boolean;
  paperMode?: boolean;
}

const PRESETS = ["NVDA", "AAPL", "TSLA", "SPY", "MSFT", "AMZN", "META", "GOOGL"];

export const Navbar: React.FC<NavbarProps> = ({
  currentSymbol,
  onSelectSymbol,
  onRefresh,
  onOpenVault,
  isLoading,
  paperMode = true,
}) => {
  const [inputVal, setInputVal] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputVal.trim()) {
      onSelectSymbol(inputVal.trim().toUpperCase());
      setInputVal("");
    }
  };

  return (
    <header className="sticky top-0 z-40 border-b border-white/[0.08] bg-obsidian-900/80 backdrop-blur-xl">
      <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
        
        {/* Brand Logo & Name */}
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-tr from-cyan-500 to-purple-600 shadow-neon-blue">
            <Zap className="h-5 w-5 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <span className="font-extrabold tracking-tight text-white sm:text-lg">
                ALPHASWARM <span className="bg-gradient-to-r from-cyan-400 to-emerald-400 bg-clip-text text-transparent">SOVEREIGN</span>
              </span>
              <span className="hidden rounded-full border border-purple-500/30 bg-purple-500/10 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-purple-300 sm:inline-block font-mono">
                SaaS v3.0
              </span>
            </div>
            <div className="flex items-center gap-2 text-[11px] text-slate-400">
              <span className="inline-block h-1.5 w-1.5 rounded-full bg-emerald-400 animate-ping" />
              <span>Multi-Tenant Vault</span>
              <span>•</span>
              <span className="text-cyan-400 font-mono">Circuit Sentinel</span>
            </div>
          </div>
        </div>

        {/* Watchlist Quick Pills & Search */}
        <div className="hidden md:flex items-center gap-2">
          <div className="flex items-center gap-1 rounded-xl bg-obsidian-800/80 p-1 border border-white/[0.06]">
            {PRESETS.slice(0, 5).map((sym) => (
              <button
                key={sym}
                onClick={() => onSelectSymbol(sym)}
                className={`rounded-lg px-2.5 py-1 text-xs font-semibold font-mono transition-all ${
                  currentSymbol === sym
                    ? "bg-gradient-to-r from-cyan-500 to-blue-600 text-white shadow-sm"
                    : "text-slate-400 hover:bg-white/[0.05] hover:text-slate-200"
                }`}
              >
                {sym}
              </button>
            ))}
          </div>

          {/* Symbol Input Form */}
          <form onSubmit={handleSubmit} className="relative">
            <input
              type="text"
              placeholder="Search ticker..."
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              className="w-32 rounded-xl border border-white/[0.08] bg-obsidian-800/60 px-3 py-1.5 pl-8 text-xs font-mono uppercase text-white placeholder-slate-500 transition-all focus:w-44 focus:border-cyan-500/50 focus:outline-none focus:ring-1 focus:ring-cyan-500/30"
            />
            <Search className="absolute left-2.5 top-2 h-3.5 w-3.5 text-slate-400" />
          </form>
        </div>

        {/* Status Badges, Vault Settings & Refresh */}
        <div className="flex items-center gap-2.5">
          
          {/* Paper vs Live Badge */}
          <div className={`flex items-center gap-1.5 rounded-full border px-3 py-1 text-xs font-medium ${
            paperMode
              ? "border-cyan-500/30 bg-cyan-500/10 text-cyan-400"
              : "border-emerald-500/40 bg-emerald-500/20 text-emerald-400 glow-emerald"
          }`}>
            <ShieldCheck className="h-3.5 w-3.5" />
            <span className="hidden sm:inline">{paperMode ? "Sandbox:" : "Gateway:"}</span>
            <span className="font-bold font-mono">{paperMode ? "PAPER" : "LIVE CAPITAL"}</span>
          </div>

          {/* BYOK Security Vault Button */}
          <button
            onClick={onOpenVault}
            className="flex items-center gap-1.5 rounded-xl border border-purple-500/30 bg-purple-500/10 px-3 py-1.5 text-xs font-bold text-purple-300 transition-all hover:bg-purple-500/20 hover:border-purple-500/50 shadow-sm"
            title="Open Security Vault & Circuit Breaker Settings"
          >
            <Lock className="h-3.5 w-3.5 text-purple-400" />
            <span className="hidden sm:inline">Vault & Keys</span>
          </button>

          {/* Refresh Button */}
          <button
            onClick={onRefresh}
            disabled={isLoading}
            className="flex h-9 w-9 items-center justify-center rounded-xl border border-white/[0.08] bg-obsidian-800/80 text-slate-300 transition-all hover:border-cyan-500/40 hover:bg-white/[0.05] hover:text-cyan-400 disabled:opacity-50"
            title="Refresh Market & Agent Consensus"
          >
            <RefreshCw className={`h-4 w-4 ${isLoading ? "animate-spin text-cyan-400" : ""}`} />
          </button>
        </div>

      </div>
    </header>
  );
};
