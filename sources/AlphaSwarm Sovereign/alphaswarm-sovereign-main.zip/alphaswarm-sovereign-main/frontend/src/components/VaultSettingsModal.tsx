"use client";

import React, { useState, useEffect } from "react";
import {
  X,
  Key,
  ShieldCheck,
  ShieldAlert,
  Lock,
  Radio,
  Sliders,
  AlertTriangle,
  CheckCircle2,
  Loader2,
  RefreshCw,
} from "lucide-react";
import { api, VaultStatusData, CircuitBreakerData } from "@/lib/api";

interface VaultSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpdated: () => void;
}

export const VaultSettingsModal: React.FC<VaultSettingsModalProps> = ({
  isOpen,
  onClose,
  onUpdated,
}) => {
  const [apiKey, setApiKey] = useState("");
  const [secretKey, setSecretKey] = useState("");
  const [isPaper, setIsPaper] = useState(true);
  const [maxDrawdown, setMaxDrawdown] = useState<number>(5.0);
  const [killSwitch, setKillSwitch] = useState<boolean>(false);

  const [vaultStatus, setVaultStatus] = useState<VaultStatusData | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const [isSaving, setIsSaving] = useState(false);
  const [msg, setMsg] = useState<{ text: string; type: "success" | "error" } | null>(null);

  const loadSettings = async () => {
    setIsLoading(true);
    try {
      const [vRes, cbRes] = await Promise.allSettled([
        api.getVaultStatus(),
        api.getCircuitBreaker(),
      ]);

      if (vRes.status === "fulfilled" && vRes.value) {
        setVaultStatus(vRes.value);
        setIsPaper(vRes.value.is_paper);
      }
      if (cbRes.status === "fulfilled" && cbRes.value) {
        setMaxDrawdown(cbRes.value.max_daily_loss_pct);
        setKillSwitch(cbRes.value.kill_switch_active);
      }
    } catch (err) {
      console.error("Failed to load vault settings:", err);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    if (isOpen) {
      loadSettings();
      setMsg(null);
    }
  }, [isOpen]);

  if (!isOpen) return null;

  const handleSaveKeys = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!apiKey.trim() || !secretKey.trim()) {
      setMsg({ text: "Please enter both API Key and Secret Key.", type: "error" });
      return;
    }

    setIsSaving(true);
    setMsg(null);
    try {
      const res = await api.saveVaultKeys({
        api_key: apiKey.trim(),
        secret_key: secretKey.trim(),
        is_paper: isPaper,
        broker: "alpaca",
      });
      setMsg({ text: res.message || "Keys securely encrypted & stored in AES-256 vault.", type: "success" });
      setApiKey("");
      setSecretKey("");
      loadSettings();
      onUpdated();
    } catch (err: any) {
      setMsg({ text: err?.message || "Failed to save keys to vault.", type: "error" });
    } finally {
      setIsSaving(false);
    }
  };

  const handleToggleMode = async (paperVal: boolean) => {
    try {
      const res = await api.toggleVaultMode(paperVal);
      setIsPaper(paperVal);
      setMsg({ text: res.message, type: "success" });
      loadSettings();
      onUpdated();
    } catch (err: any) {
      setMsg({ text: "Failed to switch trading mode.", type: "error" });
    }
  };

  const handleUpdateCircuitBreaker = async () => {
    try {
      const res = await api.updateCircuitBreaker({
        max_daily_loss_pct: maxDrawdown,
        kill_switch_active: killSwitch,
      });
      setMsg({ text: "Fiduciary Circuit Breaker parameters updated.", type: "success" });
      onUpdated();
    } catch (err: any) {
      setMsg({ text: "Failed to update circuit breaker.", type: "error" });
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-xl p-4 animate-in fade-in">
      <div className="relative w-full max-w-xl rounded-3xl border border-white/[0.12] bg-obsidian-900 p-6 shadow-2xl overflow-y-auto max-h-[90vh]">
        
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute right-4 top-4 rounded-xl p-1.5 text-slate-400 hover:bg-white/[0.05] hover:text-white"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Header */}
        <div className="flex items-center gap-3 mb-6">
          <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gradient-to-tr from-cyan-500 to-purple-600 text-white shadow-neon-blue">
            <Lock className="h-6 w-6" />
          </div>
          <div>
            <h3 className="text-xl font-black text-white">BYOK Cryptographic Vault & Risk Gateway</h3>
            <p className="text-xs text-slate-400">AES-256 Encrypted Broker Credential Management</p>
          </div>
        </div>

        {/* Status Notification */}
        {msg && (
          <div
            className={`mb-4 rounded-xl p-3 text-xs flex items-center gap-2 ${
              msg.type === "success"
                ? "bg-emerald-500/10 border border-emerald-500/30 text-emerald-300"
                : "bg-rose-500/10 border border-rose-500/30 text-rose-300"
            }`}
          >
            {msg.type === "success" ? <CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-400" /> : <AlertTriangle className="h-4 w-4 shrink-0 text-rose-400" />}
            <span>{msg.text}</span>
          </div>
        )}

        {/* Section 1: Active Vault Connection Status */}
        <div className="rounded-2xl bg-obsidian-800/60 p-4 border border-white/[0.06] mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-slate-400">
              Active Tenant Connection
            </span>
            <span className={`px-2.5 py-0.5 rounded-full text-[10px] font-bold uppercase font-mono ${
              vaultStatus?.has_keys
                ? isPaper
                  ? "bg-cyan-500/10 text-cyan-300 border border-cyan-500/30"
                  : "bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 glow-emerald"
                : "bg-amber-500/10 text-amber-300 border border-amber-500/30"
            }`}>
              {vaultStatus?.mode || "Paper Sandbox"}
            </span>
          </div>

          <div className="flex items-center justify-between text-xs font-mono">
            <span className="text-slate-400">Connected Broker Key:</span>
            <span className="text-white font-bold">{vaultStatus?.masked_key || "PKQ***CY (System Paper)"}</span>
          </div>

          {/* Mode Switcher */}
          <div className="mt-3 pt-3 border-t border-white/[0.04] flex items-center justify-between">
            <span className="text-xs text-slate-300 font-medium">Trading Environment:</span>
            <div className="flex items-center gap-1 bg-obsidian-900/80 p-1 rounded-xl border border-white/[0.06]">
              <button
                onClick={() => handleToggleMode(true)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  isPaper ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40" : "text-slate-400 hover:text-white"
                }`}
              >
                Paper Sandbox
              </button>
              <button
                onClick={() => handleToggleMode(false)}
                className={`px-3 py-1 rounded-lg text-xs font-bold transition-all ${
                  !isPaper ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 glow-emerald" : "text-slate-400 hover:text-white"
                }`}
              >
                LIVE TRADING
              </button>
            </div>
          </div>
        </div>

        {/* Section 2: BYOK Key Input Form */}
        <form onSubmit={handleSaveKeys} className="space-y-4 mb-6">
          <div className="text-xs font-bold uppercase tracking-wider text-slate-400 flex items-center gap-1.5">
            <Key className="h-3.5 w-3.5 text-cyan-400" />
            <span>Update Alpaca API Credentials</span>
          </div>

          <div className="space-y-2">
            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">ALPACA_API_KEY</label>
              <input
                type="text"
                placeholder="PKQAT..."
                value={apiKey}
                onChange={(e) => setApiKey(e.target.value)}
                className="w-full rounded-xl border border-white/[0.1] bg-obsidian-800 px-3.5 py-2 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="text-[11px] font-mono text-slate-400 block mb-1">ALPACA_SECRET_KEY</label>
              <input
                type="password"
                placeholder="9pTsZ..."
                value={secretKey}
                onChange={(e) => setSecretKey(e.target.value)}
                className="w-full rounded-xl border border-white/[0.1] bg-obsidian-800 px-3.5 py-2 text-xs font-mono text-white focus:border-cyan-500 focus:outline-none"
              />
            </div>
          </div>

          <button
            type="submit"
            disabled={isSaving}
            className="w-full rounded-xl bg-gradient-to-r from-cyan-500 to-purple-600 py-2.5 text-xs font-extrabold text-white shadow-neon-blue transition-all hover:opacity-90 disabled:opacity-50 flex items-center justify-center gap-2"
          >
            {isSaving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Lock className="h-4 w-4" />}
            <span>Encrypt & Save into Security Vault</span>
          </button>
        </form>

        {/* Section 3: Fiduciary Circuit Breaker Settings */}
        <div className="rounded-2xl bg-obsidian-800/60 p-4 border border-white/[0.06] space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sliders className="h-4 w-4 text-purple-400" />
              <span className="text-xs font-bold uppercase tracking-wider text-slate-300">
                Fiduciary Circuit Breaker
              </span>
            </div>
            <span className={`px-2 py-0.5 rounded text-[10px] font-bold font-mono ${
              killSwitch ? "bg-rose-500/20 text-rose-400 border border-rose-500/40" : "bg-emerald-500/10 text-emerald-400"
            }`}>
              {killSwitch ? "HALTED (KILL SWITCH)" : "NORMAL PROTECTION"}
            </span>
          </div>

          <div className="space-y-2">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-400">Max Intraday Loss Limit:</span>
              <span className="text-white font-bold">{maxDrawdown}% Drawdown</span>
            </div>
            <input
              type="range"
              min={1}
              max={15}
              step={0.5}
              value={maxDrawdown}
              onChange={(e) => setMaxDrawdown(parseFloat(e.target.value))}
              className="w-full accent-purple-500 cursor-pointer"
            />
          </div>

          <div className="flex items-center justify-between pt-2 border-t border-white/[0.04]">
            <div>
              <div className="text-xs font-bold text-slate-200">Emergency Kill Switch</div>
              <div className="text-[10px] text-slate-400">Instantly locks out all automated bracket orders</div>
            </div>
            <button
              type="button"
              onClick={() => setKillSwitch(!killSwitch)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold font-mono transition-all ${
                killSwitch
                  ? "bg-rose-500 text-white shadow-neon-red"
                  : "bg-obsidian-700 text-slate-300 border border-white/[0.1] hover:border-rose-500/40"
              }`}
            >
              {killSwitch ? "EMERGENCY HALT ON" : "ARM KILL SWITCH"}
            </button>
          </div>

          <button
            type="button"
            onClick={handleUpdateCircuitBreaker}
            className="w-full rounded-xl bg-obsidian-700 border border-white/[0.1] py-2 text-xs font-bold text-slate-200 hover:bg-obsidian-600 transition-all"
          >
            Save Circuit Breaker Parameters
          </button>
        </div>

      </div>
    </div>
  );
};
