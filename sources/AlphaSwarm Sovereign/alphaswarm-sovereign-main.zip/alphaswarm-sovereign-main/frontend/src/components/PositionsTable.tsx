"use client";

import React, { useState } from "react";
import { Briefcase, Clock, ArrowUpRight, ArrowDownRight } from "lucide-react";
import { PositionItem, OrderItem } from "@/lib/api";

interface PositionsTableProps {
  positions: PositionItem[];
  orders: OrderItem[];
}

export const PositionsTable: React.FC<PositionsTableProps> = ({ positions, orders }) => {
  const [activeTab, setActiveTab] = useState<"positions" | "orders">("positions");

  return (
    <div className="glass-panel p-6">
      
      {/* Header Tabs */}
      <div className="flex items-center justify-between border-b border-white/[0.08] pb-4 mb-4">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab("positions")}
            className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs sm:text-sm font-bold transition-all ${
              activeTab === "positions"
                ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Briefcase className="h-4 w-4" />
            <span>Active Portfolio ({positions.length})</span>
          </button>

          <button
            onClick={() => setActiveTab("orders")}
            className={`flex items-center gap-2 rounded-xl px-3.5 py-2 text-xs sm:text-sm font-bold transition-all ${
              activeTab === "orders"
                ? "bg-purple-500/20 text-purple-300 border border-purple-500/40"
                : "text-slate-400 hover:text-white"
            }`}
          >
            <Clock className="h-4 w-4" />
            <span>Execution Audit Trail ({orders.length})</span>
          </button>
        </div>
      </div>

      {/* Tab 1: Positions */}
      {activeTab === "positions" && (
        <div className="overflow-x-auto">
          {positions.length > 0 ? (
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-white/[0.06] text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-4">Asset</th>
                  <th className="py-3 px-4">Qty</th>
                  <th className="py-3 px-4">Avg Entry</th>
                  <th className="py-3 px-4">Current</th>
                  <th className="py-3 px-4">Market Value</th>
                  <th className="py-3 px-4 text-right">Unrealized P&L</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04]">
                {positions.map((pos, idx) => {
                  const isProfit = pos.unrealized_pl >= 0;
                  return (
                    <tr key={idx} className="hover:bg-white/[0.02] transition-colors">
                      <td className="py-3 px-4 font-extrabold text-white flex items-center gap-2">
                        <span className="h-2 w-2 rounded-full bg-cyan-400" />
                        <span>{pos.symbol}</span>
                      </td>
                      <td className="py-3 px-4 text-slate-300">{pos.qty}</td>
                      <td className="py-3 px-4 text-slate-300">${pos.avg_entry_price.toFixed(2)}</td>
                      <td className="py-3 px-4 text-white font-bold">${pos.current_price.toFixed(2)}</td>
                      <td className="py-3 px-4 text-slate-200 font-bold">${pos.market_value.toLocaleString("en-US", { minimumFractionDigits: 2 })}</td>
                      <td className="py-3 px-4 text-right">
                        <div className={`inline-flex items-center gap-1 font-bold ${isProfit ? "text-emerald-400" : "text-rose-400"}`}>
                          {isProfit ? <ArrowUpRight className="h-3.5 w-3.5" /> : <ArrowDownRight className="h-3.5 w-3.5" />}
                          <span>${pos.unrealized_pl.toFixed(2)}</span>
                          <span className="text-[11px] opacity-80">({pos.unrealized_pl_pct.toFixed(2)}%)</span>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          ) : (
            <div className="py-8 text-center text-slate-500 text-xs">
              No open positions currently recorded.
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Orders */}
      {activeTab === "orders" && (
        <div className="overflow-x-auto">
          {orders.length > 0 ? (
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-white/[0.06] text-slate-400 uppercase tracking-wider">
                  <th className="py-3 px-4">Order ID</th>
                  <th className="py-3 px-4">Symbol</th>
                  <th className="py-3 px-4">Side</th>
                  <th className="py-3 px-4">Type</th>
                  <th className="py-3 px-4">Qty</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Submitted</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-white/[0.04]">
                {orders.map((ord, idx) => (
                  <tr key={idx} className="hover:bg-white/[0.02] transition-colors">
                    <td className="py-3 px-4 text-slate-400 font-mono">{ord.id}</td>
                    <td className="py-3 px-4 font-bold text-white">{ord.symbol}</td>
                    <td className="py-3 px-4">
                      <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
                        ord.side === "BUY" ? "bg-emerald-500/20 text-emerald-400" : "bg-rose-500/20 text-rose-400"
                      }`}>
                        {ord.side}
                      </span>
                    </td>
                    <td className="py-3 px-4 text-slate-300">{ord.type}</td>
                    <td className="py-3 px-4 text-slate-300">{ord.qty}</td>
                    <td className="py-3 px-4">
                      <span className="text-emerald-400 font-bold">{ord.status}</span>
                    </td>
                    <td className="py-3 px-4 text-right text-slate-400">{ord.submitted_at}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          ) : (
            <div className="py-8 text-center text-slate-500 text-xs">
              No recent orders in log.
            </div>
          )}
        </div>
      )}

    </div>
  );
};
