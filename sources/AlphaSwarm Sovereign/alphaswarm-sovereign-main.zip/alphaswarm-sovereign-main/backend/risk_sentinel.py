﻿"""
AlphaSwarm Sovereign: Institutional Risk Sentinel & Monte Carlo VaR Engine
Enforces Wall-Street grade risk guardrails, ATR volatility circuit breakers,
Macro News VETO checks, 2% risk budgeting, and 1,000-path Monte Carlo simulations.
"""

from typing import Any, Dict, List, Optional
import numpy as np
from config import (
    MAX_RISK_PER_TRADE,
    MIN_CONFIDENCE_THRESHOLD,
    ATR_STOP_LOSS_MULTIPLIER,
    ATR_TAKE_PROFIT_MULTIPLIER,
    MAX_ATR_VOLATILITY_PCT,
)


class RiskSentinel:
    """
    Automated fiduciary compliance, position-sizing, and Monte Carlo VaR engine.
    """

    def __init__(
        self,
        max_risk_pct: float = MAX_RISK_PER_TRADE,
        min_confidence: int = MIN_CONFIDENCE_THRESHOLD,
        atr_sl_mult: float = ATR_STOP_LOSS_MULTIPLIER,
        atr_tp_mult: float = ATR_TAKE_PROFIT_MULTIPLIER,
        max_volatility_pct: float = MAX_ATR_VOLATILITY_PCT,
    ):
        self.max_risk_pct = max_risk_pct
        self.min_confidence = min_confidence
        self.atr_sl_mult = atr_sl_mult
        self.atr_tp_mult = atr_tp_mult
        self.max_volatility_pct = max_volatility_pct

    def run_monte_carlo_simulation(
        self,
        symbol: str,
        current_price: float,
        atr: float,
        days: int = 30,
        simulations: int = 1000,
    ) -> Dict[str, Any]:
        """
        Runs 1,000 Geometric Brownian Motion simulations to project 95% VaR,
        maximum projected drawdown, and terminal outcome probability distribution.
        """
        current_price = float(current_price)
        daily_vol = (atr / (current_price + 1e-6)) if atr > 0 else 0.02
        drift = 0.0004

        np.random.seed(42)
        daily_shocks = np.random.normal(drift, daily_vol, (days, simulations))
        price_paths = np.zeros((days + 1, simulations))
        price_paths[0] = current_price

        for t in range(1, days + 1):
            price_paths[t] = price_paths[t - 1] * (1 + daily_shocks[t - 1])

        terminal_prices = price_paths[-1]
        terminal_returns = (terminal_prices - current_price) / current_price

        # 95% Value at Risk (VaR)
        var_95_pct = float(np.percentile(terminal_returns, 5))
        var_95_dollar = round(abs(var_95_pct * current_price), 2)
        var_95_pct_clean = round(abs(var_95_pct) * 100, 2)

        # Expected Value & Win Probability
        expected_median = float(np.median(terminal_prices))
        win_prob = round(float(np.mean(terminal_prices > current_price)) * 100, 1)

        # Max Drawdown across paths
        peak_prices = np.maximum.accumulate(price_paths, axis=0)
        drawdowns = (price_paths - peak_prices) / peak_prices
        max_drawdown_95_pct = round(abs(float(np.percentile(drawdowns.min(axis=0), 5))) * 100, 2)

        # Build clean distribution curve bins for Recharts visualizer
        hist_counts, bin_edges = np.histogram(terminal_prices, bins=25)
        distribution_points = []
        for i in range(len(hist_counts)):
            price_point = round((bin_edges[i] + bin_edges[i + 1]) / 2, 2)
            distribution_points.append({
                "price": price_point,
                "density": int(hist_counts[i]),
                "label": f"${price_point:.1f}",
            })

        # Sample representative paths for multi-line charts
        sample_paths = []
        for d in range(0, days + 1, max(1, days // 10)):
            sample_paths.append({
                "day": f"D+{d}",
                "median": round(float(np.median(price_paths[d])), 2),
                "p95_upper": round(float(np.percentile(price_paths[d], 95)), 2),
                "p05_lower": round(float(np.percentile(price_paths[d], 5)), 2),
            })

        return {
            "symbol": symbol.upper().strip(),
            "simulations_count": simulations,
            "horizon_days": days,
            "var_95_pct": var_95_pct_clean,
            "var_95_dollar": var_95_dollar,
            "max_projected_drawdown_pct": max_drawdown_95_pct,
            "win_probability_pct": win_prob,
            "expected_median_price": round(expected_median, 2),
            "distribution_curve": distribution_points,
            "sample_trajectory": sample_paths,
            "institutional_grade": "PASSED (AAA)" if var_95_pct_clean <= 12.0 else "ELEVATED_VOLATILITY",
        }

    def validate_trade(
        self,
        account_equity: float,
        account_cash: float,
        current_price: float,
        consensus_decision: Dict[str, Any],
        atr_value: float,
        news_sentiment: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Validates trade approval and calculates mathematically sound position size and brackets,
        incorporating Macro News VETO guardrails.
        """
        checklist: List[Dict[str, Any]] = []
        is_approved = True
        rejection_reasons = []

        action = consensus_decision.get("action", "HOLD").upper()
        confidence = consensus_decision.get("confidence_score", 0)

        # 1. Action Check
        action_pass = action == "BUY"
        checklist.append({
            "check": "Agent Consensus Action is BUY",
            "passed": action_pass,
            "detail": f"Consensus Action: {action}",
        })
        if not action_pass:
            is_approved = False
            rejection_reasons.append(f"Committee voted {action}, not BUY.")

        # 2. Confidence Threshold Check
        conf_pass = confidence >= self.min_confidence
        checklist.append({
            "check": f"Confidence Score >= {self.min_confidence}%",
            "passed": conf_pass,
            "detail": f"Score: {confidence}% (Required: {self.min_confidence}%)",
        })
        if not conf_pass:
            is_approved = False
            rejection_reasons.append(f"Confidence score {confidence}% is below {self.min_confidence}% threshold.")

        # 3. Volatility / Circuit Breaker Check
        atr_safe = atr_value if atr_value > 0 else (current_price * 0.02)
        volatility_ratio = atr_safe / (current_price + 1e-6)
        vol_pass = volatility_ratio <= self.max_volatility_pct
        checklist.append({
            "check": f"ATR Volatility <= {self.max_volatility_pct * 100:.1f}%",
            "passed": vol_pass,
            "detail": f"Asset Volatility: {volatility_ratio * 100:.2f}% (Limit: {self.max_volatility_pct * 100:.1f}%)",
        })
        if not vol_pass:
            is_approved = False
            rejection_reasons.append(f"Circuit Breaker: Volatility ({volatility_ratio * 100:.2f}%) exceeds safety limit.")

        # 4. Macro News Sentiment VETO Guardrail
        macro_score = news_sentiment.get("sentiment_score", 0.3) if news_sentiment else 0.3
        macro_veto_triggered = macro_score < -0.60
        macro_pass = not macro_veto_triggered
        checklist.append({
            "check": "Macro News Sentiment > -0.60 (VETO Guardrail)",
            "passed": macro_pass,
            "detail": f"Macro Score: {macro_score:+.2f} ({news_sentiment.get('macro_bias', 'BULLISH') if news_sentiment else 'NEUTRAL'})",
        })
        if not macro_pass:
            is_approved = False
            rejection_reasons.append(f"Macro VETO: News sentiment is critically negative ({macro_score:+.2f}).")

        # 5. Dynamic Bracket Calculation
        stop_loss_delta = atr_safe * self.atr_sl_mult
        take_profit_delta = atr_safe * self.atr_tp_mult

        min_sl_delta = current_price * 0.01
        stop_loss_delta = max(stop_loss_delta, min_sl_delta)
        take_profit_delta = max(take_profit_delta, stop_loss_delta * 2.0)

        stop_loss_price = round(max(0.01, current_price - stop_loss_delta), 2)
        take_profit_price = round(current_price + take_profit_delta, 2)

        risk_per_share = current_price - stop_loss_price
        reward_per_share = take_profit_price - current_price
        rr_ratio = reward_per_share / (risk_per_share + 1e-6)

        rr_pass = rr_ratio >= 1.95
        checklist.append({
            "check": "Risk-to-Reward Ratio >= 1:2",
            "passed": rr_pass,
            "detail": f"Calculated R:R is 1:{rr_ratio:.2f} (SL: ${stop_loss_price}, TP: ${take_profit_price})",
        })

        # 6. Position Sizing
        max_capital_at_risk = account_equity * self.max_risk_pct
        if risk_per_share > 0:
            risk_based_qty = int(max_capital_at_risk / risk_per_share)
        else:
            risk_based_qty = 0

        max_cash_allocation = account_cash * 0.90
        cash_based_qty = int(max_cash_allocation / current_price) if current_price > 0 else 0

        recommended_qty = max(0, min(risk_based_qty, cash_based_qty))

        qty_pass = recommended_qty >= 1
        checklist.append({
            "check": f"Portfolio Risk <= {self.max_risk_pct * 100:.1f}% (${max_capital_at_risk:,.2f})",
            "passed": qty_pass,
            "detail": f"Recommended Size: {recommended_qty} shares (${recommended_qty * current_price:,.2f} total value)",
        })
        if not qty_pass:
            is_approved = False
            rejection_reasons.append("Insufficient cash or portfolio risk capacity to size at least 1 share.")

        total_position_cost = round(recommended_qty * current_price, 2)
        max_loss_potential = round(recommended_qty * risk_per_share, 2)
        max_gain_potential = round(recommended_qty * reward_per_share, 2)

        # 7. Monte Carlo VaR computation
        mc_sim = self.run_monte_carlo_simulation(
            symbol=consensus_decision.get("symbol", "ASSET"),
            current_price=current_price,
            atr=atr_safe,
            days=30,
            simulations=1000,
        )

        return {
            "approved": is_approved,
            "action": action,
            "recommended_qty": recommended_qty if is_approved else 0,
            "current_price": current_price,
            "stop_loss": stop_loss_price,
            "take_profit": take_profit_price,
            "risk_per_share": round(risk_per_share, 2),
            "reward_per_share": round(reward_per_share, 2),
            "risk_reward_ratio": round(rr_ratio, 2),
            "max_capital_at_risk": round(max_capital_at_risk, 2),
            "total_position_cost": total_position_cost if is_approved else 0.0,
            "potential_max_loss": max_loss_potential if is_approved else 0.0,
            "potential_max_gain": max_gain_potential if is_approved else 0.0,
            "checklist": checklist,
            "rejection_reasons": rejection_reasons,
            "monte_carlo": mc_sim,
        }
