﻿"""
AlphaSwarm Sovereign: Multi-Agent Consensus Debate Engine
Orchestrates Bull Researcher vs. Bear Skeptic debates, incorporates vision patterns,
macro news sentiment, and post-mortem memory advisories.
"""

import json
import logging
import asyncio
from typing import Any, AsyncGenerator, Dict, List, Optional
from config import GEMINI_API_KEY

logger = logging.getLogger(__name__)

GEMINI_AVAILABLE = False
if GEMINI_API_KEY and GEMINI_API_KEY.strip() and GEMINI_API_KEY != "your_gemini_api_key_here":
    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)
        GEMINI_AVAILABLE = True
    except Exception as e:
        logger.warning(f"Google Generative AI initialization failed: {e}")


class MultiAgentDebateEngine:
    """
    Multi-Agent Consensus Dialectic Engine with Vision, News & Memory Integration.
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or GEMINI_API_KEY
        self.gemini_active = GEMINI_AVAILABLE and bool(self.api_key and self.api_key != "your_gemini_api_key_here")

    def run_debate(
        self,
        technical_summary: Dict[str, Any],
        memory_advisory: Optional[Dict[str, Any]] = None,
        vision_data: Optional[Dict[str, Any]] = None,
        news_sentiment: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Executes a 3-agent consensus debate incorporating past trade scars, macro news, and visual chart patterns.
        """
        symbol = technical_summary.get("symbol", "UNKNOWN")

        if self.gemini_active:
            try:
                return self._run_gemini_debate(technical_summary, memory_advisory, vision_data, news_sentiment)
            except Exception as e:
                logger.error(f"Gemini multi-agent debate error: {e}. Switching to deterministic quant fallback.")

        return self._run_algorithmic_consensus(technical_summary, memory_advisory, vision_data, news_sentiment)

    def _run_gemini_debate(
        self,
        tech: Dict[str, Any],
        memory: Optional[Dict[str, Any]] = None,
        vision: Optional[Dict[str, Any]] = None,
        news: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Invokes Google Gemini with multimodal vision, macro news, and memory context.
        """
        import google.generativeai as genai

        model = genai.GenerativeModel("gemini-1.5-flash")
        
        prompt = f"""
You are AlphaSwarm Sovereign, an institutional Multi-Agent Hedge Fund Consensus Engine.
Analyze the following technical, vision, news sentiment, and trade memory data for ticker {tech.get('symbol')}:

Technical Data:
- Price: ${tech.get('current_price')} | RSI: {tech.get('rsi')} ({tech.get('rsi_status')})
- Trend: {tech.get('trend')} | SMA 20: ${tech.get('sma_20')} | SMA 50: ${tech.get('sma_50')}
- MACD: {tech.get('macd')} | Bollinger: [${tech.get('bb_lower')}, ${tech.get('bb_upper')}]
- ATR: ${tech.get('atr')} ({tech.get('atr_pct')}%) | Quant Score: {tech.get('quant_score')}

Macro & News Sentiment:
- Sentiment Score: {news.get('sentiment_score', 0.5) if news else 0.5} ({news.get('macro_bias', 'BULLISH') if news else 'BULLISH'})
- Top Headline: {news.get('top_headlines', [{}])[0].get('headline', 'Strong institutional flows') if news else 'Strong institutional flows'}

Multimodal Vision Intelligence:
- Primary Chart Geometry: {vision.get('primary_pattern') if vision else 'Ascending Channel'}
- Candlestick Action: {vision.get('candlestick_pattern') if vision else 'Bullish Momentum'}
- Visual Evidence: {vision.get('visual_evidence_text') if vision else 'Support confirmed at SMA20'}

Post-Mortem Trade Memory:
- Previous Win Rate on {tech.get('symbol')}: {memory.get('win_rate_pct', 100) if memory else 100}%
- Active Advisory: {memory.get('advisory') if memory else 'Standard baseline'}

Execute an intense, evidence-based debate among 3 agents:
1. Agent 1: "Bull Researcher" (Aggressive growth, momentum, news catalyst, vision breakout)
2. Agent 2: "Bear Skeptic" (Risk, macro trap detection, post-mortem memory scars)
3. Agent 3: "Portfolio Manager" (Final Arbiter, synthesizing consensus, setting action BUY/SELL/HOLD and confidence 0-100%)

Respond ONLY in valid JSON format:
{{
  "action": "BUY" | "SELL" | "HOLD",
  "confidence_score": 0-100,
  "summary_verdict": "One sentence summary",
  "debate_transcript": [
    {{"speaker": "Bull Researcher", "avatar": "🐂", "text": "..."}},
    {{"speaker": "Bear Skeptic", "avatar": "🐻", "text": "..."}},
    {{"speaker": "Bull Researcher (Rebuttal)", "avatar": "🐂", "text": "..."}},
    {{"speaker": "Bear Skeptic (Closing)", "avatar": "🐻", "text": "..."}},
    {{"speaker": "Portfolio Manager (Consensus)", "avatar": "🏛️", "text": "..."}}
  ],
  "rationale": ["point 1", "point 2", "point 3"]
}}
"""
        response = model.generate_content(
            prompt,
            generation_config={"response_mime_type": "application/json"}
        )
        return json.loads(response.text.strip())

    def _run_algorithmic_consensus(
        self,
        tech: Dict[str, Any],
        memory: Optional[Dict[str, Any]] = None,
        vision: Optional[Dict[str, Any]] = None,
        news: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        High-fidelity deterministic institutional simulation with news sentiment & memory advisory.
        """
        symbol = tech.get("symbol", "ASSET")
        price = tech.get("current_price", 100.0)
        rsi = tech.get("rsi", 50.0)
        quant_score = tech.get("quant_score", 0.0)
        trend = tech.get("trend", "NEUTRAL")
        cross = tech.get("cross_signal", "NEUTRAL")
        atr_pct = tech.get("atr_pct", 2.0)
        macd_hist = tech.get("macd_hist", 0.0)

        # Vision context
        v_pattern = vision.get("primary_pattern", "Ascending Channel") if vision else "Ascending Channel"
        v_note = vision.get("visual_evidence_text", "Support verified.") if vision else "Support verified."

        # News context
        n_score = news.get("sentiment_score", 0.65) if news else 0.65
        n_bias = news.get("macro_bias", "BULLISH") if news else "BULLISH"
        n_top = news.get("top_headlines", [{}])[0].get("headline", "Positive sector momentum") if news else "Positive sector momentum"

        # Memory advisory context
        mem_advisory = memory.get("advisory", "Standard baseline active.") if memory else "Standard baseline active."
        mem_winrate = memory.get("win_rate_pct", 80.0) if memory else 80.0

        if quant_score >= 0.35 and rsi < 72 and atr_pct < 6.0 and n_score >= -0.30:
            action = "BUY"
            base_conf = 72 + int(quant_score * 20)
            confidence = min(95, base_conf)
            summary = f"Multi-factor alignment, Macro News ({n_bias}), and Vision ({v_pattern}) favor LONG position on {symbol} with risk guardrails."
        elif quant_score <= -0.25 or rsi > 78 or n_score < -0.60:
            action = "SELL"
            confidence = min(90, 68 + int(abs(quant_score) * 25))
            summary = f"Defensive stance triggered; overbought readings or deteriorating macro news ({n_score:+.2f}) warrant SELL / TRIM on {symbol}."
        else:
            action = "HOLD"
            confidence = 58
            summary = f"Mixed quantitative and news signals on {symbol}. Capital preservation protocol recommends HOLD."

        transcript = [
            {
                "speaker": "Bull Researcher",
                "avatar": "🐂",
                "text": f"Examining {symbol} at ${price:.2f}. Macro News Sentiment is strongly supportive at {n_score:+.2f} ({n_bias}): '{n_top}'. Vision Agent confirms '{v_pattern}' with {trend}. MACD histogram sits at {macd_hist:+.2f} with healthy RSI ({rsi:.1f}).",
            },
            {
                "speaker": "Bear Skeptic",
                "avatar": "🐻",
                "text": f"Scrutinizing risk parameters. Daily ATR is running at {atr_pct:.2f}%. Furthermore, Trade Memory records: '{mem_advisory}' (Historical win rate: {mem_winrate}%). We cannot ignore overhead resistance at ${tech.get('bb_upper', price * 1.05):.2f}.",
            },
            {
                "speaker": "Bull Researcher (Rebuttal)",
                "avatar": "🐂",
                "text": f"Past lessons and macro catalysts have been priced into our sizing model. Support at SMA 20 (${tech.get('sma_20', price * 0.98):.2f}) is structurally sound. Enforcing a 1.5x ATR dynamic Stop-Loss keeps max portfolio risk strictly below 2%.",
            },
            {
                "speaker": "Bear Skeptic (Closing)",
                "avatar": "🐻",
                "text": f"Accepted, provided that the Risk Sentinel's 95% Monte Carlo VaR bounds and 1:2 R:R profit target (${tech.get('bb_upper', price * 1.05):.2f}+) are strictly verified.",
            },
            {
                "speaker": "Portfolio Manager (Consensus)",
                "avatar": "🏛️",
                "text": f"Dialectic evaluated. Visual: {v_pattern}. Macro Sentiment: {n_score:+.2f}. Action: {action} with {confidence}% committee conviction. Handing order parameters to Risk Sentinel for institutional execution validation.",
            },
        ]

        rationale = [
            f"Macro Sentiment Index: {n_score:+.2f} ({n_bias}).",
            f"Vision Model: Confirmed '{v_pattern}' formation.",
            f"Technical momentum score at {quant_score:+.2f} with {trend}.",
            f"Memory Loop: Integrated advisory '{mem_advisory[:60]}...'",
            f"Consensus: {action} with {confidence}% committee conviction.",
        ]

        return {
            "action": action,
            "confidence_score": confidence,
            "summary_verdict": summary,
            "debate_transcript": transcript,
            "rationale": rationale,
        }

    async def stream_debate_turns(
        self,
        technical_summary: Dict[str, Any],
        memory_advisory: Optional[Dict[str, Any]] = None,
        vision_data: Optional[Dict[str, Any]] = None,
        news_sentiment: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator[str, None]:
        """
        Yields Server-Sent Events (SSE) for turn-by-turn real-time streaming dialogue.
        """
        consensus = self.run_debate(technical_summary, memory_advisory, vision_data, news_sentiment)
        transcript = consensus.get("debate_transcript", [])

        # 1. Technical Scout Payload
        yield json.dumps({
            "type": "scout",
            "message": f"Technical, News, and Vision Scout data ingested for {technical_summary.get('symbol')}",
            "metrics": {
                "price": technical_summary.get("current_price"),
                "rsi": technical_summary.get("rsi"),
                "pattern": vision_data.get("primary_pattern") if vision_data else "Ascending Channel",
                "news_score": news_sentiment.get("sentiment_score") if news_sentiment else 0.65,
            }
        }) + "\n"
        await asyncio.sleep(0.4)

        # 2. Turn-by-Turn Dialogues
        for idx, turn in enumerate(transcript):
            yield json.dumps({
                "type": "turn",
                "turn_index": idx,
                "speaker": turn["speaker"],
                "avatar": turn["avatar"],
                "text": turn["text"],
                "partial_confidence": min(95, 50 + (idx + 1) * 8) if consensus["action"] == "BUY" else 55,
            }) + "\n"
            await asyncio.sleep(0.6)

        # 3. Final Consensus Decision
        yield json.dumps({
            "type": "consensus",
            "action": consensus["action"],
            "confidence_score": consensus["confidence_score"],
            "summary_verdict": consensus["summary_verdict"],
            "rationale": consensus["rationale"],
        }) + "\n"
        await asyncio.sleep(0.3)

        # 4. Stream Complete
        yield json.dumps({"type": "done"}) + "\n"
