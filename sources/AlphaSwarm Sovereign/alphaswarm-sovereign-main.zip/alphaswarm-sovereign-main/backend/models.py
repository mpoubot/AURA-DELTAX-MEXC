﻿"""
AlphaSwarm Sovereign: Database Models
Defines multi-tenant schemas for User Management, API Vault, Trade Execution,
Multi-Agent Dialectic Audit Trail, and Fiduciary Circuit Breakers.
"""

import uuid
from datetime import datetime
from sqlalchemy import (
    Column,
    String,
    Integer,
    Float,
    Boolean,
    DateTime,
    Text,
    ForeignKey,
)
from sqlalchemy.orm import relationship
from database import Base


def generate_uuid() -> str:
    return str(uuid.uuid4())


class User(Base):
    __tablename__ = "users"

    id = Column(String(36), primary_key=True, default=generate_uuid)
    email = Column(String(255), unique=True, index=True, nullable=False)
    tier = Column(String(50), default="institutional", nullable=False)
    stripe_customer_id = Column(String(255), nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    vault = relationship("UserAPIVault", back_populates="user", uselist=False, cascade="all, delete-orphan")
    circuit_breaker = relationship("CircuitBreakerConfig", back_populates="user", uselist=False, cascade="all, delete-orphan")
    trades = relationship("TradeExecution", back_populates="user", cascade="all, delete-orphan")
    dialectic_logs = relationship("DialecticLog", back_populates="user", cascade="all, delete-orphan")


class UserAPIVault(Base):
    __tablename__ = "user_api_vaults"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(36), ForeignKey("users.id"), unique=True, nullable=False)
    broker = Column(String(50), default="alpaca", nullable=False)
    encrypted_api_key = Column(Text, nullable=False)
    encrypted_secret_key = Column(Text, nullable=False)
    is_paper = Column(Boolean, default=True, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="vault")


class TradeExecution(Base):
    __tablename__ = "trade_executions"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    symbol = Column(String(20), nullable=False, index=True)
    qty = Column(Float, nullable=False)
    side = Column(String(10), default="BUY", nullable=False)
    order_type = Column(String(30), default="BRACKET_MARKET", nullable=False)
    entry_price = Column(Float, nullable=False)
    stop_loss = Column(Float, nullable=False)
    take_profit = Column(Float, nullable=False)
    status = Column(String(30), default="filled", nullable=False)
    alpaca_order_id = Column(String(100), nullable=True)
    pnl = Column(Float, default=0.0, nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="trades")


class DialecticLog(Base):
    __tablename__ = "dialectic_logs"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(String(36), ForeignKey("users.id"), nullable=False, index=True)
    symbol = Column(String(20), nullable=False, index=True)
    conviction_score = Column(Float, nullable=False)
    bull_thesis = Column(Text, nullable=True)
    bear_thesis = Column(Text, nullable=True)
    consensus_action = Column(String(10), nullable=False)
    vision_summary = Column(Text, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow, nullable=False)

    user = relationship("User", back_populates="dialectic_logs")


class CircuitBreakerConfig(Base):
    __tablename__ = "circuit_breaker_configs"

    user_id = Column(String(36), ForeignKey("users.id"), primary_key=True)
    max_daily_loss_pct = Column(Float, default=5.0, nullable=False)
    kill_switch_active = Column(Boolean, default=False, nullable=False)
    last_triggered_at = Column(DateTime, nullable=True)

    user = relationship("User", back_populates="circuit_breaker")
