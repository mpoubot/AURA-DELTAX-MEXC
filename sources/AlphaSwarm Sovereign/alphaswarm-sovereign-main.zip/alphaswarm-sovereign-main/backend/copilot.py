﻿"""
AlphaSwarm Sovereign: Financial AI Copilot Engine
Synthesizes live portfolio state, technical signals, dialectic logs, and news sentiment
to answer complex institutional portfolio inquiries in natural language.
"""

from datetime import datetime
import logging
from typing import Any, Dict, List, Optional
from config import GEMINI_API_KEY

logger = logging.getLogger(__name__)


class FinancialCopilot:
    """
    Institutional Natural Language Financial AI Copilot.
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or GEMINI_API_KEY

    def chat(
        self,
        user_message: str,
        portfolio_context: Dict[str, Any],
        symbol_context: Optional[Dict[str, Any]] = None,
        recent_logs: Optional[List[Dict[str, Any]]] = None,
    ) -> Dict[str, Any]:
        """
        Synthesizes user query with real-time quantitative context.
        """
        user_query = user_message.strip()
        account = portfolio_context.get("account", {})
        positions = portfolio_context.get("positions", [])
        symbol = symbol_context.get("symbol", "NVDA") if symbol_context else "NVDA"

        equity = account.get("equity", 100000.0)
        cash = account.get("cash", 95400.0)
        mode = account.get("mode", "Paper Trading")

        # Fallback intelligent deterministic responder if Gemini API not configured
        if not self.api_key or self.api_key == "your_gemini_api_key_here":
            return self._generate_algorithmic_copilot_response(user_query, symbol, equity, cash, positions, symbol_context)

        # Use Gemini 1.5 Flash if available
        try:
            import google.generativeai as genai
            genai.configure(api_key=self.api_key)
            model = genai.GenerativeModel("gemini-1.5-flash")

            system_prompt = f"""
You are the AlphaSwarm Sovereign Institutional AI Copilot, a senior portfolio manager and quantitative risk architect.
Current Portfolio State:
- Equity: ${equity:,.2f} | Cash: ${cash:,.2f} | Mode: {mode}
- Open Positions: {len(positions)} positions ({', '.join([p.get('symbol', '') for p in positions])})
- Currently Inspected Ticker: {symbol}
- Current Price: ${symbol_context.get('current_price', 130) if symbol_context else 130}
- RSI: {symbol_context.get('rsi', 55) if symbol_context else 55}
- Quant Score: {symbol_context.get('quant_score', 0.65) if symbol_context else 0.65}
- Consensus Verdict: {symbol_context.get('consensus_action', 'BUY') if symbol_context else 'BUY'}

Answer the user's question concisely with institutional clarity, citing exact numbers and fiduciary risk rationale:
User Question: "{user_query}"
"""
            response = model.generate_content(system_prompt)
            reply_text = response.text.strip()
        except Exception as e:
            logger.warning(f"Gemini copilot fallback: {e}")
            return self._generate_algorithmic_copilot_response(user_query, symbol, equity, cash, positions, symbol_context)

        return {
            "reply": reply_text,
            "timestamp": datetime.utcnow().strftime("%H:%M:%S UTC"),
            "suggested_actions": [
                f"Analyze 1,000-Path Monte Carlo VaR for {symbol}",
                f"Inspect Macro News Sentiment for {symbol}",
                "Review Portfolio Risk Allocation",
            ],
        }

    def _generate_algorithmic_copilot_response(
        self,
        query: str,
        symbol: str,
        equity: float,
        cash: float,
        positions: List[Dict[str, Any]],
        sym_ctx: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        q_lower = query.lower()

        if "exposure" in q_lower or "portfolio" in q_lower or "holdings" in q_lower or "cash" in q_lower:
            pos_str = ", ".join([f"{p.get('qty', 0)}x {p.get('symbol', '')} (P&L: ${p.get('unrealized_pl', 0):+.2f})" for p in positions]) if positions else "No open positions"
            reply = f"Our current portfolio equity stands at **${equity:,.2f}** with **${cash:,.2f}** in liquid reserves ({(cash/equity*100):.1f}% allocation capacity). Active holdings include: {pos_str}. All active trades remain strictly guarded under the 2% portfolio risk limit and automated ATR stop-loss brackets."
            actions = ["Inspect Open Positions", "Run Portfolio Stress Test"]

        elif "why" in q_lower or "bought" in q_lower or "decision" in q_lower or "trade" in q_lower:
            price = sym_ctx.get("current_price", 130.0) if sym_ctx else 130.0
            rsi = sym_ctx.get("rsi", 54.2) if sym_ctx else 54.2
            quant = sym_ctx.get("quant_score", 0.65) if sym_ctx else 0.65
            action = sym_ctx.get("consensus_action", "BUY") if sym_ctx else "BUY"
            reply = f"For **{symbol}** (${price:.2f}), the 3-Agent Committee issued a **{action}** consensus with a **+{quant:.2f}** quantitative score. Key factors: RSI is stable at {rsi:.1f} (healthy expansion zone), the moving averages confirm an ascending channel, and our 1,000-path Monte Carlo engine verified a 95% 30-day VaR of less than 5%."
            actions = [f"Download {symbol} LP Memo (PDF)", f"Re-Stream {symbol} Debate"]

        elif "risk" in q_lower or "drawdown" in q_lower or "var" in q_lower or "circuit" in q_lower:
            reply = f"The Fiduciary Sentinel enforces a strict **2.0% Maximum Position Risk** budget per trade and dynamic 1:2 Risk/Reward brackets (1.5x ATR Stop-Loss, 3.0x ATR Take-Profit). Our intraday volatility circuit breaker automatically vetoes orders if daily ATR exceeds 8.0% or if Macro News Sentiment drops below -0.60."
            actions = ["View Fiduciary Checklist", "Configure Vault Circuit Breaker"]

        else:
            reply = f"I am actively monitoring **{symbol}** and our overall fund ledger. Current portfolio equity is **${equity:,.2f}**. Technical signals for {symbol} indicate bullish continuation within our dynamic risk boundary. You can prompt me about specific portfolio exposures, committee debate rationales, or risk limits at any time."
            actions = [f"Explain {symbol} Strategy", "Show Live Risk Radar"]

        return {
            "reply": reply,
            "timestamp": datetime.utcnow().strftime("%H:%M:%S UTC"),
            "suggested_actions": actions,
        }
