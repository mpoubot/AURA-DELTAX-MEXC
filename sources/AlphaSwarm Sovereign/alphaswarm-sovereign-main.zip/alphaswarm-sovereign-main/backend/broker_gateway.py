﻿"""
AlphaSwarm Sovereign: Dynamic Multi-Tenant Broker Gateway & Fiduciary Circuit Breaker
Dynamically manages tenant broker sessions, decrypts credentials JIT (Just-In-Time),
and enforces automated emergency kill switches.
"""

from datetime import datetime
import logging
from typing import Any, Dict, Optional, Tuple
from sqlalchemy.orm import Session

from alpaca_client import AlpacaEngine
from models import CircuitBreakerConfig, TradeExecution, DialecticLog
from security_vault import get_decrypted_user_keys

logger = logging.getLogger(__name__)


class BrokerSessionManager:
    """
    Provisions dynamic broker instances per tenant session.
    """

    def __init__(self):
        self._session_cache: Dict[str, AlpacaEngine] = {}

    def get_engine_for_user(self, db: Session, user_id: str) -> AlpacaEngine:
        """Retrieves or provisions an AlpacaEngine instance using decrypted tenant credentials."""
        api_key, secret_key, is_paper = get_decrypted_user_keys(db, user_id)
        cache_key = f"{user_id}:{is_paper}:{api_key[:6]}"

        if cache_key in self._session_cache:
            return self._session_cache[cache_key]

        engine = AlpacaEngine(
            api_key=api_key,
            secret_key=secret_key,
            paper=is_paper,
        )
        self._session_cache[cache_key] = engine
        return engine

    def clear_cache_for_user(self, user_id: str):
        """Invalidates cached broker sessions when user updates vault keys."""
        to_delete = [k for k in self._session_cache if k.startswith(f"{user_id}:")]
        for k in to_delete:
            del self._session_cache[k]


broker_manager = BrokerSessionManager()


def check_and_enforce_circuit_breaker(
    db: Session,
    user_id: str,
    account_summary: Dict[str, Any],
) -> Tuple[bool, Optional[str]]:
    """
    Evaluates intraday drawdown and emergency kill switch status before trade execution.
    Returns: (is_allowed: bool, rejection_reason: Optional[str])
    """
    config = db.query(CircuitBreakerConfig).filter(CircuitBreakerConfig.user_id == user_id).first()
    if not config:
        config = CircuitBreakerConfig(user_id=user_id, max_daily_loss_pct=5.0, kill_switch_active=False)
        db.add(config)
        db.commit()
        db.refresh(config)

    # 1. Manual or Autonomous Kill Switch Check
    if config.kill_switch_active:
        return False, "EMERGENCY_KILL_SWITCH_ACTIVE: Trading is currently suspended by Fiduciary Sentinel."

    # 2. Intraday Drawdown Check
    equity = account_summary.get("equity", 100000.0)
    portfolio_val = account_summary.get("portfolio_value", equity)
    
    # Calculate intraday drawdown percentage
    drawdown_pct = 0.0
    if portfolio_val > 0 and equity < portfolio_val:
        drawdown_pct = ((portfolio_val - equity) / portfolio_val) * 100

    if drawdown_pct >= config.max_daily_loss_pct:
        # Trip the circuit breaker
        config.kill_switch_active = True
        config.last_triggered_at = datetime.utcnow()
        db.commit()
        logger.critical(
            f"Fiduciary Circuit Breaker TRIPPED for User {user_id}! Drawdown: {drawdown_pct:.2f}% >= {config.max_daily_loss_pct}%"
        )
        return False, f"CIRCUIT_BREAKER_TRIPPED: Intraday drawdown ({drawdown_pct:.2f}%) exceeds safety ceiling ({config.max_daily_loss_pct}%)."

    return True, None


def update_circuit_breaker_config(
    db: Session,
    user_id: str,
    max_daily_loss_pct: Optional[float] = None,
    kill_switch_active: Optional[bool] = None,
) -> Dict[str, Any]:
    """Updates user circuit breaker settings or resets kill switch."""
    config = db.query(CircuitBreakerConfig).filter(CircuitBreakerConfig.user_id == user_id).first()
    if not config:
        config = CircuitBreakerConfig(user_id=user_id, max_daily_loss_pct=5.0, kill_switch_active=False)
        db.add(config)

    if max_daily_loss_pct is not None:
        config.max_daily_loss_pct = float(max_daily_loss_pct)
    if kill_switch_active is not None:
        config.kill_switch_active = bool(kill_switch_active)
        if not kill_switch_active:
            config.last_triggered_at = None

    db.commit()
    db.refresh(config)

    return {
        "user_id": config.user_id,
        "max_daily_loss_pct": config.max_daily_loss_pct,
        "kill_switch_active": config.kill_switch_active,
        "last_triggered_at": config.last_triggered_at.isoformat() if config.last_triggered_at else None,
        "status": "EMERGENCY_HALTED" if config.kill_switch_active else "ACTIVE_PROTECTED",
    }


def record_trade_execution(
    db: Session,
    user_id: str,
    symbol: str,
    qty: float,
    entry_price: float,
    stop_loss: float,
    take_profit: float,
    status: str = "filled",
    alpaca_order_id: Optional[str] = None,
) -> TradeExecution:
    """Logs executed trade order in the persistent database."""
    trade = TradeExecution(
        user_id=user_id,
        symbol=symbol.upper().strip(),
        qty=qty,
        side="BUY",
        order_type="BRACKET_MARKET",
        entry_price=entry_price,
        stop_loss=stop_loss,
        take_profit=take_profit,
        status=status,
        alpaca_order_id=alpaca_order_id,
        pnl=0.0,
    )
    db.add(trade)
    db.commit()
    db.refresh(trade)
    return trade


def record_dialectic_log(
    db: Session,
    user_id: str,
    symbol: str,
    conviction_score: float,
    consensus_action: str,
    bull_thesis: Optional[str] = None,
    bear_thesis: Optional[str] = None,
    vision_summary: Optional[str] = None,
) -> DialecticLog:
    """Logs dialectic debate committee decision in the audit trail."""
    log = DialecticLog(
        user_id=user_id,
        symbol=symbol.upper().strip(),
        conviction_score=conviction_score,
        consensus_action=consensus_action,
        bull_thesis=bull_thesis,
        bear_thesis=bear_thesis,
        vision_summary=vision_summary,
    )
    db.add(log)
    db.commit()
    db.refresh(log)
    return log
