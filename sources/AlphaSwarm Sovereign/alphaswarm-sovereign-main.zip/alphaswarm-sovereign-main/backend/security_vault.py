"""
AlphaSwarm Sovereign: BYOK Security Vault Engine
Implements AES-256 Fernet cryptographic key management for multi-tenant broker credentials.
Ensures zero plaintext API key storage across all database layers.
"""

import os
import base64
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple
from dotenv import load_dotenv
from cryptography.fernet import Fernet
from sqlalchemy.orm import Session
from models import User, UserAPIVault, CircuitBreakerConfig

env_path = Path(__file__).resolve().parent / ".env"
load_dotenv(dotenv_path=env_path, override=True)

logger = logging.getLogger(__name__)

# Fallback master key derivation if MASTER_ENCRYPTION_KEY is not in .env
DEFAULT_MASTER_SEED = "AlphaSwarm-Institutional-SaaS-Key-32Bytes-Salt!"
MASTER_KEY_ENV = os.getenv("MASTER_ENCRYPTION_KEY")

if not MASTER_KEY_ENV:
    # Deterministically derive a standard 32-byte urlsafe base64 key
    derived_bytes = DEFAULT_MASTER_SEED.encode("utf-8")[:32].ljust(32, b"#")
    MASTER_KEY_ENV = base64.urlsafe_b64encode(derived_bytes).decode("utf-8")


def get_fernet(master_key: Optional[str] = None) -> Fernet:
    key = (master_key or MASTER_KEY_ENV or "").strip()
    try:
        return Fernet(key.encode("utf-8"))
    except Exception:
        # Fallback to safe base64
        derived = base64.urlsafe_b64encode(key.encode("utf-8")[:32].ljust(32, b"A"))
        return Fernet(derived)


def encrypt_credentials(api_key: str, secret_key: str, master_key: Optional[str] = None) -> Dict[str, str]:
    """Encrypts raw API and Secret keys using AES-256 Fernet."""
    f = get_fernet(master_key)
    enc_api = f.encrypt(api_key.strip().encode("utf-8")).decode("utf-8")
    enc_secret = f.encrypt(secret_key.strip().encode("utf-8")).decode("utf-8")
    return {
        "encrypted_api_key": enc_api,
        "encrypted_secret_key": enc_secret,
    }


def decrypt_credentials(encrypted_api_key: str, encrypted_secret_key: str, master_key: Optional[str] = None) -> Tuple[str, str]:
    """Decrypts AES-256 encrypted API and Secret keys."""
    f = get_fernet(master_key)
    dec_api = f.decrypt(encrypted_api_key.strip().encode("utf-8")).decode("utf-8")
    dec_secret = f.decrypt(encrypted_secret_key.strip().encode("utf-8")).decode("utf-8")
    return dec_api, dec_secret


def mask_key(key: str) -> str:
    """Masks a sensitive API key for safe UI display (e.g., PKQ***CY)."""
    if not key or len(key) < 6:
        return "******"
    return f"{key[:3]}...{key[-3:]}"


# -----------------------------------------------------------------------------
# VAULT DATABASE HELPERS
# -----------------------------------------------------------------------------
def get_or_create_default_user(db: Session, email: str = "institution@alphaswarm.fund") -> User:
    """Returns existing default user or creates a new institutional tenant."""
    user = db.query(User).filter(User.email == email).first()
    if not user:
        user = User(email=email, tier="institutional")
        db.add(user)
        db.commit()
        db.refresh(user)

        # Initialize default circuit breaker config
        cb = CircuitBreakerConfig(user_id=user.id, max_daily_loss_pct=5.0, kill_switch_active=False)
        db.add(cb)

        # Seed initial encrypted credentials from system env
        system_key = os.getenv("ALPACA_API_KEY", "PKQAT2NLRMRTYWK2SPLH4UURCY").strip()
        system_secret = os.getenv("ALPACA_SECRET_KEY", "9pTsZj7DVZwLniXSVQUWWHQAQ3AY896KzbqVCUncGqTA").strip()
        is_paper = os.getenv("ALPACA_PAPER", "True").lower() in ("true", "1", "yes")

        enc = encrypt_credentials(system_key, system_secret)
        vault = UserAPIVault(
            user_id=user.id,
            broker="alpaca",
            encrypted_api_key=enc["encrypted_api_key"],
            encrypted_secret_key=enc["encrypted_secret_key"],
            is_paper=is_paper,
        )
        db.add(vault)
        db.commit()
        db.refresh(user)

    return user


def save_user_vault_keys(
    db: Session,
    user_id: str,
    api_key: str,
    secret_key: str,
    is_paper: bool = True,
    broker: str = "alpaca",
) -> Dict[str, Any]:
    """Securely encrypts and upserts a user's broker credentials."""
    enc = encrypt_credentials(api_key, secret_key)
    vault = db.query(UserAPIVault).filter(UserAPIVault.user_id == user_id).first()

    if vault:
        vault.broker = broker
        vault.encrypted_api_key = enc["encrypted_api_key"]
        vault.encrypted_secret_key = enc["encrypted_secret_key"]
        vault.is_paper = is_paper
    else:
        vault = UserAPIVault(
            user_id=user_id,
            broker=broker,
            encrypted_api_key=enc["encrypted_api_key"],
            encrypted_secret_key=enc["encrypted_secret_key"],
            is_paper=is_paper,
        )
        db.add(vault)

    db.commit()
    db.refresh(vault)

    return {
        "status": "success",
        "message": f"{broker.upper()} credentials encrypted and saved securely.",
        "is_paper": vault.is_paper,
        "masked_api_key": mask_key(api_key),
    }


def get_user_vault_status(db: Session, user_id: str) -> Dict[str, Any]:
    """Returns connection status and active trading mode without exposing raw secrets."""
    vault = db.query(UserAPIVault).filter(UserAPIVault.user_id == user_id).first()
    if not vault:
        return {
            "has_keys": False,
            "broker": "alpaca",
            "is_paper": True,
            "masked_key": None,
            "mode": "Sandbox (No Vault Keys)",
        }

    try:
        dec_api, _ = decrypt_credentials(vault.encrypted_api_key, vault.encrypted_secret_key)
        masked = mask_key(dec_api)
    except Exception:
        masked = "ENC***ERR"

    return {
        "has_keys": True,
        "broker": vault.broker,
        "is_paper": vault.is_paper,
        "masked_key": masked,
        "mode": "Paper Trading" if vault.is_paper else "LIVE TRADING (REAL CAPITAL)",
        "updated_at": vault.updated_at.isoformat() if vault.updated_at else None,
    }


def toggle_user_paper_mode(db: Session, user_id: str, is_paper: bool) -> Dict[str, Any]:
    """Switches execution between Paper Sandbox and Live Trading."""
    vault = db.query(UserAPIVault).filter(UserAPIVault.user_id == user_id).first()
    if not vault:
        return {"success": False, "message": "No vault keys found for user."}

    vault.is_paper = is_paper
    db.commit()
    db.refresh(vault)

    return {
        "success": True,
        "is_paper": vault.is_paper,
        "mode": "Paper Trading" if vault.is_paper else "LIVE TRADING (REAL CAPITAL)",
        "message": f"Trading mode switched to {'Paper Trading' if is_paper else 'LIVE TRADING'}.",
    }


def get_decrypted_user_keys(db: Session, user_id: str) -> Tuple[str, str, bool]:
    """Retrieves and decrypts the user's active API keys and paper flag."""
    vault = db.query(UserAPIVault).filter(UserAPIVault.user_id == user_id).first()
    if not vault:
        # Fallback to system env
        system_key = os.getenv("ALPACA_API_KEY", "PKQAT2NLRMRTYWK2SPLH4UURCY").strip()
        system_secret = os.getenv("ALPACA_SECRET_KEY", "9pTsZj7DVZwLniXSVQUWWHQAQ3AY896KzbqVCUncGqTA").strip()
        is_paper = os.getenv("ALPACA_PAPER", "True").lower() in ("true", "1", "yes")
        return system_key, system_secret, is_paper

    dec_api, dec_secret = decrypt_credentials(vault.encrypted_api_key, vault.encrypted_secret_key)
    return dec_api, dec_secret, vault.is_paper
