﻿"""
AlphaSwarm Sovereign: Institutional Multi-Tenant SaaS Backend
Exposes BYOK Security Vault, Dynamic Multi-Tenant Broker Gateway,
Fiduciary Circuit Breaker, Monte Carlo 95% VaR, PDF Memorandum Generator,
and Natural Language Financial AI Copilot.
"""

import os
import sys
import io
from typing import Any, Dict, List, Optional
from fastapi import FastAPI, HTTPException, Query, Request, Depends, Response
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, JSONResponse
from pydantic import BaseModel, Field
from sqlalchemy.orm import Session

# Add current directory to sys.path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from database import init_db, get_db
from models import User
from alpaca_client import AlpacaEngine
from technical_engine import TechnicalEngine
from debate_core import MultiAgentDebateEngine
from risk_sentinel import RiskSentinel
from memory_engine import MemoryEngine
from vision_engine import VisionPatternEngine
from news_engine import MacroNewsEngine
from security_vault import (
    get_or_create_default_user,
    save_user_vault_keys,
    get_user_vault_status,
    toggle_user_paper_mode,
)
from broker_gateway import (
    broker_manager,
    check_and_enforce_circuit_breaker,
    update_circuit_breaker_config,
    record_trade_execution,
    record_dialectic_log,
)
from pdf_memo import generate_investment_memo_pdf
from copilot import FinancialCopilot

app = FastAPI(
    title="AlphaSwarm Sovereign SaaS API",
    description="Autonomous Multi-Agent Consensus Hedge Fund & Multi-Tenant Fiduciary Terminal",
    version="3.0.0",
)

# Bulletproof CORS Middleware for all origins, headers, and methods
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Initialize Database on Startup
@app.on_event("startup")
def on_startup():
    init_db()


# Initialize Core Singleton Services
alpaca_engine_default = AlpacaEngine()
tech_engine = TechnicalEngine(alpaca_engine_default)
debate_engine = MultiAgentDebateEngine()
risk_sentinel = RiskSentinel()
memory_engine = MemoryEngine()
vision_engine = VisionPatternEngine()
news_engine = MacroNewsEngine()
copilot_engine = FinancialCopilot()


# -----------------------------------------------------------------------------
# PYDANTIC SCHEMAS
# -----------------------------------------------------------------------------
class VaultSaveKeysRequest(BaseModel):
    user_id: Optional[str] = None
    api_key: str = Field(..., description="Alpaca API Key")
    secret_key: str = Field(..., description="Alpaca Secret Key")
    is_paper: Optional[bool] = Field(default=True)
    broker: Optional[str] = Field(default="alpaca")


class VaultToggleModeRequest(BaseModel):
    user_id: Optional[str] = None
    is_paper: bool = Field(...)


class CircuitBreakerUpdateRequest(BaseModel):
    user_id: Optional[str] = None
    max_daily_loss_pct: Optional[float] = None
    kill_switch_active: Optional[bool] = None


class TradeExecutionRequest(BaseModel):
    user_id: Optional[str] = None
    symbol: str = Field(..., description="Ticker symbol to execute")
    qty: float = Field(..., gt=0, description="Quantity of shares")
    take_profit: float = Field(..., gt=0, description="Take profit limit price")
    stop_loss: float = Field(..., gt=0, description="Stop loss limit price")
    confidence: Optional[int] = Field(default=80, description="Debate consensus score")


class FullAnalysisRequest(BaseModel):
    symbol: str = Field(default="NVDA", description="Asset ticker symbol")
    max_risk_pct: Optional[float] = Field(default=0.02)
    min_confidence: Optional[int] = Field(default=65)


class MonteCarloRequest(BaseModel):
    symbol: str = Field(default="NVDA")
    days: Optional[int] = Field(default=30, ge=5, le=180)
    simulations: Optional[int] = Field(default=1000, ge=100, le=5000)


class CopilotChatRequest(BaseModel):
    message: str = Field(..., description="Natural language query from user")
    symbol: Optional[str] = Field(default="NVDA")
    user_id: Optional[str] = None


# -----------------------------------------------------------------------------
# ROOT & SYSTEM HEALTH
# -----------------------------------------------------------------------------
@app.get("/")
def root():
    return {
        "fund": "AlphaSwarm Sovereign SaaS",
        "status": "ONLINE (INSTITUTIONAL GRADE)",
        "version": "3.0.0",
        "capabilities": [
            "BYOK AES-256 Cryptographic Vault",
            "Dynamic Multi-Tenant Broker Gateway",
            "Automated Fiduciary Circuit Breaker & Kill Switch",
            "SSE Real-Time Dialectic Streaming",
            "1000-Path Monte Carlo 95% VaR Engine",
            "Investor PDF Memorandum Generator",
            "Natural Language Financial AI Copilot",
        ],
    }


# -----------------------------------------------------------------------------
# 1. BYOK SECURITY VAULT ROUTES
# -----------------------------------------------------------------------------
@app.post("/api/vault/save-keys")
def save_keys(payload: VaultSaveKeysRequest, db: Session = Depends(get_db)):
    """Encrypts and securely upserts the user's broker credentials."""
    user = get_or_create_default_user(db)
    user_id = payload.user_id or user.id

    res = save_user_vault_keys(
        db=db,
        user_id=user_id,
        api_key=payload.api_key,
        secret_key=payload.secret_key,
        is_paper=payload.is_paper if payload.is_paper is not None else True,
        broker=payload.broker or "alpaca",
    )
    broker_manager.clear_cache_for_user(user_id)
    return res


@app.get("/api/vault/status")
def get_vault_status(user_id: Optional[str] = None, db: Session = Depends(get_db)):
    """Returns whether user has valid keys connected and current active mode without revealing secrets."""
    user = get_or_create_default_user(db)
    uid = user_id or user.id
    status = get_user_vault_status(db, uid)
    return {"success": True, "data": status, "user_id": uid}


@app.post("/api/vault/toggle-mode")
def toggle_mode(payload: VaultToggleModeRequest, db: Session = Depends(get_db)):
    """Switches execution between Paper Sandbox and Live Trading."""
    user = get_or_create_default_user(db)
    uid = payload.user_id or user.id
    res = toggle_user_paper_mode(db, uid, payload.is_paper)
    broker_manager.clear_cache_for_user(uid)
    return res


@app.get("/api/vault/circuit-breaker")
def get_circuit_breaker(user_id: Optional[str] = None, db: Session = Depends(get_db)):
    """Returns the user's current circuit breaker settings and kill switch status."""
    user = get_or_create_default_user(db)
    uid = user_id or user.id
    res = update_circuit_breaker_config(db, uid)
    return {"success": True, "data": res}


@app.post("/api/vault/circuit-breaker")
def update_circuit_breaker(payload: CircuitBreakerUpdateRequest, db: Session = Depends(get_db)):
    """Updates user circuit breaker settings or resets the emergency kill switch."""
    user = get_or_create_default_user(db)
    uid = payload.user_id or user.id
    res = update_circuit_breaker_config(
        db=db,
        user_id=uid,
        max_daily_loss_pct=payload.max_daily_loss_pct,
        kill_switch_active=payload.kill_switch_active,
    )
    return {"success": True, "data": res}


# -----------------------------------------------------------------------------
# 2. MARKET DATA & STREAMING
# -----------------------------------------------------------------------------
@app.get("/api/account")
def get_account(user_id: Optional[str] = None, db: Session = Depends(get_db)):
    """Returns live portfolio value, cash, and buying power for active user."""
    try:
        user = get_or_create_default_user(db)
        uid = user_id or user.id
        engine = broker_manager.get_engine_for_user(db, uid)
        summary = engine.get_account_summary()
        return {"success": True, "data": summary}
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.get("/api/market/{symbol}")
def get_market_data(symbol: str, limit: int = Query(default=60, ge=10, le=250)):
    """Returns historical OHLCV chart bars with SMA, RSI, MACD, and Bollinger Bands."""
    try:
        sym = symbol.upper().strip()
        summary = tech_engine.generate_technical_summary(sym)
        df = summary.get("df")

        bars = []
        if df is not None and not df.empty:
            for idx, row in df.tail(limit).iterrows():
                ts_str = idx.isoformat() if hasattr(idx, "isoformat") else str(idx)
                bars.append({
                    "time": ts_str,
                    "date": ts_str.split("T")[0] if "T" in ts_str else ts_str.split(" ")[0],
                    "open": float(row.get("open", 0)),
                    "high": float(row.get("high", 0)),
                    "low": float(row.get("low", 0)),
                    "close": float(row.get("close", 0)),
                    "volume": float(row.get("volume", 0)),
                    "sma20": float(row.get("sma_20", 0)) if pd_notna(row.get("sma_20")) else None,
                    "sma50": float(row.get("sma_50", 0)) if pd_notna(row.get("sma_50")) else None,
                    "bb_upper": float(row.get("bb_upper", 0)) if pd_notna(row.get("bb_upper")) else None,
                    "bb_lower": float(row.get("bb_lower", 0)) if pd_notna(row.get("bb_lower")) else None,
                    "macd": float(row.get("macd", 0)) if pd_notna(row.get("macd")) else None,
                    "macd_signal": float(row.get("macd_signal", 0)) if pd_notna(row.get("macd_signal")) else None,
                    "macd_hist": float(row.get("macd_hist", 0)) if pd_notna(row.get("macd_hist")) else None,
                })

        return {
            "success": True,
            "symbol": sym,
            "metrics": {
                "current_price": summary.get("current_price"),
                "rsi": summary.get("rsi"),
                "trend": summary.get("trend"),
                "cross_signal": summary.get("cross_signal"),
                "quant_score": summary.get("quant_score"),
                "atr": summary.get("atr"),
                "atr_pct": summary.get("atr_pct"),
                "volatility_status": summary.get("volatility_status"),
            },
            "bars": bars,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.get("/api/stream-debate/{symbol}")
async def stream_debate(symbol: str):
    """Server-Sent Events (SSE) streaming endpoint for live real-time multi-agent debate."""
    sym = symbol.upper().strip()
    summary = tech_engine.generate_technical_summary(sym)
    memory = memory_engine.get_symbol_memory(sym)
    vision = vision_engine.analyze_chart_geometry(summary)
    news = news_engine.get_news_sentiment(sym)

    async def event_generator():
        async for chunk in debate_engine.stream_debate_turns(summary, memory, vision, news):
            yield f"data: {chunk}\n\n"

    return StreamingResponse(event_generator(), media_type="text/event-stream")


@app.post("/api/simulate-risk")
def simulate_risk(payload: MonteCarloRequest):
    """Runs 1,000-path Monte Carlo price projection and 95% Value at Risk (VaR)."""
    try:
        sym = payload.symbol.upper().strip()
        summary = tech_engine.generate_technical_summary(sym)
        mc_result = risk_sentinel.run_monte_carlo_simulation(
            symbol=sym,
            current_price=summary.get("current_price", 100.0),
            atr=summary.get("atr", 3.0),
            days=payload.days or 30,
            simulations=payload.simulations or 1000,
        )
        return {"success": True, "data": mc_result}
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.get("/api/news-sentiment/{symbol}")
def get_news_sentiment(symbol: str):
    """Returns Macro Sentiment Index, news headlines, and VETO status for symbol."""
    try:
        sym = symbol.upper().strip()
        data = news_engine.get_news_sentiment(sym)
        return {"success": True, "data": data}
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.get("/api/memory/{symbol}")
def get_memory(symbol: str):
    """Retrieves post-mortem trade memory and retrospective lessons for symbol."""
    try:
        sym = symbol.upper().strip()
        data = memory_engine.get_symbol_memory(sym)
        return {"success": True, "data": data}
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.get("/api/vision/{symbol}")
def get_vision_analysis(symbol: str):
    """Runs the Multimodal Vision Pattern Recognition Agent for symbol."""
    try:
        sym = symbol.upper().strip()
        summary = tech_engine.generate_technical_summary(sym)
        vision_res = vision_engine.analyze_chart_geometry(summary)
        return {"success": True, "data": vision_res}
    except Exception as e:
        return {"success": False, "error": str(e)}


@app.post("/api/full-analysis")
def run_full_analysis(payload: FullAnalysisRequest, user_id: Optional[str] = None, db: Session = Depends(get_db)):
    """
    Unified endpoint executing technical analysis, macro news sentiment,
    memory advisory, vision recognition, debate consensus, and Monte Carlo risk validation.
    """
    try:
        sym = payload.symbol.upper().strip()
        user = get_or_create_default_user(db)
        uid = user_id or user.id

        engine = broker_manager.get_engine_for_user(db, uid)
        acc = engine.get_account_summary()

        summary = tech_engine.generate_technical_summary(sym)
        memory = memory_engine.get_symbol_memory(sym)
        vision = vision_engine.analyze_chart_geometry(summary)
        news = news_engine.get_news_sentiment(sym)
        consensus = debate_engine.run_debate(summary, memory, vision, news)

        # Record dialectic audit trail in database
        try:
            record_dialectic_log(
                db=db,
                user_id=uid,
                symbol=sym,
                conviction_score=float(consensus.get("confidence_score", 50)),
                consensus_action=str(consensus.get("action", "HOLD")),
                bull_thesis=consensus.get("debate_transcript", [{}])[0].get("text"),
                bear_thesis=consensus.get("debate_transcript", [{}])[1].get("text") if len(consensus.get("debate_transcript", [])) > 1 else None,
                vision_summary=vision.get("visual_evidence_text"),
            )
        except Exception as log_err:
            logger.warning(f"Failed to record dialectic log: {log_err}")

        custom_sentinel = RiskSentinel(
            max_risk_pct=payload.max_risk_pct or 0.02,
            min_confidence=payload.min_confidence or 65,
        )

        validation = custom_sentinel.validate_trade(
            account_equity=acc.get("equity", 100000.0),
            account_cash=acc.get("cash", 95000.0),
            current_price=summary.get("current_price", 100.0),
            consensus_decision=consensus,
            atr_value=summary.get("atr", 3.0),
            news_sentiment=news,
        )

        return {
            "success": True,
            "symbol": sym,
            "account": acc,
            "metrics": {
                "current_price": summary.get("current_price"),
                "rsi": summary.get("rsi"),
                "trend": summary.get("trend"),
                "cross_signal": summary.get("cross_signal"),
                "quant_score": summary.get("quant_score"),
                "atr": summary.get("atr"),
                "atr_pct": summary.get("atr_pct"),
                "volatility_status": summary.get("volatility_status"),
            },
            "news": news,
            "vision": vision,
            "memory": memory,
            "consensus": consensus,
            "risk_sentinel": validation,
        }
    except Exception as e:
        return {"success": False, "error": str(e)}


# -----------------------------------------------------------------------------
# 3. MULTI-TENANT EXECUTION & CIRCUIT BREAKER
# -----------------------------------------------------------------------------
@app.post("/api/execute")
async def execute_trade(data: dict, db: Session = Depends(get_db)):
    """
    Submits a Bracket Market BUY Order to Alpaca with pre-flight Circuit Breaker validation.
    """
    try:
        user = get_or_create_default_user(db)
        uid = data.get("user_id") or user.id
        engine = broker_manager.get_engine_for_user(db, uid)
        acc = engine.get_account_summary()

        # 1. Pre-flight Fiduciary Circuit Breaker Check
        allowed, rejection_reason = check_and_enforce_circuit_breaker(db, uid, acc)
        if not allowed:
            return JSONResponse(
                status_code=403,
                content={
                    "success": False,
                    "status": "error",
                    "code": "CIRCUIT_BREAKER_TRIPPED",
                    "message": rejection_reason,
                },
            )

        symbol = str(data.get("symbol", "NVDA")).upper().strip()
        qty = int(float(data.get("qty", 1)))
        take_profit = float(data.get("take_profit", 150.0))
        stop_loss = float(data.get("stop_loss", 120.0))
        
        result = engine.execute_bracket_order(
            symbol=symbol,
            qty=qty,
            take_profit_price=take_profit,
            stop_loss_price=stop_loss,
        )

        # 2. Record Trade in Database
        try:
            record_trade_execution(
                db=db,
                user_id=uid,
                symbol=symbol,
                qty=qty,
                entry_price=float(acc.get("current_price", 130.0) or 130.0),
                stop_loss=stop_loss,
                take_profit=take_profit,
                status=str(result.get("status", "filled")),
                alpaca_order_id=result.get("order_id"),
            )
        except Exception as t_err:
            logger.warning(f"Failed to record trade in DB: {t_err}")

        return {
            "success": result.get("success", True),
            "status": "success" if result.get("success", True) else "error",
            "message": result.get("message", "Bracket order processed."),
            "data": result,
        }
    except Exception as e:
        return {
            "success": False,
            "status": "error",
            "message": f"Execution exception: {str(e)}",
            "error": str(e),
        }


@app.get("/api/positions")
def get_positions(user_id: Optional[str] = None, db: Session = Depends(get_db)):
    """Returns active portfolio holdings for tenant."""
    try:
        user = get_or_create_default_user(db)
        uid = user_id or user.id
        engine = broker_manager.get_engine_for_user(db, uid)
        positions = engine.get_open_positions()
        return {"success": True, "positions": positions}
    except Exception as e:
        return {"success": False, "positions": [], "error": str(e)}


@app.get("/api/orders")
def get_orders(limit: int = Query(default=10, ge=1, le=50), user_id: Optional[str] = None, db: Session = Depends(get_db)):
    """Returns the latest executed or pending orders for tenant."""
    try:
        user = get_or_create_default_user(db)
        uid = user_id or user.id
        engine = broker_manager.get_engine_for_user(db, uid)
        orders = engine.get_recent_orders(limit=limit)
        return {"success": True, "orders": orders}
    except Exception as e:
        return {"success": False, "orders": [], "error": str(e)}


# -----------------------------------------------------------------------------
# 4. INVESTOR PDF MEMO & FINANCIAL COPILOT
# -----------------------------------------------------------------------------
@app.get("/api/reports/generate-memo/{symbol}")
def generate_memo(symbol: str, user_id: Optional[str] = None, db: Session = Depends(get_db)):
    """Generates an institutional PDF Investment Memorandum for symbol."""
    try:
        sym = symbol.upper().strip()
        user = get_or_create_default_user(db)
        uid = user_id or user.id
        engine = broker_manager.get_engine_for_user(db, uid)
        acc = engine.get_account_summary()

        summary = tech_engine.generate_technical_summary(sym)
        memory = memory_engine.get_symbol_memory(sym)
        vision = vision_engine.analyze_chart_geometry(summary)
        news = news_engine.get_news_sentiment(sym)
        consensus = debate_engine.run_debate(summary, memory, vision, news)
        sentinel = RiskSentinel().validate_trade(
            account_equity=acc.get("equity", 100000.0),
            account_cash=acc.get("cash", 95000.0),
            current_price=summary.get("current_price", 100.0),
            consensus_decision=consensus,
            atr_value=summary.get("atr", 3.0),
            news_sentiment=news,
        )

        analysis_payload = {
            "symbol": sym,
            "metrics": summary,
            "consensus": consensus,
            "risk_sentinel": sentinel,
            "vision": vision,
            "news": news,
            "memory": memory,
        }

        pdf_bytes = generate_investment_memo_pdf(sym, analysis_payload)
        filename = f"{sym}_Investment_Memo.pdf"

        return Response(
            content=pdf_bytes,
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={filename}"},
        )
    except Exception as e:
        logger.error(f"PDF Memo generation failed: {e}")
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/api/copilot/chat")
def copilot_chat(payload: CopilotChatRequest, db: Session = Depends(get_db)):
    """Synthesizes natural language query with live quantitative hedge fund state."""
    try:
        user = get_or_create_default_user(db)
        uid = payload.user_id or user.id
        engine = broker_manager.get_engine_for_user(db, uid)

        acc = engine.get_account_summary()
        positions = engine.get_open_positions()

        sym = (payload.symbol or "NVDA").upper().strip()
        summary = tech_engine.generate_technical_summary(sym)

        portfolio_context = {
            "account": acc,
            "positions": positions,
        }

        symbol_context = {
            "symbol": sym,
            "current_price": summary.get("current_price"),
            "rsi": summary.get("rsi"),
            "quant_score": summary.get("quant_score"),
            "trend": summary.get("trend"),
            "consensus_action": "BUY" if summary.get("quant_score", 0) > 0.2 else "HOLD",
        }

        res = copilot_engine.chat(
            user_message=payload.message,
            portfolio_context=portfolio_context,
            symbol_context=symbol_context,
        )
        return {"success": True, "data": res}
    except Exception as e:
        return {"success": False, "error": str(e)}


def pd_notna(val: Any) -> bool:
    if val is None:
        return False
    try:
        import math
        return not math.isnan(float(val))
    except (ValueError, TypeError):
        return True


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
