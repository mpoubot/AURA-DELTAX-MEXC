﻿"""
AlphaSwarm Sovereign: Self-Reflective Post-Mortem Trade Memory Engine
Maintains persistent episodic and semantic memory of past trade decisions,
exit outcomes (Take-Profit vs Stop-Loss), and retrospective advisories.
"""

import os
import sqlite3
import json
from datetime import datetime, timedelta
from typing import Any, Dict, List, Optional

DB_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "trades_memory.db")


class MemoryEngine:
    """
    Episodic Trade Memory and Retrospective Learning Loop.
    """

    def __init__(self, db_path: str = DB_PATH):
        self.db_path = db_path
        self._init_db()
        self._seed_default_memories()

    def _get_connection(self):
        return sqlite3.connect(self.db_path)

    def _init_db(self):
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                CREATE TABLE IF NOT EXISTS trade_memories (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    entry_price REAL NOT NULL,
                    exit_price REAL NOT NULL,
                    outcome TEXT NOT NULL, -- 'PROFIT_TP' | 'LOSS_SL' | 'BREAKEVEN'
                    pnl_pct REAL NOT NULL,
                    trade_date TEXT NOT NULL,
                    post_mortem_note TEXT NOT NULL,
                    advisory_rule TEXT NOT NULL,
                    strategy_adjustment TEXT NOT NULL
                )
            """)
            conn.commit()

    def _seed_default_memories(self):
        """Seed realistic historical trade reflections if table is empty."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM trade_memories")
            count = cursor.fetchone()[0]
            if count == 0:
                seeds = [
                    (
                        "NVDA",
                        118.20,
                        127.80,
                        "PROFIT_TP",
                        8.12,
                        (datetime.utcnow() - timedelta(days=14)).strftime("%Y-%m-%d"),
                        "Rally triggered by AI datacenter demand surge; broke above SMA 20 with clean volume expansion.",
                        "Positive momentum channel validated. Maintain 3.0x ATR profit target on Golden Cross setups.",
                        "CONFIDENCE_BOOST: Standard position sizing approved for NVDA.",
                    ),
                    (
                        "NVDA",
                        132.50,
                        128.10,
                        "LOSS_SL",
                        -3.32,
                        (datetime.utcnow() - timedelta(days=5)).strftime("%Y-%m-%d"),
                        "False breakout above $132 supply wall. RSI hit 76 overbought before broad tech profit-taking.",
                        "Warning: High overhead supply near all-time high. Require RSI < 70 and tighter Stop-Loss on re-entry.",
                        "RISK_PENALTY: Enforce strict 1.5x ATR stop buffer on NVDA breakouts.",
                    ),
                    (
                        "TSLA",
                        228.00,
                        216.50,
                        "LOSS_SL",
                        -5.04,
                        (datetime.utcnow() - timedelta(days=20)).strftime("%Y-%m-%d"),
                        "Intraday volatility spiked to ATR 6.2%. Stop-loss clipped due to macroeconomic interest rate commentary.",
                        "Caution: TSLA displays excessive ATR tails during macro news weeks. Enforce circuit breaker if ATR > 5.5%.",
                        "CIRCUIT_GUARD: Require 75%+ committee confidence for TSLA trades.",
                    ),
                    (
                        "SPY",
                        542.00,
                        552.40,
                        "PROFIT_TP",
                        1.92,
                        (datetime.utcnow() - timedelta(days=10)).strftime("%Y-%m-%d"),
                        "Systematic index mean-reversion off 50-day moving average support executed flawlessly.",
                        "Index ETF dip-buying retains 82% win rate when RSI > 40 on 4-hour timeframe.",
                        "STRATEGY_ALIGN: Standard size with 1:2 R:R bracket.",
                    ),
                    (
                        "AAPL",
                        230.50,
                        224.20,
                        "LOSS_SL",
                        -2.73,
                        (datetime.utcnow() - timedelta(days=18)).strftime("%Y-%m-%d"),
                        "Choppy rangebound action resulted in time-decay and support breach below 20-day average.",
                        "Avoid buying AAPL during tight Bollinger Band compression without confirmed breakout volume.",
                        "VOLUME_GATE: Require volume > 1.2x 20-day average.",
                    ),
                ]
                cursor.executemany("""
                    INSERT INTO trade_memories 
                    (symbol, entry_price, exit_price, outcome, pnl_pct, trade_date, post_mortem_note, advisory_rule, strategy_adjustment)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, seeds)
                conn.commit()

    def get_symbol_memory(self, symbol: str) -> Dict[str, Any]:
        """
        Retrieves retrospective trade history, win-rate, and active advisory for symbol.
        """
        symbol = symbol.upper().strip()
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                SELECT symbol, entry_price, exit_price, outcome, pnl_pct, trade_date, post_mortem_note, advisory_rule, strategy_adjustment
                FROM trade_memories
                WHERE symbol = ?
                ORDER BY id DESC
            """, (symbol,))
            rows = cursor.fetchall()

        if not rows:
            return {
                "symbol": symbol,
                "total_trades": 0,
                "win_rate_pct": 100.0,
                "net_pnl_pct": 0.0,
                "advisory": f"No previous trade scars recorded for {symbol}. Standard fiduciary baseline active.",
                "strategy_adjustment": "BASELINE: Default 2% equity risk allocation.",
                "recent_history": [],
            }

        history = []
        wins = 0
        total_pnl = 0.0
        for r in rows:
            is_win = r[3] == "PROFIT_TP"
            if is_win:
                wins += 1
            total_pnl += r[4]
            history.append({
                "symbol": r[0],
                "entry_price": r[1],
                "exit_price": r[2],
                "outcome": r[3],
                "pnl_pct": r[4],
                "date": r[5],
                "post_mortem": r[6],
                "advisory": r[7],
                "adjustment": r[8],
            })

        latest = history[0]
        win_rate = round((wins / len(history)) * 100, 1)

        return {
            "symbol": symbol,
            "total_trades": len(history),
            "win_rate_pct": win_rate,
            "net_pnl_pct": round(total_pnl, 2),
            "advisory": latest["advisory"],
            "strategy_adjustment": latest["adjustment"],
            "latest_post_mortem": latest["post_mortem"],
            "recent_history": history[:4],
        }

    def record_trade_memory(
        self,
        symbol: str,
        entry_price: float,
        exit_price: float,
        outcome: str,
        pnl_pct: float,
        post_mortem_note: str,
        advisory_rule: str,
        strategy_adjustment: str,
    ):
        """Records a new post-mortem retrospective memory into persistent store."""
        with self._get_connection() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO trade_memories 
                (symbol, entry_price, exit_price, outcome, pnl_pct, trade_date, post_mortem_note, advisory_rule, strategy_adjustment)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                symbol.upper().strip(),
                round(entry_price, 2),
                round(exit_price, 2),
                outcome,
                round(pnl_pct, 2),
                datetime.utcnow().strftime("%Y-%m-%d"),
                post_mortem_note,
                advisory_rule,
                strategy_adjustment,
            ))
            conn.commit()
