﻿"""
AlphaSwarm Sovereign: Multi-Agent Consensus Debate Engine
Orchestrates Bull Researcher vs. Bear Skeptic debates and synthesizes consensus
via the Portfolio Manager agent using Google Gemini with an institutional quantitative fallback.
"""

import json
import logging
from typing import Any, Dict, List, Optional
from config import GEMINI_API_KEY

logger = logging.getLogger(__name__)

GEMINI_AVAILABLE = False
if GEMINI_API_KEY and GEMINI_API_KEY.strip() and GEMINI_API_KEY != "your_gemini_api_key_here":
    try:
        import google.generativeai as genai
        genai.configure(api_key=GEMINI_API_KEY)
        GEMINI_AVAILABLE = True
    except Exception as e:
        logger.warning(f"Google Generative AI initialization failed: {e}")


class MultiAgentDebateEngine:
    """
    Multi-Agent architecture:
    1. Bull Researcher (Momentum & Breakout Thesis)
    2. Bear Skeptic (Risk & Overextension Thesis)
    3. Portfolio Manager Consensus (Moderator & Execution Arbiter)
    """

    def __init__(self, api_key: Optional[str] = None):
        self.api_key = api_key or GEMINI_API_KEY
        self.gemini_active = GEMINI_AVAILABLE and bool(self.api_key and self.api_key != "your_gemini_api_key_here")

    def run_debate(self, technical_summary: Dict[str, Any]) -> Dict[str, Any]:
        """
        Executes a 3-agent consensus debate on the target asset.
        """
        symbol = technical_summary.get("symbol", "UNKNOWN")

        if self.gemini_active:
            try:
                return self._run_gemini_debate(technical_summary)
            except Exception as e:
                logger.error(f"Gemini multi-agent debate error: {e}. Switching to deterministic quant fallback.")

        return self._run_algorithmic_consensus(technical_summary)

    def _run_gemini_debate(self, tech: Dict[str, Any]) -> Dict[str, Any]:
        """
        Invokes Google Gemini model with structured multi-agent prompt and JSON response format.
        """
        import google.generativeai as genai

        model = genai.GenerativeModel("gemini-1.5-flash")
        
        prompt = f"""
You are AlphaSwarm Sovereign, an institutional Multi-Agent Hedge Fund Consensus Engine.
Analyze the following technical and quantitative market data for ticker {tech.get('symbol')}:

Market Data Summary:
- Current Price: ${tech.get('current_price')}
- RSI (14): {tech.get('rsi')} ({tech.get('rsi_status')})
- Trend: {tech.get('trend')}
- SMA 20: ${tech.get('sma_20')} | SMA 50: ${tech.get('sma_50')} ({tech.get('cross_signal')})
- MACD: {tech.get('macd')} (Signal: {tech.get('macd_signal')}, Hist: {tech.get('macd_hist')})
- Bollinger Bands: Upper ${tech.get('bb_upper')}, Mid ${tech.get('bb_middle')}, Lower ${tech.get('bb_lower')}
- ATR Volatility: ${tech.get('atr')} ({tech.get('atr_pct')}% - {tech.get('volatility_status')})
- Quant Momentum Score: {tech.get('quant_score')} (-1.0 Bearish to +1.0 Bullish)

Execute an intense, evidence-based debate among 3 agents:
1. Agent 1: "Bull Researcher" (Aggressive growth, momentum, upside targets)
2. Agent 2: "Bear Skeptic" (Risk management, trap detection, macro vulnerabilities)
3. Agent 3: "Portfolio Manager" (Final Arbiter, synthesizing consensus, setting action BUY/SELL/HOLD and confidence 0-100%)

Respond ONLY in valid JSON format matching this exact schema:
{{
  "action": "BUY" | "SELL" | "HOLD",
  "confidence_score": 0-100,
  "summary_verdict": "One sentence summary of the trade committee verdict",
  "debate_transcript": [
    {{"speaker": "Bull Researcher", "avatar": "🐂", "text": "..."}},
    {{"speaker": "Bear Skeptic", "avatar": "🐻", "text": "..."}},
    {{"speaker": "Bull Researcher (Rebuttal)", "avatar": "🐂", "text": "..."}},
    {{"speaker": "Bear Skeptic (Closing)", "avatar": "🐻", "text": "..."}},
    {{"speaker": "Portfolio Manager (Consensus)", "avatar": "🏛️", "text": "..."}}
  ],
  "rationale": [
    "Key rationale point 1",
    "Key rationale point 2",
    "Key rationale point 3"
  ]
}}
"""
        response = model.generate_content(
            prompt,
            generation_config={"response_mime_type": "application/json"}
        )
        return json.loads(response.text.strip())

    def _run_algorithmic_consensus(self, tech: Dict[str, Any]) -> Dict[str, Any]:
        """
        High-fidelity deterministic institutional simulation when LLM API is unavailable.
        """
        symbol = tech.get("symbol", "ASSET")
        price = tech.get("current_price", 100.0)
        rsi = tech.get("rsi", 50.0)
        quant_score = tech.get("quant_score", 0.0)
        trend = tech.get("trend", "NEUTRAL")
        cross = tech.get("cross_signal", "NEUTRAL")
        atr_pct = tech.get("atr_pct", 2.0)
        macd_hist = tech.get("macd_hist", 0.0)

        if quant_score >= 0.35 and rsi < 72 and atr_pct < 6.0:
            action = "BUY"
            base_conf = 72 + int(quant_score * 20)
            confidence = min(94, base_conf)
            summary = f"Strong multi-factor alignment favors LONG position on {symbol} with controlled downside."
        elif quant_score <= -0.25 or rsi > 78:
            action = "SELL"
            confidence = min(90, 68 + int(abs(quant_score) * 25))
            summary = f"Defensive stance triggered; overbought readings or deteriorating moving averages warrant SELL / TRIM on {symbol}."
        else:
            action = "HOLD"
            confidence = 58
            summary = f"Mixed quantitative signals on {symbol}. Capital preservation protocol recommends HOLD."

        transcript = [
            {
                "speaker": "Bull Researcher",
                "avatar": "🐂",
                "text": f"Examining {symbol} at ${price:.2f}. We observe a solid technical backdrop with {trend} and MACD histogram at {macd_hist:+.2f}. RSI is sitting at {rsi:.1f}, providing room for expansion without instant overbought penalty. The moving average alignment ({cross}) reinforces our upward structural channel.",
            },
            {
                "speaker": "Bear Skeptic",
                "avatar": "🐻",
                "text": f"Caution is warranted. While momentum appears promising, ATR volatility is running at {atr_pct:.2f}%. Resistance near the upper Bollinger Band (${tech.get('bb_upper', price * 1.05):.2f}) presents an immediate supply wall. Any sudden macro liquidity shift could trigger a swift mean reversion towards SMA 50 (${tech.get('sma_50', price * 0.95):.2f}).",
            },
            {
                "speaker": "Bull Researcher (Rebuttal)",
                "avatar": "🐂",
                "text": f"The risk is asymmetric in our favor. Support at SMA 20 (${tech.get('sma_20', price * 0.98):.2f}) provides an institutional floor. By setting a disciplined bracket stop-loss at 1.5x ATR, we restrict downside to less than 2% while capturing a 3.0x ATR rally.",
            },
            {
                "speaker": "Bear Skeptic (Closing)",
                "avatar": "🐻",
                "text": "If the committee proceeds, strict position sizing and absolute adherence to the Risk Sentinel's circuit breakers must be non-negotiable.",
            },
            {
                "speaker": "Portfolio Manager (Consensus)",
                "avatar": "🏛️",
                "text": f"Debate evaluated. Quant conviction score stands at {quant_score:+.2f}. Action: {action} with {confidence}% committee consensus. Handing order parameters to Risk Sentinel for institutional execution validation.",
            },
        ]

        rationale = [
            f"Technical momentum score computed at {quant_score:+.2f} with {trend}.",
            f"RSI reading at {rsi:.1f} ({tech.get('rsi_status', 'NEUTRAL')}).",
            f"Volatility regime: ATR {atr_pct:.2f}% satisfies institutional risk boundaries.",
            f"Consensus outcome: {action} with {confidence}% committee confidence.",
        ]

        return {
            "action": action,
            "confidence_score": confidence,
            "summary_verdict": summary,
            "debate_transcript": transcript,
            "rationale": rationale,
        }
