"""
Trading Pipeline MCP Server

Exposes trading system data to Hermes via MCP protocol.
Runs on airig:8101, accessible from sparkier.

Tools exposed:
  - get_daily_predictions: Today's sector predictions with confidence
  - get_sector_calibration: Win rates and calibration adjustments
  - get_recent_signals: Latest scored news signals from Qdrant
  - get_portfolio_state: Current positions, cash, P&L
  - get_active_rules: Top inference rules being applied
  - get_critic_verdicts: Recent prediction critic decisions
  - get_sector_breakers: Which sectors are paused and why
  - validate_trade: Run a proposed trade through all portfolio gates
  - execute_trade: Validate and execute a trade (gates must pass)
"""

import sqlite3
import json
import os
import logging
import sys
from datetime import datetime, timezone, timedelta
from pathlib import Path

# Ensure pipeline directory is in path for imports
_pipeline_dir = str(Path(__file__).parent.parent)
if _pipeline_dir not in sys.path:
    sys.path.insert(0, _pipeline_dir)

from mcp.server.fastmcp import FastMCP
from portfolio.market_calendar import is_trading_day
from portfolio.vix_gate import get_vix_gate
from alpaca_feed.data import get_live_prices

log = logging.getLogger(__name__)

mcp = FastMCP("Trading Pipeline", host="0.0.0.0", port=8101)

PAPER_DB     = Path("/home/trading/trading-ai/data/paper_trading.db")
PORTFOLIO_DB = Path("/home/trading/trading-ai/data/portfolio.db")
RULES_DB     = Path("/home/trading/trading-ai/data/rules.db")
LESSONS_DB   = Path("/home/trading/trading-ai/data/lessons.db")


@mcp.tool()
def get_daily_predictions() -> str:
    """
    Get today's sector predictions from the AI pipeline.
    Returns direction, confidence, and critic verdict for each sector.
    """
    conn = sqlite3.connect(PAPER_DB)
    today = datetime.now(timezone.utc).strftime('%Y-%m-%d')
    rows = conn.execute("""
        SELECT query, direction, confidence, critic_verdict, critic_reasoning,
               reasoning_summary, created_at
        FROM predictions
        WHERE date(created_at) = ? AND was_correct IS NULL
        ORDER BY created_at DESC
    """, (today,)).fetchall()
    conn.close()

    if not rows:
        return json.dumps({"error": "No predictions found for today", "date": today})

    predictions = []
    for r in rows:
        query = r[0]
        sector = query.split('—')[0].strip() if '—' in query else query[:40]
        predictions.append({
            "sector":         sector,
            "direction":      r[1],
            "confidence":     f"{r[2]:.0%}",
            "critic_verdict": r[3] or "pending",
            "critic_note":    r[4][:100] if r[4] else "",
            "summary":        r[5][:150] if r[5] else "",
            "generated_at":   r[6][:16],
        })

    return json.dumps({
        "date": today,
        "predictions": predictions,
        "count": len(predictions),
        "actionable": [p for p in predictions
                       if float(p["confidence"].strip('%'))/100 >= 0.70
                       and p["critic_verdict"] != "reject"]
    }, indent=2)


@mcp.tool()
def get_sector_calibration() -> str:
    """
    Get sector win rates and calibration adjustments.
    Shows which sectors the AI has been accurate on historically.
    """
    conn = sqlite3.connect(PAPER_DB)
    rows = conn.execute("""
        SELECT
            CASE
                WHEN query LIKE '%energy%' THEN 'energy'
                WHEN query LIKE '%technology%' OR query LIKE '%semiconductor%' THEN 'technology'
                WHEN query LIKE '%financial%' OR query LIKE '%bank%' THEN 'financials'
                WHEN query LIKE '%healthcare%' OR query LIKE '%biotech%' THEN 'healthcare'
                WHEN query LIKE '%materials%' OR query LIKE '%mining%' THEN 'materials'
                WHEN query LIKE '%industrial%' THEN 'industrials'
                WHEN query LIKE '%consumer%' THEN 'consumer'
                ELSE 'market_overview'
            END as sector,
            COUNT(*) as total,
            SUM(CASE WHEN was_correct=1 THEN 1 ELSE 0 END) as correct
        FROM predictions
        WHERE was_correct IS NOT NULL
        GROUP BY sector
        ORDER BY correct*1.0/COUNT(*) DESC
    """).fetchall()
    conn.close()

    calibration = []
    for r in rows:
        sector, total, correct = r
        win_rate = correct / total if total > 0 else 0
        if win_rate < 0.35:
            adj = -0.20
        elif win_rate < 0.45:
            adj = -0.10
        elif win_rate > 0.55:
            adj = +0.05
        else:
            adj = 0.0

        calibration.append({
            "sector":     sector,
            "win_rate":   f"{win_rate:.0%}",
            "correct":    f"{correct}/{total}",
            "adjustment": f"{adj:+.2f}",
            "status":     "strong" if win_rate > 0.55 else
                          "weak" if win_rate < 0.35 else "average"
        })

    return json.dumps({"sector_calibration": calibration}, indent=2)


@mcp.tool()
def get_portfolio_state() -> str:
    """
    Get current portfolio state: positions, cash, P&L, sector exposure.
    """
    conn = sqlite3.connect(PORTFOLIO_DB)

    cash_row = conn.execute(
        "SELECT balance FROM cash_ledger ORDER BY id DESC LIMIT 1"
    ).fetchone()
    cash = cash_row[0] if cash_row else 0

    positions = conn.execute("""
        SELECT ticker, sector, shares, entry_price, current_price,
               stop_loss, tiers_triggered, entry_date
        FROM positions WHERE status='open'
        ORDER BY entry_date
    """).fetchall()

    pos_list = []
    total_pos_value = 0
    for p in positions:
        current = p[4] or p[3]
        value = p[2] * current
        pnl_pct = (current - p[3]) / p[3] * 100
        total_pos_value += value
        pos_list.append({
            "ticker":     p[0],
            "sector":     p[1],
            "shares":     p[2],
            "entry":      f"${p[3]:.2f}",
            "current":    f"${current:.2f}",
            "pnl_pct":    f"{pnl_pct:+.1f}%",
            "value":      f"${value:.2f}",
            "stop":       f"${p[5]:.2f}",
            "tiers":      p[6] or 0,
            "held_since": p[7][:10],
        })

    total = cash + total_pos_value
    conn.close()

    return json.dumps({
        "cash":            f"${cash:,.2f}",
        "positions_value": f"${total_pos_value:,.2f}",
        "total":           f"${total:,.2f}",
        "return_pct":      f"{(total-100000)/100000*100:+.2f}%",
        "open_positions":  len(pos_list),
        "positions":       pos_list,
        "cash_pct":        f"{cash/total*100:.0f}%" if total > 0 else "100%",
    }, indent=2)


@mcp.tool()
def get_sector_breakers() -> str:
    """
    Get sector circuit breaker status — which sectors are paused due to losses.
    """
    conn = sqlite3.connect(PORTFOLIO_DB)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()

    sectors = ['technology', 'healthcare', 'energy', 'defense',
               'financials', 'consumer', 'materials', 'industrials']

    breakers = []
    for sector in sectors:
        stops = conn.execute("""
            SELECT COUNT(*), GROUP_CONCAT(ticker || ' (' || pnl_pct || '%)', ', ')
            FROM positions
            WHERE sector=? AND status='closed'
              AND exit_reason LIKE 'stop_loss%'
              AND exit_date >= ?
        """, (sector, cutoff)).fetchone()

        count = stops[0] if stops else 0
        tickers = stops[1] if stops and stops[1] else ""
        paused = count >= 2

        breakers.append({
            "sector":   sector,
            "stops_7d": count,
            "paused":   paused,
            "reason":   f"{tickers}" if paused else "open for entries",
        })

    conn.close()
    return json.dumps({
        "sector_breakers": breakers,
        "paused_count": sum(1 for b in breakers if b["paused"]),
    }, indent=2)


@mcp.tool()
def get_recent_signals(sector: str = "", limit: int = 5) -> str:
    """
    Get recent high-confidence signals from the news pipeline.
    Optionally filter by sector (energy, technology, healthcare, etc.)
    """
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import Filter, FieldCondition, MatchText

        client = QdrantClient(host="localhost", port=6333)

        filter_conditions = None
        if sector:
            filter_conditions = Filter(
                must=[FieldCondition(key="sectors", match=MatchText(text=sector))]
            )

        # Filter to last 7 days only
        from qdrant_client.models import DatetimeRange
        from datetime import datetime, timezone, timedelta
        cutoff = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()

        recency_condition = FieldCondition(
            key="published",
            range=DatetimeRange(gte=cutoff)
        )

        if filter_conditions:
            filter_conditions.must.append(recency_condition)
        else:
            filter_conditions = Filter(must=[recency_condition])

        results = client.scroll(
            collection_name="trading_signals",
            scroll_filter=filter_conditions,
            limit=limit,
            with_payload=True,
            order_by="published"
        )

        signals = []
        for point in results[0]:
            p = point.payload
            signals.append({
                "title":     p.get("title", "")[:80],
                "source":    p.get("source", ""),
                "sentiment": p.get("sentiment", ""),
                "confidence": p.get("confidence", 0),
                "sectors":   p.get("sectors", []),
                "tickers":   p.get("tickers", []),
                "themes":    p.get("macro_themes", [])[:3],
            })

        return json.dumps({
            "sector_filter": sector or "all",
            "signals": signals,
            "count": len(signals)
        }, indent=2)

    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def get_active_rules(limit: int = 10) -> str:
    """
    Get the top active inference rules the system has learned.
    These rules were discovered through post-mortem analysis of failed predictions.
    """
    conn = sqlite3.connect(RULES_DB)
    rows = conn.execute("""
        SELECT trigger, sectors, confidence, source, created_at
        FROM inference_rules
        WHERE status='active' OR status IS NULL
        ORDER BY confidence DESC, created_at DESC
        LIMIT ?
    """, (limit,)).fetchall()

    total = conn.execute("SELECT COUNT(*) FROM inference_rules").fetchone()[0]
    conn.close()

    rules = [{"trigger": r[0], "sectors": r[1],
              "confidence": r[2], "source": r[3]} for r in rows]

    return json.dumps({"total_rules": total, "top_rules": rules}, indent=2)


@mcp.tool()
def get_critic_verdicts(days: int = 3) -> str:
    """
    Get recent prediction critic verdicts — which predictions were approved,
    challenged, or rejected and why.
    """
    conn = sqlite3.connect(PAPER_DB)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    rows = conn.execute("""
        SELECT query, direction, confidence, critic_verdict,
               critic_reasoning, critic_confidence, created_at
        FROM predictions
        WHERE critic_verdict IS NOT NULL AND critic_verdict != ''
          AND created_at >= ?
        ORDER BY created_at DESC
        LIMIT 20
    """, (cutoff,)).fetchall()
    conn.close()

    verdicts = []
    for r in rows:
        sector = r[0].split('—')[0].strip()[:30]
        verdicts.append({
            "sector":        sector,
            "direction":     r[1],
            "original_conf": f"{r[2]:.0%}",
            "verdict":       r[3],
            "adjusted_conf": f"{r[5]:.0%}" if r[5] else "same",
            "reason":        r[4][:120] if r[4] else "",
            "time":          r[6][:16],
        })

    summary = {v: sum(1 for x in verdicts if x["verdict"] == v)
               for v in ["approve", "challenge", "reject"]}

    return json.dumps({
        "days": days,
        "summary": summary,
        "verdicts": verdicts
    }, indent=2)


@mcp.tool()
def validate_trade(ticker: str, shares: float, side: str = "buy") -> str:
    """
    Validate a proposed trade against all portfolio gates.
    Returns gate-by-gate approval status and reasoning.
    Use this before execute_trade to understand why a trade may be rejected.
    """
    gates = []
    approved = True

    # Get current price
    try:
        prices = get_live_prices([ticker])
        price = prices.get(ticker)
    except Exception:
        price = None

    value = round(shares * price, 2) if price else None

    # Gate 1: Market hours
    try:
        trading_day = is_trading_day()
    except Exception:
        trading_day = True  # assume open if check fails

    if not trading_day:
        from datetime import date
        gates.append({
            "gate": "Market Hours",
            "pass": False,
            "reason": f"Market is closed today ({date.today()})"
        })
        approved = False
    else:
        gates.append({"gate": "Market Hours", "pass": True,
                      "reason": "Market is open"})

    if side.lower() == "buy":
        conn = sqlite3.connect(PORTFOLIO_DB)

        # Gate 2: Portfolio circuit breaker
        snaps = conn.execute("""
            SELECT total_value FROM portfolio_snapshots
            ORDER BY snapshot_at DESC LIMIT 10
        """).fetchall()
        if snaps:
            peak = max(s[0] for s in snaps)
            current_val = snaps[0][0]
            drawdown = (peak - current_val) / peak
            if drawdown >= 0.05:
                gates.append({
                    "gate": "Portfolio Circuit Breaker",
                    "pass": False,
                    "reason": f"Portfolio down {drawdown:.1%} from peak — all entries paused"
                })
                approved = False
            else:
                gates.append({"gate": "Portfolio Circuit Breaker", "pass": True,
                              "reason": f"Drawdown {drawdown:.1%} within limit"})

        # Gate 3: Position size (max 10% of portfolio)
        if value:
            cash_row = conn.execute(
                "SELECT balance FROM cash_ledger ORDER BY id DESC LIMIT 1"
            ).fetchone()
            cash = cash_row[0] if cash_row else 0
            max_position = cash * 0.10
            if value > max_position:
                gates.append({
                    "gate": "Position Size",
                    "pass": False,
                    "reason": f"${value:,.0f} exceeds 10% max position size (${max_position:,.0f} of ${cash:,.0f} cash)"
                })
                approved = False
            else:
                gates.append({"gate": "Position Size", "pass": True,
                              "reason": f"${value:,.0f} within 10% limit"})

        # Gate 4: Sector circuit breaker
        sector_map = {
            'XLK': 'technology', 'NVDA': 'technology', 'AAPL': 'technology',
            'MSFT': 'technology', 'AMD': 'technology', 'INTC': 'technology',
            'XLV': 'healthcare', 'UNH': 'healthcare', 'JNJ': 'healthcare',
            'XLE': 'energy', 'XOM': 'energy', 'CVX': 'energy',
            'XLF': 'financials', 'JPM': 'financials', 'BAC': 'financials',
            'XLB': 'materials', 'XLI': 'industrials', 'XLP': 'consumer',
            'ITA': 'defense', 'SPY': 'macro', 'QQQ': 'technology',
            'AMZN': 'technology', 'CRM': 'technology', 'GOOGL': 'technology',
            'META': 'technology', 'TSLA': 'technology',
        }
        sector = sector_map.get(ticker.upper(), 'unknown')

        if sector != 'unknown':
            cutoff_7d = (datetime.now(timezone.utc) - timedelta(days=7)).isoformat()
            stops = conn.execute("""
                SELECT COUNT(*) FROM positions
                WHERE sector=? AND status='closed'
                  AND exit_reason LIKE 'stop_loss%'
                  AND exit_date >= ?
            """, (sector, cutoff_7d)).fetchone()[0]

            if stops >= 2:
                gates.append({
                    "gate": "Sector Circuit Breaker",
                    "pass": False,
                    "reason": f"{sector} sector has {stops} stop losses in last 7 days — entries paused"
                })
                approved = False
            else:
                gates.append({"gate": "Sector Circuit Breaker", "pass": True,
                              "reason": f"{sector}: {stops} stops this week, below threshold"})

        # Gate 5: Prediction confidence
        today = datetime.now(timezone.utc).strftime('%Y-%m-%d')
        if sector and sector != 'unknown':
            paper_conn = sqlite3.connect(PAPER_DB)
            pred = paper_conn.execute("""
                SELECT direction, confidence, critic_verdict FROM predictions
                WHERE query LIKE ? AND date(created_at) = ?
                  AND was_correct IS NULL
                ORDER BY created_at DESC LIMIT 1
            """, (f'%{sector}%', today)).fetchone()
            paper_conn.close()

            if pred:
                direction, confidence, verdict = pred
                if confidence < 0.70:
                    gates.append({
                        "gate": "Prediction Confidence",
                        "pass": False,
                        "reason": f"{sector}: {direction} {confidence:.0%} — below 0.70 threshold (critic: {verdict})"
                    })
                    approved = False
                else:
                    gates.append({"gate": "Prediction Confidence", "pass": True,
                                  "reason": f"{sector}: {direction} {confidence:.0%} ≥ 0.70"})
            else:
                gates.append({
                    "gate": "Prediction Confidence",
                    "pass": False,
                    "reason": f"No prediction found for {sector} today"
                })
                approved = False

        # Gate 6: Weekly trade limit
        week_start = datetime.now(timezone.utc)
        week_start = week_start - timedelta(days=week_start.weekday())
        week_start = week_start.replace(hour=0, minute=0, second=0, microsecond=0)
        week_buys = conn.execute("""
            SELECT COUNT(*) FROM transactions
            WHERE action='BUY' AND timestamp >= ?
        """, (week_start.isoformat(),)).fetchone()[0]

        if week_buys >= 5:
            gates.append({
                "gate": "Weekly Trade Limit",
                "pass": False,
                "reason": f"Weekly limit reached ({week_buys}/5 trades this week)"
            })
            approved = False
        else:
            gates.append({"gate": "Weekly Trade Limit", "pass": True,
                          "reason": f"{week_buys}/5 trades used this week"})

        # Gate 7: VIX
        try:
            vix = get_vix_gate()
            if vix['action'] == 'pause':
                gates.append({"gate": "VIX Gate", "pass": False,
                              "reason": vix['reason']})
                approved = False
            else:
                gates.append({"gate": "VIX Gate", "pass": True,
                              "reason": vix['reason']})
        except Exception:
            gates.append({"gate": "VIX Gate", "pass": True,
                          "reason": "VIX check unavailable — proceeding"})

        conn.close()

    passed = sum(1 for g in gates if g["pass"])
    total_gates = len(gates)

    return json.dumps({
        "ticker":   ticker,
        "shares":   shares,
        "side":     side,
        "price":    f"${price:.2f}" if price else "unknown",
        "value":    f"${value:,.2f}" if value else "unknown",
        "approved": approved,
        "summary":  f"{passed}/{total_gates} gates passed",
        "gates":    gates,
        "verdict":  "APPROVED — trade meets all system requirements" if approved
                    else "REJECTED — trade does not meet system requirements"
    }, indent=2)


@mcp.tool()
def execute_trade(ticker: str, shares: float, side: str = "buy") -> str:
    """
    Execute a trade through the portfolio management system.
    Runs all gates via validate_trade first — only places order if ALL gates pass.
    This is the ONLY correct way to place orders through Hermes.
    """
    # Step 1: Run validation
    validation = json.loads(validate_trade(ticker, shares, side))

    if not validation['approved']:
        failed = [g for g in validation['gates'] if not g['pass']]
        return json.dumps({
            "status":      "REJECTED",
            "ticker":      ticker,
            "shares":      shares,
            "side":        side,
            "message":     f"Trade rejected — {len(failed)} gate(s) failed",
            "failed_gates": failed,
            "all_gates":   validation['gates'],
            "action":      "No order placed. Address the failed gates before retrying."
        }, indent=2)

    # Step 2: All gates passed — place the order
    try:
        from alpaca_feed.trading_hackathon import place_market_order
        result = place_market_order(
            ticker, shares, side,
            reason=f"Hermes-initiated {side} — all gates passed"
        )

        if result.get('success'):
            return json.dumps({
                "status":       "EXECUTED",
                "ticker":       ticker,
                "shares":       shares,
                "side":         side,
                "order_id":     result.get('order_id'),
                "alpaca_status": result.get('status'),
                "gates_passed": validation['summary'],
                "message":      "Order placed successfully via Alpaca paper account"
            }, indent=2)
        else:
            return json.dumps({
                "status":  "FAILED",
                "ticker":  ticker,
                "error":   result.get('error'),
                "message": "All gates passed but Alpaca order failed"
            }, indent=2)

    except Exception as e:
        return json.dumps({
            "status": "ERROR",
            "ticker": ticker,
            "error":  str(e)
        }, indent=2)



@mcp.tool()
def get_latest_weekly_report() -> str:
    """
    Get the most recent weekly performance report.
    Contains P&L, win rate, sector breakdown, key mistakes, and lessons learned.
    Use this for deeper analysis before approving trade recommendations.
    """
    import glob
    report_dir = Path("/mnt/qnap/timeseries/reports/weekly")
    reports = sorted(glob.glob(str(report_dir / "*.md")))
    if not reports:
        return json.dumps({"error": "No weekly reports found"})
    latest = reports[-1]
    content = Path(latest).read_text()
    filename = Path(latest).name
    date = filename.replace("_weekly.md", "")
    return json.dumps({
        "report_date": date,
        "filename": filename,
        "content": content[:8000]  # cap at 8K chars
    }, indent=2)


@mcp.tool()
def get_latest_monthly_report() -> str:
    """
    Get the most recent monthly performance report.
    Contains comprehensive P&L analysis, prediction accuracy by sector,
    key mistakes, root causes, and strategic recommendations.
    Essential for long-term trend analysis before major decisions.
    """
    import glob
    report_dir = Path("/mnt/qnap/timeseries/reports/monthly")
    reports = sorted(glob.glob(str(report_dir / "*.md")))
    if not reports:
        return json.dumps({"error": "No monthly reports found"})
    latest = reports[-1]
    content = Path(latest).read_text()
    filename = Path(latest).name
    date = filename.replace("_monthly.md", "")
    return json.dumps({
        "report_date": date,
        "filename": filename,
        "content": content[:12000]  # cap at 12K chars
    }, indent=2)


@mcp.tool()
def get_trade_history(days: int = 30) -> str:
    """
    Get recent closed trade history with outcomes.
    Shows what worked, what didn't, and patterns across sectors.
    Use this alongside reports for trade approval decisions.
    """
    conn = sqlite3.connect(PORTFOLIO_DB)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
    rows = conn.execute("""
        SELECT ticker, sector, shares, entry_price, exit_price,
               pnl, exit_reason, entry_date, exit_date
        FROM positions
        WHERE status='closed' AND exit_date >= ?
        ORDER BY exit_date DESC
        LIMIT 30
    """, (cutoff,)).fetchall()
    conn.close()

    trades = []
    for r in rows:
        pnl_pct = ((r[4] - r[3]) / r[3] * 100) if r[3] and r[4] else 0
        trades.append({
            "ticker":      r[0],
            "sector":      r[1],
            "shares":      r[2],
            "entry":       f"${r[3]:.2f}",
            "exit":        f"${r[4]:.2f}" if r[4] else "open",
            "pnl":         f"${r[5]:+.2f}" if r[5] else "$0",
            "pnl_pct":     f"{pnl_pct:+.1f}%",
            "exit_reason": r[6] or "",
            "held":        f"{r[7][:10]} → {r[8][:10]}" if r[8] else r[7][:10],
            "outcome":     "WIN" if (r[5] or 0) > 0 else "LOSS"
        })

    wins = sum(1 for t in trades if t["outcome"] == "WIN")
    total_pnl = sum(float(t["pnl"].replace("$","").replace("+","")) for t in trades)

    return json.dumps({
        "days": days,
        "total_trades": len(trades),
        "wins": wins,
        "losses": len(trades) - wins,
        "win_rate": f"{wins/len(trades)*100:.0f}%" if trades else "0%",
        "total_pnl": f"${total_pnl:+.2f}",
        "trades": trades
    }, indent=2)


@mcp.tool()
def get_organic_account_info() -> str:
    """
    Get account info for the organic trading account (account #1).
    This is the autonomous pipeline account active since May 2026.
    Use this to see the long-running portfolio history.
    """
    try:
        from alpaca.trading.client import TradingClient
        import os
        client = TradingClient(
            os.getenv("ALPACA_API_KEY"),
            os.getenv("ALPACA_SECRET_KEY"),
            paper=True
        )
        account = client.get_account()
        positions = client.get_all_positions()
        pos_list = [{
            'ticker': p.symbol,
            'qty': float(p.qty),
            'avg_cost': float(p.avg_entry_price),
            'market_value': float(p.market_value),
            'unrealized_pl': float(p.unrealized_pl),
            'unrealized_plpc': f"{float(p.unrealized_plpc)*100:+.1f}%",
            'current_price': float(p.current_price),
        } for p in positions]
        return json.dumps({
            'account': 'organic',
            'account_number': account.account_number,
            'cash': float(account.cash),
            'portfolio_value': float(account.portfolio_value),
            'positions': pos_list,
            'open_positions': len(pos_list),
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def get_hackathon_account_info() -> str:
    """
    Get account info for the hackathon demo account (PA3Y2DOOQXZW).
    This is the clean account started Aug 28, 2026 for the hackathon.
    Use this to see positions placed via Hermes or mirrored from organic.
    """
    try:
        from alpaca.trading.client import TradingClient
        import os
        client = TradingClient(
            os.getenv("ALPACA_HACKATHON_KEY"),
            os.getenv("ALPACA_HACKATHON_SECRET"),
            paper=True
        )
        account = client.get_account()
        positions = client.get_all_positions()
        pos_list = [{
            'ticker': p.symbol,
            'qty': float(p.qty),
            'avg_cost': float(p.avg_entry_price),
            'market_value': float(p.market_value),
            'unrealized_pl': float(p.unrealized_pl),
            'unrealized_plpc': f"{float(p.unrealized_plpc)*100:+.1f}%",
            'current_price': float(p.current_price),
        } for p in positions]
        return json.dumps({
            'account': 'hackathon',
            'account_number': account.account_number,
            'cash': float(account.cash),
            'portfolio_value': float(account.portfolio_value),
            'positions': pos_list,
            'open_positions': len(pos_list),
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def get_signal_ledger(days: int = 7) -> str:
    """
    Get recently rejected signals from the signal ledger.
    Shows which predictions were blocked and why — enables outcome analysis.
    Use this to evaluate whether rejected signals would have been profitable.
    """
    conn = sqlite3.connect(PAPER_DB)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    rows = conn.execute("""
        SELECT sector, direction, raw_confidence, adj_confidence,
               gate_failed, gate_reason, created_at,
               next_day_drift, was_correct
        FROM signal_ledger
        WHERE created_at >= ?
        ORDER BY created_at DESC
        LIMIT 50
    """, (cutoff,)).fetchall()
    conn.close()

    signals = []
    for r in rows:
        signals.append({
            "sector":       r[0],
            "direction":    r[1],
            "raw_conf":     f"{r[2]:.0%}",
            "adj_conf":     f"{r[3]:.0%}",
            "gate":         r[4],
            "reason":       r[5][:80] if r[5] else "",
            "time":         r[6][:16],
            "next_drift":   f"{r[7]:+.1%}" if r[7] else "pending",
            "was_correct":  r[8],
        })

    gate_counts = {}
    for s in signals:
        gate_counts[s["gate"]] = gate_counts.get(s["gate"], 0) + 1

    return json.dumps({
        "days": days,
        "total_rejected": len(signals),
        "by_gate": gate_counts,
        "signals": signals
    }, indent=2)


@mcp.tool()
def get_idle_cash_analysis() -> str:
    """
    Analyze idle cash opportunity cost.
    Shows how long cash has been uninvested and estimated yield loss vs BIL.
    Flags when cash has been idle 5+ days with no new positions opened.
    """
    conn = sqlite3.connect(PORTFOLIO_DB)

    cash_row = conn.execute(
        "SELECT balance FROM cash_ledger ORDER BY id DESC LIMIT 1"
    ).fetchone()
    cash = cash_row[0] if cash_row else 0

    # Days since last BUY
    last_buy = conn.execute("""
        SELECT MAX(entry_date) FROM positions WHERE status='open'
    """).fetchone()[0]

    if last_buy:
        from datetime import date
        last_buy_date = date.fromisoformat(last_buy[:10])
        idle_days = (date.today() - last_buy_date).days
    else:
        idle_days = 0

    # BIL yield ~4.28% annual (from weekly report shadow position)
    annual_yield = 0.0428
    daily_yield = annual_yield / 252
    lost_yield_daily = cash * daily_yield
    lost_yield_week = lost_yield_daily * 5
    lost_yield_month = lost_yield_daily * 21

    # Check open positions count
    open_count = conn.execute(
        "SELECT COUNT(*) FROM positions WHERE status='open'"
    ).fetchone()[0]
    conn.close()

    alert = idle_days >= 5 and open_count < 6

    return json.dumps({
        "cash_balance":      f"${cash:,.2f}",
        "idle_days":         idle_days,
        "open_positions":    open_count,
        "opportunity_cost": {
            "daily":   f"${lost_yield_daily:,.2f}",
            "weekly":  f"${lost_yield_week:,.2f}",
            "monthly": f"${lost_yield_month:,.2f}",
            "annual_rate": "4.28% (BIL equivalent)",
        },
        "alert": alert,
        "alert_reason": f"Cash idle {idle_days} days with only {open_count} positions" if alert else None,
        "recommendation": "Consider BIL/SHV deployment or lower confidence threshold" if alert else "Normal"
    }, indent=2)


@mcp.tool()
def get_pipeline_health() -> str:
    """
    Get a comprehensive pipeline health report.
    Shows rule counts by status, recent parse errors, signal ingestion
    rates, and any bottlenecks. Use this before creating Kanban tasks
    to verify findings with actual data.
    """
    import glob
    from pathlib import Path

    result = {}

    # Rule status breakdown
    try:
        rules_conn = sqlite3.connect("/home/trading/trading-ai/data/rules.db")
        rule_status = rules_conn.execute(
            "SELECT status, COUNT(*) FROM inference_rules GROUP BY status"
        ).fetchall()
        rules_conn.close()
        result["inference_rules"] = {row[0]: row[1] for row in rule_status}
    except Exception as e:
        result["inference_rules"] = {"error": str(e)}

    # Indirect dependencies count
    try:
        lessons_conn = sqlite3.connect("/home/trading/trading-ai/data/lessons.db")
        dep_count = lessons_conn.execute(
            "SELECT COUNT(*) FROM indirect_dependencies"
        ).fetchone()[0]
        result["indirect_dependencies"] = dep_count
        lessons_conn.close()
    except Exception as e:
        result["indirect_dependencies"] = {"error": str(e)}

    # Signal counts by day for last 7 days
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import Filter, FieldCondition, DatetimeRange
        client = QdrantClient(host="localhost", port=6333)
        signal_counts = {}
        for days_back in [1, 3, 7, 14, 30]:
            cutoff = (datetime.now(timezone.utc) - timedelta(days=days_back)).isoformat()
            count = client.count(
                collection_name="trading_signals",
                count_filter=Filter(must=[FieldCondition(
                    key="published",
                    range=DatetimeRange(gte=cutoff)
                )])
            )
            signal_counts[f"last_{days_back}_days"] = count.count
        result["qdrant_signals"] = signal_counts
    except Exception as e:
        result["qdrant_signals"] = {"error": str(e)}

    # Parse error count from score log
    try:
        score_log = Path("/mnt/qnap/timeseries/logs/score.log")
        if score_log.exists():
            lines = score_log.read_text().splitlines()
            total_errors = sum(1 for l in lines if "Parse error" in l)
            recent_errors = sum(1 for l in lines
                if "Parse error" in l and
                datetime.now().strftime("%Y-%m") in l)
            result["parse_errors"] = {
                "total_all_time": total_errors,
                "this_month": recent_errors
            }
    except Exception as e:
        result["parse_errors"] = {"error": str(e)}

    return json.dumps(result, indent=2)


@mcp.tool()
def get_prediction_accuracy(days: int = 7) -> str:
    """
    Get prediction accuracy breakdown by sector and direction for the last N days.
    Shows win rates, correct/incorrect counts, and confidence averages.
    Use this to identify which sectors are systematically over or under-performing.
    """
    conn = sqlite3.connect(PAPER_DB)
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

    rows = conn.execute("""
        SELECT
            substr(query, 1, 30) as sector_hint,
            direction,
            COUNT(*) as total,
            SUM(CASE WHEN was_correct=1 THEN 1 ELSE 0 END) as correct,
            AVG(confidence) as avg_conf,
            AVG(critic_confidence) as avg_critic_conf
        FROM predictions
        WHERE created_at >= ? AND was_correct IS NOT NULL
        GROUP BY sector_hint, direction
        ORDER BY total DESC
    """, (cutoff,)).fetchall()
    conn.close()

    sectors = []
    for r in rows:
        win_rate = r[3]/r[2] if r[2] > 0 else 0
        sectors.append({
            "sector": r[0],
            "direction": r[1],
            "total": r[2],
            "correct": r[3],
            "win_rate": f"{win_rate:.0%}",
            "avg_confidence": f"{r[4]:.0%}" if r[4] else "n/a",
            "avg_critic_confidence": f"{r[5]:.0%}" if r[5] else "n/a",
        })

    return json.dumps({
        "days": days,
        "sectors": sectors,
        "total_predictions": sum(s["total"] for s in sectors),
        "overall_win_rate": f"{sum(s['correct'] for s in sectors)/max(sum(s['total'] for s in sectors),1):.0%}"
    }, indent=2)


@mcp.tool()
def get_indirect_dependencies(limit: int = 30) -> str:
    """
    Get the current indirect dependency rules — cross-sector and cross-ticker
    causal relationships the system has learned.
    Use this during causality analysis to avoid proposing duplicate rules.
    """
    try:
        conn = sqlite3.connect("/home/trading/trading-ai/data/lessons.db")
        rows = conn.execute("""
            SELECT id, from_entity, to_entity, relationship, confidence, occurrences, last_seen
            FROM indirect_dependencies
            ORDER BY confidence DESC, occurrences DESC
            LIMIT ?
        """, (limit,)).fetchall()
        conn.close()

        deps = [{
            "id": r[0],
            "from": r[1],
            "to": r[2],
            "relationship": r[3][:120],
            "confidence": r[4],
            "occurrences": r[5],
            "last_seen": r[6][:10] if r[6] else None
        } for r in rows]

        return json.dumps({
            "total_rules": len(deps),
            "dependencies": deps
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def get_signal_event_breakdown(days: int = 7) -> str:
    """
    Get a breakdown of recent signals by event_type and source.
    Use this during signal classification review to identify
    how many signals are tagged as 'other' vs specific categories.
    """
    try:
        from qdrant_client import QdrantClient
        from qdrant_client.models import Filter, FieldCondition, DatetimeRange
        client = QdrantClient(host="localhost", port=6333)
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

        results, _ = client.scroll(
            collection_name="trading_signals",
            limit=2000,
            with_payload=True,
            scroll_filter=Filter(must=[FieldCondition(
                key="published",
                range=DatetimeRange(gte=cutoff)
            )])
        )

        from collections import Counter
        event_types = Counter(p.payload.get("event_type", "unknown") for p in results)
        sources = Counter(p.payload.get("source", "unknown") for p in results)

        # Sample of "other" tagged signals for review
        other_samples = [
            {
                "title": p.payload.get("title", "")[:80],
                "tickers": p.payload.get("tickers", []),
                "source": p.payload.get("source", ""),
                "published": p.payload.get("published", "")[:10]
            }
            for p in results
            if p.payload.get("event_type") == "other"
        ][:20]

        return json.dumps({
            "days": days,
            "total_signals_sampled": len(results),
            "by_event_type": dict(event_types.most_common()),
            "by_source": dict(sources.most_common()),
            "other_samples": other_samples
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})


@mcp.tool()
def get_sector_trim() -> str:
    """
    Get current sector fuel trim state — LTFT and STFT for all sectors.
    LTFT: long-term trim (accumulated baseline, changes slowly)
    STFT: short-term trim (recent correction, resets nightly)
    Combined penalty = abs(LTFT + STFT)
    Use this to understand why a sector's confidence is being adjusted
    and how the dynamic calibration is evolving over time.
    """
    try:
        import sqlite3
        conn = sqlite3.connect("/home/trading/trading-ai/data/paper_trading.db")
        rows = conn.execute("""
            SELECT sector, ltft, stft, learning_rate, updated_at
            FROM sector_trim
            ORDER BY ltft ASC
        """).fetchall()
        conn.close()

        sectors = []
        for r in rows:
            combined = r[1] + r[2]
            sectors.append({
                "sector":        r[0],
                "ltft":          round(r[1], 4),
                "stft":          round(r[2], 4),
                "combined":      round(combined, 4),
                "penalty_pct":   f"{abs(combined):.1%}",
                "learning_rate": r[3],
                "updated_at":    r[4][:16] if r[4] else None,
                "trend":         "tightening" if r[2] < 0 else "loosening" if r[2] > 0 else "stable"
            })

        return json.dumps({
            "sectors": sectors,
            "note": "LTFT absorbs STFT nightly at 5AM ET. Negative = penalty applied to confidence."
        }, indent=2)
    except Exception as e:
        return json.dumps({"error": str(e)})

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO,
                        format="%(asctime)s [%(levelname)s] %(message)s")
    log.info("Starting Trading Pipeline MCP on 0.0.0.0:8101")
    mcp.run(transport="streamable-http")