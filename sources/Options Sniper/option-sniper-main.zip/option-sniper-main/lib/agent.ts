// The Options Sniper agent:
// Dynamic Market Discovery -> Top Candidates -> News & Corporate Action Check ->
// Options Chain -> IV + Greeks + Liquidity Analysis -> Opportunity Score ->
// Risk Check -> Best Sniper Target -> Automatic Alpaca Paper Order ->
// Position Monitoring -> Automatic Exit.
// Stateless: Alpaca is the only source of truth.
import {
  cancelOrder,
  closePosition,
  daysToExpiry,
  getAccount,
  getFillActivities,
  getOpenOrders,
  getPositions,
  getStockBars,
  IS_MOCK,
  parseOccSymbol,
  placeSpreadOrder,
  type AlpacaAccount,
  type AlpacaFillActivity,
  type AlpacaPosition,
} from "./alpaca";
import {
  mockBars,
  mockClosePosition,
  mockGetAccount,
  mockGetPositions,
  mockPlaceSpread,
} from "./mock";
import { computeIndicators, scanAll, scoreOpportunity } from "./scanner";
import { discoverMarkets } from "./discovery";
import { buildOptionsIntelligence, optionsQualityScoreModifier } from "./intelligence";
import { assessNewsRisk, newsImpactScoreModifier } from "./newsRisk";
import type {
  AccountView,
  AgentLogEntry,
  ClosedTrade,
  Decision,
  MarketDiscovery,
  NewsRiskAssessment,
  Opportunity,
  OptionsIntelligence,
  PositionLeg,
  ScanRow,
  SpreadPosition,
  TickResult,
} from "./types";
import { SCAN_SYMBOLS } from "./types";

const MIN_SCORE = Number(process.env.AGENT_MIN_SCORE || 75);
const MAX_RISK_PCT = Number(process.env.AGENT_MAX_RISK_PCT || 1.0); // % of equity per trade
const ENTRY_SLIPPAGE = 0.05; // per-share cushion above quoted debit to improve fills
// Auto-exit thresholds (tighter than 50% to lock in small gains / cut small losses)
const PROFIT_TARGET_PCT = Number(process.env.AGENT_PROFIT_PCT || 0.10); // take profit at +10%
const MAX_LOSS_PCT = Number(process.env.AGENT_MAX_LOSS_PCT || 0.25); // cut loss at -25%
const TIME_EXIT_DTE = Number(process.env.AGENT_TIME_EXIT_DTE || 7); // time exit at <= N DTE
const MAX_POSITIONS_PER_UNDERLYING = Number(process.env.AGENT_MAX_POS_PER_UNDERLYING || 3); // max concurrent spreads per underlying

export function logEntry(level: AgentLogEntry["level"], message: string, log: AgentLogEntry[]): void {
  log.push({ ts: Date.now(), level, message });
}

export async function getAccountView(): Promise<AccountView> {
  const acc: AlpacaAccount = IS_MOCK ? mockGetAccount() : await getAccount();
  return {
    accountNumber: acc.account_number,
    equity: Number(acc.equity),
    buyingPower: Number(acc.buying_power),
    cash: Number(acc.cash),
    portfolioValue: Number(acc.portfolio_value),
    lastEquity: Number(acc.last_equity),
    status: acc.status,
    mock: IS_MOCK,
  };
}

/** Build one position view per raw Alpaca option leg so every position
 *  the user sees in Alpaca is represented in the dashboard. Paired long+short
 *  legs share a `groupId` and the same spread-level exit signal so the agent
 *  can still close them together (short first). */
export async function buildSpreadPositions(rawPositions: AlpacaPosition[]): Promise<SpreadPosition[]> {
  const optionPositions = rawPositions.filter((p) => p.asset_class === "us_option");
  interface Group {
    underlying: string;
    expiry: string;
    legs: PositionLeg[];
  }
  const groups = new Map<string, Group>();
  for (const p of optionPositions) {
    const parsed = parseOccSymbol(p.symbol);
    if (!parsed) continue;
    const key = `${parsed.underlying}|${parsed.expiry}|${parsed.type}`;
    if (!groups.has(key)) groups.set(key, { underlying: parsed.underlying, expiry: parsed.expiry, legs: [] });
    groups.get(key)!.legs.push({
      symbol: p.symbol,
      qty: Number(p.qty),
      side: Number(p.qty) > 0 ? "long" : "short",
      strike: parsed.strike,
      avgEntryPrice: Number(p.avg_entry_price),
      currentPrice: Number(p.current_price),
      marketValue: Number(p.market_value),
    });
  }

  // Underlying trend data (for trend-reversal exits) - fetch once per underlying
  const trendCache = new Map<string, "bullish" | "bearish" | "neutral">();
  for (const g of groups.values()) {
    if (trendCache.has(g.underlying)) continue;
    try {
      const bars = IS_MOCK ? mockBars(g.underlying) : await getStockBars(g.underlying);
      trendCache.set(g.underlying, computeIndicators(bars).trend);
    } catch {
      trendCache.set(g.underlying, "neutral");
    }
  }

  const spreads: SpreadPosition[] = [];
  for (const [key, g] of groups) {
    const longLegs = g.legs.filter((l) => l.side === "long").sort((a, b) => a.strike - b.strike);
    const shortLegs = g.legs.filter((l) => l.side === "short").sort((a, b) => a.strike - b.strike);
    const dte = daysToExpiry(g.expiry);
    const trend = trendCache.get(g.underlying) ?? "neutral";

    const pairCount = Math.min(longLegs.length, shortLegs.length);

    // Pre-compute spread-level exit signals for paired legs
    const pairExitSignals = new Map<number, string | null>();
    for (let i = 0; i < pairCount; i++) {
      const ll = longLegs[i];
      const sl = shortLegs[i];
      const netEntry = ll.avgEntryPrice * ll.qty + sl.avgEntryPrice * sl.qty;
      const netValue = ll.currentPrice * ll.qty + sl.currentPrice * sl.qty;
      const pnlPct = netEntry !== 0 ? (netValue - netEntry) / netEntry : 0;

      let exitSignal: string | null = null;
      if (pnlPct >= PROFIT_TARGET_PCT)
        exitSignal = `TARGET HIT: +${Math.round(pnlPct * 100)}% profit (target ${(PROFIT_TARGET_PCT * 100).toFixed(0)}%)`;
      else if (pnlPct <= -MAX_LOSS_PCT)
        exitSignal = `MAX LOSS: ${Math.round(pnlPct * 100)}% of debit (limit ${(MAX_LOSS_PCT * 100).toFixed(0)}%)`;
      else if (dte <= TIME_EXIT_DTE)
        exitSignal = `TIME EXIT: ${dte} DTE (<= ${TIME_EXIT_DTE})`;
      else if (trend === "bearish") exitSignal = `TREND REVERSAL: ${g.underlying} turned bearish`;

      pairExitSignals.set(i, exitSignal);
    }

    // Emit one SpreadPosition per raw option position
    for (let i = 0; i < pairCount; i++) {
      const ll = longLegs[i];
      const sl = shortLegs[i];
      const groupId = `${key}|${ll.strike}|${sl.strike}`;
      const exitSignal = pairExitSignals.get(i) ?? null;
      const netEntry = ll.avgEntryPrice * ll.qty + sl.avgEntryPrice * sl.qty;
      const netValue = ll.currentPrice * ll.qty + sl.currentPrice * sl.qty;
      const spreadQty = Math.abs(ll.qty) || 1;
      const entryPerSpread = Math.round((netEntry / spreadQty) * 1000) / 1000;
      const valuePerSpread = Math.round((netValue / spreadQty) * 1000) / 1000;

      // Long leg entry
      const llPnl = (ll.currentPrice - ll.avgEntryPrice) * ll.qty * 100;
      const llPnlPct = ll.avgEntryPrice !== 0 ? (ll.currentPrice - ll.avgEntryPrice) / ll.avgEntryPrice : 0;
      spreads.push({
        id: `${groupId}|long`,
        groupId,
        underlying: g.underlying,
        expiry: g.expiry,
        dte,
        qty: Math.abs(ll.qty) || 1,
        legs: [ll, sl],
        entryDebit: ll.avgEntryPrice,
        currentValue: ll.currentPrice,
        pnl: Math.round(llPnl * 100) / 100,
        pnlPct: Math.round(llPnlPct * 1000) / 1000,
        longStrike: ll.strike,
        shortStrike: sl.strike,
        stopLoss: Math.round(entryPerSpread * (1 - MAX_LOSS_PCT) * 1000) / 1000,
        profitTarget: Math.round(entryPerSpread * (1 + PROFIT_TARGET_PCT) * 1000) / 1000,
        exitSignal,
        side: "long",
      });

      // Short leg entry
      const slPnl = (sl.currentPrice - sl.avgEntryPrice) * sl.qty * 100;
      const slPnlPct = sl.avgEntryPrice !== 0 ? (sl.currentPrice - sl.avgEntryPrice) / sl.avgEntryPrice : 0;
      spreads.push({
        id: `${groupId}|short`,
        groupId,
        underlying: g.underlying,
        expiry: g.expiry,
        dte,
        qty: Math.abs(sl.qty) || 1,
        legs: [ll, sl],
        entryDebit: sl.avgEntryPrice,
        currentValue: sl.currentPrice,
        pnl: Math.round(slPnl * 100) / 100,
        pnlPct: Math.round(slPnlPct * 1000) / 1000,
        longStrike: ll.strike,
        shortStrike: sl.strike,
        stopLoss: Math.round(entryPerSpread * (1 - MAX_LOSS_PCT) * 1000) / 1000,
        profitTarget: Math.round(entryPerSpread * (1 + PROFIT_TARGET_PCT) * 1000) / 1000,
        exitSignal,
        side: "short",
      });
    }

    // Unpaired long legs (no matching short)
    for (let i = pairCount; i < longLegs.length; i++) {
      const ll = longLegs[i];
      const entryPerSpread = ll.avgEntryPrice;
      const valuePerSpread = ll.currentPrice;
      const pnlPct = entryPerSpread !== 0 ? (valuePerSpread - entryPerSpread) / entryPerSpread : 0;
      let exitSignal: string | null = null;
      if (pnlPct <= -MAX_LOSS_PCT)
        exitSignal = `MAX LOSS: ${Math.round(pnlPct * 100)}% (limit ${(MAX_LOSS_PCT * 100).toFixed(0)}%)`;
      else if (dte <= TIME_EXIT_DTE)
        exitSignal = `TIME EXIT: ${dte} DTE (<= ${TIME_EXIT_DTE})`;
      else if (trend === "bearish") exitSignal = `TREND REVERSAL: ${g.underlying} turned bearish`;

      spreads.push({
        id: `${key}|${ll.strike}|solo`,
        underlying: g.underlying,
        expiry: g.expiry,
        dte,
        qty: Math.abs(ll.qty) || 1,
        legs: [ll],
        entryDebit: entryPerSpread,
        currentValue: valuePerSpread,
        pnl: Math.round((valuePerSpread - entryPerSpread) * ll.qty * 100 * 100) / 100,
        pnlPct: Math.round(pnlPct * 1000) / 1000,
        longStrike: ll.strike,
        shortStrike: 0,
        stopLoss: Math.round(entryPerSpread * (1 - MAX_LOSS_PCT) * 1000) / 1000,
        profitTarget: Math.round(entryPerSpread * (1 + PROFIT_TARGET_PCT) * 1000) / 1000,
        exitSignal,
        side: "long",
      });
    }

    // Unpaired short legs (no matching long)
    for (let i = pairCount; i < shortLegs.length; i++) {
      const sl = shortLegs[i];
      const pnlPct = sl.avgEntryPrice !== 0 ? (sl.currentPrice - sl.avgEntryPrice) / sl.avgEntryPrice : 0;
      let exitSignal: string | null = null;
      if (pnlPct >= PROFIT_TARGET_PCT)
        exitSignal = `TARGET HIT: +${Math.round(pnlPct * 100)}% profit (target ${(PROFIT_TARGET_PCT * 100).toFixed(0)}%)`;
      else if (dte <= TIME_EXIT_DTE)
        exitSignal = `TIME EXIT: ${dte} DTE (<= ${TIME_EXIT_DTE})`;

      spreads.push({
        id: `${key}|${sl.strike}|solo-short`,
        underlying: g.underlying,
        expiry: g.expiry,
        dte,
        qty: Math.abs(sl.qty) || 1,
        legs: [sl],
        entryDebit: sl.avgEntryPrice,
        currentValue: sl.currentPrice,
        pnl: Math.round((sl.currentPrice - sl.avgEntryPrice) * sl.qty * 100 * 100) / 100,
        pnlPct: Math.round(pnlPct * 1000) / 1000,
        longStrike: 0,
        shortStrike: sl.strike,
        stopLoss: 0,
        profitTarget: 0,
        exitSignal,
        side: "short",
      });
    }
  }
  return spreads.sort((a, b) => a.underlying.localeCompare(b.underlying));
}

/** Enter a spread if the score and risk limits pass. Returns a decision. */
export async function evaluateAndEnter(
  best: Opportunity,
  account: AccountView,
  existingSpreads: SpreadPosition[],
  autoEnter: boolean,
  log: AgentLogEntry[]
): Promise<Decision> {
  const { candidate: cand, score } = best;
  const label = `${cand.underlying} ${cand.longLeg.strike}/${cand.shortLeg.strike}C ${cand.expiry} (${cand.dte} DTE)`;

  // Risk check: max loss of one spread must be <= MAX_RISK_PCT of equity
  const maxLossPerSpread = cand.maxLoss * 100;
  const riskPct = (maxLossPerSpread / account.equity) * 100;
  const maxRiskDollars = (account.equity * MAX_RISK_PCT) / 100;
  const suggestedQty = Math.max(0, Math.floor(maxRiskDollars / maxLossPerSpread));

  if (score < MIN_SCORE) {
    logEntry("info", `WAIT: ${label} scores ${score} < ${MIN_SCORE} threshold`, log);
    return { action: "WAIT", reason: `Score ${score} is below the ${MIN_SCORE} entry threshold`, score, riskPct };
  }
  if (riskPct > MAX_RISK_PCT) {
    logEntry("warn", `WAIT: ${label} risk ${riskPct.toFixed(2)}% of equity exceeds ${MAX_RISK_PCT}% limit`, log);
    return { action: "WAIT", reason: `Risk ${riskPct.toFixed(2)}% exceeds ${MAX_RISK_PCT}% per-trade limit`, score, riskPct };
  }
  if (suggestedQty < 1) {
    logEntry("warn", `WAIT: ${label} position sizing rounds to 0 spreads`, log);
    return { action: "WAIT", reason: "Position size rounds to zero spreads at this risk limit", score, riskPct };
  }
  const existingOnUnderlying = existingSpreads.filter((s) => s.underlying === cand.underlying);
  // Count unique spreads (group by groupId to avoid double-counting paired legs).
  // Unpaired legs (no groupId) each count as 1 position — they still occupy risk.
  const uniqueGroupIds = new Set<string>();
  let unpairedCount = 0;
  for (const s of existingOnUnderlying) {
    if (s.groupId) uniqueGroupIds.add(s.groupId);
    else unpairedCount++;
  }
  const uniqueCount = uniqueGroupIds.size + unpairedCount;
  if (uniqueCount >= MAX_POSITIONS_PER_UNDERLYING) {
    logEntry("info", `WAIT: already have ${uniqueCount}/${MAX_POSITIONS_PER_UNDERLYING} open ${cand.underlying} positions`, log);
    return { action: "WAIT", reason: `${uniqueCount} open ${cand.underlying} position(s) — limit ${MAX_POSITIONS_PER_UNDERLYING} per underlying`, score, riskPct };
  }
  if (uniqueCount > 0 && existingOnUnderlying.some((s) => s.pnlPct >= 0)) {
    const profitable = existingOnUnderlying.filter((s) => s.pnlPct >= 0).length;
    logEntry("info", `WAIT: ${cand.underlying} has ${profitable} profitable position(s) — only add when existing is at a loss`, log);
    return { action: "WAIT", reason: `Existing ${cand.underlying} position is profitable — only add when at a loss`, score, riskPct };
  }

  if (!autoEnter) {
    logEntry("info", `ENTER approved (not submitted): ${label} score ${score}, risk ${riskPct.toFixed(2)}% - awaiting manual submit`, log);
    return { action: "ENTER", reason: "Signal approved - press SUBMIT TRADE to place the paper order", score, riskPct, suggestedQty };
  }

  try {
    // Cancel any stale sniper orders for this underlying before re-entering
    if (!IS_MOCK) {
      try {
        const open = await getOpenOrders();
        const stale = open.filter((o) => o.client_order_id?.startsWith(`sniper-${cand.underlying}-`));
        for (const s of stale) {
          await cancelOrder(s.id);
          logEntry("info", `Canceled stale ${cand.underlying} order ${s.id.slice(0, 8)}`, log);
        }
      } catch (err) {
        logEntry("warn", `Could not check/cancel stale orders: ${err instanceof Error ? err.message : String(err)}`, log);
      }
    }

    const qty = Math.min(suggestedQty, 10);
    const legs = [
      { symbol: cand.longLeg.symbol, ratio: 1, side: "buy" as const },
      { symbol: cand.shortLeg.symbol, ratio: 1, side: "sell" as const },
    ];
    const clientId = `sniper-${cand.underlying}-${cand.expiry}-${Date.now()}`;
    // Conservative debit + small slippage cushion so the limit fills in fast markets
    const limitPrice = Math.round((cand.debit + ENTRY_SLIPPAGE) * 100) / 100;
    if (IS_MOCK) {
      // demo brokerage fills each leg at its quoted price
      mockPlaceSpread({
        qty,
        legs: [
          { symbol: cand.longLeg.symbol, side: "buy", price: cand.longLeg.ask },
          { symbol: cand.shortLeg.symbol, side: "sell", price: cand.shortLeg.bid },
        ],
      });
    } else {
      await placeSpreadOrder({ qty, limitPrice, legs, clientId });
    }
    logEntry("trade", `ENTER: bought ${qty}x ${label} @ $${limitPrice.toFixed(2)} debit (max loss $${(maxLossPerSpread * qty).toFixed(0)}, max profit $${(cand.maxProfit * 100 * qty).toFixed(0)})`, log);
    logEntry("success", `Paper order submitted to Alpaca (${clientId})`, log);
    return { action: "ENTER", reason: `Paper order placed: ${qty} spread(s) @ $${limitPrice.toFixed(2)} debit`, score, riskPct, suggestedQty: qty };
  } catch (err) {
    const msg = err instanceof Error ? err.message : String(err);
    logEntry("error", `Order failed for ${label}: ${msg}`, log);
    return { action: "WAIT", reason: `Order submission failed: ${msg}`, score, riskPct, suggestedQty };
  }
}

/** Close all legs of a spread. Short leg first, then long: closing the long
 *  leg while the short leg is still open would briefly leave a naked short
 *  option (rejected with 403 on level-3 accounts). */
export async function exitSpread(spread: SpreadPosition, reason: string, log: AgentLogEntry[]): Promise<boolean> {
  logEntry("trade", `EXIT ${spread.underlying} ${spread.longStrike}/${spread.shortStrike}C ${spread.expiry}: ${reason}`, log);
  try {
    const ordered = [...spread.legs].sort((a, b) => {
      if (a.side === b.side) return 0;
      return a.side === "short" ? -1 : 1;
    });
    for (const leg of ordered) {
      if (IS_MOCK) mockClosePosition(leg.symbol);
      else await closePosition(leg.symbol);
    }
    logEntry("success", `Closed ${spread.legs.length} leg(s) via Alpaca paper trading (short first, then long)`, log);
    return true;
  } catch (err) {
    logEntry("error", `Exit failed for ${spread.underlying} spread: ${err instanceof Error ? err.message : String(err)}`, log);
    return false;
  }
}

/**
 * Build closed trade history from Alpaca FILL activities.
 * Processes fills per-symbol to extract round-trips, then pairs long/short
 * legs into spreads and computes realized P&L per spread. Returns up to 10 most recent.
 */
export async function buildClosedTrades(): Promise<ClosedTrade[]> {
  let fills: AlpacaFillActivity[];
  try {
    fills = IS_MOCK ? [] : await getFillActivities();
  } catch {
    return [];
  }

  // Filter to option fills only (OCC symbol format: AAAYYMMDD[CP]NNNNNNN)
  const optionFills = fills.filter((f) => parseOccSymbol(f.symbol));
  if (optionFills.length === 0) return [];

  // Compute signed cash impact for a fill (Alpaca FILL activities lack net_amount)
  const fillCash = (f: AlpacaFillActivity): number => {
    const qty = Number(f.qty) || 0;
    const price = Number(f.price) || 0;
    // Options: 100 shares per contract; buys are cash out (-), sells are cash in (+)
    return f.side === "buy" ? -(qty * price * 100) : qty * price * 100;
  };

  // Step 1: Group fills by symbol
  const bySymbol = new Map<string, AlpacaFillActivity[]>();
  for (const f of optionFills) {
    if (!bySymbol.has(f.symbol)) bySymbol.set(f.symbol, []);
    bySymbol.get(f.symbol)!.push(f);
  }

  // Step 2: For each symbol, extract round-trips (entry → exit) via position tracking
  interface RoundTrip {
    symbol: string;
    entrySide: "long" | "short";
    qty: number;
    entryFills: AlpacaFillActivity[];
    exitFills: AlpacaFillActivity[];
    entryCash: number;
    exitCash: number;
    entryDate: string;
    exitDate: string;
    parsed: NonNullable<ReturnType<typeof parseOccSymbol>>;
  }

  const roundTrips: RoundTrip[] = [];

  for (const [symbol, symFills] of bySymbol) {
    const parsed = parseOccSymbol(symbol);
    if (!parsed) continue;

    symFills.sort((a, b) => new Date(a.transaction_time).getTime() - new Date(b.transaction_time).getTime());

    let position = 0;
    let entryFills: AlpacaFillActivity[] = [];
    let exitFills: AlpacaFillActivity[] = [];
    let entrySide: "long" | "short" | null = null;

    for (const f of symFills) {
      const signed = f.side === "buy" ? Number(f.qty) : -Number(f.qty);
      const prev = position;
      position += signed;

      if (prev === 0 && position !== 0) {
        // Opening new position
        entryFills = [f];
        exitFills = [];
        entrySide = signed > 0 ? "long" : "short";
      } else if (position !== 0 && Math.sign(signed) === Math.sign(prev)) {
        // Adding to existing position (same direction)
        entryFills.push(f);
      } else if (prev !== 0 && position === 0) {
        // Closing position completely
        exitFills.push(f);

        if (entrySide && entryFills.length > 0 && exitFills.length > 0) {
          const qty = entryFills.reduce((s, ef) => s + Number(ef.qty), 0);
          roundTrips.push({
            symbol,
            entrySide,
            qty,
            entryFills: [...entryFills],
            exitFills: [...exitFills],
            entryCash: entryFills.reduce((s, ef) => s + fillCash(ef), 0),
            exitCash: exitFills.reduce((s, ef) => s + fillCash(ef), 0),
            entryDate: entryFills[0].transaction_time,
            exitDate: exitFills[exitFills.length - 1].transaction_time,
            parsed,
          });
        }
        entryFills = [];
        exitFills = [];
        entrySide = null;
      } else if (prev !== 0 && position !== 0 && Math.sign(signed) !== Math.sign(prev)) {
        // Reducing position (partial exit)
        exitFills.push(f);
      }
    }
  }

  // Step 3: Group round-trips by underlying|expiry|type, then pair longs with shorts
  const byGroup = new Map<string, RoundTrip[]>();
  for (const rt of roundTrips) {
    const gk = `${rt.parsed.underlying}|${rt.parsed.expiry}|${rt.parsed.type}`;
    if (!byGroup.has(gk)) byGroup.set(gk, []);
    byGroup.get(gk)!.push(rt);
  }

  const trades: ClosedTrade[] = [];

  for (const [groupKey, rts] of byGroup) {
    const longs = rts
      .filter((r) => r.entrySide === "long")
      .sort((a, b) => new Date(a.entryDate).getTime() - new Date(b.entryDate).getTime());
    const shorts = rts
      .filter((r) => r.entrySide === "short")
      .sort((a, b) => new Date(a.entryDate).getTime() - new Date(b.entryDate).getTime());

    // Match each long leg to the short leg with closest entry time (short strike > long strike)
    const usedShorts = new Set<number>();

    for (const long of longs) {
      let bestIdx = -1;
      let bestTimeDiff = Infinity;

      for (let i = 0; i < shorts.length; i++) {
        if (usedShorts.has(i)) continue;
        const short = shorts[i];
        if (short.parsed.strike <= long.parsed.strike) continue;
        const timeDiff = Math.abs(new Date(short.entryDate).getTime() - new Date(long.entryDate).getTime());
        if (timeDiff < bestTimeDiff) {
          bestTimeDiff = timeDiff;
          bestIdx = i;
        }
      }

      if (bestIdx === -1) continue;
      usedShorts.add(bestIdx);

      const short = shorts[bestIdx];
      const entryCash = long.entryCash + short.entryCash;
      const exitCash = long.exitCash + short.exitCash;
      const realizedPnl = exitCash + entryCash;
      const qty = Math.min(long.qty, short.qty);
      const entryDebit = Math.abs(entryCash) / (qty * 100);
      const exitCredit = exitCash / (qty * 100);

      if (entryDebit === 0 || isNaN(entryDebit)) continue;

      const parts = groupKey.split("|");
      const underlying = parts[0];
      const expiry = parts[1];

      trades.push({
        id: `${groupKey}|${long.parsed.strike}-${short.parsed.strike}`,
        underlying,
        longStrike: long.parsed.strike,
        shortStrike: short.parsed.strike,
        expiry,
        entryDate: long.entryDate,
        exitDate: [long.exitDate, short.exitDate].sort()[1],
        entryDebit: Math.round(entryDebit * 1000) / 1000,
        exitCredit: Math.round(exitCredit * 1000) / 1000,
        qty,
        pnl: Math.round(realizedPnl * 100) / 100,
        pnlPct: Math.round((realizedPnl / Math.abs(entryCash)) * 10000) / 100,
        legs: [...long.entryFills, ...short.entryFills, ...long.exitFills, ...short.exitFills].map((f) => ({
          symbol: f.symbol,
          side: f.side,
          qty: Number(f.qty),
          price: Number(f.price),
          netAmount: fillCash(f),
        })),
      });
    }
  }

  // Sort by exit date descending, return last 10
  return trades
    .sort((a, b) => new Date(b.exitDate).getTime() - new Date(a.exitDate).getTime())
    .slice(0, 10);
}

/**
 * One full agent tick with the complete pipeline:
 * 1. Account
 * 2. Monitor & exit positions
 * 3. Dynamic Market Discovery
 * 4. Scan discovered candidates
 * 5. For best candidate: Options Intelligence + News Risk
 * 6. Score with all factors
 * 7. Decision & entry
 */
export async function runAgentTick(opts: { autoEnter: boolean; autoExit: boolean }): Promise<TickResult> {
  const log: AgentLogEntry[] = [];
  const startedAt = new Date();

  // 1) Account (Alpaca = source of truth)
  let account: AccountView | null = null;
  try {
    account = await getAccountView();
    logEntry("info", `Account: equity $${account.equity.toLocaleString()} | buying power $${account.buyingPower.toLocaleString()}`, log);
  } catch (err) {
    logEntry("error", `Account fetch failed: ${err instanceof Error ? err.message : String(err)}`, log);
    return {
      account: null, scan: [], best: null,
      decision: { action: "WAIT", reason: "Could not reach Alpaca account API" },
      positions: [], log, mock: IS_MOCK, discovery: null, intelligence: null, newsRisk: null,
    };
  }

  // 2) Existing positions -> monitor / exit first
  let positions: SpreadPosition[] = [];
  try {
    const raw = IS_MOCK ? mockGetPositions() : await getPositions();
    positions = await buildSpreadPositions(raw);
    if (positions.length > 0 && opts.autoExit) {
      // Deduplicate by groupId so paired legs are closed once (short first)
      const closed = new Set<string>();
      for (const spread of positions) {
        const gid = spread.groupId || spread.id;
        if (spread.exitSignal && !closed.has(gid)) {
          closed.add(gid);
          await exitSpread(spread, spread.exitSignal, log);
        }
      }
      const rawAfter = IS_MOCK ? mockGetPositions() : await getPositions();
      positions = await buildSpreadPositions(rawAfter);
    } else if (positions.length > 0) {
      const signaled = new Set<string>();
      for (const spread of positions) {
        const gid = spread.groupId || spread.id;
        if (spread.exitSignal && !signaled.has(gid)) {
          signaled.add(gid);
          logEntry("warn", `EXIT SIGNAL on ${spread.underlying} ${spread.side} ${spread.longStrike}/${spread.shortStrike || "—"}C: ${spread.exitSignal} (auto-exit off)`, log);
        }
      }
    }
  } catch (err) {
    logEntry("error", `Position fetch failed: ${err instanceof Error ? err.message : String(err)}`, log);
  }

  // 3) Dynamic Market Discovery
  let discovery: MarketDiscovery | null = null;
  try {
    discovery = await discoverMarkets();
    const gainerCount = discovery.topGainers.filter((m) => m.qualified).length;
    const activeCount = discovery.mostActive.filter((m) => m.qualified).length;
    logEntry("info", `Market Discovery: ${discovery.topGainers.length} gainers, ${discovery.topLosers.length} losers, ${discovery.mostActive.length} active — ${discovery.qualifiedSymbols.length} qualified for options`, log);
    logEntry("info", `Qualified: ${gainerCount} gainers + ${activeCount} active → ${discovery.sniperCandidates.length} sniper candidates`, log);
  } catch (err) {
    logEntry("warn", `Market Discovery failed (falling back to default watchlist): ${err instanceof Error ? err.message : String(err)}`, log);
  }

  // 4) Scan candidates (from discovery or default watchlist)
  const scanSymbols = discovery?.sniperCandidates.length
    ? discovery.sniperCandidates
    : SCAN_SYMBOLS;
  const scanConcurrency = Math.min(scanSymbols.length, 5); // cap at 5 parallel
  logEntry("info", `Scanning ${scanSymbols.join(", ")} for bullish Bull Call Spread setups...`, log);
  const scan: ScanRow[] = await scanAll(scanSymbols, scanConcurrency);
  const bullish = scan.filter((r) => r.indicators.trend === "bullish");
  logEntry("info", `Bullish trend: ${bullish.length ? bullish.map((r) => r.symbol).join(", ") : "none"} | neutral/bearish: ${scan.filter((r) => r.indicators.trend !== "bullish").map((r) => r.symbol).join(", ") || "none"}`, log);

  // 5) Find best opportunity and enrich with intelligence + news risk
  let best: Opportunity | null = null;
  let intelligence: OptionsIntelligence | null = null;
  let newsRisk: NewsRiskAssessment | null = null;

  for (const row of scan) {
    if (row.candidate && row.candidateScore !== null) {
      if (!best || row.candidateScore > best.score) {
        best = {
          candidate: row.candidate,
          score: row.candidateScore,
          breakdown: scoreOpportunity(row.candidate, row.indicators).breakdown,
        };
      }
    }
  }

  // 6) Enrich best candidate with Options Intelligence + News Risk
  if (best) {
    const cand = best.candidate;
    const sym = cand.underlying;

    // Options Intelligence
    try {
      intelligence = buildOptionsIntelligence(
        sym,
        {
          symbol: cand.longLeg.symbol,
          strike: cand.longLeg.strike,
          expiry: cand.longLeg.expiry,
          bid: cand.longLeg.bid,
          ask: cand.longLeg.ask,
          bidSize: cand.longLeg.bidSize,
          askSize: cand.longLeg.askSize,
          openInterest: cand.longLeg.openInterest,
          delta: cand.longLeg.delta,
          volume: cand.longLeg.volume,
          iv: cand.longLeg.iv,
          gamma: cand.longLeg.gamma,
          theta: cand.longLeg.theta,
          vega: cand.longLeg.vega,
        },
        {
          symbol: cand.shortLeg.symbol,
          strike: cand.shortLeg.strike,
          expiry: cand.shortLeg.expiry,
          bid: cand.shortLeg.bid,
          ask: cand.shortLeg.ask,
          bidSize: cand.shortLeg.bidSize,
          askSize: cand.shortLeg.askSize,
          openInterest: cand.shortLeg.openInterest,
          delta: cand.shortLeg.delta,
          volume: cand.shortLeg.volume,
          iv: cand.shortLeg.iv,
          gamma: cand.shortLeg.gamma,
          theta: cand.shortLeg.theta,
          vega: cand.shortLeg.vega,
        },
        scan.find((r) => r.symbol === sym)?.indicators.price ?? cand.longLeg.strike
      );
      logEntry("info", `Options Intelligence: ${sym} IV ${intelligence.greeks.iv !== null ? (intelligence.greeks.iv * 100).toFixed(1) + "%" : "N/A"} | Quality ${intelligence.optionsQuality}/100 | Liquidity ${intelligence.liquidityRating} | Vol ${intelligence.volatilityRating}`, log);
    } catch (err) {
      logEntry("warn", `Options Intelligence failed for ${sym}: ${err instanceof Error ? err.message : String(err)}`, log);
    }

    // News + Corporate Action Risk
    try {
      newsRisk = await assessNewsRisk(sym);
      logEntry("info", `News Risk: ${sym} sentiment ${newsRisk.sentiment} | Corp Actions ${newsRisk.corporateActionStatus} | Impact ${newsRisk.newsImpact >= 0 ? "+" : ""}${newsRisk.newsImpact}${newsRisk.riskWarning ? " | ⚠️ " + newsRisk.riskWarning : ""}`, log);
    } catch (err) {
      logEntry("warn", `News Risk failed for ${sym}: ${err instanceof Error ? err.message : String(err)}`, log);
    }

    // Re-score with all factors
    const ind = scan.find((r) => r.symbol === sym)?.indicators;
    if (ind) {
      const oqMod = optionsQualityScoreModifier(intelligence);
      const niMod = newsImpactScoreModifier(newsRisk);
      const fullScore = scoreOpportunity(cand, ind, oqMod, niMod);
      best = {
        candidate: cand,
        score: fullScore.score,
        breakdown: fullScore.breakdown,
      };
      logEntry("info", `Full score: ${fullScore.score.toFixed(1)} (base ${fullScore.breakdown.trend + fullScore.breakdown.rsi + fullScore.breakdown.momentum + fullScore.breakdown.liquidity + fullScore.breakdown.riskReward} + options ${fullScore.breakdown.optionsQuality} + news ${fullScore.breakdown.newsImpact})`, log);

      // News risk can reject the trade entirely
      if (newsRisk?.riskWarning && newsRisk.newsImpact <= -5) {
        logEntry("warn", `TRADE REJECTED: ${sym} — ${newsRisk.riskWarning}`, log);
        best = null;
      }
    }
  }

  // 7) Decision (score >= 75 and risk <= 1% of equity => ENTER, else WAIT)
  let decision: Decision;
  if (!best) {
    decision = { action: "WAIT", reason: "No qualified Bull Call Spread found in the current market" };
    logEntry("info", "WAIT: no qualified opportunity across candidates", log);
  } else {
    decision = await evaluateAndEnter(best, account, positions, opts.autoEnter, log);
  }

  logEntry("info", `Tick complete in ${((Date.now() - startedAt.getTime()) / 1000).toFixed(1)}s`, log);
  return { account, scan, best, decision, positions, log, mock: IS_MOCK, discovery, intelligence, newsRisk };
}
