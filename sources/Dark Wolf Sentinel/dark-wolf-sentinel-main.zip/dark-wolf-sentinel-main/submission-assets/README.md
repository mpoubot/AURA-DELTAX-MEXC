# Dark Wolf Sentinel Local Submission Assets

This directory contains the local, unpublished judge-facing media package
prepared from repository evidence and the verified pitch-deck visual system.

## Artifacts

- `dark-wolf-sentinel-pitch-deck.pptx` — editable 16:9 PowerPoint with nine
  slides and concise speaker notes.
- `dark-wolf-sentinel-pitch-deck.pdf` — nine-page PDF preview rendered from the
  PowerPoint.
- `dark-wolf-sentinel-cover.png` — primary 1920 × 1080 Lablab cover image.
- `dark-wolf-sentinel-cover.jpg` — high-quality 1920 × 1080 JPEG fallback.

## Lablab Step 2 asset mapping

Use the following files without renaming their repository copies:

| Lablab field | Local asset | Upload note |
| --- | --- | --- |
| Cover image | `submission-assets/dark-wolf-sentinel-cover.png` | Primary 16:9 PNG. Use the JPG only if the upload form rejects PNG or imposes a smaller-file preference. |
| Presentation | `submission-assets/dark-wolf-sentinel-pitch-deck.pdf` | Judge-facing nine-page PDF. Keep the PPTX as the editable local source. |
| Video | `dark-wolf-sentinel-demo.mp4` | Locate this filename in your local media folder; the audited source is intentionally not copied into or committed to this repository. |

The video is 160 seconds (2:40), 1920 × 1080, H.264/AVC at 24 fps, with a
present, non-silent mono AAC narration track at 48 kHz. Its file size is
6,571,574 bytes and its SHA-256 checksum is
`9266b8c845ea5682b426ef55fb4d9f773cb38947f23003c6e73c361640dabaa5`.

Video audit verdict: **PASS** for the current submission package. Eighty-one
frames sampled at two-second intervals were inspected across the full runtime.
The video is a narrated product walkthrough with an embedded dashboard capture
and clearly labeled offline/synthetic evidence. It exposes no credentials,
personal data, notifications, unrelated windows, broker actions, or performance
claims. It consistently states that PAPER execution, broker submission, LIVE
trading, and AI execution authority remain disabled. Its 187-test evidence is
tied to source checkpoint `350dffa`, which remains in the current repository
history. The current deployment-prepared suite expands that evidence without
altering what the recorded 187-test checkpoint claimed.

## Factual scope

The deck uses `README.md`, `PRE_EVENT_BASELINE.md`, `docs/DEMO_SCRIPT.md`, the
architecture and safety documents, repository history, verified test/audit
results, and an existing local dashboard screenshot. It does not claim
profitability, performance, deployment, production users, LIVE trading, broker
submission, or AI execution authority.

Pre-event capabilities and event-period work are presented separately. The
deck states that organizer eligibility clarification remains pending.

## Verification

- Nine PowerPoint slides rendered and inspected individually.
- PDF conversion verified at nine pages and inspected against the PowerPoint.
- Both cover exports verified at exactly 1920 × 1080 and inspected at full size
  and thumbnail size for legibility, contrast, clipping, distortion, and export
  artifacts.
- Automated slide overflow check passed.
- Nine speaker-note sections and source blocks verified.
- Embedded dashboard image has descriptive alternative text.
- No unresolved placeholders or external hyperlinks are present.
- The original demo video was not modified, copied into the repository, or
  staged for commit.

These files have not been uploaded, published, deployed, or submitted.
