from __future__ import annotations

import asyncio
import json
import os
import shutil
from pathlib import Path
from typing import Any

from mcp import (
    ClientSession,
    StdioServerParameters,
)
from mcp.client.stdio import (
    stdio_client,
)

from app.config import Settings


RESULT_PATH = Path(
    "data/alpaca_mcp_probe.json"
)

ALLOWED_TOOLSETS = (
    "stock-data,news"
)

FORBIDDEN_PREFIXES = (
    "place_",
    "cancel_",
    "close_",
    "create_",
    "update_",
    "delete_",
    "add_",
    "remove_",
    "exercise_",
    "do_not_",
)


def safe_environment(
    settings: Settings,
) -> dict[str, str]:
    """Minimal environment for the MCP subprocess."""

    env: dict[str, str] = {}

    for name in (
        "PATH",
        "HOME",
        "USER",
        "TMPDIR",
        "LANG",
        "LC_ALL",
        "SSL_CERT_FILE",
        "REQUESTS_CA_BUNDLE",
    ):
        value = os.environ.get(name)

        if value:
            env[name] = value

    env.update(
        {
            "ALPACA_API_KEY":
                settings.alpaca_api_key or "",
            "ALPACA_SECRET_KEY":
                settings.alpaca_secret_key or "",
            "ALPACA_PAPER_TRADE":
                "true",
            "ALPACA_TOOLSETS":
                ALLOWED_TOOLSETS,
        }
    )

    return env


def tool_schema(
    tool: Any,
) -> dict[str, Any]:
    value = getattr(
        tool,
        "inputSchema",
        None,
    )

    if value is None:
        value = getattr(
            tool,
            "input_schema",
            None,
        )

    return value or {}


def assert_read_only(
    names: list[str],
) -> None:
    if not names:
        raise RuntimeError(
            "MCP exposed no tools."
        )

    forbidden = []

    for name in names:
        lowered = name.lower()

        if lowered.startswith(
            FORBIDDEN_PREFIXES
        ):
            forbidden.append(name)

    if forbidden:
        raise RuntimeError(
            "Write-capable MCP tools exposed: "
            + ", ".join(forbidden)
        )

    expected = {
        "get_stock_bars",
        "get_stock_latest_trade",
        "get_stock_snapshot",
        "get_most_active_stocks",
        "get_market_movers",
        "get_news",
    }

    missing = sorted(
        expected - set(names)
    )

    if missing:
        raise RuntimeError(
            "Expected read-only MCP tools missing: "
            + ", ".join(missing)
        )


def most_active_arguments(
    tool: Any,
) -> dict[str, Any]:
    schema = tool_schema(
        tool
    )

    properties = schema.get(
        "properties",
        {},
    )

    required = schema.get(
        "required",
        [],
    )

    args: dict[str, Any] = {}

    # Prefer a small deterministic response.
    if "top" in properties:
        args["top"] = 5

    if "by" in properties:
        args["by"] = "volume"

    for field in required:
        if field in args:
            continue

        if field == "top":
            args[field] = 5

        elif field == "by":
            args[field] = "volume"

        elif field == "feed":
            args[field] = "iex"

        else:
            raise RuntimeError(
                "Unknown required MCP argument "
                f"for most-actives: {field}"
            )

    return args


def serialize_result(
    result: Any,
) -> dict[str, Any]:
    if hasattr(
        result,
        "model_dump",
    ):
        return result.model_dump(
            mode="json"
        )

    return {
        "text": str(result)
    }


async def run_probe() -> dict[str, Any]:
    settings = Settings()

    settings.assert_paper_only()

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "MCP probe requires execution disabled."
        )

    if not settings.alpaca_configured:
        raise RuntimeError(
            "Alpaca PAPER credentials missing."
        )

    uvx = shutil.which(
        "uvx"
    )

    if not uvx:
        raise RuntimeError(
            "uvx is not installed."
        )

    server = StdioServerParameters(
        command=uvx,
        args=[
            "alpaca-mcp-server",
        ],
        env=safe_environment(
            settings
        ),
    )

    async with stdio_client(
        server
    ) as (
        read_stream,
        write_stream,
    ):
        async with ClientSession(
            read_stream,
            write_stream,
        ) as session:
            await session.initialize()

            listed = await session.list_tools()

            tools = listed.tools

            names = sorted(
                tool.name
                for tool in tools
            )

            assert_read_only(
                names
            )

            tool_map = {
                tool.name: tool
                for tool in tools
            }

            target = tool_map[
                "get_most_active_stocks"
            ]

            arguments = (
                most_active_arguments(
                    target
                )
            )

            result = await session.call_tool(
                "get_most_active_stocks",
                arguments=arguments,
            )

            serialized = serialize_result(
                result
            )

    output = {
        "mode":
            "ALPACA_MCP_READ_ONLY",
        "paper":
            True,
        "toolsets":
            ALLOWED_TOOLSETS,
        "tool_count":
            len(names),
        "tools":
            names,
        "forbidden_write_tools":
            [],
        "sample_tool":
            "get_most_active_stocks",
        "sample_arguments":
            arguments,
        "sample_result":
            serialized,
        "order_submission_enabled":
            False,
        "trading_authority":
            False,
        "live_trading":
            False,
    }

    RESULT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    RESULT_PATH.write_text(
        json.dumps(
            output,
            indent=2,
        )
        + "\n"
    )

    return output


def main() -> None:
    result = asyncio.run(
        run_probe()
    )

    print(
        "MODE:",
        result["mode"]
    )

    print(
        "PAPER:",
        result["paper"]
    )

    print(
        "TOOLSETS:",
        result["toolsets"]
    )

    print(
        "TOOLS EXPOSED:",
        result["tool_count"]
    )

    print()
    print(
        "AVAILABLE MCP TOOLS:"
    )

    for name in result["tools"]:
        print(
            "-",
            name,
        )

    print()
    print(
        "SAMPLE TOOL:",
        result["sample_tool"]
    )

    print(
        "SAMPLE ARGS:",
        result["sample_arguments"]
    )

    print()
    print(
        "PASS - Alpaca MCP connected"
    )

    print(
        "PASS - stock-data/news only"
    )

    print(
        "PASS - no write tools exposed"
    )

    print(
        "PASS - no trading toolset exposed"
    )

    print(
        "PASS - trading authority false"
    )


if __name__ == "__main__":
    main()
