from __future__ import annotations

import asyncio
import json
import shutil
from typing import Any

from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

from app.config import Settings
from app.mcp.alpaca_readonly import safe_environment


def tool_schema(tool: Any) -> dict[str, Any]:
    schema = getattr(
        tool,
        "inputSchema",
        None,
    )

    if schema is None:
        schema = getattr(
            tool,
            "input_schema",
            None,
        )

    return schema or {}


def build_news_arguments(
    tool: Any,
    symbol: str,
    limit: int = 5,
) -> dict[str, Any]:
    schema = tool_schema(tool)

    properties = schema.get(
        "properties",
        {},
    )

    required = schema.get(
        "required",
        [],
    )

    args: dict[str, Any] = {}

    if "symbols" in properties:
        symbol_schema = properties["symbols"]

        if symbol_schema.get("type") == "array":
            args["symbols"] = [symbol]
        else:
            args["symbols"] = symbol

    elif "symbol" in properties:
        args["symbol"] = symbol

    if "limit" in properties:
        args["limit"] = limit

    if "sort" in properties:
        args["sort"] = "desc"

    for field in required:
        if field in args:
            continue

        if field == "symbols":
            field_schema = properties.get(
                field,
                {},
            )

            if field_schema.get("type") == "array":
                args[field] = [symbol]
            else:
                args[field] = symbol

        elif field == "symbol":
            args[field] = symbol

        elif field == "limit":
            args[field] = limit

        elif field == "sort":
            args[field] = "desc"

        else:
            raise RuntimeError(
                "Unknown required get_news field: "
                + field
            )

    return args


def collect_text_blocks(
    value: Any,
) -> list[str]:
    output: list[str] = []

    if isinstance(value, dict):
        for key, item in value.items():
            if (
                key == "text"
                and isinstance(item, str)
            ):
                output.append(item)
            else:
                output.extend(
                    collect_text_blocks(item)
                )

    elif isinstance(value, list):
        for item in value:
            output.extend(
                collect_text_blocks(item)
            )

    return output


def collect_headlines(
    value: Any,
) -> list[str]:
    output: list[str] = []

    if isinstance(value, dict):
        headline = value.get(
            "headline"
        ) or value.get(
            "title"
        )

        summary = value.get(
            "summary"
        )

        if (
            isinstance(headline, str)
            and headline.strip()
        ):
            line = headline.strip()

            if (
                isinstance(summary, str)
                and summary.strip()
            ):
                clean_summary = (
                    " ".join(
                        summary.split()
                    )
                )

                if len(clean_summary) > 220:
                    clean_summary = (
                        clean_summary[:217]
                        + "..."
                    )

                line += (
                    " — "
                    + clean_summary
                )

            output.append(line)

        for item in value.values():
            output.extend(
                collect_headlines(item)
            )

    elif isinstance(value, list):
        for item in value:
            output.extend(
                collect_headlines(item)
            )

    return output


def parse_news_result(
    result: Any,
    limit: int = 5,
) -> list[str]:
    if hasattr(
        result,
        "model_dump",
    ):
        raw = result.model_dump(
            mode="json"
        )
    else:
        raw = {
            "text": str(result)
        }

    headlines: list[str] = []

    headlines.extend(
        collect_headlines(raw)
    )

    for text in collect_text_blocks(raw):
        try:
            parsed = json.loads(text)

        except Exception:
            parsed = None

        if parsed is not None:
            headlines.extend(
                collect_headlines(
                    parsed
                )
            )

    unique: list[str] = []

    seen = set()

    for line in headlines:
        clean = " ".join(
            line.split()
        )

        if not clean:
            continue

        key = clean.lower()

        if key in seen:
            continue

        seen.add(key)
        unique.append(clean)

        if len(unique) >= limit:
            break

    return unique


async def fetch_news_async(
    settings: Settings,
    symbol: str,
    limit: int = 5,
) -> list[str]:
    settings.assert_paper_only()

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "News retrieval requires "
            "execution disabled."
        )

    uvx = shutil.which(
        "uvx"
    )

    if not uvx:
        raise RuntimeError(
            "uvx not installed."
        )

    server = StdioServerParameters(
        command=uvx,
        args=[
            "--from",
            "alpaca-mcp-server==2.3.0",
            "--with",
            "fastmcp==3.4.7",
            "alpaca-mcp-server",
        ],
        env=safe_environment(
            settings
        ),
    )

    async with stdio_client(
        server
    ) as (
        read_stream,
        write_stream,
    ):
        async with ClientSession(
            read_stream,
            write_stream,
        ) as session:
            await session.initialize()

            listed = (
                await session.list_tools()
            )

            tool_map = {
                tool.name: tool
                for tool in listed.tools
            }

            if "get_news" not in tool_map:
                raise RuntimeError(
                    "Alpaca MCP get_news "
                    "tool unavailable."
                )

            tool = tool_map[
                "get_news"
            ]

            args = build_news_arguments(
                tool,
                symbol,
                limit,
            )

            result = await session.call_tool(
                "get_news",
                arguments=args,
            )

            return parse_news_result(
                result,
                limit,
            )


def fetch_news(
    settings: Settings,
    symbol: str,
    limit: int = 5,
) -> list[str]:
    return asyncio.run(
        fetch_news_async(
            settings,
            symbol,
            limit,
        )
    )
