from __future__ import annotations

from datetime import (
    date,
    datetime,
)
from decimal import Decimal
from enum import Enum
from typing import Any
from uuid import (
    NAMESPACE_URL,
    uuid5,
)

from alpaca.trading.enums import (
    AssetClass,
    OrderClass,
    OrderSide,
    OrderType,
    PositionIntent,
    PositionSide,
    TimeInForce,
)
from alpaca.trading.requests import (
    LimitOrderRequest,
    OptionLegRequest,
)
from pydantic import (
    BaseModel,
    Field,
    model_validator,
)

from app.options_verticals import (
    VerticalSpreadType,
)


MODE = "OPTIONS_LIFECYCLE_SHADOW"

TRADING_AUTHORITY = False
ORDER_SUBMISSION_AUTHORITY = False
BROKER_CONNECTION = False
EXECUTION_EFFECT = False

PRODUCTION_EXIT_POLICY_CONFIGURED = False

CENT = Decimal("0.01")


class OptionsLifecycleError(
    ValueError
):
    pass


class LifecycleAction(
    str,
    Enum,
):
    HOLD = "hold"
    EXIT_PROFIT = "exit_profit"
    EXIT_STOP = "exit_stop"
    EXIT_THESIS_EXPIRED = (
        "exit_thesis_expired"
    )
    EXIT_DTE = "exit_dte"


class OptionsLifecyclePolicy(
    BaseModel
):
    """
    Explicit strategy policy.

    There are intentionally no production defaults for
    these strategy parameters. They must be configured
    and certified separately before autonomous entries.
    """

    profit_capture_pct: Decimal = Field(
        gt=0,
        le=100,
    )

    stop_loss_pct_of_debit: Decimal = Field(
        gt=0,
        le=100,
    )

    min_dte_exit: int = Field(
        ge=0,
        le=45,
    )


class OptionsPositionRecord(
    BaseModel
):
    record_id: str = Field(
        min_length=1,
        max_length=256,
    )

    underlying: str = Field(
        min_length=1,
        max_length=32,
    )

    spread_type: VerticalSpreadType

    long_symbol: str = Field(
        min_length=1,
        max_length=64,
    )

    short_symbol: str = Field(
        min_length=1,
        max_length=64,
    )

    quantity: int = Field(
        gt=0,
    )

    expiration: date

    opened_at: datetime

    thesis_expires_at: datetime

    entry_debit: Decimal = Field(
        gt=0,
    )

    width: Decimal = Field(
        gt=0,
    )

    max_loss_per_spread: Decimal = Field(
        gt=0,
    )

    max_profit_per_spread: Decimal = Field(
        gt=0,
    )

    @model_validator(
        mode="after"
    )
    def validate_record(
        self,
    ):
        if (
            self.long_symbol.upper()
            == self.short_symbol.upper()
        ):
            raise ValueError(
                "DUPLICATE_LEG_SYMBOL"
            )

        if (
            self.opened_at.utcoffset()
            is None
        ):
            raise ValueError(
                "OPENED_AT_MUST_BE_TIMEZONE_AWARE"
            )

        if (
            self.thesis_expires_at
            .utcoffset()
            is None
        ):
            raise ValueError(
                "THESIS_EXPIRY_MUST_BE_TIMEZONE_AWARE"
            )

        if (
            self.thesis_expires_at
            <= self.opened_at
        ):
            raise ValueError(
                "THESIS_EXPIRY_MUST_FOLLOW_OPEN"
            )

        if self.entry_debit >= self.width:
            raise ValueError(
                "ENTRY_DEBIT_MUST_BE_BELOW_WIDTH"
            )

        return self


class BrokerOptionPosition(
    BaseModel
):
    symbol: str = Field(
        min_length=1,
        max_length=64,
    )

    asset_class: AssetClass = (
        AssetClass.US_OPTION
    )

    side: PositionSide

    quantity: int = Field(
        gt=0,
    )

    @model_validator(
        mode="after"
    )
    def options_only(
        self,
    ):
        if (
            self.asset_class
            != AssetClass.US_OPTION
        ):
            raise ValueError(
                "NON_OPTION_POSITION_FORBIDDEN"
            )

        return self


class OptionsLifecycleDecision(
    BaseModel
):
    mode: str = MODE

    record_id: str

    action: LifecycleAction

    exit_required: bool

    reason: str

    close_credit: Decimal = Field(
        ge=0,
    )

    entry_debit: Decimal = Field(
        gt=0,
    )

    profit_target_credit: Decimal = Field(
        ge=0,
    )

    stop_credit: Decimal = Field(
        ge=0,
    )

    unrealized_pnl_per_spread: Decimal

    dte: int

    trading_authority: bool = False
    order_submission_authority: bool = False
    broker_connection: bool = False
    execution_effect: bool = False


class OptionsCloseIntent(
    BaseModel
):
    mode: str = "OPTIONS_CLOSE_MLEG_INTENT_SHADOW"

    record_id: str

    client_order_id: str = Field(
        min_length=1,
        max_length=64,
    )

    underlying: str

    spread_type: VerticalSpreadType

    quantity: int = Field(
        gt=0,
    )

    close_credit: Decimal = Field(
        gt=0,
    )

    alpaca_limit_price: Decimal = Field(
        lt=0,
    )

    long_symbol: str
    short_symbol: str

    request_payload: dict[str, Any]

    trading_authority: bool = False
    order_submission_authority: bool = False
    broker_connection: bool = False
    execution_effect: bool = False


def reconcile_broker_positions(
    *,
    record: OptionsPositionRecord,
    positions: list[
        BrokerOptionPosition
    ],
) -> dict[
    str,
    BrokerOptionPosition,
]:
    """
    Fail closed unless the broker contains exactly the
    two expected option legs with exact sides and sizes.
    """

    if len(positions) != 2:
        raise OptionsLifecycleError(
            "EXPECTED_EXACTLY_TWO_OPTION_POSITIONS"
        )

    by_symbol = {}

    for position in positions:
        key = position.symbol.upper()

        if key in by_symbol:
            raise OptionsLifecycleError(
                "DUPLICATE_BROKER_POSITION_SYMBOL"
            )

        by_symbol[key] = position

    long_key = record.long_symbol.upper()
    short_key = record.short_symbol.upper()

    if set(
        by_symbol
    ) != {
        long_key,
        short_key,
    }:
        raise OptionsLifecycleError(
            "BROKER_POSITION_SYMBOL_MISMATCH"
        )

    long_position = by_symbol[
        long_key
    ]

    short_position = by_symbol[
        short_key
    ]

    if (
        long_position.side
        != PositionSide.LONG
    ):
        raise OptionsLifecycleError(
            "LONG_LEG_BROKER_SIDE_MISMATCH"
        )

    if (
        short_position.side
        != PositionSide.SHORT
    ):
        raise OptionsLifecycleError(
            "SHORT_LEG_BROKER_SIDE_MISMATCH"
        )

    if (
        long_position.quantity
        != record.quantity
    ):
        raise OptionsLifecycleError(
            "LONG_LEG_QUANTITY_MISMATCH"
        )

    if (
        short_position.quantity
        != record.quantity
    ):
        raise OptionsLifecycleError(
            "SHORT_LEG_QUANTITY_MISMATCH"
        )

    return {
        "long": long_position,
        "short": short_position,
    }


def evaluate_lifecycle(
    *,
    record: OptionsPositionRecord,
    positions: list[
        BrokerOptionPosition
    ],
    close_credit: Decimal,
    policy: OptionsLifecyclePolicy,
    as_of: datetime,
) -> OptionsLifecycleDecision:
    """
    Deterministic measurement-only lifecycle decision.

    close_credit is the positive economic credit that
    could currently be received to close the spread.
    """

    reconcile_broker_positions(
        record=record,
        positions=positions,
    )

    if as_of.utcoffset() is None:
        raise OptionsLifecycleError(
            "AS_OF_MUST_BE_TIMEZONE_AWARE"
        )

    close_credit = Decimal(
        str(
            close_credit
        )
    )

    if close_credit < 0:
        raise OptionsLifecycleError(
            "NEGATIVE_ECONOMIC_CLOSE_CREDIT"
        )

    if close_credit > record.width:
        raise OptionsLifecycleError(
            "CLOSE_CREDIT_EXCEEDS_SPREAD_WIDTH"
        )

    profit_fraction = (
        policy.profit_capture_pct
        / Decimal("100")
    )

    stop_fraction = (
        policy.stop_loss_pct_of_debit
        / Decimal("100")
    )

    profit_target_credit = (
        record.entry_debit
        + (
            record.max_profit_per_spread
            / Decimal("100")
        )
        * profit_fraction
    )

    stop_credit = (
        record.entry_debit
        * (
            Decimal("1")
            - stop_fraction
        )
    )

    if stop_credit < 0:
        stop_credit = Decimal("0")

    dte = (
        record.expiration
        - as_of.date()
    ).days

    pnl_per_spread = (
        (
            close_credit
            - record.entry_debit
        )
        * Decimal("100")
    )

    # Safety/time exits take priority over profit exits.
    if as_of >= record.thesis_expires_at:
        action = (
            LifecycleAction
            .EXIT_THESIS_EXPIRED
        )

        reason = "THESIS_EXPIRED"

    elif dte <= policy.min_dte_exit:
        action = (
            LifecycleAction
            .EXIT_DTE
        )

        reason = "MIN_DTE_EXIT"

    elif close_credit <= stop_credit:
        action = (
            LifecycleAction
            .EXIT_STOP
        )

        reason = "STOP_LOSS_THRESHOLD"

    elif (
        close_credit
        >= profit_target_credit
    ):
        action = (
            LifecycleAction
            .EXIT_PROFIT
        )

        reason = "PROFIT_TARGET"

    else:
        action = LifecycleAction.HOLD
        reason = "HOLD"

    return OptionsLifecycleDecision(
        record_id=record.record_id,
        action=action,
        exit_required=(
            action
            != LifecycleAction.HOLD
        ),
        reason=reason,
        close_credit=close_credit,
        entry_debit=
            record.entry_debit,
        profit_target_credit=
            profit_target_credit,
        stop_credit=stop_credit,
        unrealized_pnl_per_spread=
            pnl_per_spread,
        dte=dte,
        trading_authority=False,
        order_submission_authority=False,
        broker_connection=False,
        execution_effect=False,
    )


def close_client_order_id(
    *,
    record_id: str,
    decision_id: str,
) -> str:
    raw = (
        "dark-wolf-options-close:"
        + record_id.strip()
        + ":"
        + decision_id.strip()
    )

    if not record_id.strip():
        raise OptionsLifecycleError(
            "EMPTY_RECORD_ID"
        )

    if not decision_id.strip():
        raise OptionsLifecycleError(
            "EMPTY_EXIT_DECISION_ID"
        )

    return (
        "dwoc-"
        + str(
            uuid5(
                NAMESPACE_URL,
                raw,
            )
        )
    )


def build_close_mleg_intent(
    *,
    record: OptionsPositionRecord,
    decision: OptionsLifecycleDecision,
    close_credit_limit: Decimal,
    decision_id: str,
) -> tuple[
    OptionsCloseIntent,
    LimitOrderRequest,
]:
    """
    Serialize an inert long-debit-vertical closing MLEG.

    Economic close credit is positive internally.
    Alpaca MLEG credit limit is serialized NEGATIVE.
    """

    if (
        decision.record_id
        != record.record_id
    ):
        raise OptionsLifecycleError(
            "LIFECYCLE_RECORD_DECISION_MISMATCH"
        )

    if not decision.exit_required:
        raise OptionsLifecycleError(
            "EXIT_NOT_REQUIRED"
        )

    if (
        decision.action
        == LifecycleAction.HOLD
    ):
        raise OptionsLifecycleError(
            "HOLD_CANNOT_BUILD_EXIT"
        )

    if decision.trading_authority:
        raise OptionsLifecycleError(
            "DECISION_TRADING_AUTHORITY_FORBIDDEN"
        )

    if decision.order_submission_authority:
        raise OptionsLifecycleError(
            "DECISION_ORDER_AUTHORITY_FORBIDDEN"
        )

    if decision.broker_connection:
        raise OptionsLifecycleError(
            "DECISION_BROKER_CONNECTION_FORBIDDEN"
        )

    if decision.execution_effect:
        raise OptionsLifecycleError(
            "DECISION_EXECUTION_EFFECT_FORBIDDEN"
        )

    credit = Decimal(
        str(
            close_credit_limit
        )
    )

    if credit <= 0:
        raise OptionsLifecycleError(
            "CLOSE_CREDIT_MUST_BE_POSITIVE"
        )

    # Pricing policy is intentionally separate.
    # The lifecycle layer accepts only an already
    # cent-denominated minimum acceptable credit.
    if (
        credit.quantize(
            CENT
        )
        != credit
    ):
        raise OptionsLifecycleError(
            "CLOSE_CREDIT_MUST_BE_CENT_DENOMINATED"
        )

    if credit > record.width:
        raise OptionsLifecycleError(
            "CLOSE_CREDIT_EXCEEDS_SPREAD_WIDTH"
        )

    client_order_id = (
        close_client_order_id(
            record_id=
                record.record_id,
            decision_id=
                decision_id,
        )
    )

    legs = [
        OptionLegRequest(
            symbol=
                record.long_symbol,
            ratio_qty=1,
            side=OrderSide.SELL,
            position_intent=
                PositionIntent
                .SELL_TO_CLOSE,
        ),
        OptionLegRequest(
            symbol=
                record.short_symbol,
            ratio_qty=1,
            side=OrderSide.BUY,
            position_intent=
                PositionIntent
                .BUY_TO_CLOSE,
        ),
    ]

    alpaca_limit = -credit

    request = LimitOrderRequest(
        qty=float(
            record.quantity
        ),
        type=OrderType.LIMIT,
        time_in_force=
            TimeInForce.DAY,
        order_class=
            OrderClass.MLEG,
        legs=legs,
        limit_price=float(
            alpaca_limit
        ),
        client_order_id=
            client_order_id,
    )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    if payload.get(
        "order_class"
    ) != "mleg":
        raise OptionsLifecycleError(
            "CLOSE_ORDER_CLASS_MUST_BE_MLEG"
        )

    if payload.get(
        "type"
    ) != "limit":
        raise OptionsLifecycleError(
            "CLOSE_MARKET_ORDER_FORBIDDEN"
        )

    if payload.get(
        "time_in_force"
    ) != "day":
        raise OptionsLifecycleError(
            "CLOSE_TIF_MUST_BE_DAY"
        )

    if payload.get(
        "limit_price"
    ) >= 0:
        raise OptionsLifecycleError(
            "CLOSE_CREDIT_ALPACA_LIMIT_MUST_BE_NEGATIVE"
        )

    payload_legs = payload.get(
        "legs",
        [],
    )

    if len(payload_legs) != 2:
        raise OptionsLifecycleError(
            "CLOSE_MLEG_REQUIRES_TWO_LEGS"
        )

    return (
        OptionsCloseIntent(
            record_id=
                record.record_id,
            client_order_id=
                client_order_id,
            underlying=
                record.underlying,
            spread_type=
                record.spread_type,
            quantity=
                record.quantity,
            close_credit=
                credit,
            alpaca_limit_price=
                alpaca_limit,
            long_symbol=
                record.long_symbol,
            short_symbol=
                record.short_symbol,
            request_payload=
                payload,
            trading_authority=False,
            order_submission_authority=False,
            broker_connection=False,
            execution_effect=False,
        ),
        request,
    )


def status() -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "production_exit_policy_configured":
            PRODUCTION_EXIT_POLICY_CONFIGURED,

        "broker_positions_required":
            True,

        "exact_two_leg_reconciliation":
            True,

        "profit_exit_supported":
            True,

        "stop_exit_supported":
            True,

        "thesis_expiry_exit_supported":
            True,

        "dte_exit_supported":
            True,

        "close_long_leg":
            "sell_to_close",

        "close_short_leg":
            "buy_to_close",

        "close_order_class":
            "mleg",

        "close_order_type":
            "limit",

        "close_credit_internal_sign":
            "positive",

        "alpaca_close_credit_sign":
            "negative",

        "pricing_policy_embedded":
            False,

        "trading_authority":
            TRADING_AUTHORITY,

        "order_submission_authority":
            ORDER_SUBMISSION_AUTHORITY,

        "broker_connection":
            BROKER_CONNECTION,

        "execution_effect":
            EXECUTION_EFFECT,
    }
