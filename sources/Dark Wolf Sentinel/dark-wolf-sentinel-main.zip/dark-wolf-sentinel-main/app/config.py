from __future__ import annotations

from functools import lru_cache

from pydantic import Field
from pydantic_settings import (
    BaseSettings,
    SettingsConfigDict,
)


class Settings(BaseSettings):
    """Dark Wolf Sentinel runtime configuration."""

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
    )

    alpaca_api_key: str | None = Field(
        default=None,
        alias="ALPACA_API_KEY",
    )

    alpaca_secret_key: str | None = Field(
        default=None,
        alias="ALPACA_SECRET_KEY",
    )

    alpaca_paper: bool = Field(
        default=True,
        alias="ALPACA_PAPER",
    )

    openai_api_key: str | None = Field(
        default=None,
        alias="OPENAI_API_KEY",
    )

    openai_model: str = Field(
        default="gpt-5.6",
        alias="OPENAI_MODEL",
    )

    paper_execution_enabled: bool = Field(
        default=False,
        alias="SENTINEL_PAPER_EXECUTION_ENABLED",
    )

    options_paper_execution_enabled: bool = Field(
        default=False,
        alias="SENTINEL_OPTIONS_PAPER_EXECUTION_ENABLED",
    )

    starting_equity: float = Field(
        default=100_000.0,
        alias="SENTINEL_STARTING_EQUITY",
    )

    min_confidence: float = Field(
        default=85.0,
        alias="SENTINEL_MIN_CONFIDENCE",
    )

    max_total_risk_pct: float = Field(
        default=3.0,
        alias="SENTINEL_MAX_TOTAL_RISK_PCT",
    )

    max_crypto_risk_pct: float = Field(
        default=1.0,
        alias="SENTINEL_MAX_CRYPTO_RISK_PCT",
    )

    max_exposure_pct: float = Field(
        default=60.0,
        alias="SENTINEL_MAX_EXPOSURE_PCT",
    )

    risk_per_trade_pct: float = Field(
        default=1.0,
        alias="SENTINEL_RISK_PER_TRADE_PCT",
    )

    max_position_pct: float = Field(
        default=20.0,
        alias="SENTINEL_MAX_POSITION_PCT",
    )

    @property
    def openai_configured(self) -> bool:
        return bool(
            self.openai_api_key
        )

    @property
    def alpaca_configured(self) -> bool:
        return bool(
            self.alpaca_api_key
            and self.alpaca_secret_key
        )

    def assert_paper_only(self) -> None:
        if self.alpaca_paper is not True:
            raise RuntimeError(
                "Dark Wolf Sentinel is PAPER ONLY."
            )


@lru_cache
def get_settings() -> Settings:
    settings = Settings()
    settings.assert_paper_only()
    return settings
