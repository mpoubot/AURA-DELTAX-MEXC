from __future__ import annotations

from enum import Enum

from pydantic import BaseModel, Field


class AssetClass(str, Enum):
    EQUITY = "equity"
    CRYPTO = "crypto"


class TradeSide(str, Enum):
    BUY = "buy"


class TradeCandidate(BaseModel):
    symbol: str = Field(
        min_length=1,
        max_length=32,
    )

    asset_class: AssetClass

    side: TradeSide = TradeSide.BUY

    entry_price: float = Field(gt=0)
    stop_price: float = Field(gt=0)
    target_price: float = Field(gt=0)

    confidence: float = Field(
        ge=0,
        le=100,
    )

    thesis: str = Field(
        min_length=1,
        max_length=4000,
    )

    catalyst: str | None = Field(
        default=None,
        max_length=2000,
    )

    invalidation: str | None = Field(
        default=None,
        max_length=2000,
    )


class PortfolioState(BaseModel):
    equity: float = Field(gt=0)

    current_open_risk: float = Field(
        ge=0,
        default=0,
    )

    current_crypto_risk: float = Field(
        ge=0,
        default=0,
    )

    current_exposure: float = Field(
        ge=0,
        default=0,
    )

    open_symbols: list[str] = Field(
        default_factory=list,
    )

    kill_switch: bool = False


class RiskDecision(BaseModel):
    approved: bool
    reason: str

    symbol: str

    quantity: float = 0
    position_value: float = 0

    risk_dollars: float = 0
    risk_pct_equity: float = 0

    exposure_after: float = 0
    total_risk_after: float = 0
    crypto_risk_after: float = 0

    live_order_allowed: bool = False
    trading_authority: bool = False
