from __future__ import annotations

from fastapi import FastAPI, HTTPException

from app.audit import (
    init_db,
    record_decision,
)
from app.broker.alpaca_paper import (
    AlpacaPaperBroker,
)
from app.config import (
    get_settings,
)
from app.models import (
    PortfolioState,
    RiskDecision,
    TradeCandidate,
)
from app.risk import (
    RiskPolicy,
    evaluate_trade,
)


app = FastAPI(
    title="Dark Wolf Sentinel",
    version="0.1.0",
)


@app.on_event("startup")
def startup() -> None:
    settings = get_settings()
    settings.assert_paper_only()
    init_db()


@app.get("/health")
def health() -> dict:
    settings = get_settings()

    return {
        "status": "ok",
        "project":
            "Dark Wolf Sentinel",
        "mode": "PAPER",
        "alpaca_paper": True,
        "alpaca_configured":
            settings.alpaca_configured,
        "order_submission_enabled":
            False,
        "live_trading": False,
        "trading_authority": False,
    }


@app.post(
    "/risk/evaluate",
    response_model=RiskDecision,
)
def risk_evaluate(
    candidate: TradeCandidate,
    portfolio: PortfolioState,
) -> RiskDecision:
    settings = get_settings()

    policy = RiskPolicy.from_settings(
        settings
    )

    decision = evaluate_trade(
        candidate,
        portfolio,
        policy,
    )

    record_decision(
        candidate,
        portfolio,
        decision,
    )

    return decision


@app.get("/alpaca/snapshot")
def alpaca_snapshot() -> dict:
    settings = get_settings()

    if not settings.alpaca_configured:
        raise HTTPException(
            status_code=503,
            detail=(
                "Alpaca PAPER credentials "
                "not configured."
            ),
        )

    try:
        broker = AlpacaPaperBroker(
            settings
        )

        return broker.snapshot()

    except Exception as exc:
        raise HTTPException(
            status_code=502,
            detail=(
                "Alpaca PAPER read failed: "
                f"{type(exc).__name__}"
            ),
        ) from exc
