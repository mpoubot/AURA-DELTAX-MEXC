from __future__ import annotations

from typing import Any

from app.options_order_intent import (
    build_mleg_request,
)
from app.options_selector import (
    OptionSelectionResult,
)


MODE = "SENTINEL_OPTIONS_MLEG_INTENT_SHADOW"

TRADING_AUTHORITY = False
ORDER_SUBMISSION_AUTHORITY = False
BROKER_CONNECTION = False
EXECUTION_EFFECT = False


def _empty_result(
    *,
    status: str,
    reason: str,
) -> dict[str, Any]:
    return {
        "mode": MODE,
        "status": status,
        "reason": reason,
        "intent": None,
        "request_payload": None,
        "trading_authority": False,
        "order_submission_authority": False,
        "broker_connection": False,
        "execution_effect": False,
    }


def build_shadow_order_intent(
    *,
    options_shadow: dict[str, Any],
    decision_id: str,
) -> dict[str, Any] | None:
    """
    Convert an approved options-shadow result into an
    Alpaca-compatible but completely inert MLEG packet.

    No broker or executor dependency exists here.
    """

    if (
        options_shadow.get(
            "trading_authority",
            False,
        )
        or options_shadow.get(
            "order_authority",
            False,
        )
        or options_shadow.get(
            "execution_effect",
            False,
        )
    ):
        return _empty_result(
            status="DEGRADED",
            reason="OPTIONS_SHADOW_AUTHORITY_FORBIDDEN",
        )

    shadow_status = options_shadow.get(
        "status"
    )

    if shadow_status == "SKIPPED_PASS":
        return None

    if shadow_status != "OK":
        return _empty_result(
            status="SKIPPED",
            reason=(
                "OPTIONS_SHADOW_NOT_OK:"
                + str(shadow_status)
            ),
        )

    raw_selection = options_shadow.get(
        "selection"
    )

    if not isinstance(
        raw_selection,
        dict,
    ):
        return _empty_result(
            status="DEGRADED",
            reason="MISSING_OPTIONS_SELECTION",
        )

    try:
        selection = (
            OptionSelectionResult
            .model_validate(
                raw_selection
            )
        )

        if not selection.selected:
            return _empty_result(
                status="SKIPPED",
                reason="OPTIONS_NOT_SELECTED",
            )

        if selection.risk_decision is None:
            return _empty_result(
                status="DEGRADED",
                reason="MISSING_OPTIONS_RISK_DECISION",
            )

        if not selection.risk_decision.approved:
            return _empty_result(
                status="SKIPPED",
                reason="OPTIONS_RISK_NOT_APPROVED",
            )

        intent, request = build_mleg_request(
            selection=selection,
            decision_id=decision_id,
        )

        return {
            "mode": MODE,
            "status": "READY_INERT",
            "reason": "BROKER_READY_INTENT_NO_EXECUTION",
            "intent": intent.model_dump(
                mode="json"
            ),
            "request_payload": request.model_dump(
                mode="json",
                exclude_none=True,
            ),
            "trading_authority": False,
            "order_submission_authority": False,
            "broker_connection": False,
            "execution_effect": False,
        }

    except Exception as exc:
        result = _empty_result(
            status="DEGRADED",
            reason="INTENT_BUILD_FAILED",
        )

        result["error_type"] = type(
            exc
        ).__name__

        return result


def status() -> dict[str, Any]:
    return {
        "mode": MODE,
        "input":
            "APPROVED_OPTIONS_SHADOW_SELECTION",
        "output":
            "INERT_ALPACA_MLEG_INTENT",
        "pass_creates_intent":
            False,
        "risk_approval_required":
            True,
        "executor_dependency":
            False,
        "trading_authority":
            TRADING_AUTHORITY,
        "order_submission_authority":
            ORDER_SUBMISSION_AUTHORITY,
        "broker_connection":
            BROKER_CONNECTION,
        "execution_effect":
            EXECUTION_EFFECT,
    }
