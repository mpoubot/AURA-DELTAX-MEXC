from __future__ import annotations

from typing import Any

from alpaca.trading.client import TradingClient
from alpaca.trading.enums import QueryOrderStatus
from alpaca.trading.requests import GetOrdersRequest

from app.config import Settings


class AlpacaPaperBroker:
    """Read-only Alpaca PAPER adapter.

    STEP 3 intentionally contains no submit_order,
    cancel_order, or live-trading implementation.
    """

    PAPER_ONLY = True
    TRADING_AUTHORITY = False
    ORDER_SUBMISSION_ENABLED = False

    def __init__(
        self,
        settings: Settings,
    ) -> None:
        settings.assert_paper_only()

        if not settings.alpaca_configured:
            raise RuntimeError(
                "Alpaca PAPER credentials "
                "are not configured."
            )

        self._client = TradingClient(
            settings.alpaca_api_key,
            settings.alpaca_secret_key,
            paper=True,
        )

    def account(self) -> dict[str, Any]:
        account = self._client.get_account()

        account_id = str(account.id)

        masked_id = (
            "*" * max(
                0,
                len(account_id) - 4,
            )
            + account_id[-4:]
        )

        return {
            "account_id_masked": masked_id,
            "status": str(account.status),
            "currency": str(account.currency),
            "cash": float(account.cash),
            "equity": float(account.equity),
            "buying_power": float(
                account.buying_power
            ),
            "pattern_day_trader": bool(
                account.pattern_day_trader
            ),
        }

    def positions(self) -> list[dict[str, Any]]:
        positions = (
            self._client.get_all_positions()
        )

        return [
            {
                "symbol": item.symbol,
                "qty": float(item.qty),
                "side": str(item.side),
                "market_value": float(
                    item.market_value
                ),
                "avg_entry_price": float(
                    item.avg_entry_price
                ),
                "unrealized_pl": float(
                    item.unrealized_pl
                ),
            }
            for item in positions
        ]

    def open_orders(self) -> list[dict[str, Any]]:
        request = GetOrdersRequest(
            status=QueryOrderStatus.OPEN,
        )

        orders = self._client.get_orders(
            filter=request
        )

        return [
            {
                "id": str(item.id),
                "client_order_id":
                    item.client_order_id,
                "symbol": item.symbol,
                "side": str(item.side),
                "type": str(item.type),
                "status": str(item.status),
                "qty": (
                    float(item.qty)
                    if item.qty is not None
                    else None
                ),
                "notional": (
                    float(item.notional)
                    if item.notional is not None
                    else None
                ),
            }
            for item in orders
        ]

    def snapshot(self) -> dict[str, Any]:
        return {
            "mode": "ALPACA_PAPER_READ_ONLY",
            "paper": True,
            "trading_authority": False,
            "order_submission_enabled": False,
            "account": self.account(),
            "positions": self.positions(),
            "open_orders": self.open_orders(),
        }
