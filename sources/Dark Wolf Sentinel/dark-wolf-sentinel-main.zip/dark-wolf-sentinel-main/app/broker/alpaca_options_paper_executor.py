from __future__ import annotations

from decimal import Decimal
from typing import Any

from alpaca.trading.requests import (
    LimitOrderRequest,
)
from pydantic import BaseModel

from app.options_order_intent import (
    OptionsMlegIntent,
)


MODE = "OPTIONS_PAPER_EXECUTOR_DORMANT"

LIVE_TRADING = False
AI_TRADING_AUTHORITY = False


class OptionsPaperExecutionError(
    RuntimeError
):
    pass


class OptionsPaperExecutionResult(
    BaseModel
):
    mode: str = MODE

    submitted: bool

    reason: str

    client_order_id: str

    broker_order_id: str | None = None

    broker_status: str | None = None

    paper_execution: bool = True

    live_trading: bool = False

    ai_trading_authority: bool = False


def _money(
    value: Any,
) -> Decimal:
    return Decimal(
        str(value)
    ).quantize(
        Decimal("0.01")
    )


def validate_request_against_intent(
    *,
    intent: OptionsMlegIntent,
    request: LimitOrderRequest,
) -> None:
    """
    Revalidate an inert MLEG intent immediately before
    a PAPER submission boundary.

    The intent itself carries zero authority.
    """

    if intent.trading_authority:
        raise OptionsPaperExecutionError(
            "INTENT_TRADING_AUTHORITY_FORBIDDEN"
        )

    if intent.order_submission_authority:
        raise OptionsPaperExecutionError(
            "INTENT_SUBMISSION_AUTHORITY_FORBIDDEN"
        )

    if intent.broker_connection:
        raise OptionsPaperExecutionError(
            "INTENT_BROKER_CONNECTION_FORBIDDEN"
        )

    if intent.execution_effect:
        raise OptionsPaperExecutionError(
            "INTENT_EXECUTION_EFFECT_FORBIDDEN"
        )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    if payload.get(
        "order_class"
    ) != "mleg":
        raise OptionsPaperExecutionError(
            "ORDER_CLASS_MUST_BE_MLEG"
        )

    if payload.get(
        "type"
    ) != "limit":
        raise OptionsPaperExecutionError(
            "MARKET_ORDER_FORBIDDEN"
        )

    if payload.get(
        "time_in_force"
    ) != "day":
        raise OptionsPaperExecutionError(
            "TIME_IN_FORCE_MUST_BE_DAY"
        )

    if "symbol" in payload:
        raise OptionsPaperExecutionError(
            "TOP_LEVEL_SYMBOL_FORBIDDEN"
        )

    if "side" in payload:
        raise OptionsPaperExecutionError(
            "TOP_LEVEL_SIDE_FORBIDDEN"
        )

    if "notional" in payload:
        raise OptionsPaperExecutionError(
            "NOTIONAL_FORBIDDEN"
        )

    qty = payload.get(
        "qty"
    )

    if qty is None:
        raise OptionsPaperExecutionError(
            "QUANTITY_REQUIRED"
        )

    if float(qty) <= 0:
        raise OptionsPaperExecutionError(
            "NON_POSITIVE_QUANTITY"
        )

    if float(qty) != float(
        intent.quantity
    ):
        raise OptionsPaperExecutionError(
            "QUANTITY_INTENT_MISMATCH"
        )

    limit_price = payload.get(
        "limit_price"
    )

    if limit_price is None:
        raise OptionsPaperExecutionError(
            "LIMIT_PRICE_REQUIRED"
        )

    if _money(
        limit_price
    ) != intent.limit_price:
        raise OptionsPaperExecutionError(
            "LIMIT_PRICE_INTENT_MISMATCH"
        )

    if payload.get(
        "client_order_id"
    ) != intent.client_order_id:
        raise OptionsPaperExecutionError(
            "CLIENT_ORDER_ID_MISMATCH"
        )

    legs = payload.get(
        "legs",
        []
    )

    if len(legs) != 2:
        raise OptionsPaperExecutionError(
            "EXACTLY_TWO_LEGS_REQUIRED"
        )

    long_leg = legs[0]
    short_leg = legs[1]

    if (
        long_leg.get("symbol")
        != intent.long_symbol
    ):
        raise OptionsPaperExecutionError(
            "LONG_SYMBOL_MISMATCH"
        )

    if (
        short_leg.get("symbol")
        != intent.short_symbol
    ):
        raise OptionsPaperExecutionError(
            "SHORT_SYMBOL_MISMATCH"
        )

    if (
        long_leg.get("side")
        != "buy"
    ):
        raise OptionsPaperExecutionError(
            "LONG_LEG_MUST_BUY"
        )

    if (
        long_leg.get(
            "position_intent"
        )
        != "buy_to_open"
    ):
        raise OptionsPaperExecutionError(
            "LONG_INTENT_MUST_BUY_TO_OPEN"
        )

    if (
        short_leg.get("side")
        != "sell"
    ):
        raise OptionsPaperExecutionError(
            "SHORT_LEG_MUST_SELL"
        )

    if (
        short_leg.get(
            "position_intent"
        )
        != "sell_to_open"
    ):
        raise OptionsPaperExecutionError(
            "SHORT_INTENT_MUST_SELL_TO_OPEN"
        )


class AlpacaOptionsPaperExecutor:
    """
    Dormant PAPER-only submission boundary.

    A broker client must be explicitly injected.

    This class does not create a broker client and is not
    connected to the Sentinel worker.
    """

    def __init__(
        self,
        settings: Any,
        *,
        client: Any,
    ) -> None:
        if client is None:
            raise OptionsPaperExecutionError(
                "BROKER_CLIENT_REQUIRED"
            )

        self.settings = settings
        self.client = client

    def execute(
        self,
        *,
        intent: OptionsMlegIntent,
        request: LimitOrderRequest,
    ) -> OptionsPaperExecutionResult:
        self.settings.assert_paper_only()

        if (
            getattr(
                self.settings,
                "alpaca_paper",
                False,
            )
            is not True
        ):
            raise OptionsPaperExecutionError(
                "NON_PAPER_ACCOUNT_FORBIDDEN"
            )

        if (
            getattr(
                self.settings,
                "options_paper_execution_enabled",
                False,
            )
            is not True
        ):
            raise OptionsPaperExecutionError(
                "OPTIONS_PAPER_EXECUTION_DISABLED"
            )

        validate_request_against_intent(
            intent=intent,
            request=request,
        )

        # This is the only broker-effect boundary in
        # this dormant module. Production code does not
        # instantiate this class yet.
        order = self.client.submit_order(
            order_data=request
        )

        order_id = getattr(
            order,
            "id",
            None,
        )

        status = getattr(
            order,
            "status",
            None,
        )

        return OptionsPaperExecutionResult(
            submitted=True,
            reason=
                "PAPER_MLEG_SUBMITTED",
            client_order_id=
                intent.client_order_id,
            broker_order_id=(
                str(order_id)
                if order_id
                is not None
                else None
            ),
            broker_status=(
                str(
                    getattr(
                        status,
                        "value",
                        status,
                    )
                )
                if status
                is not None
                else None
            ),
            paper_execution=True,
            live_trading=False,
            ai_trading_authority=False,
        )


def status() -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "broker_client_factory":
            False,

        "client_injection_required":
            True,

        "paper_only":
            True,

        "paper_execution_flag_required":
            True,

        "request_revalidation":
            True,

        "supported_order_class":
            "mleg",

        "supported_order_type":
            "limit",

        "supported_time_in_force":
            "day",

        "live_trading":
            LIVE_TRADING,

        "ai_trading_authority":
            AI_TRADING_AUTHORITY,

        "connected_to_worker":
            False,
    }
