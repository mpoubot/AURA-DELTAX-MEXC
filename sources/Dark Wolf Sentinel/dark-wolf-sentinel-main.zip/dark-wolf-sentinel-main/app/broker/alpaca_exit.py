from __future__ import annotations

import json
from typing import Any
from uuid import (
    NAMESPACE_URL,
    uuid5,
)

from alpaca.trading.client import TradingClient
from alpaca.trading.enums import (
    OrderSide,
    TimeInForce,
)
from alpaca.trading.requests import (
    MarketOrderRequest,
)

from app.broker.alpaca_executor import (
    public_order,
)
from app.config import Settings
from app.exit_journal import (
    create_or_get_exit,
    get_exit,
    mark_exit_reconciled,
    mark_exit_submitted,
)


def exit_client_order_id_for(
    entry_decision_id: str,
) -> str:
    value = uuid5(
        NAMESPACE_URL,
        (
            "dark-wolf-sentinel-exit:"
            + entry_decision_id
        ),
    )

    return f"dws-exit-{value}"


class AlpacaPaperExitExecutor:
    """Deterministic PAPER-only risk-reducing exit."""

    PAPER_ONLY = True
    LIVE_TRADING = False
    TRADING_AUTHORITY = False

    def __init__(
        self,
        settings: Settings,
        *,
        client: Any | None = None,
    ) -> None:
        settings.assert_paper_only()

        self.settings = settings

        if client is not None:
            self.client = client

        else:
            if not settings.alpaca_configured:
                raise RuntimeError(
                    "Alpaca PAPER credentials missing."
                )

            self.client = TradingClient(
                settings.alpaca_api_key,
                settings.alpaca_secret_key,
                paper=True,
            )

    def prepare(
        self,
        *,
        symbol: str,
        quantity: float,
        entry_decision_id: str,
    ) -> dict[str, Any]:
        symbol = symbol.upper().strip()

        if quantity <= 0:
            raise RuntimeError(
                "Exit quantity must be positive."
            )

        position = self.client.get_open_position(
            symbol
        )

        held = float(
            position.qty
        )

        if held <= 0:
            raise RuntimeError(
                "Broker confirms no long "
                "position to exit."
            )

        if quantity > held + 1e-9:
            raise RuntimeError(
                "Exit quantity exceeds "
                "broker-confirmed position."
            )

        cid = exit_client_order_id_for(
            entry_decision_id
        )

        return create_or_get_exit(
            entry_decision_id=
                entry_decision_id,
            symbol=symbol,
            quantity=quantity,
            client_order_id=cid,
        )

    def submit(
        self,
        *,
        symbol: str,
        quantity: float,
        entry_decision_id: str,
    ) -> dict[str, Any]:
        if (
            self.settings.paper_execution_enabled
            is not True
        ):
            raise RuntimeError(
                "PAPER execution is disabled."
            )

        intent = self.prepare(
            symbol=symbol,
            quantity=quantity,
            entry_decision_id=
                entry_decision_id,
        )

        if intent["state"] in {
            "SUBMITTED",
            "RECONCILED",
        }:
            response = (
                json.loads(
                    intent["response_json"]
                )
                if intent.get(
                    "response_json"
                )
                else {}
            )

            return {
                "duplicate_prevented": True,
                "intent": intent,
                "order": response,
            }

        request = MarketOrderRequest(
            symbol=intent["symbol"],
            qty=float(
                intent["quantity"]
            ),
            side=OrderSide.SELL,
            time_in_force=TimeInForce.DAY,
            client_order_id=
                intent["client_order_id"],
        )

        order = self.client.submit_order(
            order_data=request
        )

        response = public_order(
            order
        )

        mark_exit_submitted(
            entry_decision_id=
                entry_decision_id,
            broker_order_id=
                response["order_id"],
            broker_status=
                response["status"],
            response=response,
        )

        return {
            "duplicate_prevented": False,
            "intent":
                get_exit(
                    entry_decision_id
                ),
            "order": response,
        }

    def reconcile(
        self,
        *,
        entry_decision_id: str,
    ) -> dict[str, Any]:
        intent = get_exit(
            entry_decision_id
        )

        if not intent:
            raise RuntimeError(
                "Exit intent not found."
            )

        if not intent.get(
            "broker_order_id"
        ):
            raise RuntimeError(
                "Exit intent has no broker order."
            )

        order = self.client.get_order_by_id(
            intent["broker_order_id"]
        )

        response = public_order(
            order
        )

        mark_exit_reconciled(
            entry_decision_id=
                entry_decision_id,
            broker_status=
                response["status"],
            response=response,
        )

        return {
            "intent":
                get_exit(
                    entry_decision_id
                ),
            "order": response,
        }
