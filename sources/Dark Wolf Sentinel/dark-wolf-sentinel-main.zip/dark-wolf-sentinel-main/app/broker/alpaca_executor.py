from __future__ import annotations

import json
from typing import Any
from uuid import (
    NAMESPACE_URL,
    uuid5,
)

from alpaca.trading.client import TradingClient
from alpaca.trading.enums import (
    OrderSide,
    TimeInForce,
)
from alpaca.trading.requests import (
    MarketOrderRequest,
)

from app.config import Settings
from app.execution_journal import (
    create_or_get,
    get_by_decision_id,
    mark_reconciled,
    mark_submitted,
)
from app.models import (
    AssetClass,
    RiskDecision,
    TradeCandidate,
)


def client_order_id_for(
    decision_id: str,
) -> str:
    value = uuid5(
        NAMESPACE_URL,
        (
            "dark-wolf-sentinel:"
            + decision_id
        ),
    )

    return f"dws-{value}"


def public_order(
    order: Any,
) -> dict[str, Any]:
    return {
        "order_id":
            str(order.id),
        "client_order_id":
            str(order.client_order_id),
        "symbol":
            str(order.symbol),
        "status":
            str(order.status),
        "side":
            str(order.side),
        "qty":
            (
                float(order.qty)
                if order.qty is not None
                else None
            ),
        "filled_qty":
            (
                float(order.filled_qty)
                if getattr(
                    order,
                    "filled_qty",
                    None,
                ) is not None
                else None
            ),
        "filled_avg_price":
            (
                float(
                    order.filled_avg_price
                )
                if getattr(
                    order,
                    "filled_avg_price",
                    None,
                ) is not None
                else None
            ),
    }


class AlpacaPaperExecutor:
    """Risk-gated Alpaca PAPER execution.

    The executor cannot use LIVE credentials.

    Execution is additionally disabled by configuration
    until explicitly enabled for PAPER testing.
    """

    PAPER_ONLY = True
    LIVE_TRADING = False
    TRADING_AUTHORITY = False

    def __init__(
        self,
        settings: Settings,
        *,
        client: Any | None = None,
    ) -> None:
        settings.assert_paper_only()

        self.settings = settings

        if client is not None:
            self.client = client

        else:
            if not settings.alpaca_configured:
                raise RuntimeError(
                    "Alpaca PAPER credentials "
                    "not configured."
                )

            self.client = TradingClient(
                settings.alpaca_api_key,
                settings.alpaca_secret_key,
                paper=True,
            )

    def prepare(
        self,
        *,
        candidate: TradeCandidate,
        decision: RiskDecision,
        decision_id: str,
    ) -> dict[str, Any]:
        if not decision.approved:
            raise RuntimeError(
                "Risk decision rejected."
            )

        if decision.live_order_allowed:
            raise RuntimeError(
                "LIVE authorization is forbidden."
            )

        if decision.trading_authority:
            raise RuntimeError(
                "AI trading authority is forbidden."
            )

        if candidate.asset_class != AssetClass.EQUITY:
            raise RuntimeError(
                "Step 5 executor supports "
                "equities only."
            )

        if candidate.side.value != "buy":
            raise RuntimeError(
                "Step 5 executor supports "
                "BUY only."
            )

        if (
            candidate.symbol.upper()
            != decision.symbol.upper()
        ):
            raise RuntimeError(
                "Candidate/decision symbol mismatch."
            )

        if decision.quantity <= 0:
            raise RuntimeError(
                "Risk engine produced "
                "invalid quantity."
            )

        cid = client_order_id_for(
            decision_id
        )

        row = create_or_get(
            decision_id=decision_id,
            symbol=decision.symbol.upper(),
            quantity=decision.quantity,
            client_order_id=cid,
        )

        return row

    def submit(
        self,
        *,
        candidate: TradeCandidate,
        decision: RiskDecision,
        decision_id: str,
        execution_quantity: float | None = None,
    ) -> dict[str, Any]:
        if (
            self.settings.paper_execution_enabled
            is not True
        ):
            raise RuntimeError(
                "PAPER execution is disabled."
            )

        if execution_quantity is None:
            execution_quantity = decision.quantity

        if execution_quantity <= 0:
            raise RuntimeError(
                "Execution quantity must be positive."
            )

        if execution_quantity > decision.quantity:
            raise RuntimeError(
                "Execution quantity exceeds "
                "risk-approved quantity."
            )

        intent = self.prepare(
            candidate=candidate,
            decision=decision,
            decision_id=decision_id,
        )

        # Risk decision is the maximum permissible size.
        # A controlled PAPER probe may execute LESS,
        # never more.
        if intent["state"] == "PREPARED":
            from app.execution_journal import (
                update_prepared_quantity,
            )

            update_prepared_quantity(
                decision_id=decision_id,
                quantity=execution_quantity,
            )

            intent = get_by_decision_id(
                decision_id
            )

        if intent["state"] in {
            "SUBMITTED",
            "RECONCILED",
        }:
            response = (
                json.loads(
                    intent["response_json"]
                )
                if intent.get(
                    "response_json"
                )
                else {}
            )

            return {
                "duplicate_prevented": True,
                "intent": intent,
                "order": response,
            }

        request = MarketOrderRequest(
            symbol=intent["symbol"],
            qty=float(intent["quantity"]),
            side=OrderSide.BUY,
            time_in_force=TimeInForce.DAY,
            client_order_id=
                intent["client_order_id"],
        )

        order = self.client.submit_order(
            order_data=request
        )

        response = public_order(order)

        mark_submitted(
            decision_id=decision_id,
            broker_order_id=response[
                "order_id"
            ],
            broker_status=response[
                "status"
            ],
            response=response,
        )

        return {
            "duplicate_prevented": False,
            "intent":
                get_by_decision_id(
                    decision_id
                ),
            "order": response,
        }

    def reconcile(
        self,
        *,
        decision_id: str,
    ) -> dict[str, Any]:
        intent = get_by_decision_id(
            decision_id
        )

        if not intent:
            raise RuntimeError(
                "Execution intent not found."
            )

        if not intent.get(
            "broker_order_id"
        ):
            raise RuntimeError(
                "Intent has no broker order."
            )

        order = self.client.get_order_by_id(
            intent["broker_order_id"]
        )

        response = public_order(order)

        mark_reconciled(
            decision_id=decision_id,
            broker_status=response[
                "status"
            ],
            response=response,
        )

        return {
            "intent":
                get_by_decision_id(
                    decision_id
                ),
            "order": response,
        }
