from __future__ import annotations

import re
from dataclasses import dataclass


ALIASES: dict[str, list[str]] = {
    "AAPL": [
        "apple",
        "iphone",
        "ipad",
        "mac",
    ],
    "MSFT": [
        "microsoft",
        "azure",
        "windows",
        "copilot",
        "github",
        "openai",
    ],
    "NVDA": [
        "nvidia",
        "geforce",
        "cuda",
    ],
    "AMZN": [
        "amazon",
        "aws",
    ],
    "META": [
        "meta platforms",
        "facebook",
        "instagram",
        "whatsapp",
        "meta",
    ],
    "TSLA": [
        "tesla",
        "elon musk",
    ],
    "SPY": [
        "s&p 500",
        "spdr",
        "spy",
    ],
    "QQQ": [
        "nasdaq-100",
        "nasdaq 100",
        "invesco qqq",
        "qqq",
    ],
}


@dataclass
class RankedNews:
    text: str
    score: float
    reasons: list[str]


def symbol_token_present(
    text: str,
    symbol: str,
) -> bool:
    return bool(
        re.search(
            rf"\b{re.escape(symbol)}\b",
            text,
            flags=re.IGNORECASE,
        )
    )


def score_news(
    symbol: str,
    text: str,
) -> RankedNews:
    lowered = text.lower()

    score = 0.0
    reasons: list[str] = []

    if symbol_token_present(
        text,
        symbol,
    ):
        score += 5
        reasons.append(
            "ticker"
        )

    aliases = ALIASES.get(
        symbol.upper(),
        [],
    )

    for index, alias in enumerate(
        aliases
    ):
        if alias.lower() not in lowered:
            continue

        points = (
            4
            if index == 0
            else 2
        )

        score += points

        reasons.append(
            f"alias:{alias}"
        )

    return RankedNews(
        text=text,
        score=score,
        reasons=reasons,
    )


def filter_relevant_news(
    symbol: str,
    items: list[str],
    *,
    limit: int = 5,
    minimum_score: float = 2,
) -> tuple[
    list[str],
    list[RankedNews],
]:
    ranked = [
        score_news(
            symbol,
            item,
        )
        for item in items
    ]

    ranked.sort(
        key=lambda item: item.score,
        reverse=True,
    )

    relevant = [
        item.text
        for item in ranked
        if item.score >= minimum_score
    ][:limit]

    return (
        relevant,
        ranked,
    )
