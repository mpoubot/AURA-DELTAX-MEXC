from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from typing import Any

from app.execution_journal import DB_PATH


def utc_now() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


def init_exit_db() -> None:
    DB_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS exit_intents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entry_decision_id TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                symbol TEXT NOT NULL,
                quantity REAL NOT NULL,
                client_order_id TEXT NOT NULL UNIQUE,
                state TEXT NOT NULL,
                broker_order_id TEXT,
                broker_status TEXT,
                response_json TEXT
            )
            """
        )

        conn.commit()


def create_or_get_exit(
    *,
    entry_decision_id: str,
    symbol: str,
    quantity: float,
    client_order_id: str,
) -> dict[str, Any]:
    init_exit_db()

    now = utc_now()

    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row

        conn.execute(
            """
            INSERT OR IGNORE INTO exit_intents (
                entry_decision_id,
                created_at,
                updated_at,
                symbol,
                quantity,
                client_order_id,
                state
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                entry_decision_id,
                now,
                now,
                symbol,
                quantity,
                client_order_id,
                "PREPARED",
            ),
        )

        conn.commit()

        row = conn.execute(
            """
            SELECT *
            FROM exit_intents
            WHERE entry_decision_id = ?
            """,
            (
                entry_decision_id,
            ),
        ).fetchone()

    return dict(row)


def get_exit(
    entry_decision_id: str,
) -> dict[str, Any] | None:
    init_exit_db()

    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row

        row = conn.execute(
            """
            SELECT *
            FROM exit_intents
            WHERE entry_decision_id = ?
            """,
            (
                entry_decision_id,
            ),
        ).fetchone()

    return dict(row) if row else None


def mark_exit_submitted(
    *,
    entry_decision_id: str,
    broker_order_id: str,
    broker_status: str,
    response: dict[str, Any],
) -> None:
    init_exit_db()

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            UPDATE exit_intents
            SET
                updated_at = ?,
                state = ?,
                broker_order_id = ?,
                broker_status = ?,
                response_json = ?
            WHERE entry_decision_id = ?
            """,
            (
                utc_now(),
                "SUBMITTED",
                broker_order_id,
                broker_status,
                json.dumps(response),
                entry_decision_id,
            ),
        )

        conn.commit()


def mark_exit_reconciled(
    *,
    entry_decision_id: str,
    broker_status: str,
    response: dict[str, Any],
) -> None:
    init_exit_db()

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            UPDATE exit_intents
            SET
                updated_at = ?,
                state = ?,
                broker_status = ?,
                response_json = ?
            WHERE entry_decision_id = ?
            """,
            (
                utc_now(),
                "RECONCILED",
                broker_status,
                json.dumps(response),
                entry_decision_id,
            ),
        )

        conn.commit()
