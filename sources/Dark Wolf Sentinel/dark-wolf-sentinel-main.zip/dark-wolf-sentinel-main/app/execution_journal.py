from __future__ import annotations

import json
import sqlite3
from datetime import (
    datetime,
    timezone,
)
from pathlib import Path
from typing import Any


DB_PATH = Path(
    "data/sentinel_execution.db"
)


def utc_now() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


def init_db() -> None:
    DB_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS execution_intents (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                decision_id TEXT NOT NULL UNIQUE,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                symbol TEXT NOT NULL,
                quantity REAL NOT NULL,
                client_order_id TEXT NOT NULL UNIQUE,
                state TEXT NOT NULL,
                broker_order_id TEXT,
                broker_status TEXT,
                response_json TEXT
            )
            """
        )

        conn.commit()


def create_or_get(
    *,
    decision_id: str,
    symbol: str,
    quantity: float,
    client_order_id: str,
) -> dict[str, Any]:
    init_db()

    now = utc_now()

    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row

        conn.execute(
            """
            INSERT OR IGNORE INTO execution_intents (
                decision_id,
                created_at,
                updated_at,
                symbol,
                quantity,
                client_order_id,
                state
            )
            VALUES (?, ?, ?, ?, ?, ?, ?)
            """,
            (
                decision_id,
                now,
                now,
                symbol,
                quantity,
                client_order_id,
                "PREPARED",
            ),
        )

        conn.commit()

        row = conn.execute(
            """
            SELECT *
            FROM execution_intents
            WHERE decision_id = ?
            """,
            (decision_id,),
        ).fetchone()

    return dict(row)


def get_by_decision_id(
    decision_id: str,
) -> dict[str, Any] | None:
    init_db()

    with sqlite3.connect(DB_PATH) as conn:
        conn.row_factory = sqlite3.Row

        row = conn.execute(
            """
            SELECT *
            FROM execution_intents
            WHERE decision_id = ?
            """,
            (decision_id,),
        ).fetchone()

    return (
        dict(row)
        if row
        else None
    )


def mark_submitted(
    *,
    decision_id: str,
    broker_order_id: str,
    broker_status: str,
    response: dict[str, Any],
) -> None:
    init_db()

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            UPDATE execution_intents
            SET
                updated_at = ?,
                state = ?,
                broker_order_id = ?,
                broker_status = ?,
                response_json = ?
            WHERE decision_id = ?
            """,
            (
                utc_now(),
                "SUBMITTED",
                broker_order_id,
                broker_status,
                json.dumps(response),
                decision_id,
            ),
        )

        conn.commit()


def mark_reconciled(
    *,
    decision_id: str,
    broker_status: str,
    response: dict[str, Any],
) -> None:
    init_db()

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            UPDATE execution_intents
            SET
                updated_at = ?,
                state = ?,
                broker_status = ?,
                response_json = ?
            WHERE decision_id = ?
            """,
            (
                utc_now(),
                "RECONCILED",
                broker_status,
                json.dumps(response),
                decision_id,
            ),
        )

        conn.commit()


def update_prepared_quantity(
    *,
    decision_id: str,
    quantity: float,
) -> None:
    """Reduce a PREPARED intent to a smaller safe quantity."""

    if quantity <= 0:
        raise ValueError(
            "Quantity must be positive."
        )

    init_db()

    with sqlite3.connect(DB_PATH) as conn:
        row = conn.execute(
            """
            SELECT state, quantity
            FROM execution_intents
            WHERE decision_id = ?
            """,
            (decision_id,),
        ).fetchone()

        if not row:
            raise RuntimeError(
                "Execution intent not found."
            )

        state, existing_quantity = row

        if state != "PREPARED":
            raise RuntimeError(
                "Only PREPARED intents may be resized."
            )

        if quantity > float(existing_quantity):
            raise RuntimeError(
                "Cannot increase prepared quantity."
            )

        conn.execute(
            """
            UPDATE execution_intents
            SET
                updated_at = ?,
                quantity = ?
            WHERE decision_id = ?
            """,
            (
                utc_now(),
                float(quantity),
                decision_id,
            ),
        )

        conn.commit()
