from __future__ import annotations

import json
import os
import tempfile
from datetime import (
    date,
    datetime,
)
from decimal import Decimal
from enum import Enum
from pathlib import Path
from typing import Any

from pydantic import (
    BaseModel,
    Field,
    model_validator,
)

from app.options_lifecycle import (
    OptionsPositionRecord,
)
from app.options_verticals import (
    VerticalSpreadType,
)


MODE = "OPTIONS_POSITION_STORE"

SCHEMA_VERSION = 1

BROKER_CONNECTION = False
BROKER_WRITES = False
ORDER_SUBMISSION_AUTHORITY = False
EXECUTION_EFFECT = False

CENT = Decimal("0.01")


class OptionsPositionStoreError(
    ValueError
):
    pass


class EntryState(
    str,
    Enum,
):
    PREPARED = "prepared"
    SUBMITTED = "submitted"
    FILLED = "filled"
    CANCELED = "canceled"
    REJECTED = "rejected"
    CLOSED = "closed"


TERMINAL_STATES = {
    EntryState.CANCELED,
    EntryState.REJECTED,
    EntryState.CLOSED,
}


class OptionsEntryManifest(
    BaseModel
):
    """
    Durable metadata written BEFORE crossing the broker
    submission boundary.

    If submission succeeds but the process dies before a
    follow-up write, PREPARED + deterministic client order
    ID remains sufficient for broker reconciliation.
    """

    record_id: str = Field(
        min_length=1,
        max_length=256,
    )

    decision_id: str = Field(
        min_length=1,
        max_length=512,
    )

    client_order_id: str = Field(
        min_length=1,
        max_length=64,
    )

    underlying: str = Field(
        min_length=1,
        max_length=32,
    )

    spread_type: VerticalSpreadType

    long_symbol: str = Field(
        min_length=1,
        max_length=64,
    )

    short_symbol: str = Field(
        min_length=1,
        max_length=64,
    )

    quantity: int = Field(
        gt=0,
    )

    expiration: date

    thesis_expires_at: datetime

    width: Decimal = Field(
        gt=0,
    )

    selected_debit: Decimal = Field(
        gt=0,
    )

    executable_entry_limit: Decimal = Field(
        gt=0,
    )

    approved_max_loss: Decimal = Field(
        gt=0,
    )

    created_at: datetime

    state: EntryState = (
        EntryState.PREPARED
    )

    broker_order_id: str | None = None

    broker_status: str | None = None

    submitted_at: datetime | None = None

    filled_at: datetime | None = None

    filled_debit: Decimal | None = None

    closed_at: datetime | None = None

    closing_credit: Decimal | None = None

    close_broker_order_id: str | None = None

    @model_validator(
        mode="after"
    )
    def validate_manifest(
        self,
    ):
        if (
            self.long_symbol.upper()
            == self.short_symbol.upper()
        ):
            raise ValueError(
                "DUPLICATE_LEG_SYMBOL"
            )

        if (
            self.created_at.utcoffset()
            is None
        ):
            raise ValueError(
                "CREATED_AT_MUST_BE_TIMEZONE_AWARE"
            )

        if (
            self.thesis_expires_at
            .utcoffset()
            is None
        ):
            raise ValueError(
                "THESIS_EXPIRY_MUST_BE_TIMEZONE_AWARE"
            )

        if (
            self.thesis_expires_at
            <= self.created_at
        ):
            raise ValueError(
                "THESIS_EXPIRY_MUST_FOLLOW_CREATION"
            )

        if (
            self.selected_debit
            >= self.width
        ):
            raise ValueError(
                "SELECTED_DEBIT_MUST_BE_BELOW_WIDTH"
            )

        if (
            self.executable_entry_limit
            > self.selected_debit
        ):
            raise ValueError(
                "ENTRY_LIMIT_EXCEEDS_SELECTED_DEBIT"
            )

        if (
            self.executable_entry_limit
            >= self.width
        ):
            raise ValueError(
                "ENTRY_LIMIT_MUST_BE_BELOW_WIDTH"
            )

        executable_loss = (
            self.executable_entry_limit
            * Decimal("100")
            * Decimal(
                self.quantity
            )
        )

        if (
            executable_loss
            > self.approved_max_loss
        ):
            raise ValueError(
                "ENTRY_LIMIT_EXCEEDS_APPROVED_RISK"
            )

        if (
            self.state
            in {
                EntryState.SUBMITTED,
                EntryState.FILLED,
                EntryState.CLOSED,
            }
            and not self.broker_order_id
        ):
            raise ValueError(
                "BROKER_ORDER_ID_REQUIRED"
            )

        if (
            self.state
            in {
                EntryState.SUBMITTED,
                EntryState.FILLED,
                EntryState.CLOSED,
            }
            and self.submitted_at is None
        ):
            raise ValueError(
                "SUBMITTED_AT_REQUIRED"
            )

        if (
            self.state
            in {
                EntryState.FILLED,
                EntryState.CLOSED,
            }
        ):
            if self.filled_at is None:
                raise ValueError(
                    "FILLED_AT_REQUIRED"
                )

            if self.filled_debit is None:
                raise ValueError(
                    "FILLED_DEBIT_REQUIRED"
                )

            if self.filled_debit <= 0:
                raise ValueError(
                    "FILLED_DEBIT_MUST_BE_POSITIVE"
                )

            if (
                self.filled_debit
                > self.executable_entry_limit
            ):
                raise ValueError(
                    "FILL_DEBIT_EXCEEDS_LIMIT"
                )

            if (
                self.filled_debit
                >= self.width
            ):
                raise ValueError(
                    "FILL_DEBIT_MUST_BE_BELOW_WIDTH"
                )

            actual_loss = (
                self.filled_debit
                * Decimal("100")
                * Decimal(
                    self.quantity
                )
            )

            if (
                actual_loss
                > self.approved_max_loss
            ):
                raise ValueError(
                    "FILL_EXCEEDS_APPROVED_RISK"
                )

        if self.state == EntryState.CLOSED:
            if self.closed_at is None:
                raise ValueError(
                    "CLOSED_AT_REQUIRED"
                )

            if self.closing_credit is None:
                raise ValueError(
                    "CLOSING_CREDIT_REQUIRED"
                )

            if self.closing_credit < 0:
                raise ValueError(
                    "CLOSING_CREDIT_NEGATIVE"
                )

            if not self.close_broker_order_id:
                raise ValueError(
                    "CLOSE_BROKER_ORDER_ID_REQUIRED"
                )

        return self

    def to_position_record(
        self,
    ) -> OptionsPositionRecord:
        if self.state != EntryState.FILLED:
            raise OptionsPositionStoreError(
                "POSITION_RECORD_REQUIRES_FILLED_STATE"
            )

        assert self.filled_at is not None
        assert self.filled_debit is not None

        max_loss_per_spread = (
            self.filled_debit
            * Decimal("100")
        )

        max_profit_per_spread = (
            (
                self.width
                - self.filled_debit
            )
            * Decimal("100")
        )

        return OptionsPositionRecord(
            record_id=
                self.record_id,
            underlying=
                self.underlying,
            spread_type=
                self.spread_type,
            long_symbol=
                self.long_symbol,
            short_symbol=
                self.short_symbol,
            quantity=
                self.quantity,
            expiration=
                self.expiration,
            opened_at=
                self.filled_at,
            thesis_expires_at=
                self.thesis_expires_at,
            entry_debit=
                self.filled_debit,
            width=
                self.width,
            max_loss_per_spread=
                max_loss_per_spread,
            max_profit_per_spread=
                max_profit_per_spread,
        )


class OptionsPositionStoreDocument(
    BaseModel
):
    schema_version: int = (
        SCHEMA_VERSION
    )

    revision: int = Field(
        ge=0,
        default=0,
    )

    records: list[
        OptionsEntryManifest
    ] = Field(
        default_factory=list
    )

    @model_validator(
        mode="after"
    )
    def validate_document(
        self,
    ):
        if (
            self.schema_version
            != SCHEMA_VERSION
        ):
            raise ValueError(
                "UNSUPPORTED_SCHEMA_VERSION"
            )

        record_ids = [
            item.record_id
            for item in self.records
        ]

        if (
            len(record_ids)
            != len(set(record_ids))
        ):
            raise ValueError(
                "DUPLICATE_RECORD_ID"
            )

        client_ids = [
            item.client_order_id
            for item in self.records
        ]

        if (
            len(client_ids)
            != len(set(client_ids))
        ):
            raise ValueError(
                "DUPLICATE_CLIENT_ORDER_ID"
            )

        active = [
            item
            for item in self.records
            if item.state
            not in TERMINAL_STATES
        ]

        if len(active) > 1:
            raise ValueError(
                "MULTIPLE_ACTIVE_OPTIONS_RECORDS"
            )

        return self


def _atomic_write_json(
    *,
    path: Path,
    payload: dict[str, Any],
) -> None:
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    fd, temp_name = tempfile.mkstemp(
        prefix=(
            "."
            + path.name
            + "."
        ),
        suffix=".tmp",
        dir=str(
            path.parent
        ),
        text=True,
    )

    temp_path = Path(
        temp_name
    )

    try:
        with os.fdopen(
            fd,
            "w",
            encoding="utf-8",
        ) as handle:
            json.dump(
                payload,
                handle,
                indent=2,
                sort_keys=True,
            )

            handle.write("\n")
            handle.flush()
            os.fsync(
                handle.fileno()
            )

        os.replace(
            temp_path,
            path,
        )

        # Persist the directory entry as well as the file
        # contents where supported.
        try:
            directory_fd = os.open(
                str(
                    path.parent
                ),
                os.O_RDONLY,
            )

        except OSError:
            directory_fd = None

        if directory_fd is not None:
            try:
                os.fsync(
                    directory_fd
                )
            finally:
                os.close(
                    directory_fd
                )

    finally:
        if temp_path.exists():
            temp_path.unlink()


class OptionsPositionStore:
    def __init__(
        self,
        path: str | Path,
    ):
        self.path = Path(
            path
        )

    def load(
        self,
    ) -> OptionsPositionStoreDocument:
        if not self.path.exists():
            return (
                OptionsPositionStoreDocument()
            )

        try:
            raw = json.loads(
                self.path.read_text(
                    encoding="utf-8"
                )
            )

        except Exception as exc:
            raise OptionsPositionStoreError(
                "POSITION_STORE_READ_FAILED"
            ) from exc

        try:
            return (
                OptionsPositionStoreDocument
                .model_validate(
                    raw
                )
            )

        except Exception as exc:
            raise OptionsPositionStoreError(
                "POSITION_STORE_VALIDATION_FAILED"
            ) from exc

    def _save(
        self,
        document: OptionsPositionStoreDocument,
    ) -> OptionsPositionStoreDocument:
        next_document = (
            document.model_copy(
                update={
                    "revision":
                        document.revision
                        + 1
                }
            )
        )

        # Revalidate after every mutation.
        next_document = (
            OptionsPositionStoreDocument
            .model_validate(
                next_document.model_dump()
            )
        )

        _atomic_write_json(
            path=self.path,
            payload=
                next_document.model_dump(
                    mode="json"
                ),
        )

        return next_document

    def active_record(
        self,
    ) -> OptionsEntryManifest | None:
        document = self.load()

        active = [
            item
            for item in document.records
            if item.state
            not in TERMINAL_STATES
        ]

        if not active:
            return None

        if len(active) != 1:
            raise OptionsPositionStoreError(
                "MULTIPLE_ACTIVE_OPTIONS_RECORDS"
            )

        return active[0]

    def prepare_entry(
        self,
        manifest: OptionsEntryManifest,
    ) -> OptionsEntryManifest:
        if (
            manifest.state
            != EntryState.PREPARED
        ):
            raise OptionsPositionStoreError(
                "NEW_MANIFEST_MUST_BE_PREPARED"
            )

        document = self.load()

        for existing in document.records:
            if (
                existing.record_id
                == manifest.record_id
            ):
                if (
                    existing
                    == manifest
                ):
                    return existing

                raise OptionsPositionStoreError(
                    "RECORD_ID_ALREADY_EXISTS"
                )

            if (
                existing.client_order_id
                == manifest.client_order_id
            ):
                raise OptionsPositionStoreError(
                    "CLIENT_ORDER_ID_ALREADY_EXISTS"
                )

        active = [
            item
            for item in document.records
            if item.state
            not in TERMINAL_STATES
        ]

        if active:
            raise OptionsPositionStoreError(
                "ACTIVE_OPTIONS_RECORD_EXISTS"
            )

        records = list(
            document.records
        )

        records.append(
            manifest
        )

        self._save(
            document.model_copy(
                update={
                    "records":
                        records
                }
            )
        )

        return manifest

    def _replace(
        self,
        updated: OptionsEntryManifest,
    ) -> OptionsEntryManifest:
        document = self.load()

        found = False
        records = []

        for item in document.records:
            if (
                item.record_id
                == updated.record_id
            ):
                records.append(
                    updated
                )
                found = True
            else:
                records.append(
                    item
                )

        if not found:
            raise OptionsPositionStoreError(
                "POSITION_RECORD_NOT_FOUND"
            )

        self._save(
            document.model_copy(
                update={
                    "records":
                        records
                }
            )
        )

        return updated

    def get(
        self,
        record_id: str,
    ) -> OptionsEntryManifest:
        document = self.load()

        matches = [
            item
            for item in document.records
            if item.record_id
            == record_id
        ]

        if len(matches) != 1:
            raise OptionsPositionStoreError(
                "POSITION_RECORD_NOT_FOUND"
            )

        return matches[0]

    def mark_submitted(
        self,
        *,
        record_id: str,
        broker_order_id: str,
        broker_status: str,
        submitted_at: datetime,
    ) -> OptionsEntryManifest:
        current = self.get(
            record_id
        )

        if (
            submitted_at.utcoffset()
            is None
        ):
            raise OptionsPositionStoreError(
                "SUBMITTED_AT_MUST_BE_TIMEZONE_AWARE"
            )

        if not broker_order_id.strip():
            raise OptionsPositionStoreError(
                "EMPTY_BROKER_ORDER_ID"
            )

        if (
            current.state
            == EntryState.SUBMITTED
        ):
            if (
                current.broker_order_id
                == broker_order_id
                and current.broker_status
                == broker_status
                and current.submitted_at
                == submitted_at
            ):
                return current

            raise OptionsPositionStoreError(
                "SUBMITTED_STATE_CONFLICT"
            )

        if (
            current.state
            != EntryState.PREPARED
        ):
            raise OptionsPositionStoreError(
                "INVALID_SUBMITTED_TRANSITION"
            )

        updated = current.model_copy(
            update={
                "state":
                    EntryState.SUBMITTED,

                "broker_order_id":
                    broker_order_id,

                "broker_status":
                    broker_status,

                "submitted_at":
                    submitted_at,
            }
        )

        updated = (
            OptionsEntryManifest
            .model_validate(
                updated.model_dump()
            )
        )

        return self._replace(
            updated
        )

    def mark_filled(
        self,
        *,
        record_id: str,
        broker_order_id: str,
        broker_status: str,
        filled_debit: Decimal,
        filled_at: datetime,
    ) -> OptionsEntryManifest:
        current = self.get(
            record_id
        )

        if (
            filled_at.utcoffset()
            is None
        ):
            raise OptionsPositionStoreError(
                "FILLED_AT_MUST_BE_TIMEZONE_AWARE"
            )

        filled_debit = Decimal(
            str(
                filled_debit
            )
        )

        if (
            current.state
            == EntryState.FILLED
        ):
            if (
                current.broker_order_id
                == broker_order_id
                and current.filled_debit
                == filled_debit
                and current.filled_at
                == filled_at
            ):
                return current

            raise OptionsPositionStoreError(
                "FILLED_STATE_CONFLICT"
            )

        if (
            current.state
            != EntryState.SUBMITTED
        ):
            raise OptionsPositionStoreError(
                "INVALID_FILLED_TRANSITION"
            )

        if (
            current.broker_order_id
            != broker_order_id
        ):
            raise OptionsPositionStoreError(
                "BROKER_ORDER_ID_MISMATCH"
            )

        updated = current.model_copy(
            update={
                "state":
                    EntryState.FILLED,

                "broker_status":
                    broker_status,

                "filled_at":
                    filled_at,

                "filled_debit":
                    filled_debit,
            }
        )

        updated = (
            OptionsEntryManifest
            .model_validate(
                updated.model_dump()
            )
        )

        return self._replace(
            updated
        )

    def mark_canceled(
        self,
        *,
        record_id: str,
        broker_status: str,
    ) -> OptionsEntryManifest:
        current = self.get(
            record_id
        )

        if (
            current.state
            == EntryState.CANCELED
        ):
            return current

        if current.state not in {
            EntryState.PREPARED,
            EntryState.SUBMITTED,
        }:
            raise OptionsPositionStoreError(
                "INVALID_CANCELED_TRANSITION"
            )

        updated = current.model_copy(
            update={
                "state":
                    EntryState.CANCELED,

                "broker_status":
                    broker_status,
            }
        )

        updated = (
            OptionsEntryManifest
            .model_validate(
                updated.model_dump()
            )
        )

        return self._replace(
            updated
        )

    def mark_rejected(
        self,
        *,
        record_id: str,
        broker_status: str,
    ) -> OptionsEntryManifest:
        current = self.get(
            record_id
        )

        if (
            current.state
            == EntryState.REJECTED
        ):
            return current

        if current.state not in {
            EntryState.PREPARED,
            EntryState.SUBMITTED,
        }:
            raise OptionsPositionStoreError(
                "INVALID_REJECTED_TRANSITION"
            )

        updated = current.model_copy(
            update={
                "state":
                    EntryState.REJECTED,

                "broker_status":
                    broker_status,
            }
        )

        updated = (
            OptionsEntryManifest
            .model_validate(
                updated.model_dump()
            )
        )

        return self._replace(
            updated
        )

    def mark_closed(
        self,
        *,
        record_id: str,
        closing_credit: Decimal,
        close_broker_order_id: str,
        closed_at: datetime,
    ) -> OptionsEntryManifest:
        current = self.get(
            record_id
        )

        if current.state != EntryState.FILLED:
            raise OptionsPositionStoreError(
                "INVALID_CLOSED_TRANSITION"
            )

        if (
            closed_at.utcoffset()
            is None
        ):
            raise OptionsPositionStoreError(
                "CLOSED_AT_MUST_BE_TIMEZONE_AWARE"
            )

        credit = Decimal(
            str(
                closing_credit
            )
        )

        if credit < 0:
            raise OptionsPositionStoreError(
                "CLOSING_CREDIT_NEGATIVE"
            )

        if (
            credit.quantize(
                CENT
            )
            != credit
        ):
            raise OptionsPositionStoreError(
                "CLOSING_CREDIT_MUST_BE_CENT_DENOMINATED"
            )

        if not close_broker_order_id.strip():
            raise OptionsPositionStoreError(
                "EMPTY_CLOSE_BROKER_ORDER_ID"
            )

        updated = current.model_copy(
            update={
                "state":
                    EntryState.CLOSED,

                "closing_credit":
                    credit,

                "close_broker_order_id":
                    close_broker_order_id,

                "closed_at":
                    closed_at,
            }
        )

        updated = (
            OptionsEntryManifest
            .model_validate(
                updated.model_dump()
            )
        )

        return self._replace(
            updated
        )


def status() -> dict[str, Any]:
    return {
        "mode": MODE,

        "schema_version":
            SCHEMA_VERSION,

        "atomic_replace":
            True,

        "fsync_before_replace":
            True,

        "pre_submission_manifest":
            True,

        "deterministic_client_order_recovery":
            True,

        "single_active_record":
            True,

        "filled_record_to_lifecycle":
            True,

        "broker_connection":
            BROKER_CONNECTION,

        "broker_writes":
            BROKER_WRITES,

        "order_submission_authority":
            ORDER_SUBMISSION_AUTHORITY,

        "execution_effect":
            EXECUTION_EFFECT,
    }
