from __future__ import annotations

from datetime import (
    datetime,
    timezone,
)
from decimal import (
    Decimal,
    ROUND_DOWN,
)
from typing import (
    Any,
    Callable,
)

from alpaca.data.historical.option import (
    OptionHistoricalDataClient,
)
from alpaca.data.requests import (
    OptionLatestQuoteRequest,
)
from alpaca.trading.client import (
    TradingClient,
)
from alpaca.trading.enums import (
    AssetClass,
    PositionSide,
)

from app.options_lifecycle import (
    BrokerOptionPosition,
    OptionsLifecycleError,
    OptionsLifecyclePolicy,
    OptionsPositionRecord,
    evaluate_lifecycle,
)


MODE = "OPTIONS_LIFECYCLE_MARKET_BRIDGE_READ_ONLY"

MAX_QUOTE_AGE_SECONDS = 120
CENT = Decimal("0.01")

TRADING_AUTHORITY = False
ORDER_SUBMISSION_AUTHORITY = False
BROKER_WRITES = False
EXECUTION_EFFECT = False


def _base(
    *,
    status: str,
    reason: str,
) -> dict[str, Any]:
    return {
        "mode": MODE,
        "status": status,
        "reason": reason,
        "trading_authority": False,
        "order_submission_authority": False,
        "broker_writes": False,
        "execution_effect": False,
    }


def _enum_value(
    value: Any,
) -> Any:
    return getattr(
        value,
        "value",
        value,
    )


def _quote_age_seconds(
    timestamp: datetime | None,
    *,
    now: datetime,
) -> Decimal | None:
    if timestamp is None:
        return None

    ts = timestamp

    if ts.tzinfo is None:
        ts = ts.replace(
            tzinfo=timezone.utc
        )

    return Decimal(
        str(
            (
                now.astimezone(
                    timezone.utc
                )
                - ts.astimezone(
                    timezone.utc
                )
            ).total_seconds()
        )
    )


def _decimal(
    value: Any,
) -> Decimal:
    return Decimal(
        str(value)
    )


def _broker_positions(
    *,
    raw_positions: list[Any],
) -> list[
    BrokerOptionPosition
]:
    result = []

    for item in raw_positions:
        asset_class = getattr(
            item,
            "asset_class",
            None,
        )

        if (
            _enum_value(
                asset_class
            )
            != AssetClass.US_OPTION.value
        ):
            raise OptionsLifecycleError(
                "NON_OPTION_POSITION_PRESENT"
            )

        side = getattr(
            item,
            "side",
            None,
        )

        side_value = _enum_value(
            side
        )

        if (
            side_value
            == PositionSide.LONG.value
        ):
            parsed_side = (
                PositionSide.LONG
            )

        elif (
            side_value
            == PositionSide.SHORT.value
        ):
            parsed_side = (
                PositionSide.SHORT
            )

        else:
            raise OptionsLifecycleError(
                "UNKNOWN_BROKER_POSITION_SIDE"
            )

        quantity_decimal = _decimal(
            getattr(
                item,
                "qty",
                None,
            )
        )

        if (
            quantity_decimal
            != quantity_decimal
            .to_integral_value()
        ):
            raise OptionsLifecycleError(
                "FRACTIONAL_OPTION_QUANTITY"
            )

        quantity = int(
            quantity_decimal
        )

        if quantity <= 0:
            raise OptionsLifecycleError(
                "NON_POSITIVE_OPTION_QUANTITY"
            )

        result.append(
            BrokerOptionPosition(
                symbol=str(
                    getattr(
                        item,
                        "symbol",
                        "",
                    )
                ),
                asset_class=
                    AssetClass.US_OPTION,
                side=parsed_side,
                quantity=quantity,
            )
        )

    return result


def evaluate_market_lifecycle(
    *,
    settings: Any,
    record: OptionsPositionRecord,
    policy: OptionsLifecyclePolicy,
    trading_client_factory: Callable[..., Any] = TradingClient,
    option_data_client_factory: Callable[..., Any] = OptionHistoricalDataClient,
    now: datetime | None = None,
) -> dict[str, Any]:
    """
    Read-only broker + option quote adapter.

    This function has no broker-write method and never
    constructs an executor.
    """

    settings.assert_paper_only()

    if (
        getattr(
            settings,
            "alpaca_paper",
            False,
        )
        is not True
    ):
        return _base(
            status="BLOCKED",
            reason="NON_PAPER_ACCOUNT_FORBIDDEN",
        )

    # Lifecycle evidence remains observation-only.
    if (
        getattr(
            settings,
            "paper_execution_enabled",
            False,
        )
        is True
        or getattr(
            settings,
            "options_paper_execution_enabled",
            False,
        )
        is True
    ):
        return _base(
            status="BLOCKED",
            reason="READ_ONLY_BRIDGE_REQUIRES_EXECUTION_OFF",
        )

    observed_at = (
        now
        or datetime.now(
            timezone.utc
        )
    )

    if observed_at.utcoffset() is None:
        return _base(
            status="DEGRADED",
            reason="OBSERVATION_TIME_NOT_TIMEZONE_AWARE",
        )

    try:
        trading = trading_client_factory(
            settings.alpaca_api_key,
            settings.alpaca_secret_key,
            paper=True,
        )

        raw_positions = (
            trading.get_all_positions()
        )

        if not raw_positions:
            result = _base(
                status="FLAT",
                reason="NO_OPEN_POSITIONS",
            )

            result["positions_count"] = 0
            result["quotes_requested"] = 0

            return result

        positions = _broker_positions(
            raw_positions=
                list(raw_positions)
        )

        # The current Sentinel architecture is
        # deliberately one-spread-at-a-time.
        if len(positions) != 2:
            result = _base(
                status="BLOCKED",
                reason="EXPECTED_EXACTLY_TWO_OPTION_POSITIONS",
            )

            result["positions_count"] = (
                len(positions)
            )

            return result

        # Kernel performs exact symbol/side/qty
        # reconciliation later; only after the broker
        # shape is valid do we request quotes.
        data_client = (
            option_data_client_factory(
                settings.alpaca_api_key,
                settings.alpaca_secret_key,
            )
        )

        request = (
            OptionLatestQuoteRequest(
                symbol_or_symbols=[
                    record.long_symbol,
                    record.short_symbol,
                ]
            )
        )

        response = (
            data_client
            .get_option_latest_quote(
                request
            )
        )

        quote_map = getattr(
            response,
            "data",
            response,
        )

        if (
            record.long_symbol
            not in quote_map
        ):
            raise OptionsLifecycleError(
                "LONG_QUOTE_MISSING"
            )

        if (
            record.short_symbol
            not in quote_map
        ):
            raise OptionsLifecycleError(
                "SHORT_QUOTE_MISSING"
            )

        long_quote = quote_map[
            record.long_symbol
        ]

        short_quote = quote_map[
            record.short_symbol
        ]

        long_bid = _decimal(
            long_quote.bid_price
        )

        long_ask = _decimal(
            long_quote.ask_price
        )

        short_bid = _decimal(
            short_quote.bid_price
        )

        short_ask = _decimal(
            short_quote.ask_price
        )

        for (
            label,
            bid,
            ask,
        ) in (
            (
                "LONG",
                long_bid,
                long_ask,
            ),
            (
                "SHORT",
                short_bid,
                short_ask,
            ),
        ):
            if bid < 0:
                raise OptionsLifecycleError(
                    f"{label}_NEGATIVE_BID"
                )

            if ask < 0:
                raise OptionsLifecycleError(
                    f"{label}_NEGATIVE_ASK"
                )

            if ask < bid:
                raise OptionsLifecycleError(
                    f"{label}_CROSSED_QUOTE"
                )

        long_age = _quote_age_seconds(
            getattr(
                long_quote,
                "timestamp",
                None,
            ),
            now=observed_at,
        )

        short_age = _quote_age_seconds(
            getattr(
                short_quote,
                "timestamp",
                None,
            ),
            now=observed_at,
        )

        if long_age is None:
            raise OptionsLifecycleError(
                "LONG_QUOTE_TIMESTAMP_MISSING"
            )

        if short_age is None:
            raise OptionsLifecycleError(
                "SHORT_QUOTE_TIMESTAMP_MISSING"
            )

        if long_age < 0:
            raise OptionsLifecycleError(
                "LONG_QUOTE_FROM_FUTURE"
            )

        if short_age < 0:
            raise OptionsLifecycleError(
                "SHORT_QUOTE_FROM_FUTURE"
            )

        if (
            long_age
            > Decimal(
                MAX_QUOTE_AGE_SECONDS
            )
        ):
            raise OptionsLifecycleError(
                "LONG_QUOTE_STALE"
            )

        if (
            short_age
            > Decimal(
                MAX_QUOTE_AGE_SECONDS
            )
        ):
            raise OptionsLifecycleError(
                "SHORT_QUOTE_STALE"
            )

        raw_credit = (
            long_bid
            - short_ask
        )

        close_credit = max(
            Decimal("0"),
            raw_credit,
        ).quantize(
            CENT,
            rounding=ROUND_DOWN,
        )

        midpoint_credit = (
            (
                long_bid
                + long_ask
            )
            / Decimal("2")
            - (
                short_bid
                + short_ask
            )
            / Decimal("2")
        )

        decision = evaluate_lifecycle(
            record=record,
            positions=positions,
            close_credit=
                close_credit,
            policy=policy,
            as_of=observed_at,
        )

        result = _base(
            status="OK",
            reason="LIFECYCLE_EVALUATED_READ_ONLY",
        )

        result.update(
            {
                "positions_count":
                    len(positions),

                "quotes_requested":
                    2,

                "long_symbol":
                    record.long_symbol,

                "short_symbol":
                    record.short_symbol,

                "long_bid":
                    str(long_bid),

                "long_ask":
                    str(long_ask),

                "short_bid":
                    str(short_bid),

                "short_ask":
                    str(short_ask),

                "long_quote_age_seconds":
                    str(long_age),

                "short_quote_age_seconds":
                    str(short_age),

                "conservative_close_credit":
                    str(close_credit),

                "midpoint_credit_diagnostic":
                    str(
                        midpoint_credit
                    ),

                "decision":
                    decision.model_dump(
                        mode="json"
                    ),
            }
        )

        return result

    except Exception as exc:
        result = _base(
            status="DEGRADED",
            reason="LIFECYCLE_MARKET_DATA_FAILED",
        )

        result["error_type"] = (
            type(exc).__name__
        )

        result["error_reason"] = (
            str(exc)
        )

        return result


def status() -> dict[str, Any]:
    return {
        "mode": MODE,
        "read_only": True,
        "paper_only": True,
        "broker_position_reads": True,
        "option_quote_reads": True,
        "quote_freshness_seconds":
            MAX_QUOTE_AGE_SECONDS,
        "close_credit_formula":
            "long_bid_minus_short_ask",
        "midpoint_drives_exit":
            False,
        "trading_authority":
            TRADING_AUTHORITY,
        "order_submission_authority":
            ORDER_SUBMISSION_AUTHORITY,
        "broker_writes":
            BROKER_WRITES,
        "execution_effect":
            EXECUTION_EFFECT,
    }
