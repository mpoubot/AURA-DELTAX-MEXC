from __future__ import annotations

from datetime import (
    datetime,
    timezone,
)
from pathlib import Path
from typing import (
    Any,
    Callable,
)

from alpaca.trading.client import (
    TradingClient,
)

from app.options_execution_bridge import (
    execute_options_paper_if_enabled,
)
from app.options_manifest_bridge import (
    build_entry_manifest,
)
from app.options_position_store import (
    EntryState,
    OptionsPositionStore,
)
from app.options_prepared_recovery import (
    recover_prepared_entry,
)


MODE = "SENTINEL_OPTIONS_DURABLE_PAPER_EXECUTION_GATE"

DEFAULT_POSITION_STORE_PATH = (
    Path(__file__)
    .resolve()
    .parent
    .parent
    / "data"
    / "options_positions.json"
)

LIVE_TRADING = False
AI_LIVE_TRADING_AUTHORITY = False


def _decorate(
    result: dict[str, Any],
    *,
    manifest_written: bool = False,
    durable_state: str | None = None,
    recovery: dict[str, Any] | None = None,
    durable_update_status: str | None = None,
) -> dict[str, Any]:
    output = dict(
        result
    )

    output[
        "durable_mode"
    ] = MODE

    output[
        "manifest_written"
    ] = manifest_written

    output[
        "durable_state"
    ] = durable_state

    output[
        "recovery"
    ] = recovery

    output[
        "durable_update_status"
    ] = durable_update_status

    return output


def _blocked(
    *,
    reason: str,
    durable_state: str | None = None,
    recovery: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return {
        "mode":
            "SENTINEL_OPTIONS_PAPER_EXECUTION_GATE",

        "status":
            "BLOCKED",

        "reason":
            reason,

        "submitted":
            False,

        "broker_order_id":
            None,

        "broker_status":
            None,

        "paper_only":
            True,

        "live_trading":
            False,

        "ai_live_trading_authority":
            False,

        "durable_mode":
            MODE,

        "manifest_written":
            False,

        "durable_state":
            durable_state,

        "recovery":
            recovery,

        "durable_update_status":
            None,
    }


def execute_options_paper_durable_if_enabled(
    *,
    settings: Any,
    agent_proposal: Any,
    options_shadow: dict[str, Any],
    options_order_intent: dict[str, Any] | None,
    client_factory: Callable[..., Any] = TradingClient,
    store_factory: Callable[
        [str | Path],
        OptionsPositionStore,
    ] = OptionsPositionStore,
    store_path: str | Path = DEFAULT_POSITION_STORE_PATH,
) -> dict[str, Any]:
    """
    Durable wrapper around Sentinel's existing options
    PAPER execution boundary.

    When the dedicated options gate is OFF, behavior is
    identical to the existing execution bridge and no
    broker client or durable manifest is created.

    When enabled in the future:
      - existing durable state is checked first
      - PREPARED state is reconciled before any new order
      - active SUBMITTED/FILLED state blocks new entries
      - a new manifest is atomically PREPARED only after
        all broker/account preflight checks have passed
      - PREPARED is written immediately before executor
        submission
      - successful submission advances to SUBMITTED
      - uncertain post-boundary failures retain PREPARED
        for deterministic recovery
    """

    settings.assert_paper_only()

    # Preserve the existing disabled behavior exactly.
    # This path constructs neither store nor broker client.
    if (
        options_order_intent is None
        or options_order_intent.get(
            "status"
        )
        != "READY_INERT"
        or getattr(
            settings,
            "options_paper_execution_enabled",
            False,
        )
        is not True
        or getattr(
            settings,
            "paper_execution_enabled",
            False,
        )
        is True
    ):
        base = execute_options_paper_if_enabled(
            settings=settings,
            options_order_intent=
                options_order_intent,
            client_factory=
                client_factory,
        )

        return _decorate(
            base,
            manifest_written=False,
            durable_state=None,
        )

    store = store_factory(
        store_path
    )

    try:
        active = store.active_record()

    except Exception as exc:
        result = _blocked(
            reason="DURABLE_POSITION_STORE_FAILED",
        )

        result[
            "error_type"
        ] = type(exc).__name__

        return result

    # Never permit a second entry while durable state
    # says an earlier entry remains unresolved.
    if active is not None:
        if active.state == EntryState.PREPARED:
            try:
                client = client_factory(
                    settings.alpaca_api_key,
                    settings.alpaca_secret_key,
                    paper=True,
                )

                recovery = recover_prepared_entry(
                    store=store,
                    client=client,
                )

            except Exception as exc:
                result = _blocked(
                    reason="PREPARED_RECOVERY_FAILED",
                    durable_state=
                        EntryState.PREPARED.value,
                )

                result[
                    "error_type"
                ] = type(exc).__name__

                return result

            # Even a terminal recovery does not submit a
            # new order during the same cycle. A later
            # Sentinel cycle may evaluate a fresh trade.
            recovered_active = (
                store.active_record()
            )

            return _blocked(
                reason="PREPARED_RECORD_RECONCILED_NO_SAME_CYCLE_SUBMISSION",
                durable_state=(
                    recovered_active.state.value
                    if recovered_active
                    is not None
                    else None
                ),
                recovery=recovery,
            )

        return _blocked(
            reason="ACTIVE_DURABLE_OPTIONS_RECORD",
            durable_state=
                active.state.value,
        )

    # Gate is enabled and no unresolved durable position
    # exists. Use one client instance for preflight,
    # submission and post-submit durable confirmation.
    client = client_factory(
        settings.alpaca_api_key,
        settings.alpaca_secret_key,
        paper=True,
    )

    prepared: dict[
        str,
        Any,
    ] = {}

    def before_submit(
        intent,
        request,
        executor_client,
    ) -> None:
        if executor_client is not client:
            raise RuntimeError(
                "EXECUTOR_CLIENT_IDENTITY_MISMATCH"
            )

        manifest = build_entry_manifest(
            agent_proposal=
                agent_proposal,
            options_shadow=
                options_shadow,
            options_order_intent=
                options_order_intent,
            created_at=datetime.now(
                timezone.utc
            ),
        )

        if (
            manifest.client_order_id
            != intent.client_order_id
        ):
            raise RuntimeError(
                "MANIFEST_INTENT_CLIENT_ID_MISMATCH"
            )

        request_client_id = getattr(
            request,
            "client_order_id",
            None,
        )

        if (
            request_client_id
            != manifest.client_order_id
        ):
            raise RuntimeError(
                "MANIFEST_REQUEST_CLIENT_ID_MISMATCH"
            )

        store.prepare_entry(
            manifest
        )

        prepared[
            "manifest"
        ] = manifest

    base = execute_options_paper_if_enabled(
        settings=settings,
        options_order_intent=
            options_order_intent,
        client_factory=(
            lambda *args, **kwargs:
                client
        ),
        before_submit=
            before_submit,
    )

    manifest = prepared.get(
        "manifest"
    )

    if not base.get(
        "submitted",
        False,
    ):
        active_after = (
            store.active_record()
            if manifest is not None
            else None
        )

        return _decorate(
            base,
            manifest_written=(
                manifest is not None
            ),
            durable_state=(
                active_after.state.value
                if active_after
                is not None
                else None
            ),
            durable_update_status=(
                "PREPARED_RETAINED_FOR_RECOVERY"
                if active_after
                is not None
                else None
            ),
        )

    # Broker has reported submission. From this point on,
    # never disguise submission as false merely because
    # the durable follow-up read/write has a problem.
    try:
        if manifest is None:
            raise RuntimeError(
                "SUBMITTED_WITHOUT_PREPARED_MANIFEST"
            )

        broker_order_id = base.get(
            "broker_order_id"
        )

        if not broker_order_id:
            raise RuntimeError(
                "SUBMITTED_ORDER_ID_MISSING"
            )

        order = client.get_order_by_id(
            broker_order_id
        )

        if (
            getattr(
                order,
                "client_order_id",
                None,
            )
            != manifest.client_order_id
        ):
            raise RuntimeError(
                "POST_SUBMIT_CLIENT_ID_MISMATCH"
            )

        submitted_at = getattr(
            order,
            "submitted_at",
            None,
        )

        if (
            submitted_at is None
            or submitted_at.utcoffset()
            is None
        ):
            raise RuntimeError(
                "POST_SUBMIT_TIMESTAMP_INVALID"
            )

        broker_status = getattr(
            getattr(
                order,
                "status",
                None,
            ),
            "value",
            getattr(
                order,
                "status",
                None,
            ),
        )

        updated = store.mark_submitted(
            record_id=
                manifest.record_id,
            broker_order_id=
                str(
                    broker_order_id
                ),
            broker_status=
                str(
                    broker_status
                ),
            submitted_at=
                submitted_at,
        )

        return _decorate(
            base,
            manifest_written=True,
            durable_state=
                updated.state.value,
            durable_update_status=
                "SUBMITTED_PERSISTED",
        )

    except Exception as exc:
        # Crucially: submitted remains TRUE.
        active_after = None

        try:
            active_after = (
                store.active_record()
            )
        except Exception:
            pass

        result = _decorate(
            base,
            manifest_written=(
                manifest is not None
            ),
            durable_state=(
                active_after.state.value
                if active_after
                is not None
                else None
            ),
            durable_update_status=
                "DEGRADED_AFTER_BROKER_SUBMISSION",
        )

        result[
            "durable_error_type"
        ] = type(exc).__name__

        return result


def status() -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "durable_manifest_before_submit":
            True,

        "prepared_recovery_before_new_submission":
            True,

        "same_cycle_resubmit_after_recovery":
            False,

        "single_active_options_record":
            True,

        "submitted_truth_preserved_after_boundary":
            True,

        "filled_recovery_supported":
            False,

        "partial_fill_recovery_supported":
            False,

        "dedicated_options_gate_required":
            True,

        "global_execution_must_remain_off":
            True,

        "live_trading":
            LIVE_TRADING,

        "ai_live_trading_authority":
            AI_LIVE_TRADING_AUTHORITY,
    }
