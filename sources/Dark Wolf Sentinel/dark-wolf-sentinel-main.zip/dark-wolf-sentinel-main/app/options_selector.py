from __future__ import annotations

import re
from datetime import (
    date,
    datetime,
    timezone,
)
from decimal import (
    Decimal,
    ROUND_HALF_UP,
)
from enum import Enum
from typing import Any

from pydantic import (
    BaseModel,
    Field,
)

from app.options_verticals import (
    OptionContractSpec,
    OptionLeg,
    OptionRight,
    OptionsPortfolioState,
    OptionsRiskDecision,
    OptionsRiskPolicy,
    PositionSide,
    VerticalRiskMetrics,
    VerticalSpreadProposal,
    calculate_vertical_risk,
    evaluate_vertical_risk,
)


MODE = "OPTIONS_CHAIN_SELECTOR_READ_ONLY"

TRADING_AUTHORITY = False
ORDER_AUTHORITY = False
EXECUTION_EFFECT = False

OCC_PATTERN = re.compile(
    r"^([A-Z0-9]+)"
    r"(\d{6})"
    r"([CP])"
    r"(\d{8})$"
)


class OptionDirection(str, Enum):
    BULLISH = "bullish"
    BEARISH = "bearish"


class OptionQuoteCandidate(BaseModel):
    contract: OptionContractSpec

    bid: Decimal = Field(
        ge=0,
    )

    ask: Decimal = Field(
        gt=0,
    )

    delta: Decimal

    # Informational only. Alpaca option-chain snapshots
    # may omit daily_bar entirely, so zero here must not
    # be interpreted as zero market activity.
    daily_volume: int = Field(
        ge=0,
        default=0,
    )

    bid_size: int = Field(
        ge=0,
        default=0,
    )

    ask_size: int = Field(
        ge=0,
        default=0,
    )

    latest_quote_at: datetime | None = None

    latest_trade_at: datetime | None = None

    implied_volatility: Decimal | None = None

    source: str = Field(
        default="ALPACA_OPTION_CHAIN",
        min_length=1,
    )

    def midpoint(
        self,
    ) -> Decimal:
        return (
            self.bid
            + self.ask
        ) / Decimal("2")

    def relative_spread(
        self,
    ) -> Decimal:
        mid = self.midpoint()

        if mid <= 0:
            return Decimal("999")

        return (
            self.ask
            - self.bid
        ) / mid


class OptionSelectorPolicy(BaseModel):
    min_dte: int = Field(
        default=7,
        ge=1,
    )

    max_dte: int = Field(
        default=45,
        ge=1,
    )

    target_dte: int = Field(
        default=21,
        ge=1,
    )

    max_relative_spread: Decimal = Field(
        default=Decimal("0.20"),
        gt=0,
    )

    min_quote_size: int = Field(
        default=1,
        ge=1,
    )

    max_quote_age_seconds: int = Field(
        default=120,
        ge=1,
    )

    max_trade_age_seconds: int = Field(
        default=1800,
        ge=1,
    )

    long_delta_min: Decimal = Field(
        default=Decimal("0.45"),
        gt=0,
        lt=1,
    )

    long_delta_max: Decimal = Field(
        default=Decimal("0.70"),
        gt=0,
        lt=1,
    )

    short_delta_min: Decimal = Field(
        default=Decimal("0.20"),
        gt=0,
        lt=1,
    )

    short_delta_max: Decimal = Field(
        default=Decimal("0.45"),
        gt=0,
        lt=1,
    )

    target_long_delta: Decimal = Field(
        default=Decimal("0.55"),
        gt=0,
        lt=1,
    )

    target_short_delta: Decimal = Field(
        default=Decimal("0.30"),
        gt=0,
        lt=1,
    )

    max_width: Decimal = Field(
        default=Decimal("20"),
        gt=0,
    )

    min_reward_to_risk: Decimal = Field(
        default=Decimal("0.40"),
        gt=0,
    )


class OptionSelectionResult(BaseModel):
    mode: str = MODE

    selected: bool

    reason: str

    direction: OptionDirection

    considered_contracts: int = 0

    eligible_contracts: int = 0

    pairs_evaluated: int = 0

    rejection_counts: dict[str, int] = Field(
            default_factory=dict,
        )

    proposal: VerticalSpreadProposal | None = None

    metrics: VerticalRiskMetrics | None = None

    risk_decision: OptionsRiskDecision | None = None

    trading_authority: bool = False

    order_authority: bool = False

    execution_effect: bool = False


def money(
    value: Decimal,
) -> Decimal:
    return value.quantize(
        Decimal("0.01"),
        rounding=ROUND_HALF_UP,
    )


def parse_occ_contract(
    symbol: str,
    *,
    source: str = "ALPACA_OPTION_CHAIN",
) -> OptionContractSpec:
    clean = symbol.upper().strip()

    match = OCC_PATTERN.match(
        clean
    )

    if match is None:
        raise ValueError(
            "INVALID_OCC_OPTION_SYMBOL"
        )

    underlying = match.group(1)

    expiration = datetime.strptime(
        match.group(2),
        "%y%m%d",
    ).date()

    right = (
        OptionRight.CALL
        if match.group(3) == "C"
        else OptionRight.PUT
    )

    strike = (
        Decimal(
            match.group(4)
        )
        / Decimal("1000")
    )

    return OptionContractSpec(
        symbol=clean,
        underlying=underlying,
        right=right,
        strike=strike,
        expiration=expiration,
        multiplier=Decimal("100"),
        tradable=True,
        source=source,
    )


def _decimal_or_none(
    value: Any,
) -> Decimal | None:
    if value is None:
        return None

    try:
        return Decimal(
            str(value)
        )
    except Exception:
        return None


def adapt_alpaca_chain(
    chain: dict[str, Any],
) -> tuple[
    list[OptionQuoteCandidate],
    dict[str, int],
]:
    candidates: list[
        OptionQuoteCandidate
    ] = []

    rejected: dict[str, int] = {}

    def mark(
        reason: str,
    ) -> None:
        rejected[reason] = (
            rejected.get(
                reason,
                0,
            )
            + 1
        )

    for symbol, snapshot in chain.items():
        try:
            contract = parse_occ_contract(
                symbol
            )

        except Exception:
            mark(
                "INVALID_OCC_SYMBOL"
            )
            continue

        quote = getattr(
            snapshot,
            "latest_quote",
            None,
        )

        if quote is None:
            mark(
                "MISSING_QUOTE"
            )
            continue

        bid = _decimal_or_none(
            getattr(
                quote,
                "bid_price",
                None,
            )
        )

        ask = _decimal_or_none(
            getattr(
                quote,
                "ask_price",
                None,
            )
        )

        if (
            bid is None
            or ask is None
        ):
            mark(
                "INVALID_QUOTE"
            )
            continue

        greeks = getattr(
            snapshot,
            "greeks",
            None,
        )

        if greeks is None:
            mark(
                "MISSING_GREEKS"
            )
            continue

        delta = _decimal_or_none(
            getattr(
                greeks,
                "delta",
                None,
            )
        )

        if delta is None:
            mark(
                "MISSING_DELTA"
            )
            continue

        daily_bar = getattr(
            snapshot,
            "daily_bar",
            None,
        )

        volume_raw = (
            getattr(
                daily_bar,
                "volume",
                0,
            )
            if daily_bar is not None
            else 0
        )

        try:
            volume = int(
                volume_raw or 0
            )
        except Exception:
            volume = 0

        iv = _decimal_or_none(
            getattr(
                snapshot,
                "implied_volatility",
                None,
            )
        )

        try:
            bid_size = int(
                getattr(
                    quote,
                    "bid_size",
                    0,
                )
                or 0
            )
        except Exception:
            bid_size = 0

        try:
            ask_size = int(
                getattr(
                    quote,
                    "ask_size",
                    0,
                )
                or 0
            )
        except Exception:
            ask_size = 0

        latest_quote_at = getattr(
            quote,
            "timestamp",
            None,
        )

        latest_trade = getattr(
            snapshot,
            "latest_trade",
            None,
        )

        latest_trade_at = (
            getattr(
                latest_trade,
                "timestamp",
                None,
            )
            if latest_trade is not None
            else None
        )

        try:
            candidate = (
                OptionQuoteCandidate(
                    contract=contract,
                    bid=bid,
                    ask=ask,
                    delta=delta,
                    daily_volume=volume,
                    bid_size=bid_size,
                    ask_size=ask_size,
                    latest_quote_at=
                        latest_quote_at,
                    latest_trade_at=
                        latest_trade_at,
                    implied_volatility=iv,
                )
            )

        except Exception:
            mark(
                "INVALID_CANDIDATE"
            )
            continue

        candidates.append(
            candidate
        )

    return (
        candidates,
        rejected,
    )


def _mark(
    counts: dict[str, int],
    reason: str,
) -> None:
    counts[reason] = (
        counts.get(
            reason,
            0,
        )
        + 1
    )


def _age_seconds(
    *,
    now: datetime,
    event: datetime,
) -> float:
    if now.tzinfo is None:
        now = now.replace(
            tzinfo=timezone.utc
        )

    if event.tzinfo is None:
        event = event.replace(
            tzinfo=timezone.utc
        )

    now_utc = now.astimezone(
        timezone.utc
    )

    event_utc = event.astimezone(
        timezone.utc
    )

    return max(
        0.0,
        (
            now_utc
            - event_utc
        ).total_seconds(),
    )


def _is_basic_eligible(
    item: OptionQuoteCandidate,
    *,
    expected_right: OptionRight,
    policy: OptionSelectorPolicy,
    as_of: date,
    as_of_time: datetime,
    rejected: dict[str, int],
) -> bool:
    contract = item.contract

    if (
        contract.right
        != expected_right
    ):
        _mark(
            rejected,
            "WRONG_OPTION_RIGHT",
        )
        return False

    dte = (
        contract.expiration
        - as_of
    ).days

    if dte < policy.min_dte:
        _mark(
            rejected,
            "DTE_TOO_SHORT",
        )
        return False

    if dte > policy.max_dte:
        _mark(
            rejected,
            "DTE_TOO_LONG",
        )
        return False

    if (
        item.bid <= 0
        or item.ask <= item.bid
    ):
        _mark(
            rejected,
            "INVALID_MARKET",
        )
        return False

    if (
        item.relative_spread()
        > policy.max_relative_spread
    ):
        _mark(
            rejected,
            "BID_ASK_TOO_WIDE",
        )
        return False

    if (
        item.bid_size
        < policy.min_quote_size
        or item.ask_size
        < policy.min_quote_size
    ):
        _mark(
            rejected,
            "INSUFFICIENT_QUOTE_SIZE",
        )
        return False

    if item.latest_quote_at is None:
        _mark(
            rejected,
            "MISSING_QUOTE_TIMESTAMP",
        )
        return False

    quote_age = _age_seconds(
        now=as_of_time,
        event=item.latest_quote_at,
    )

    if (
        quote_age
        > policy.max_quote_age_seconds
    ):
        _mark(
            rejected,
            "STALE_QUOTE",
        )
        return False

    if item.latest_trade_at is None:
        _mark(
            rejected,
            "MISSING_RECENT_TRADE",
        )
        return False

    trade_age = _age_seconds(
        now=as_of_time,
        event=item.latest_trade_at,
    )

    if (
        trade_age
        > policy.max_trade_age_seconds
    ):
        _mark(
            rejected,
            "STALE_LAST_TRADE",
        )
        return False

    abs_delta = abs(
        item.delta
    )

    if (
        abs_delta <= 0
        or abs_delta >= 1
    ):
        _mark(
            rejected,
            "INVALID_DELTA",
        )
        return False

    return True


def select_debit_vertical(
    *,
    direction: OptionDirection,
    chain: list[OptionQuoteCandidate],
    confidence: float,
    thesis: str,
    portfolio: OptionsPortfolioState,
    risk_policy: OptionsRiskPolicy,
    selector_policy: OptionSelectorPolicy | None = None,
    requested_quantity: int = 1,
    as_of: date | None = None,
    as_of_time: datetime | None = None,
    adapter_rejections: dict[str, int] | None = None,
) -> OptionSelectionResult:
    """
    Deterministic read-only vertical selector.

    BULLISH -> bull call debit spread.
    BEARISH -> bear put debit spread.

    The selector has no broker or order authority.
    Final sizing remains with the deterministic
    maximum-loss risk kernel.
    """

    if selector_policy is None:
        selector_policy = (
            OptionSelectorPolicy()
        )

    if as_of is None:
        as_of = date.today()

    if as_of_time is None:
        as_of_time = datetime.now(
            timezone.utc
        )

    rejected = dict(
        adapter_rejections
        or {}
    )

    expected_right = (
        OptionRight.CALL
        if direction
        == OptionDirection.BULLISH
        else OptionRight.PUT
    )

    eligible = [
        item
        for item in chain
        if _is_basic_eligible(
            item,
            expected_right=
                expected_right,
            policy=
                selector_policy,
            as_of=as_of,
            as_of_time=as_of_time,
            rejected=rejected,
        )
    ]

    long_candidates = []

    short_candidates = []

    for item in eligible:
        delta = abs(
            item.delta
        )

        if (
            selector_policy
            .long_delta_min
            <= delta
            <= selector_policy
            .long_delta_max
        ):
            long_candidates.append(
                item
            )

        if (
            selector_policy
            .short_delta_min
            <= delta
            <= selector_policy
            .short_delta_max
        ):
            short_candidates.append(
                item
            )

    ranked: list[
        tuple[
            tuple[
                float,
                float,
                float,
                float,
                float,
            ],
            VerticalSpreadProposal,
            VerticalRiskMetrics,
        ]
    ] = []

    pairs_evaluated = 0

    for long_item in long_candidates:
        for short_item in short_candidates:
            long_contract = (
                long_item.contract
            )

            short_contract = (
                short_item.contract
            )

            if (
                long_contract.expiration
                != short_contract.expiration
            ):
                continue

            if (
                long_contract.symbol
                == short_contract.symbol
            ):
                continue

            if (
                direction
                == OptionDirection.BULLISH
            ):
                valid_order = (
                    long_contract.strike
                    < short_contract.strike
                )

            else:
                valid_order = (
                    long_contract.strike
                    > short_contract.strike
                )

            if not valid_order:
                continue

            width = abs(
                long_contract.strike
                - short_contract.strike
            )

            if (
                width
                > selector_policy.max_width
            ):
                _mark(
                    rejected,
                    "WIDTH_TOO_LARGE",
                )
                continue

            pairs_evaluated += 1

            proposal = (
                VerticalSpreadProposal(
                    long_leg=OptionLeg(
                        contract=
                            long_contract,
                        side=
                            PositionSide.LONG,
                        premium=
                            long_item
                            .midpoint(),
                    ),
                    short_leg=OptionLeg(
                        contract=
                            short_contract,
                        side=
                            PositionSide.SHORT,
                        premium=
                            short_item
                            .midpoint(),
                    ),
                    quantity=
                        requested_quantity,
                    confidence=
                        confidence,
                    thesis=
                        thesis,
                )
            )

            try:
                metrics = (
                    calculate_vertical_risk(
                        proposal
                    )
                )

            except Exception:
                _mark(
                    rejected,
                    "INVALID_VERTICAL_PAIR",
                )
                continue

            if (
                metrics.reward_to_risk
                < selector_policy
                .min_reward_to_risk
            ):
                _mark(
                    rejected,
                    "REWARD_RISK_TOO_LOW",
                )
                continue

            dte = (
                long_contract.expiration
                - as_of
            ).days

            combined_spread = (
                long_item.relative_spread()
                + short_item.relative_spread()
            )

            score = (
                float(
                    abs(
                        dte
                        - selector_policy
                        .target_dte
                    )
                ),
                float(
                    abs(
                        abs(
                            long_item.delta
                        )
                        - selector_policy
                        .target_long_delta
                    )
                ),
                float(
                    abs(
                        abs(
                            short_item.delta
                        )
                        - selector_policy
                        .target_short_delta
                    )
                ),
                float(
                    combined_spread
                ),
                float(
                    width
                ),
            )

            ranked.append(
                (
                    score,
                    proposal,
                    metrics,
                )
            )

    if not ranked:
        return OptionSelectionResult(
            selected=False,
            reason="NO_VALID_VERTICAL",
            direction=direction,
            considered_contracts=
                len(chain),
            eligible_contracts=
                len(eligible),
            pairs_evaluated=
                pairs_evaluated,
            rejection_counts=
                rejected,
            trading_authority=False,
            order_authority=False,
            execution_effect=False,
        )

    ranked.sort(
        key=lambda item:
            item[0]
    )

    _, proposal, metrics = (
        ranked[0]
    )

    risk_decision = (
        evaluate_vertical_risk(
            proposal,
            portfolio,
            risk_policy,
        )
    )

    reason = (
        "SELECTED_AND_RISK_APPROVED"
        if risk_decision.approved
        else (
            "SELECTED_BUT_RISK_REJECTED:"
            + risk_decision.reason
        )
    )

    return OptionSelectionResult(
        selected=True,
        reason=reason,
        direction=direction,
        considered_contracts=
            len(chain),
        eligible_contracts=
            len(eligible),
        pairs_evaluated=
            pairs_evaluated,
        rejection_counts=
            rejected,
        proposal=
            proposal,
        metrics=
            metrics,
        risk_decision=
            risk_decision,
        trading_authority=False,
        order_authority=False,
        execution_effect=False,
    )


def status() -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "supported_directions": [
            item.value
            for item
            in OptionDirection
        ],

        "selected_structures": [
            "bull_call_debit",
            "bear_put_debit",
        ],

        "zero_dte_allowed":
            False,

        "quote_quality_filter":
            True,

        "snapshot_daily_volume_required":
            False,

        "quote_size_filter":
            True,

        "quote_freshness_filter":
            True,

        "recent_trade_filter":
            True,

        "greeks_required":
            True,

        "risk_authority":
            (
                "OPTIONS_MAX_LOSS_KERNEL"
            ),

        "trading_authority":
            TRADING_AUTHORITY,

        "order_authority":
            ORDER_AUTHORITY,

        "execution_effect":
            EXECUTION_EFFECT,
    }
