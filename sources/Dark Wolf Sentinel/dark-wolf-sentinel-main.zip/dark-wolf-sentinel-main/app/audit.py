from __future__ import annotations

import json
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from uuid import uuid4

from app.models import (
    PortfolioState,
    RiskDecision,
    TradeCandidate,
)


DB_PATH = Path(
    "data/sentinel_audit.db"
)


def utc_now() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


def init_db() -> None:
    DB_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS trade_decisions (
                id TEXT PRIMARY KEY,
                created_at TEXT NOT NULL,
                symbol TEXT NOT NULL,
                candidate_json TEXT NOT NULL,
                portfolio_json TEXT NOT NULL,
                decision_json TEXT NOT NULL,
                approved INTEGER NOT NULL,
                reason TEXT NOT NULL,
                live_order_allowed INTEGER NOT NULL,
                trading_authority INTEGER NOT NULL
            )
            """
        )

        conn.commit()


def record_decision(
    candidate: TradeCandidate,
    portfolio: PortfolioState,
    decision: RiskDecision,
) -> str:
    init_db()

    record_id = str(
        uuid4()
    )

    with sqlite3.connect(DB_PATH) as conn:
        conn.execute(
            """
            INSERT INTO trade_decisions (
                id,
                created_at,
                symbol,
                candidate_json,
                portfolio_json,
                decision_json,
                approved,
                reason,
                live_order_allowed,
                trading_authority
            )
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                record_id,
                utc_now(),
                decision.symbol,
                json.dumps(
                    candidate.model_dump(
                        mode="json"
                    )
                ),
                json.dumps(
                    portfolio.model_dump(
                        mode="json"
                    )
                ),
                json.dumps(
                    decision.model_dump(
                        mode="json"
                    )
                ),
                int(decision.approved),
                decision.reason,
                int(
                    decision.live_order_allowed
                ),
                int(
                    decision.trading_authority
                ),
            ),
        )

        conn.commit()

    return record_id
