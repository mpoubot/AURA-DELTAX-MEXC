from __future__ import annotations

from typing import Any, Callable

from alpaca.trading.client import TradingClient
from alpaca.trading.enums import QueryOrderStatus
from alpaca.trading.requests import (
    GetOrdersRequest,
    LimitOrderRequest,
    OptionLegRequest,
)

from app.broker.alpaca_options_paper_executor import (
    AlpacaOptionsPaperExecutor,
)
from app.options_order_intent import (
    OptionsMlegIntent,
)


MODE = "SENTINEL_OPTIONS_PAPER_EXECUTION_GATE"

LIVE_TRADING = False
AI_LIVE_TRADING_AUTHORITY = False


def _result(
    *,
    status: str,
    reason: str,
    submitted: bool = False,
    broker_order_id: str | None = None,
    broker_status: str | None = None,
) -> dict[str, Any]:
    return {
        "mode": MODE,
        "status": status,
        "reason": reason,
        "submitted": submitted,
        "broker_order_id": broker_order_id,
        "broker_status": broker_status,
        "paper_only": True,
        "live_trading": False,
        "ai_live_trading_authority": False,
    }


def _reconstruct_packet(
    packet: dict[str, Any],
) -> tuple[
    OptionsMlegIntent,
    LimitOrderRequest,
]:
    raw_intent = packet.get(
        "intent"
    )

    raw_request = packet.get(
        "request_payload"
    )

    if not isinstance(
        raw_intent,
        dict,
    ):
        raise ValueError(
            "MISSING_MLEG_INTENT"
        )

    if not isinstance(
        raw_request,
        dict,
    ):
        raise ValueError(
            "MISSING_MLEG_REQUEST"
        )

    intent = (
        OptionsMlegIntent
        .model_validate(
            raw_intent
        )
    )

    payload = dict(
        raw_request
    )

    raw_legs = payload.get(
        "legs",
        [],
    )

    if len(raw_legs) != 2:
        raise ValueError(
            "MLEG_REQUIRES_EXACTLY_TWO_LEGS"
        )

    payload["legs"] = [
        OptionLegRequest.model_validate(
            leg
        )
        for leg in raw_legs
    ]

    request = (
        LimitOrderRequest
        .model_validate(
            payload
        )
    )

    return (
        intent,
        request,
    )


def execute_options_paper_if_enabled(
    *,
    settings: Any,
    options_order_intent: dict[str, Any] | None,
    client_factory: Callable[..., Any] = TradingClient,
    before_submit: Callable[
        [OptionsMlegIntent, LimitOrderRequest, Any],
        None,
    ] | None = None,
) -> dict[str, Any]:
    """
    Sentinel's only path toward options PAPER execution.

    No broker client is constructed unless the dedicated
    options execution flag is explicitly enabled.
    """

    settings.assert_paper_only()

    if getattr(
        settings,
        "alpaca_paper",
        False,
    ) is not True:
        return _result(
            status="BLOCKED",
            reason="NON_PAPER_ACCOUNT_FORBIDDEN",
        )

    if options_order_intent is None:
        return _result(
            status="SKIPPED_NO_INTENT",
            reason="NO_MLEG_INTENT",
        )

    if (
        options_order_intent.get(
            "status"
        )
        != "READY_INERT"
    ):
        return _result(
            status="SKIPPED_NOT_READY",
            reason="MLEG_INTENT_NOT_READY",
        )

    # Dedicated gate must be checked before any
    # broker-client construction or broker request.
    if (
        getattr(
            settings,
            "options_paper_execution_enabled",
            False,
        )
        is not True
    ):
        return _result(
            status="DISABLED",
            reason="OPTIONS_PAPER_EXECUTION_DISABLED",
        )

    # Keep the older global/equity execution path
    # isolated while options automation is evaluated.
    if (
        getattr(
            settings,
            "paper_execution_enabled",
            False,
        )
        is True
    ):
        return _result(
            status="BLOCKED",
            reason="GLOBAL_EXECUTION_MUST_REMAIN_DISABLED",
        )

    try:
        intent, request = (
            _reconstruct_packet(
                options_order_intent
            )
        )

        client = client_factory(
            settings.alpaca_api_key,
            settings.alpaca_secret_key,
            paper=True,
        )

        account = client.get_account()
        clock = client.get_clock()

        if getattr(
            account,
            "account_blocked",
            False,
        ):
            return _result(
                status="BLOCKED",
                reason="ACCOUNT_BLOCKED",
            )

        if getattr(
            account,
            "trading_blocked",
            False,
        ):
            return _result(
                status="BLOCKED",
                reason="TRADING_BLOCKED",
            )

        approved_level = getattr(
            account,
            "options_approved_level",
            None,
        )

        trading_level = getattr(
            account,
            "options_trading_level",
            None,
        )

        if (
            approved_level is None
            or trading_level is None
            or int(
                approved_level
            ) < 3
            or int(
                trading_level
            ) < 3
        ):
            return _result(
                status="BLOCKED",
                reason="OPTIONS_LEVEL_INSUFFICIENT",
            )

        if getattr(
            clock,
            "is_open",
            False,
        ) is not True:
            return _result(
                status="BLOCKED",
                reason="MARKET_CLOSED",
            )

        positions = (
            client
            .get_all_positions()
        )

        if positions:
            return _result(
                status="BLOCKED",
                reason="EXISTING_POSITION",
            )

        open_orders = client.get_orders(
            filter=GetOrdersRequest(
                status=
                    QueryOrderStatus.OPEN,
            )
        )

        if open_orders:
            return _result(
                status="BLOCKED",
                reason="EXISTING_OPEN_ORDER",
            )

        # Final hook immediately before the only
        # options submit_order() effect boundary.
        #
        # Production uses this to fsync the durable
        # PREPARED manifest before broker submission.
        if before_submit is not None:
            before_submit(
                intent,
                request,
                client,
            )

        executor = (
            AlpacaOptionsPaperExecutor(
                settings,
                client=client,
            )
        )

        execution = executor.execute(
            intent=intent,
            request=request,
        )

        return _result(
            status="SUBMITTED",
            reason=execution.reason,
            submitted=True,
            broker_order_id=
                execution
                .broker_order_id,
            broker_status=
                execution
                .broker_status,
        )

    except Exception as exc:
        result = _result(
            status="DEGRADED",
            reason="OPTIONS_EXECUTION_FAILED",
        )

        result["error_type"] = (
            type(exc).__name__
        )

        return result


def status() -> dict[str, Any]:
    return {
        "mode": MODE,
        "dedicated_options_gate":
            True,
        "global_gate_must_remain_off":
            True,
        "client_created_when_disabled":
            False,
        "flat_account_required":
            True,
        "zero_open_orders_required":
            True,
        "market_open_required":
            True,
        "options_level_required":
            3,
        "live_trading":
            LIVE_TRADING,
        "ai_live_trading_authority":
            AI_LIVE_TRADING_AUTHORITY,
    }
