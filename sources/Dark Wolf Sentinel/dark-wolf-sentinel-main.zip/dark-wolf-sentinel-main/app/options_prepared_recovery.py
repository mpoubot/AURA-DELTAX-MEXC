from __future__ import annotations

from decimal import Decimal
from typing import Any

from alpaca.trading.enums import (
    OrderStatus,
)
from alpaca.trading.requests import (
    GetOrderByIdRequest,
)

from app.options_position_store import (
    EntryState,
    OptionsEntryManifest,
    OptionsPositionStore,
)


MODE = "OPTIONS_PREPARED_ENTRY_RECOVERY"

BROKER_READS = True
BROKER_WRITES = False
ORDER_SUBMISSION_AUTHORITY = False
EXECUTION_EFFECT = False


class OptionsPreparedRecoveryError(
    ValueError
):
    pass


NONFILLED_SUBMITTED_STATUSES = {
    OrderStatus.NEW.value,
    OrderStatus.ACCEPTED.value,
    OrderStatus.PENDING_NEW.value,
    OrderStatus.PENDING_REVIEW.value,
    OrderStatus.ACCEPTED_FOR_BIDDING.value,
    OrderStatus.HELD.value,
    OrderStatus.PENDING_CANCEL.value,
    OrderStatus.PENDING_REPLACE.value,
}

NONFILLED_CANCELED_STATUSES = {
    OrderStatus.CANCELED.value,
    OrderStatus.EXPIRED.value,
    OrderStatus.DONE_FOR_DAY.value,
}

REJECTED_STATUSES = {
    OrderStatus.REJECTED.value,
}


def _enum_value(
    value: Any,
) -> Any:
    return getattr(
        value,
        "value",
        value,
    )


def _decimal(
    value: Any,
) -> Decimal:
    return Decimal(
        str(value)
    )


def _result(
    *,
    status: str,
    reason: str,
    record: OptionsEntryManifest | None = None,
    broker_order_id: str | None = None,
    broker_status: str | None = None,
) -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "status":
            status,

        "reason":
            reason,

        "record_id":
            (
                record.record_id
                if record is not None
                else None
            ),

        "durable_state":
            (
                record.state.value
                if record is not None
                else None
            ),

        "broker_order_id":
            broker_order_id,

        "broker_status":
            broker_status,

        "resubmission_allowed":
            False,

        "broker_reads":
            True,

        "broker_writes":
            False,

        "order_submission_authority":
            False,

        "execution_effect":
            False,
    }


def _validate_broker_identity(
    *,
    manifest: OptionsEntryManifest,
    order: Any,
) -> None:
    if (
        getattr(
            order,
            "client_order_id",
            None,
        )
        != manifest.client_order_id
    ):
        raise OptionsPreparedRecoveryError(
            "CLIENT_ORDER_ID_MISMATCH"
        )

    if (
        _enum_value(
            getattr(
                order,
                "order_class",
                None,
            )
        )
        != "mleg"
    ):
        raise OptionsPreparedRecoveryError(
            "RECOVERED_ORDER_NOT_MLEG"
        )

    if (
        _enum_value(
            getattr(
                order,
                "type",
                None,
            )
        )
        != "limit"
    ):
        raise OptionsPreparedRecoveryError(
            "RECOVERED_ORDER_NOT_LIMIT"
        )

    qty = _decimal(
        getattr(
            order,
            "qty",
            None,
        )
    )

    if qty != Decimal(
        manifest.quantity
    ):
        raise OptionsPreparedRecoveryError(
            "RECOVERED_ORDER_QTY_MISMATCH"
        )

    limit_price = _decimal(
        getattr(
            order,
            "limit_price",
            None,
        )
    )

    if (
        limit_price
        != manifest.executable_entry_limit
    ):
        raise OptionsPreparedRecoveryError(
            "RECOVERED_ORDER_LIMIT_MISMATCH"
        )

    legs = (
        getattr(
            order,
            "legs",
            None,
        )
        or []
    )

    if len(legs) != 2:
        raise OptionsPreparedRecoveryError(
            "RECOVERED_MLEG_REQUIRES_TWO_LEGS"
        )

    by_symbol = {}

    for leg in legs:
        symbol = getattr(
            leg,
            "symbol",
            None,
        )

        if not symbol:
            raise OptionsPreparedRecoveryError(
                "RECOVERED_LEG_SYMBOL_MISSING"
            )

        if symbol in by_symbol:
            raise OptionsPreparedRecoveryError(
                "RECOVERED_DUPLICATE_LEG_SYMBOL"
            )

        by_symbol[symbol] = leg

    expected_symbols = {
        manifest.long_symbol,
        manifest.short_symbol,
    }

    if set(
        by_symbol
    ) != expected_symbols:
        raise OptionsPreparedRecoveryError(
            "RECOVERED_LEG_SYMBOL_MISMATCH"
        )

    long_leg = by_symbol[
        manifest.long_symbol
    ]

    short_leg = by_symbol[
        manifest.short_symbol
    ]

    if (
        _enum_value(
            getattr(
                long_leg,
                "side",
                None,
            )
        )
        != "buy"
    ):
        raise OptionsPreparedRecoveryError(
            "RECOVERED_LONG_SIDE_MISMATCH"
        )

    if (
        _enum_value(
            getattr(
                long_leg,
                "position_intent",
                None,
            )
        )
        != "buy_to_open"
    ):
        raise OptionsPreparedRecoveryError(
            "RECOVERED_LONG_INTENT_MISMATCH"
        )

    if (
        _enum_value(
            getattr(
                short_leg,
                "side",
                None,
            )
        )
        != "sell"
    ):
        raise OptionsPreparedRecoveryError(
            "RECOVERED_SHORT_SIDE_MISMATCH"
        )

    if (
        _enum_value(
            getattr(
                short_leg,
                "position_intent",
                None,
            )
        )
        != "sell_to_open"
    ):
        raise OptionsPreparedRecoveryError(
            "RECOVERED_SHORT_INTENT_MISMATCH"
        )


def recover_prepared_entry(
    *,
    store: OptionsPositionStore,
    client: Any,
) -> dict[str, Any]:
    """
    Reconcile a durable PREPARED manifest with Alpaca.

    Critical rule:
      recovery NEVER resubmits.

    A definitive 404 means the broker does not currently
    know that client order ID, but the PREPARED manifest
    remains intact until a later explicit recovery policy
    decides what to do.

    FILLED / partial-fill economics remain deliberately
    blocked until parent MLEG fill-price semantics have
    been separately certified.
    """

    active = store.active_record()

    if active is None:
        return _result(
            status="NO_ACTIVE_RECORD",
            reason="NO_DURABLE_OPTIONS_RECORD",
        )

    if active.state != EntryState.PREPARED:
        return _result(
            status="SKIPPED_STATE",
            reason=(
                "RECOVERY_ONLY_HANDLES_PREPARED"
            ),
            record=active,
            broker_order_id=
                active.broker_order_id,
            broker_status=
                active.broker_status,
        )

    try:
        located = (
            client
            .get_order_by_client_id(
                active.client_order_id
            )
        )

    except Exception as exc:
        status_code = getattr(
            exc,
            "status_code",
            None,
        )

        if status_code == 404:
            return _result(
                status="BROKER_NOT_FOUND",
                reason=(
                    "DEFINITIVE_CLIENT_ORDER_ID_404"
                ),
                record=active,
            )

        result = _result(
            status="DEGRADED",
            reason="AMBIGUOUS_BROKER_LOOKUP_FAILURE",
            record=active,
        )

        result[
            "error_type"
        ] = type(exc).__name__

        return result

    order_id = getattr(
        located,
        "id",
        None,
    )

    if order_id is None:
        return _result(
            status="DEGRADED",
            reason="RECOVERED_ORDER_ID_MISSING",
            record=active,
        )

    try:
        order = client.get_order_by_id(
            order_id,
            filter=GetOrderByIdRequest(
                nested=True
            ),
        )

        _validate_broker_identity(
            manifest=active,
            order=order,
        )

    except Exception as exc:
        result = _result(
            status="DEGRADED",
            reason="BROKER_ORDER_RECONCILIATION_FAILED",
            record=active,
            broker_order_id=
                str(order_id),
        )

        result[
            "error_type"
        ] = type(exc).__name__

        result[
            "error_reason"
        ] = str(exc)

        return result

    broker_status = str(
        _enum_value(
            getattr(
                order,
                "status",
                None,
            )
        )
    )

    broker_order_id = str(
        order.id
    )

    filled_qty = _decimal(
        getattr(
            order,
            "filled_qty",
            0,
        )
        or 0
    )

    # Any fill evidence is a hard stop until MLEG
    # parent fill economics have been certified.
    if filled_qty > 0:
        return _result(
            status="BLOCKED_FILL_RECOVERY",
            reason="MLEG_FILL_SEMANTICS_NOT_CERTIFIED",
            record=active,
            broker_order_id=
                broker_order_id,
            broker_status=
                broker_status,
        )

    if (
        broker_status
        == OrderStatus.FILLED.value
        or broker_status
        == OrderStatus.PARTIALLY_FILLED.value
    ):
        return _result(
            status="BLOCKED_FILL_RECOVERY",
            reason="MLEG_FILL_SEMANTICS_NOT_CERTIFIED",
            record=active,
            broker_order_id=
                broker_order_id,
            broker_status=
                broker_status,
        )

    if (
        broker_status
        in NONFILLED_SUBMITTED_STATUSES
    ):
        submitted_at = getattr(
            order,
            "submitted_at",
            None,
        )

        if (
            submitted_at is None
            or submitted_at.utcoffset()
            is None
        ):
            return _result(
                status="DEGRADED",
                reason="BROKER_SUBMITTED_AT_INVALID",
                record=active,
                broker_order_id=
                    broker_order_id,
                broker_status=
                    broker_status,
            )

        updated = store.mark_submitted(
            record_id=
                active.record_id,
            broker_order_id=
                broker_order_id,
            broker_status=
                broker_status,
            submitted_at=
                submitted_at,
        )

        return _result(
            status="RECOVERED_SUBMITTED",
            reason="PREPARED_RECONCILED_TO_SUBMITTED",
            record=updated,
            broker_order_id=
                broker_order_id,
            broker_status=
                broker_status,
        )

    if (
        broker_status
        in NONFILLED_CANCELED_STATUSES
    ):
        updated = store.mark_canceled(
            record_id=
                active.record_id,
            broker_status=
                broker_status,
        )

        return _result(
            status="RECOVERED_TERMINAL",
            reason="PREPARED_RECONCILED_TO_CANCELED",
            record=updated,
            broker_order_id=
                broker_order_id,
            broker_status=
                broker_status,
        )

    if (
        broker_status
        in REJECTED_STATUSES
    ):
        updated = store.mark_rejected(
            record_id=
                active.record_id,
            broker_status=
                broker_status,
        )

        return _result(
            status="RECOVERED_TERMINAL",
            reason="PREPARED_RECONCILED_TO_REJECTED",
            record=updated,
            broker_order_id=
                broker_order_id,
            broker_status=
                broker_status,
        )

    return _result(
        status="BLOCKED_UNKNOWN_STATUS",
        reason="UNHANDLED_BROKER_ORDER_STATUS",
        record=active,
        broker_order_id=
            broker_order_id,
        broker_status=
            broker_status,
    )


def status() -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "prepared_only":
            True,

        "lookup_by_client_order_id":
            True,

        "nested_order_reconciliation":
            True,

        "exact_mleg_identity_required":
            True,

        "definitive_404_resubmits":
            False,

        "ambiguous_read_resubmits":
            False,

        "filled_recovery_supported":
            False,

        "partial_fill_recovery_supported":
            False,

        "broker_reads":
            BROKER_READS,

        "broker_writes":
            BROKER_WRITES,

        "order_submission_authority":
            ORDER_SUBMISSION_AUTHORITY,

        "execution_effect":
            EXECUTION_EFFECT,
    }
