from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

from alpaca.data.enums import DataFeed
from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.requests import (
    StockBarsRequest,
    StockLatestTradeRequest,
)
from alpaca.data.timeframe import (
    TimeFrame,
    TimeFrameUnit,
)

from app.config import Settings


UNIVERSE = [
    "AAPL",
    "MSFT",
    "NVDA",
    "AMZN",
    "META",
    "TSLA",
    "SPY",
    "QQQ",
]


@dataclass
class TechnicalSnapshot:
    symbol: str
    current_price: float
    ema20: float
    ema50: float
    rsi: float | None
    prior_high: float
    volume_ratio: float | None
    trend: str
    score: float


def ema(
    values: list[float],
    period: int,
) -> float:
    multiplier = 2 / (period + 1)
    value = values[0]

    for price in values[1:]:
        value = (
            price * multiplier
            + value * (1 - multiplier)
        )

    return value


def rsi(
    values: list[float],
    period: int = 14,
) -> float | None:
    if len(values) < period + 1:
        return None

    changes = [
        values[i] - values[i - 1]
        for i in range(1, len(values))
    ]

    gains = [
        max(change, 0)
        for change in changes[-period:]
    ]

    losses = [
        abs(min(change, 0))
        for change in changes[-period:]
    ]

    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period

    if avg_loss == 0:
        return 100.0

    rs = avg_gain / avg_loss

    return 100 - (100 / (1 + rs))


def score_snapshot(
    *,
    current_price: float,
    ema20_value: float,
    ema50_value: float,
    rsi_value: float | None,
    prior_high: float,
    volume_ratio: float | None,
) -> float:
    """Deterministic opportunity ranking.

    This score chooses what GPT analyzes.
    It does NOT approve a trade.
    """

    score = 0.0

    if current_price > ema20_value:
        score += 20

    if ema20_value > ema50_value:
        score += 25

    if current_price > prior_high:
        score += 20

    if rsi_value is not None:
        if 52 <= rsi_value <= 72:
            score += 20
        elif 45 <= rsi_value < 52:
            score += 8
        elif 72 < rsi_value <= 78:
            score += 5

    if volume_ratio is not None:
        if volume_ratio >= 1.25:
            score += 15
        elif volume_ratio >= 1.0:
            score += 8

    return round(score, 2)


def scan(
    settings: Settings,
) -> list[TechnicalSnapshot]:
    data = StockHistoricalDataClient(
        settings.alpaca_api_key,
        settings.alpaca_secret_key,
    )

    now = datetime.now(timezone.utc)

    snapshots = []

    timeframe = TimeFrame(
        15,
        TimeFrameUnit.Minute,
    )

    for symbol in UNIVERSE:
        bars = data.get_stock_bars(
            StockBarsRequest(
                symbol_or_symbols=symbol,
                timeframe=timeframe,
                start=now - timedelta(days=10),
                end=now,
                feed=DataFeed.IEX,
            )
        )

        raw = list(
            bars[symbol]
        )

        if len(raw) < 60:
            continue

        closes = [
            float(bar.close)
            for bar in raw
        ]

        volumes = [
            float(bar.volume)
            for bar in raw
        ]

        latest = data.get_stock_latest_trade(
            StockLatestTradeRequest(
                symbol_or_symbols=symbol,
                feed=DataFeed.IEX,
            )
        )[symbol]

        current_price = float(
            latest.price
        )

        ema20_value = ema(
            closes[-60:],
            20,
        )

        ema50_value = ema(
            closes[-100:],
            50,
        )

        rsi_value = rsi(
            closes
        )

        prior_high = max(
            closes[-21:-1]
        )

        recent_volume = (
            sum(volumes[-20:])
            / 20
        )

        prior_volume = (
            sum(volumes[-40:-20])
            / 20
        )

        volume_ratio = (
            recent_volume / prior_volume
            if prior_volume > 0
            else None
        )

        if (
            current_price
            > ema20_value
            > ema50_value
        ):
            trend = "UP"

        elif (
            current_price
            < ema20_value
            < ema50_value
        ):
            trend = "DOWN"

        else:
            trend = "MIXED"

        score = score_snapshot(
            current_price=current_price,
            ema20_value=ema20_value,
            ema50_value=ema50_value,
            rsi_value=rsi_value,
            prior_high=prior_high,
            volume_ratio=volume_ratio,
        )

        snapshots.append(
            TechnicalSnapshot(
                symbol=symbol,
                current_price=round(
                    current_price,
                    4,
                ),
                ema20=round(
                    ema20_value,
                    4,
                ),
                ema50=round(
                    ema50_value,
                    4,
                ),
                rsi=(
                    round(
                        rsi_value,
                        2,
                    )
                    if rsi_value
                    is not None
                    else None
                ),
                prior_high=round(
                    prior_high,
                    4,
                ),
                volume_ratio=(
                    round(
                        volume_ratio,
                        3,
                    )
                    if volume_ratio
                    is not None
                    else None
                ),
                trend=trend,
                score=score,
            )
        )

    return sorted(
        snapshots,
        key=lambda item: item.score,
        reverse=True,
    )
