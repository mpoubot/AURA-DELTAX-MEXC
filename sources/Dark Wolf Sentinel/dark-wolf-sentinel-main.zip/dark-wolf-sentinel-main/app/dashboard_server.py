from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from fastapi import FastAPI
from fastapi.responses import HTMLResponse
from fastapi.responses import JSONResponse

from app.broker.alpaca_paper import (
    AlpacaPaperBroker,
)
from app.config import Settings
from app.deployment import (
    DeploymentConfigurationError,
    validate_judge_deployment,
)


RESULT_PATH = Path(
    "data/sentinel_news_latest.json"
)

HTML_PATH = Path(
    "app/dashboard.html"
)


app = FastAPI(
    title="Dark Wolf Sentinel",
    version="0.2.0",
)


def load_latest() -> dict[str, Any]:
    if not RESULT_PATH.exists():
        return {}

    return json.loads(
        RESULT_PATH.read_text()
    )


def sanitize_broker_snapshot(
    snapshot: dict[str, Any],
) -> dict[str, Any]:
    account = snapshot.get(
        "account",
        {},
    )

    return {
        "status":
            account.get("status"),
        "equity":
            account.get("equity"),
        "cash":
            account.get("cash"),
        "positions":
            len(
                snapshot.get(
                    "positions",
                    [],
                )
            ),
        "open_orders":
            len(
                snapshot.get(
                    "open_orders",
                    [],
                )
            ),
    }


# DASHBOARD_BROKER_DEGRADE_V1
_LAST_GOOD_BROKER: dict[str, Any] | None = None


def safe_broker_snapshot(
    settings: Settings,
) -> dict[str, Any]:
    """
    Dashboard reliability boundary.

    Alpaca PAPER availability must never determine whether
    /api/state itself is available.

    A broker outage therefore degrades broker telemetry
    instead of producing HTTP 500.
    """

    global _LAST_GOOD_BROKER

    try:
        raw = AlpacaPaperBroker(
            settings
        ).snapshot()

        broker = {
            "health": "OK",
            "stale": False,
            **sanitize_broker_snapshot(
                raw
            ),
        }

        _LAST_GOOD_BROKER = dict(
            broker
        )

        return broker

    except Exception as exc:
        if _LAST_GOOD_BROKER:
            broker = dict(
                _LAST_GOOD_BROKER
            )

            broker.update(
                {
                    "health":
                        "DEGRADED",

                    "stale":
                        True,

                    "error":
                        "BROKER_READ_FAILED",

                    "error_type":
                        type(exc).__name__,
                }
            )

            return broker

        return {
            "health":
                "DEGRADED",

            "stale":
                True,

            "status":
                "UNAVAILABLE",

            "equity":
                None,

            "cash":
                None,

            "positions":
                None,

            "open_orders":
                None,

            "error":
                "BROKER_READ_FAILED",

            "error_type":
                type(exc).__name__,
        }



@app.get(
    "/health",
)
def health() -> dict[str, str]:
    return {
        "status": "ok",
        "service":
            "dark-wolf-sentinel-dashboard",
    }


@app.get(
    "/ready",
)
def ready() -> Any:
    """Secret-free readiness for the future judge deployment."""

    try:
        return validate_judge_deployment(
            Settings()
        )

    except DeploymentConfigurationError:
        return JSONResponse(
            status_code=503,
            content={
                "status": "not_ready",
                "service":
                    "dark-wolf-sentinel-dashboard",
                "reason":
                    "SAFE_CONFIGURATION_REQUIRED",
            },
        )


@app.get(
    "/api/state",
)
def api_state() -> dict[str, Any]:
    settings = Settings()

    latest = load_latest()

    broker = safe_broker_snapshot(
        settings
    )

    return {
        "project":
            "Dark Wolf Sentinel",
        "model":
            settings.openai_model,
        "mode":
            latest.get(
                "mode",
                "NO_RESULT_YET",
            ),
        "generated_at":
            latest.get(
                "generated_at",
            ),
        "market_data_at":
            latest.get(
                "market_data_at",
            ),
        "selected_symbol":
            latest.get(
                "selected_symbol",
            ),
        "selected_snapshot":
            latest.get(
                "selected_snapshot",
                {},
            ),
        "ranking":
            latest.get(
                "ranking",
                [],
            ),
        "news":
            latest.get(
                "news_context",
                [],
            ),
        "news_raw_count":
            latest.get(
                "news_raw_count",
                0,
            ),
        "news_relevant_count":
            latest.get(
                "news_relevant_count",
                0,
            ),
        "proposal":
            latest.get(
                "proposal",
            ),
        "risk_decision":
            latest.get(
                "risk_decision",
            ),
        "broker":
            broker,
        "safety": {
            "alpaca_paper":
                settings.alpaca_paper,
            "paper_execution":
                settings.paper_execution_enabled,
            "live_trading":
                latest.get(
                    "live_trading",
                    False,
                ),
            "ai_trading_authority":
                latest.get(
                    "ai_trading_authority",
                    False,
                ),
            "mcp_trading_tools":
                latest.get(
                    "mcp_trading_tools",
                    False,
                ),
            "broker_order_submitted":
                latest.get(
                    "broker_order_submitted",
                    False,
                ),
        },
    }


@app.get(
    "/",
    response_class=HTMLResponse,
)
def dashboard() -> HTMLResponse:
    return HTMLResponse(
        HTML_PATH.read_text()
    )
