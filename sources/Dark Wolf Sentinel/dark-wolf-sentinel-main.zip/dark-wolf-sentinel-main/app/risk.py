from __future__ import annotations

from dataclasses import dataclass

from app.config import Settings
from app.models import (
    AssetClass,
    PortfolioState,
    RiskDecision,
    TradeCandidate,
)


@dataclass(frozen=True)
class RiskPolicy:
    min_confidence: float
    risk_per_trade_pct: float
    max_total_risk_pct: float
    max_crypto_risk_pct: float
    max_exposure_pct: float
    max_position_pct: float

    @classmethod
    def from_settings(
        cls,
        settings: Settings,
    ) -> "RiskPolicy":
        return cls(
            min_confidence=settings.min_confidence,
            risk_per_trade_pct=settings.risk_per_trade_pct,
            max_total_risk_pct=settings.max_total_risk_pct,
            max_crypto_risk_pct=settings.max_crypto_risk_pct,
            max_exposure_pct=settings.max_exposure_pct,
            max_position_pct=settings.max_position_pct,
        )


def reject(
    candidate: TradeCandidate,
    reason: str,
) -> RiskDecision:
    return RiskDecision(
        approved=False,
        reason=reason,
        symbol=candidate.symbol.upper(),
        live_order_allowed=False,
        trading_authority=False,
    )


def evaluate_trade(
    candidate: TradeCandidate,
    portfolio: PortfolioState,
    policy: RiskPolicy,
) -> RiskDecision:
    """Deterministic final authority.

    AI output enters here as an untrusted proposal.

    This function cannot authorize LIVE trading.
    """

    symbol = candidate.symbol.upper().strip()

    if portfolio.kill_switch:
        return reject(
            candidate,
            "GLOBAL_KILL_SWITCH",
        )

    if (
        candidate.confidence
        < policy.min_confidence
    ):
        return reject(
            candidate,
            "CONFIDENCE_BELOW_GATE",
        )

    existing = {
        item.upper().strip()
        for item in portfolio.open_symbols
    }

    if symbol in existing:
        return reject(
            candidate,
            "DUPLICATE_OPEN_SYMBOL",
        )

    if candidate.stop_price >= candidate.entry_price:
        return reject(
            candidate,
            "INVALID_LONG_STOP",
        )

    if candidate.target_price <= candidate.entry_price:
        return reject(
            candidate,
            "INVALID_LONG_TARGET",
        )

    equity = portfolio.equity

    risk_per_unit = (
        candidate.entry_price
        - candidate.stop_price
    )

    max_trade_risk = (
        equity
        * policy.risk_per_trade_pct
        / 100
    )

    total_risk_cap = (
        equity
        * policy.max_total_risk_pct
        / 100
    )

    remaining_total_risk = max(
        0.0,
        total_risk_cap
        - portfolio.current_open_risk,
    )

    risk_budget = min(
        max_trade_risk,
        remaining_total_risk,
    )

    if candidate.asset_class == AssetClass.CRYPTO:
        crypto_cap = (
            equity
            * policy.max_crypto_risk_pct
            / 100
        )

        remaining_crypto_risk = max(
            0.0,
            crypto_cap
            - portfolio.current_crypto_risk,
        )

        risk_budget = min(
            risk_budget,
            remaining_crypto_risk,
        )

    if risk_budget <= 0:
        return reject(
            candidate,
            "NO_REMAINING_RISK_BUDGET",
        )

    quantity_by_risk = (
        risk_budget
        / risk_per_unit
    )

    position_cap = (
        equity
        * policy.max_position_pct
        / 100
    )

    exposure_cap = (
        equity
        * policy.max_exposure_pct
        / 100
    )

    remaining_exposure = max(
        0.0,
        exposure_cap
        - portfolio.current_exposure,
    )

    max_position_value = min(
        position_cap,
        remaining_exposure,
    )

    if max_position_value <= 0:
        return reject(
            candidate,
            "NO_REMAINING_EXPOSURE",
        )

    quantity_by_exposure = (
        max_position_value
        / candidate.entry_price
    )

    quantity = min(
        quantity_by_risk,
        quantity_by_exposure,
    )

    if quantity <= 0:
        return reject(
            candidate,
            "ZERO_POSITION_SIZE",
        )

    position_value = (
        quantity
        * candidate.entry_price
    )

    actual_risk = (
        quantity
        * risk_per_unit
    )

    total_risk_after = (
        portfolio.current_open_risk
        + actual_risk
    )

    crypto_risk_after = (
        portfolio.current_crypto_risk
    )

    if candidate.asset_class == AssetClass.CRYPTO:
        crypto_risk_after += actual_risk

    exposure_after = (
        portfolio.current_exposure
        + position_value
    )

    return RiskDecision(
        approved=True,
        reason="APPROVED_BY_DETERMINISTIC_RISK",
        symbol=symbol,
        quantity=round(quantity, 8),
        position_value=round(
            position_value,
            2,
        ),
        risk_dollars=round(
            actual_risk,
            2,
        ),
        risk_pct_equity=round(
            actual_risk
            / equity
            * 100,
            4,
        ),
        exposure_after=round(
            exposure_after,
            2,
        ),
        total_risk_after=round(
            total_risk_after,
            2,
        ),
        crypto_risk_after=round(
            crypto_risk_after,
            2,
        ),

        # Explicit hackathon safety invariant.
        live_order_allowed=False,
        trading_authority=False,
    )
