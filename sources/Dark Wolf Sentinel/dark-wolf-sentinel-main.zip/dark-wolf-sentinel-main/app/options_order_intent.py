from __future__ import annotations

from decimal import (
    Decimal,
    ROUND_DOWN,
    ROUND_HALF_UP,
)
from typing import Any
from uuid import (
    NAMESPACE_URL,
    uuid5,
)

from alpaca.trading.enums import (
    OrderClass,
    OrderSide,
    OrderType,
    PositionIntent,
    TimeInForce,
)
from alpaca.trading.requests import (
    LimitOrderRequest,
    OptionLegRequest,
)
from pydantic import BaseModel, Field

from app.options_selector import (
    OptionSelectionResult,
)
from app.options_verticals import (
    VerticalSpreadType,
)


MODE = "OPTIONS_MLEG_INTENT_SHADOW"

TRADING_AUTHORITY = False
ORDER_SUBMISSION_AUTHORITY = False
BROKER_CONNECTION = False
EXECUTION_EFFECT = False

SUPPORTED_STRUCTURES = {
    VerticalSpreadType.BULL_CALL_DEBIT,
    VerticalSpreadType.BEAR_PUT_DEBIT,
}

CENT = Decimal("0.01")


class OptionsIntentError(ValueError):
    pass


class OptionsMlegIntent(BaseModel):
    mode: str = MODE

    decision_id: str = Field(
        min_length=1,
        max_length=256,
    )

    client_order_id: str = Field(
        min_length=1,
        max_length=64,
    )

    underlying: str = Field(
        min_length=1,
        max_length=32,
    )

    spread_type: VerticalSpreadType

    quantity: int = Field(
        gt=0,
    )

    limit_price: Decimal = Field(
        gt=0,
    )

    long_symbol: str = Field(
        min_length=1,
        max_length=64,
    )

    short_symbol: str = Field(
        min_length=1,
        max_length=64,
    )

    order_class: str = "mleg"
    order_type: str = "limit"
    time_in_force: str = "day"

    request_payload: dict[str, Any]

    trading_authority: bool = False
    order_submission_authority: bool = False
    broker_connection: bool = False
    execution_effect: bool = False


def money(
    value: Decimal,
) -> Decimal:
    return value.quantize(
        CENT,
        rounding=ROUND_HALF_UP,
    )


def debit_limit_price(
    value: Decimal,
) -> Decimal:
    """
    Convert a theoretical debit to an executable
    cent-denominated limit without increasing risk.

    Debit spreads must never be rounded upward,
    because doing so could raise executable maximum
    loss above the deterministic risk approval.
    """

    if value <= 0:
        raise OptionsIntentError(
            "NON_POSITIVE_THEORETICAL_DEBIT"
        )

    result = value.quantize(
        CENT,
        rounding=ROUND_DOWN,
    )

    if result <= 0:
        raise OptionsIntentError(
            "NON_POSITIVE_LIMIT_DEBIT"
        )

    return result


def client_order_id_for(
    decision_id: str,
) -> str:
    clean = decision_id.strip()

    if not clean:
        raise OptionsIntentError(
            "EMPTY_DECISION_ID"
        )

    value = uuid5(
        NAMESPACE_URL,
        "dark-wolf-options:"
        + clean,
    )

    return "dwo-" + str(value)


def _assert_zero_authority(
    selection: OptionSelectionResult,
) -> None:
    if selection.trading_authority:
        raise OptionsIntentError(
            "SELECTION_TRADING_AUTHORITY_FORBIDDEN"
        )

    if selection.order_authority:
        raise OptionsIntentError(
            "SELECTION_ORDER_AUTHORITY_FORBIDDEN"
        )

    if selection.execution_effect:
        raise OptionsIntentError(
            "SELECTION_EXECUTION_EFFECT_FORBIDDEN"
        )

    risk = selection.risk_decision

    if risk is None:
        raise OptionsIntentError(
            "MISSING_RISK_DECISION"
        )

    if risk.trading_authority:
        raise OptionsIntentError(
            "RISK_TRADING_AUTHORITY_FORBIDDEN"
        )

    if risk.live_order_allowed:
        raise OptionsIntentError(
            "LIVE_ORDER_AUTHORITY_FORBIDDEN"
        )

    if risk.order_authority:
        raise OptionsIntentError(
            "RISK_ORDER_AUTHORITY_FORBIDDEN"
        )

    if risk.execution_effect:
        raise OptionsIntentError(
            "RISK_EXECUTION_EFFECT_FORBIDDEN"
        )


def build_mleg_request(
    *,
    selection: OptionSelectionResult,
    decision_id: str,
) -> tuple[
    OptionsMlegIntent,
    LimitOrderRequest,
]:
    """
    Build an Alpaca-compatible two-leg debit-spread request.

    This is serialization only.

    This module intentionally has:
      - no broker client,
      - no broker connection,
      - no order-submission call,
      - no PAPER execution authority,
      - no LIVE execution authority.
    """

    _assert_zero_authority(
        selection
    )

    if not selection.selected:
        raise OptionsIntentError(
            "SELECTION_NOT_SELECTED"
        )

    proposal = selection.proposal
    metrics = selection.metrics
    risk = selection.risk_decision

    if proposal is None:
        raise OptionsIntentError(
            "MISSING_SPREAD_PROPOSAL"
        )

    if metrics is None:
        raise OptionsIntentError(
            "MISSING_SPREAD_METRICS"
        )

    if risk is None:
        raise OptionsIntentError(
            "MISSING_RISK_DECISION"
        )

    if not risk.approved:
        raise OptionsIntentError(
            "RISK_DECISION_NOT_APPROVED"
        )

    if metrics.spread_type not in SUPPORTED_STRUCTURES:
        raise OptionsIntentError(
            "UNSUPPORTED_MLEG_STRUCTURE"
        )

    if risk.spread_type != metrics.spread_type:
        raise OptionsIntentError(
            "RISK_METRICS_STRUCTURE_MISMATCH"
        )

    quantity = int(
        risk.approved_quantity
    )

    # alpaca-py 0.44.0 locally accepts qty=0 for MLEG,
    # so Dark Wolf must enforce this invariant itself.
    if quantity <= 0:
        raise OptionsIntentError(
            "NON_POSITIVE_APPROVED_QUANTITY"
        )

    if quantity > risk.max_contracts_by_risk:
        raise OptionsIntentError(
            "QUANTITY_EXCEEDS_RISK_MAXIMUM"
        )

    long_leg = proposal.long_leg
    short_leg = proposal.short_leg

    if long_leg.side.value != "long":
        raise OptionsIntentError(
            "INVALID_LONG_LEG_SIDE"
        )

    if short_leg.side.value != "short":
        raise OptionsIntentError(
            "INVALID_SHORT_LEG_SIDE"
        )

    if (
        long_leg.contract.underlying.upper()
        != short_leg.contract.underlying.upper()
    ):
        raise OptionsIntentError(
            "UNDERLYING_MISMATCH"
        )

    if (
        long_leg.contract.expiration
        != short_leg.contract.expiration
    ):
        raise OptionsIntentError(
            "EXPIRATION_MISMATCH"
        )

    if (
        long_leg.contract.symbol.upper()
        == short_leg.contract.symbol.upper()
    ):
        raise OptionsIntentError(
            "DUPLICATE_LEG_SYMBOL"
        )

    # The selector/risk layer can preserve half-cent
    # economics while exposing a cent-rounded debit.
    #
    # Example:
    #   displayed debit      = 5.73
    #   approved max loss    = 572.50
    #   approved quantity    = 1
    #
    # Sending 5.73 would create $573 of executable
    # loss and exceed the deterministic approval.
    #
    # Therefore the executable debit is capped by
    # BOTH the selected debit and the deterministic
    # approved-loss budget, then rounded DOWN.
    risk_capped_debit_per_share = (
        risk.approved_max_loss
        / (
            Decimal("100")
            * Decimal(quantity)
        )
    )

    if risk_capped_debit_per_share <= 0:
        raise OptionsIntentError(
            "NON_POSITIVE_RISK_CAPPED_DEBIT"
        )

    executable_debit_basis = min(
        metrics.net_debit_per_share,
        risk_capped_debit_per_share,
    )

    limit_price = debit_limit_price(
        executable_debit_basis
    )

    if limit_price <= 0:
        raise OptionsIntentError(
            "NON_POSITIVE_LIMIT_DEBIT"
        )

    if limit_price >= metrics.width:
        raise OptionsIntentError(
            "DEBIT_NOT_BELOW_SPREAD_WIDTH"
        )

    executable_loss = money(
        limit_price
        * Decimal("100")
        * Decimal(quantity)
    )

    if (
        executable_loss
        > risk.approved_max_loss
    ):
        raise OptionsIntentError(
            "REQUEST_DEBIT_EXCEEDS_APPROVED_MAX_LOSS"
        )

    client_order_id = (
        client_order_id_for(
            decision_id
        )
    )

    legs = [
        OptionLegRequest(
            symbol=
                long_leg
                .contract
                .symbol,
            ratio_qty=1,
            side=OrderSide.BUY,
            position_intent=
                PositionIntent.BUY_TO_OPEN,
        ),
        OptionLegRequest(
            symbol=
                short_leg
                .contract
                .symbol,
            ratio_qty=1,
            side=OrderSide.SELL,
            position_intent=
                PositionIntent.SELL_TO_OPEN,
        ),
    ]

    request = LimitOrderRequest(
        qty=float(
            quantity
        ),
        type=OrderType.LIMIT,
        time_in_force=
            TimeInForce.DAY,
        order_class=
            OrderClass.MLEG,
        legs=legs,
        limit_price=float(
            limit_price
        ),
        client_order_id=
            client_order_id,
    )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    if payload.get(
        "symbol"
    ) is not None:
        raise OptionsIntentError(
            "MLEG_TOP_LEVEL_SYMBOL_FORBIDDEN"
        )

    if payload.get(
        "side"
    ) is not None:
        raise OptionsIntentError(
            "MLEG_TOP_LEVEL_SIDE_FORBIDDEN"
        )

    if payload.get(
        "order_class"
    ) != "mleg":
        raise OptionsIntentError(
            "INVALID_ORDER_CLASS"
        )

    if payload.get(
        "type"
    ) != "limit":
        raise OptionsIntentError(
            "MARKET_ORDER_FORBIDDEN"
        )

    if payload.get(
        "time_in_force"
    ) != "day":
        raise OptionsIntentError(
            "INVALID_TIME_IN_FORCE"
        )

    payload_legs = payload.get(
        "legs",
        []
    )

    if len(
        payload_legs
    ) != 2:
        raise OptionsIntentError(
            "MLEG_REQUIRES_EXACTLY_TWO_LEGS"
        )

    return (
        OptionsMlegIntent(
            decision_id=
                decision_id.strip(),
            client_order_id=
                client_order_id,
            underlying=
                metrics
                .underlying,
            spread_type=
                metrics
                .spread_type,
            quantity=
                quantity,
            limit_price=
                limit_price,
            long_symbol=
                long_leg
                .contract
                .symbol,
            short_symbol=
                short_leg
                .contract
                .symbol,
            request_payload=
                payload,
            trading_authority=False,
            order_submission_authority=False,
            broker_connection=False,
            execution_effect=False,
        ),
        request,
    )


def status() -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "supported_structures": [
            item.value
            for item
            in sorted(
                SUPPORTED_STRUCTURES,
                key=lambda value:
                    value.value,
            )
        ],

        "order_class":
            "mleg",

        "order_type":
            "limit",

        "time_in_force":
            "day",

        "legs":
            2,

        "long_position_intent":
            "buy_to_open",

        "short_position_intent":
            "sell_to_open",

        "market_orders_allowed":
            False,

        "positive_quantity_enforced":
            True,

        "risk_approved_quantity_required":
            True,

        "broker_connection":
            BROKER_CONNECTION,

        "trading_authority":
            TRADING_AUTHORITY,

        "order_submission_authority":
            ORDER_SUBMISSION_AUTHORITY,

        "execution_effect":
            EXECUTION_EFFECT,
    }
