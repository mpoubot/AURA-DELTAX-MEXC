from __future__ import annotations

from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal
from typing import Any

from alpaca.data.historical.option import (
    OptionHistoricalDataClient,
)
from alpaca.data.requests import (
    OptionChainRequest,
)
from alpaca.trading.enums import ContractType

from app.agent.models import (
    AgentAction,
    AgentProposal,
)
from app.config import Settings
from app.options_selector import (
    OptionDirection,
    OptionSelectorPolicy,
    adapt_alpaca_chain,
    select_debit_vertical,
)
from app.options_verticals import (
    OptionsPortfolioState,
    OptionsRiskPolicy,
)


MODE = "SENTINEL_OPTIONS_SHADOW"

TRADING_AUTHORITY = False
ORDER_AUTHORITY = False
EXECUTION_EFFECT = False


def direction_for_proposal(
    proposal: AgentProposal,
) -> OptionDirection | None:
    """
    Explicit AI-to-options direction boundary.

    Current AI schema supports PASS, BUY, and BEARISH.

    BUY maps to bullish options analysis.
    BEARISH maps to bearish options analysis.
    PASS produces no options proposal.

    Bearish inference from prose, scanner trend, RSI,
    news, or any other indirect field is forbidden.
    """

    if proposal.action == AgentAction.PASS:
        return None

    if proposal.action == AgentAction.BUY:
        return OptionDirection.BULLISH

    if proposal.action == AgentAction.BEARISH:
        return OptionDirection.BEARISH

    raise RuntimeError(
        "UNSUPPORTED_AGENT_ACTION"
    )


def _base_result(
    *,
    proposal: AgentProposal,
    status: str,
    reason: str,
    direction: OptionDirection | None,
) -> dict[str, Any]:
    return {
        "mode": MODE,
        "status": status,
        "reason": reason,
        "proposal_action": proposal.action.value,
        "underlying": proposal.symbol.upper().strip(),
        "direction": (
            direction.value
            if direction is not None
            else None
        ),
        "raw_chain_count": 0,
        "adapted_contracts": 0,
        "adapter_rejections": {},
        "selection": None,
        "trading_authority": False,
        "order_authority": False,
        "execution_effect": False,
    }


def evaluate_options_shadow(
    *,
    settings: Settings,
    proposal: AgentProposal,
    equity: float | Decimal,
    current_open_risk: float | Decimal = Decimal("0"),
    requested_quantity: int = 1,
    data_client: Any | None = None,
    as_of: date | None = None,
    as_of_time: datetime | None = None,
) -> dict[str, Any]:
    """
    Read-only Sentinel options analysis.

    This function:
      - cannot submit orders,
      - cannot authorize PAPER execution,
      - cannot authorize LIVE execution,
      - treats the AI proposal as untrusted input,
      - delegates final sizing to deterministic max-loss risk.

    Market-data failures degrade only the options shadow result.
    They do not invalidate the underlying Sentinel analysis.
    """

    settings.assert_paper_only()

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "PAPER execution must remain disabled."
        )

    direction = direction_for_proposal(
        proposal
    )

    if direction is None:
        return _base_result(
            proposal=proposal,
            status="SKIPPED_PASS",
            reason="GPT_PASS",
            direction=None,
        )

    if as_of is None:
        as_of = date.today()

    if as_of_time is None:
        as_of_time = datetime.now(
            timezone.utc
        )

    selector_policy = OptionSelectorPolicy()

    if data_client is None:
        if not settings.alpaca_configured:
            raise RuntimeError(
                "Alpaca PAPER credentials missing."
            )

        data_client = OptionHistoricalDataClient(
            api_key=settings.alpaca_api_key,
            secret_key=settings.alpaca_secret_key,
        )

    contract_type = (
        ContractType.CALL
        if direction == OptionDirection.BULLISH
        else ContractType.PUT
    )

    try:
        chain = data_client.get_option_chain(
            OptionChainRequest(
                underlying_symbol=proposal.symbol.upper(),
                type=contract_type,
                expiration_date_gte=(
                    as_of
                    + timedelta(
                        days=selector_policy.min_dte
                    )
                ),
                expiration_date_lte=(
                    as_of
                    + timedelta(
                        days=selector_policy.max_dte
                    )
                ),
            )
        )

        candidates, adapter_rejections = adapt_alpaca_chain(
            chain
        )

        selection = select_debit_vertical(
            direction=direction,
            chain=candidates,
            confidence=proposal.confidence,
            thesis=proposal.thesis,
            portfolio=OptionsPortfolioState(
                equity=Decimal(str(equity)),
                current_open_risk=Decimal(
                    str(current_open_risk)
                ),
                open_underlyings=[],
                kill_switch=False,
            ),
            risk_policy=OptionsRiskPolicy.from_settings(
                settings
            ),
            selector_policy=selector_policy,
            requested_quantity=requested_quantity,
            as_of=as_of,
            as_of_time=as_of_time,
            adapter_rejections=adapter_rejections,
        )

        return {
            "mode": MODE,
            "status": "OK",
            "reason": selection.reason,
            "proposal_action": proposal.action.value,
            "underlying": proposal.symbol.upper().strip(),
            "direction": direction.value,
            "raw_chain_count": len(chain),
            "adapted_contracts": len(candidates),
            "adapter_rejections": adapter_rejections,
            "selection": selection.model_dump(
                mode="json"
            ),
            "trading_authority": False,
            "order_authority": False,
            "execution_effect": False,
        }

    except Exception as exc:
        result = _base_result(
            proposal=proposal,
            status="DEGRADED",
            reason="OPTIONS_MARKET_DATA_OR_SELECTION_FAILED",
            direction=direction,
        )

        result["error_type"] = type(exc).__name__

        return result


def status() -> dict[str, Any]:
    return {
        "mode": MODE,
        "agent_action_mapping": {
            "PASS": None,
            "BUY": "bullish",
            "BEARISH": "bearish",
        },
        "bearish_ai_action_supported": True,
        "bearish_inference_from_text": False,
        "market_data_only": True,
        "risk_authority": "OPTIONS_MAX_LOSS_KERNEL",
        "trading_authority": TRADING_AUTHORITY,
        "order_authority": ORDER_AUTHORITY,
        "execution_effect": EXECUTION_EFFECT,
    }
