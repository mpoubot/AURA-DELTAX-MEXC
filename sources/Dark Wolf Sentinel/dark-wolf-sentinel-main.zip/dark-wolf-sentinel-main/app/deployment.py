from __future__ import annotations

import shutil
from typing import Any

from app.config import Settings


REQUIRED_MODEL = "gpt-5.6"


class DeploymentConfigurationError(RuntimeError):
    """A public demo must not start from unsafe or incomplete config."""


def validate_judge_deployment(
    settings: Settings,
    *,
    require_uvx: bool = True,
) -> dict[str, Any]:
    """Validate the judge-facing, analysis-only deployment boundary.

    This performs no broker, model, or network calls and never returns secret
    values. External availability is checked by the separate demo worker.
    """

    failures: list[str] = []

    if settings.alpaca_paper is not True:
        failures.append("Alpaca PAPER mode is required")

    if settings.paper_execution_enabled is not False:
        failures.append("equity PAPER execution must remain disabled")

    if settings.options_paper_execution_enabled is not False:
        failures.append("options PAPER execution must remain disabled")

    if not settings.alpaca_configured:
        failures.append("Alpaca PAPER credentials are missing")

    if not settings.openai_configured:
        failures.append("OpenAI configuration is missing")

    if settings.openai_model.strip() != REQUIRED_MODEL:
        failures.append("OPENAI_MODEL must remain gpt-5.6")

    if require_uvx and shutil.which("uvx") is None:
        failures.append("uvx is unavailable")

    if failures:
        raise DeploymentConfigurationError("; ".join(failures))

    return {
        "status": "ready",
        "service": "dark-wolf-sentinel-dashboard",
        "model": REQUIRED_MODEL,
        "alpaca_paper": True,
        "paper_execution": False,
        "options_paper_execution": False,
        "live_trading": False,
        "broker_submission": False,
        "ai_execution_authority": False,
        "mcp_trading_tools": False,
        "credentials_present": True,
        "uvx_present": True,
    }
