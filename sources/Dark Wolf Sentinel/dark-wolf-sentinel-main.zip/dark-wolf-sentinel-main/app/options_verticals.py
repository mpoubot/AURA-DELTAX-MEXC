from __future__ import annotations

from datetime import date
from decimal import (
    Decimal,
    ROUND_HALF_UP,
)
from enum import Enum
from typing import Any

from pydantic import BaseModel, Field

from app.config import Settings


MODE = "OPTIONS_VERTICAL_RISK_SHADOW"

TRADING_AUTHORITY = False
ORDER_AUTHORITY = False
EXECUTION_EFFECT = False
BROKER_CONNECTION = False

CENT = Decimal("0.01")


class OptionsRiskError(ValueError):
    pass


class OptionRight(str, Enum):
    CALL = "call"
    PUT = "put"


class PositionSide(str, Enum):
    LONG = "long"
    SHORT = "short"


class VerticalSpreadType(str, Enum):
    BULL_CALL_DEBIT = "bull_call_debit"
    BEAR_PUT_DEBIT = "bear_put_debit"
    BULL_PUT_CREDIT = "bull_put_credit"
    BEAR_CALL_CREDIT = "bear_call_credit"


DEBIT_SPREADS = {
    VerticalSpreadType.BULL_CALL_DEBIT,
    VerticalSpreadType.BEAR_PUT_DEBIT,
}

CREDIT_SPREADS = {
    VerticalSpreadType.BULL_PUT_CREDIT,
    VerticalSpreadType.BEAR_CALL_CREDIT,
}


class OptionContractSpec(BaseModel):
    symbol: str = Field(
        min_length=1,
        max_length=64,
    )

    underlying: str = Field(
        min_length=1,
        max_length=32,
    )

    right: OptionRight

    strike: Decimal = Field(
        gt=0,
    )

    expiration: date

    multiplier: Decimal = Field(
        gt=0,
    )

    tradable: bool = True

    source: str = Field(
        default="UNRESOLVED",
        min_length=1,
        max_length=128,
    )


class OptionLeg(BaseModel):
    contract: OptionContractSpec

    side: PositionSide

    premium: Decimal = Field(
        gt=0,
    )


class VerticalSpreadProposal(BaseModel):
    long_leg: OptionLeg
    short_leg: OptionLeg

    quantity: int = Field(
        gt=0,
    )

    confidence: float = Field(
        ge=0,
        le=100,
    )

    thesis: str = Field(
        min_length=1,
        max_length=4000,
    )


class OptionsPortfolioState(BaseModel):
    equity: Decimal = Field(
        gt=0,
    )

    current_open_risk: Decimal = Field(
        ge=0,
        default=Decimal("0"),
    )

    open_underlyings: list[str] = Field(
        default_factory=list,
    )

    kill_switch: bool = False


class OptionsRiskPolicy(BaseModel):
    min_confidence: float = Field(
        ge=0,
        le=100,
    )

    risk_per_trade_pct: Decimal = Field(
        gt=0,
        le=100,
    )

    max_total_risk_pct: Decimal = Field(
        gt=0,
        le=100,
    )

    @classmethod
    def from_settings(
        cls,
        settings: Settings,
    ) -> "OptionsRiskPolicy":
        return cls(
            min_confidence=
                settings.min_confidence,

            risk_per_trade_pct=
                Decimal(
                    str(
                        settings.risk_per_trade_pct
                    )
                ),

            max_total_risk_pct=
                Decimal(
                    str(
                        settings.max_total_risk_pct
                    )
                ),
        )


class VerticalRiskMetrics(BaseModel):
    mode: str = MODE

    spread_type: VerticalSpreadType

    underlying: str
    expiration: date

    quantity: int

    multiplier: Decimal
    width: Decimal

    net_debit_per_share: Decimal
    net_credit_per_share: Decimal

    max_loss_per_spread: Decimal
    max_profit_per_spread: Decimal

    total_max_loss: Decimal
    total_max_profit: Decimal

    breakeven: Decimal

    reward_to_risk: Decimal

    trading_authority: bool = False
    order_authority: bool = False
    execution_effect: bool = False


class OptionsRiskDecision(BaseModel):
    approved: bool

    reason: str

    underlying: str

    spread_type: VerticalSpreadType | None = None

    requested_quantity: int = 0

    max_contracts_by_risk: int = 0

    approved_quantity: int = 0

    max_loss_per_spread: Decimal = Decimal("0")

    approved_max_loss: Decimal = Decimal("0")

    risk_budget: Decimal = Decimal("0")

    projected_total_open_risk: Decimal = Decimal("0")

    trading_authority: bool = False

    live_order_allowed: bool = False

    order_authority: bool = False

    execution_effect: bool = False


def money(
    value: Decimal,
) -> Decimal:
    return value.quantize(
        CENT,
        rounding=ROUND_HALF_UP,
    )


def _normalized_underlying(
    value: str,
) -> str:
    clean = str(
        value
    ).upper().strip()

    if not clean:
        raise OptionsRiskError(
            "EMPTY_UNDERLYING"
        )

    return clean


def validate_vertical(
    proposal: VerticalSpreadProposal,
) -> VerticalSpreadType:
    long_leg = proposal.long_leg
    short_leg = proposal.short_leg

    if (
        long_leg.side
        != PositionSide.LONG
    ):
        raise OptionsRiskError(
            "LONG_LEG_NOT_LONG"
        )

    if (
        short_leg.side
        != PositionSide.SHORT
    ):
        raise OptionsRiskError(
            "SHORT_LEG_NOT_SHORT"
        )

    long_contract = (
        long_leg.contract
    )

    short_contract = (
        short_leg.contract
    )

    long_underlying = (
        _normalized_underlying(
            long_contract.underlying
        )
    )

    short_underlying = (
        _normalized_underlying(
            short_contract.underlying
        )
    )

    if (
        long_underlying
        != short_underlying
    ):
        raise OptionsRiskError(
            "UNDERLYING_MISMATCH"
        )

    if (
        long_contract.symbol.upper()
        == short_contract.symbol.upper()
    ):
        raise OptionsRiskError(
            "DUPLICATE_OPTION_CONTRACT"
        )

    if (
        long_contract.right
        != short_contract.right
    ):
        raise OptionsRiskError(
            "OPTION_RIGHT_MISMATCH"
        )

    if (
        long_contract.expiration
        != short_contract.expiration
    ):
        raise OptionsRiskError(
            "EXPIRATION_MISMATCH"
        )

    if (
        long_contract.expiration
        < date.today()
    ):
        raise OptionsRiskError(
            "EXPIRED_CONTRACT"
        )

    if (
        long_contract.multiplier
        != short_contract.multiplier
    ):
        raise OptionsRiskError(
            "MULTIPLIER_MISMATCH"
        )

    if (
        not long_contract.tradable
        or not short_contract.tradable
    ):
        raise OptionsRiskError(
            "NON_TRADABLE_CONTRACT"
        )

    long_strike = (
        long_contract.strike
    )

    short_strike = (
        short_contract.strike
    )

    if (
        long_strike
        == short_strike
    ):
        raise OptionsRiskError(
            "ZERO_WIDTH_VERTICAL"
        )

    if (
        long_contract.right
        == OptionRight.CALL
    ):
        if (
            long_strike
            < short_strike
        ):
            spread_type = (
                VerticalSpreadType
                .BULL_CALL_DEBIT
            )

        else:
            spread_type = (
                VerticalSpreadType
                .BEAR_CALL_CREDIT
            )

    else:
        if (
            long_strike
            > short_strike
        ):
            spread_type = (
                VerticalSpreadType
                .BEAR_PUT_DEBIT
            )

        else:
            spread_type = (
                VerticalSpreadType
                .BULL_PUT_CREDIT
            )

    width = abs(
        long_strike
        - short_strike
    )

    net = (
        long_leg.premium
        - short_leg.premium
    )

    if (
        spread_type
        in DEBIT_SPREADS
    ):
        if net <= 0:
            raise OptionsRiskError(
                "DEBIT_SPREAD_REQUIRES_NET_DEBIT"
            )

        if net >= width:
            raise OptionsRiskError(
                "DEBIT_MUST_BE_LESS_THAN_WIDTH"
            )

    else:
        credit = -net

        if credit <= 0:
            raise OptionsRiskError(
                "CREDIT_SPREAD_REQUIRES_NET_CREDIT"
            )

        if credit >= width:
            raise OptionsRiskError(
                "CREDIT_MUST_BE_LESS_THAN_WIDTH"
            )

    return spread_type


def calculate_vertical_risk(
    proposal: VerticalSpreadProposal,
) -> VerticalRiskMetrics:
    spread_type = validate_vertical(
        proposal
    )

    long_leg = proposal.long_leg
    short_leg = proposal.short_leg

    long_contract = (
        long_leg.contract
    )

    short_contract = (
        short_leg.contract
    )

    multiplier = (
        long_contract.multiplier
    )

    width = abs(
        long_contract.strike
        - short_contract.strike
    )

    net = (
        long_leg.premium
        - short_leg.premium
    )

    if (
        spread_type
        in DEBIT_SPREADS
    ):
        debit = net
        credit = Decimal("0")

        max_loss_per_spread = (
            debit
            * multiplier
        )

        max_profit_per_spread = (
            (width - debit)
            * multiplier
        )

    else:
        debit = Decimal("0")
        credit = -net

        max_loss_per_spread = (
            (width - credit)
            * multiplier
        )

        max_profit_per_spread = (
            credit
            * multiplier
        )

    if (
        max_loss_per_spread
        <= 0
        or max_profit_per_spread
        <= 0
    ):
        raise OptionsRiskError(
            "NON_POSITIVE_DEFINED_RISK"
        )

    if (
        spread_type
        == VerticalSpreadType
        .BULL_CALL_DEBIT
    ):
        breakeven = (
            long_contract.strike
            + debit
        )

    elif (
        spread_type
        == VerticalSpreadType
        .BEAR_PUT_DEBIT
    ):
        breakeven = (
            long_contract.strike
            - debit
        )

    elif (
        spread_type
        == VerticalSpreadType
        .BULL_PUT_CREDIT
    ):
        breakeven = (
            short_contract.strike
            - credit
        )

    else:
        breakeven = (
            short_contract.strike
            + credit
        )

    total_loss = (
        max_loss_per_spread
        * proposal.quantity
    )

    total_profit = (
        max_profit_per_spread
        * proposal.quantity
    )

    reward_to_risk = (
        max_profit_per_spread
        / max_loss_per_spread
    )

    return VerticalRiskMetrics(
        spread_type=spread_type,

        underlying=
            _normalized_underlying(
                long_contract.underlying
            ),

        expiration=
            long_contract.expiration,

        quantity=
            proposal.quantity,

        multiplier=
            multiplier,

        width=
            money(width),

        net_debit_per_share=
            money(debit),

        net_credit_per_share=
            money(credit),

        max_loss_per_spread=
            money(
                max_loss_per_spread
            ),

        max_profit_per_spread=
            money(
                max_profit_per_spread
            ),

        total_max_loss=
            money(total_loss),

        total_max_profit=
            money(total_profit),

        breakeven=
            money(breakeven),

        reward_to_risk=
            reward_to_risk.quantize(
                Decimal("0.0001"),
                rounding=ROUND_HALF_UP,
            ),

        trading_authority=False,

        order_authority=False,

        execution_effect=False,
    )


def reject(
    proposal: VerticalSpreadProposal,
    reason: str,
    *,
    spread_type: VerticalSpreadType | None = None,
    max_loss_per_spread: Decimal = Decimal("0"),
    risk_budget: Decimal = Decimal("0"),
) -> OptionsRiskDecision:
    underlying = (
        _normalized_underlying(
            proposal.long_leg
            .contract
            .underlying
        )
    )

    return OptionsRiskDecision(
        approved=False,

        reason=reason,

        underlying=underlying,

        spread_type=
            spread_type,

        requested_quantity=
            proposal.quantity,

        max_loss_per_spread=
            money(
                max_loss_per_spread
            ),

        risk_budget=
            money(
                risk_budget
            ),

        trading_authority=False,

        live_order_allowed=False,

        order_authority=False,

        execution_effect=False,
    )


def evaluate_vertical_risk(
    proposal: VerticalSpreadProposal,
    portfolio: OptionsPortfolioState,
    policy: OptionsRiskPolicy,
) -> OptionsRiskDecision:
    """
    Deterministic options risk authority.

    AI output is treated as an untrusted proposal.

    This function sizes defined-risk verticals by their
    broker-independent theoretical maximum loss.

    It cannot submit an order and cannot authorize LIVE
    or PAPER execution.
    """

    if portfolio.kill_switch:
        return reject(
            proposal,
            "GLOBAL_KILL_SWITCH",
        )

    if (
        proposal.confidence
        < policy.min_confidence
    ):
        return reject(
            proposal,
            "CONFIDENCE_BELOW_GATE",
        )

    try:
        metrics = (
            calculate_vertical_risk(
                proposal
            )
        )

    except OptionsRiskError as exc:
        return reject(
            proposal,
            (
                "INVALID_VERTICAL:"
                + str(exc)
            ),
        )

    underlying = (
        metrics.underlying
    )

    open_underlyings = {
        str(
            item
        ).upper().strip()
        for item
        in portfolio.open_underlyings
    }

    if (
        underlying
        in open_underlyings
    ):
        return reject(
            proposal,
            "DUPLICATE_OPEN_UNDERLYING",
            spread_type=
                metrics.spread_type,
            max_loss_per_spread=
                metrics
                .max_loss_per_spread,
        )

    equity = portfolio.equity

    trade_cap = (
        equity
        * policy.risk_per_trade_pct
        / Decimal("100")
    )

    total_cap = (
        equity
        * policy.max_total_risk_pct
        / Decimal("100")
    )

    remaining_total = max(
        Decimal("0"),
        total_cap
        - portfolio.current_open_risk,
    )

    risk_budget = min(
        trade_cap,
        remaining_total,
    )

    if risk_budget <= 0:
        return reject(
            proposal,
            "NO_REMAINING_RISK_BUDGET",
            spread_type=
                metrics.spread_type,
            max_loss_per_spread=
                metrics
                .max_loss_per_spread,
            risk_budget=
                risk_budget,
        )

    one_spread_loss = (
        metrics.max_loss_per_spread
    )

    max_contracts = int(
        risk_budget
        / one_spread_loss
    )

    if max_contracts < 1:
        return reject(
            proposal,
            "ONE_SPREAD_EXCEEDS_RISK_BUDGET",
            spread_type=
                metrics.spread_type,
            max_loss_per_spread=
                one_spread_loss,
            risk_budget=
                risk_budget,
        )

    approved_quantity = min(
        proposal.quantity,
        max_contracts,
    )

    approved_max_loss = (
        one_spread_loss
        * approved_quantity
    )

    projected_total_risk = (
        portfolio.current_open_risk
        + approved_max_loss
    )

    if (
        projected_total_risk
        > total_cap
    ):
        return reject(
            proposal,
            "TOTAL_RISK_CAP_EXCEEDED",
            spread_type=
                metrics.spread_type,
            max_loss_per_spread=
                one_spread_loss,
            risk_budget=
                risk_budget,
        )

    return OptionsRiskDecision(
        approved=True,

        reason=
            "APPROVED_BY_OPTIONS_MAX_LOSS_RISK",

        underlying=
            underlying,

        spread_type=
            metrics.spread_type,

        requested_quantity=
            proposal.quantity,

        max_contracts_by_risk=
            max_contracts,

        approved_quantity=
            approved_quantity,

        max_loss_per_spread=
            one_spread_loss,

        approved_max_loss=
            money(
                approved_max_loss
            ),

        risk_budget=
            money(
                risk_budget
            ),

        projected_total_open_risk=
            money(
                projected_total_risk
            ),

        trading_authority=False,

        live_order_allowed=False,

        order_authority=False,

        execution_effect=False,
    )


def status() -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "supported_structures": [
            item.value
            for item
            in VerticalSpreadType
        ],

        "defined_risk_only":
            True,

        "risk_measure":
            "THEORETICAL_MAX_LOSS",

        "policy_source":
            (
                "EXISTING_SENTINEL_"
                "CONFIDENCE_AND_RISK_LIMITS"
            ),

        "broker_connection":
            BROKER_CONNECTION,

        "trading_authority":
            TRADING_AUTHORITY,

        "order_authority":
            ORDER_AUTHORITY,

        "execution_effect":
            EXECUTION_EFFECT,
    }
