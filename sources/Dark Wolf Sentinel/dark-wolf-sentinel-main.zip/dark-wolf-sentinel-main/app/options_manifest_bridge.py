from __future__ import annotations

from datetime import datetime
from typing import Any
from uuid import (
    NAMESPACE_URL,
    uuid5,
)

from app.agent.models import (
    AgentAction,
    AgentProposal,
)
from app.options_order_intent import (
    OptionsMlegIntent,
)
from app.options_position_store import (
    OptionsEntryManifest,
)
from app.options_selector import (
    OptionSelectionResult,
)


MODE = "OPTIONS_PRE_SUBMISSION_MANIFEST_ADAPTER"

BROKER_CONNECTION = False
BROKER_READS = False
BROKER_WRITES = False
ORDER_SUBMISSION_AUTHORITY = False
EXECUTION_EFFECT = False


class OptionsManifestBridgeError(
    ValueError
):
    pass


def _record_id(
    *,
    client_order_id: str,
) -> str:
    value = client_order_id.strip()

    if not value:
        raise OptionsManifestBridgeError(
            "EMPTY_CLIENT_ORDER_ID"
        )

    return (
        "dwop-"
        + str(
            uuid5(
                NAMESPACE_URL,
                (
                    "dark-wolf-options-position:"
                    + value
                ),
            )
        )
    )


def build_entry_manifest(
    *,
    agent_proposal: AgentProposal | dict[str, Any],
    options_shadow: dict[str, Any],
    options_order_intent: dict[str, Any],
    created_at: datetime,
) -> OptionsEntryManifest:
    """
    Convert already-approved upstream evidence into the
    durable PREPARED manifest schema.

    This layer chooses no thesis horizon, option expiry,
    sizing, risk, or execution policy.
    """

    if created_at.utcoffset() is None:
        raise OptionsManifestBridgeError(
            "CREATED_AT_MUST_BE_TIMEZONE_AWARE"
        )

    proposal = (
        agent_proposal
        if isinstance(
            agent_proposal,
            AgentProposal,
        )
        else AgentProposal.model_validate(
            agent_proposal
        )
    )

    if proposal.action not in {
        AgentAction.BUY,
        AgentAction.BEARISH,
    }:
        raise OptionsManifestBridgeError(
            "ENTRY_MANIFEST_REQUIRES_BUY_OR_BEARISH"
        )

    if proposal.thesis_expires_at is None:
        raise OptionsManifestBridgeError(
            "MISSING_THESIS_EXPIRY"
        )

    if (
        proposal.thesis_expires_at
        <= created_at
    ):
        raise OptionsManifestBridgeError(
            "THESIS_ALREADY_EXPIRED"
        )

    if (
        options_shadow.get(
            "status"
        )
        != "OK"
    ):
        raise OptionsManifestBridgeError(
            "OPTIONS_SHADOW_NOT_OK"
        )

    if (
        options_shadow.get(
            "trading_authority",
            False,
        )
        or options_shadow.get(
            "order_authority",
            False,
        )
        or options_shadow.get(
            "execution_effect",
            False,
        )
    ):
        raise OptionsManifestBridgeError(
            "OPTIONS_SHADOW_AUTHORITY_FORBIDDEN"
        )

    raw_selection = options_shadow.get(
        "selection"
    )

    if not isinstance(
        raw_selection,
        dict,
    ):
        raise OptionsManifestBridgeError(
            "MISSING_OPTIONS_SELECTION"
        )

    selection = (
        OptionSelectionResult
        .model_validate(
            raw_selection
        )
    )

    if not selection.selected:
        raise OptionsManifestBridgeError(
            "OPTIONS_NOT_SELECTED"
        )

    if selection.proposal is None:
        raise OptionsManifestBridgeError(
            "MISSING_VERTICAL_PROPOSAL"
        )

    if selection.metrics is None:
        raise OptionsManifestBridgeError(
            "MISSING_VERTICAL_METRICS"
        )

    if selection.risk_decision is None:
        raise OptionsManifestBridgeError(
            "MISSING_OPTIONS_RISK_DECISION"
        )

    if not selection.risk_decision.approved:
        raise OptionsManifestBridgeError(
            "OPTIONS_RISK_NOT_APPROVED"
        )

    if (
        options_order_intent.get(
            "status"
        )
        != "READY_INERT"
    ):
        raise OptionsManifestBridgeError(
            "MLEG_INTENT_NOT_READY"
        )

    if (
        options_order_intent.get(
            "trading_authority",
            False,
        )
        or options_order_intent.get(
            "order_submission_authority",
            False,
        )
        or options_order_intent.get(
            "broker_connection",
            False,
        )
        or options_order_intent.get(
            "execution_effect",
            False,
        )
    ):
        raise OptionsManifestBridgeError(
            "MLEG_INTENT_AUTHORITY_FORBIDDEN"
        )

    raw_intent = options_order_intent.get(
        "intent"
    )

    if not isinstance(
        raw_intent,
        dict,
    ):
        raise OptionsManifestBridgeError(
            "MISSING_MLEG_INTENT"
        )

    intent = (
        OptionsMlegIntent
        .model_validate(
            raw_intent
        )
    )

    vertical = selection.proposal
    metrics = selection.metrics
    risk = selection.risk_decision

    long_contract = (
        vertical.long_leg.contract
    )

    short_contract = (
        vertical.short_leg.contract
    )

    expiration = (
        long_contract.expiration
    )

    if (
        short_contract.expiration
        != expiration
    ):
        raise OptionsManifestBridgeError(
            "LEG_EXPIRATION_MISMATCH"
        )

    if (
        metrics.expiration
        != expiration
    ):
        raise OptionsManifestBridgeError(
            "METRICS_EXPIRATION_MISMATCH"
        )

    if (
        proposal.thesis_expires_at.date()
        > expiration
    ):
        raise OptionsManifestBridgeError(
            "THESIS_EXPIRY_AFTER_OPTION_EXPIRATION"
        )

    underlying = (
        long_contract.underlying.upper()
    )

    if (
        short_contract.underlying.upper()
        != underlying
    ):
        raise OptionsManifestBridgeError(
            "LEG_UNDERLYING_MISMATCH"
        )

    if (
        metrics.underlying.upper()
        != underlying
    ):
        raise OptionsManifestBridgeError(
            "METRICS_UNDERLYING_MISMATCH"
        )

    if (
        risk.underlying.upper()
        != underlying
    ):
        raise OptionsManifestBridgeError(
            "RISK_UNDERLYING_MISMATCH"
        )

    if (
        intent.underlying.upper()
        != underlying
    ):
        raise OptionsManifestBridgeError(
            "INTENT_UNDERLYING_MISMATCH"
        )

    if (
        proposal.symbol.upper()
        != underlying
    ):
        raise OptionsManifestBridgeError(
            "AGENT_UNDERLYING_MISMATCH"
        )

    if (
        metrics.spread_type
        != intent.spread_type
    ):
        raise OptionsManifestBridgeError(
            "INTENT_SPREAD_TYPE_MISMATCH"
        )

    if (
        risk.spread_type
        != intent.spread_type
    ):
        raise OptionsManifestBridgeError(
            "RISK_SPREAD_TYPE_MISMATCH"
        )

    if (
        long_contract.symbol
        != intent.long_symbol
    ):
        raise OptionsManifestBridgeError(
            "LONG_SYMBOL_MISMATCH"
        )

    if (
        short_contract.symbol
        != intent.short_symbol
    ):
        raise OptionsManifestBridgeError(
            "SHORT_SYMBOL_MISMATCH"
        )

    if (
        vertical.thesis
        != proposal.thesis
    ):
        raise OptionsManifestBridgeError(
            "THESIS_CONTEXT_MISMATCH"
        )

    if (
        intent.quantity
        != risk.approved_quantity
    ):
        raise OptionsManifestBridgeError(
            "INTENT_RISK_QUANTITY_MISMATCH"
        )

    if (
        intent.quantity
        != metrics.quantity
    ):
        raise OptionsManifestBridgeError(
            "INTENT_METRICS_QUANTITY_MISMATCH"
        )

    if (
        risk.approved_max_loss
        <= 0
    ):
        raise OptionsManifestBridgeError(
            "NON_POSITIVE_APPROVED_MAX_LOSS"
        )

    if (
        intent.limit_price
        <= 0
    ):
        raise OptionsManifestBridgeError(
            "ENTRY_DEBIT_LIMIT_MUST_BE_POSITIVE"
        )

    if (
        metrics.net_debit_per_share
        <= 0
    ):
        raise OptionsManifestBridgeError(
            "SELECTED_DEBIT_MUST_BE_POSITIVE"
        )

    manifest = OptionsEntryManifest(
        record_id=
            _record_id(
                client_order_id=
                    intent.client_order_id,
            ),

        decision_id=
            intent.decision_id,

        client_order_id=
            intent.client_order_id,

        underlying=
            underlying,

        spread_type=
            intent.spread_type,

        long_symbol=
            intent.long_symbol,

        short_symbol=
            intent.short_symbol,

        quantity=
            intent.quantity,

        expiration=
            expiration,

        thesis_expires_at=
            proposal.thesis_expires_at,

        width=
            metrics.width,

        selected_debit=
            metrics.net_debit_per_share,

        executable_entry_limit=
            intent.limit_price,

        approved_max_loss=
            risk.approved_max_loss,

        created_at=
            created_at,
    )

    return manifest


def status() -> dict[str, Any]:
    return {
        "mode":
            MODE,

        "agent_thesis_expiry_required":
            True,

        "selected_contract_expiry_required":
            True,

        "leg_expiry_match_required":
            True,

        "metrics_expiry_match_required":
            True,

        "thesis_after_creation_required":
            True,

        "thesis_not_after_option_expiry":
            True,

        "exact_underlying_match":
            True,

        "exact_leg_symbol_match":
            True,

        "exact_quantity_match":
            True,

        "risk_approval_required":
            True,

        "risk_limit_preserved":
            True,

        "horizon_policy_embedded":
            False,

        "broker_connection":
            BROKER_CONNECTION,

        "broker_reads":
            BROKER_READS,

        "broker_writes":
            BROKER_WRITES,

        "order_submission_authority":
            ORDER_SUBMISSION_AUTHORITY,

        "execution_effect":
            EXECUTION_EFFECT,
    }
