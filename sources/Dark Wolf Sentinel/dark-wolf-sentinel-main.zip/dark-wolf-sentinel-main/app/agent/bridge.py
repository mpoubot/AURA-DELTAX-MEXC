from __future__ import annotations

from app.agent.models import (
    AgentAction,
    AgentProposal,
)
from app.models import (
    AssetClass,
    TradeCandidate,
)


def proposal_to_candidate(
    proposal: AgentProposal,
    *,
    asset_class: AssetClass,
) -> TradeCandidate | None:
    """Convert an AI proposal into an UNTRUSTED risk candidate.

    This does not approve or execute anything.
    """

    if proposal.action == AgentAction.PASS:
        return None

    # BEARISH is explicitly reserved for the options
    # shadow path. It must never become an equity-short
    # candidate through this bridge.
    if proposal.action == AgentAction.BEARISH:
        return None

    if proposal.action != AgentAction.BUY:
        raise RuntimeError(
            "Unsupported AI action."
        )

    assert proposal.entry_price is not None
    assert proposal.stop_price is not None
    assert proposal.target_price is not None

    return TradeCandidate(
        symbol=proposal.symbol,
        asset_class=asset_class,
        entry_price=proposal.entry_price,
        stop_price=proposal.stop_price,
        target_price=proposal.target_price,
        confidence=proposal.confidence,
        thesis=proposal.thesis,
        catalyst=proposal.catalyst,
        invalidation=proposal.invalidation,
    )
