from __future__ import annotations

from datetime import datetime
from enum import Enum

from pydantic import (
    BaseModel,
    Field,
    model_validator,
)


class AgentAction(str, Enum):
    PASS = "PASS"
    BUY = "BUY"
    BEARISH = "BEARISH"


class MarketContext(BaseModel):
    symbol: str = Field(
        min_length=1,
        max_length=32,
    )

    asset_class: str

    current_price: float = Field(
        gt=0,
    )

    timeframe: str = "15m"

    market_regime: str | None = None

    trend: str | None = None

    rsi: float | None = None

    ema20: float | None = None
    ema50: float | None = None

    prior_high: float | None = None

    volume_ratio: float | None = None

    news_context: list[str] = Field(
        default_factory=list,
    )


class AgentProposal(BaseModel):
    action: AgentAction

    symbol: str = Field(
        min_length=1,
        max_length=32,
    )

    confidence: float = Field(
        ge=0,
        le=100,
    )

    entry_price: float | None = Field(
        default=None,
        gt=0,
    )

    stop_price: float | None = Field(
        default=None,
        gt=0,
    )

    target_price: float | None = Field(
        default=None,
        gt=0,
    )

    thesis: str = Field(
        min_length=1,
        max_length=4000,
    )

    # Explicit strategy-thesis lifetime supplied
    # upstream by the analysis model.
    #
    # PASS carries no actionable thesis horizon.
    # BUY / BEARISH must provide a timezone-aware
    # absolute expiration timestamp.
    thesis_expires_at: datetime | None = None

    catalyst: str | None = Field(
        default=None,
        max_length=2000,
    )

    invalidation: str | None = Field(
        default=None,
        max_length=2000,
    )

    risk_notes: str | None = Field(
        default=None,
        max_length=2000,
    )

    # Explicit proof that the LLM cannot size trades.
    requested_quantity: None = None

    # Explicit proof that the LLM cannot authorize orders.
    trading_authority: bool = False

    live_order_allowed: bool = False

    @model_validator(
        mode="after"
    )
    def validate_proposal(
        self,
    ) -> "AgentProposal":
        if self.trading_authority:
            raise ValueError(
                "AI trading authority is forbidden."
            )

        if self.live_order_allowed:
            raise ValueError(
                "AI live-order authority is forbidden."
            )

        if (
            self.thesis_expires_at is not None
            and self.thesis_expires_at.utcoffset()
            is None
        ):
            raise ValueError(
                "Thesis expiration must be timezone-aware."
            )

        if self.action in {
            AgentAction.BUY,
            AgentAction.BEARISH,
        }:
            if self.thesis_expires_at is None:
                raise ValueError(
                    "BUY/BEARISH proposal requires "
                    "thesis_expires_at."
                )

        if (
            self.action == AgentAction.PASS
            and self.thesis_expires_at is not None
        ):
            raise ValueError(
                "PASS proposal thesis expiration "
                "must be null."
            )

        if self.action == AgentAction.BUY:
            required = {
                "entry_price":
                    self.entry_price,
                "stop_price":
                    self.stop_price,
                "target_price":
                    self.target_price,
            }

            missing = [
                name
                for name, value
                in required.items()
                if value is None
            ]

            if missing:
                raise ValueError(
                    "BUY proposal missing: "
                    + ", ".join(missing)
                )

            assert self.entry_price is not None
            assert self.stop_price is not None
            assert self.target_price is not None

            if (
                self.stop_price
                >= self.entry_price
            ):
                raise ValueError(
                    "Long stop must be below entry."
                )

            if (
                self.target_price
                <= self.entry_price
            ):
                raise ValueError(
                    "Long target must be above entry."
                )

        if self.action == AgentAction.BEARISH:
            price_fields = {
                "entry_price": self.entry_price,
                "stop_price": self.stop_price,
                "target_price": self.target_price,
            }

            supplied = [
                name
                for name, value in price_fields.items()
                if value is not None
            ]

            if supplied:
                raise ValueError(
                    "BEARISH is options-analysis only; "
                    "equity price levels must be null: "
                    + ", ".join(supplied)
                )

        return self
