from __future__ import annotations

import json
from typing import Any

from openai import OpenAI

from app.agent.models import (
    AgentProposal,
    MarketContext,
)
from app.config import Settings


SYSTEM_INSTRUCTIONS = """
You are the market-analysis component of Dark Wolf Sentinel.

You may analyze market information and propose a trade.

You are NOT a broker.
You do NOT control position sizing.
You do NOT control portfolio exposure.
You do NOT have trading authority.
You cannot enable live trading.
You cannot submit or cancel orders.

Allowed actions:
- PASS
- BUY
- BEARISH

The deterministic risk engine is the final authority.

Return exactly one JSON object with these keys:

action
symbol
confidence
entry_price
stop_price
target_price
thesis
thesis_expires_at
catalyst
invalidation
risk_notes
trading_authority
live_order_allowed

Rules:

1. trading_authority must always be false.
2. live_order_allowed must always be false.
3. confidence must be between 0 and 100.
4. If action is PASS, price fields must be null.
5. If action is BUY:
   - stop_price must be below entry_price.
   - target_price must be above entry_price.
   - BUY represents a bullish underlying thesis.
6. If action is BEARISH:
   - entry_price must be null.
   - stop_price must be null.
   - target_price must be null.
   - BEARISH means bearish options analysis only.
   - It does NOT authorize short stock.
   - It does NOT authorize any order.
7. Do not include quantity, dollar size, leverage,
   portfolio allocation, or an order instruction.
8. When evidence is insufficient, return PASS.
9. thesis_expires_at:
   - For BUY or BEARISH, return an absolute ISO-8601 timestamp with an explicit timezone.
   - It is the time after which this specific market thesis should no longer justify holding or initiating the options position.
   - Choose the horizon from the stated thesis, catalyst, market setup, and expected timing; do not use a fixed default.
   - For PASS, thesis_expires_at must be null.
10. Never use thesis_expires_at to grant trading or sizing authority.

"""


class OpenAITradingAgent:
    """AI proposal generator.

    This module has no broker dependency and no execution path.
    """

    TRADING_AUTHORITY = False
    LIVE_ORDER_ALLOWED = False

    def __init__(
        self,
        settings: Settings,
        *,
        client: Any | None = None,
    ) -> None:
        self.settings = settings

        if client is not None:
            self.client = client
            return

        if not settings.openai_configured:
            raise RuntimeError(
                "OpenAI API key is not configured."
            )

        self.client = OpenAI(
            api_key=settings.openai_api_key,
        )

    def analyze(
        self,
        context: MarketContext,
    ) -> AgentProposal:
        prompt = (
            SYSTEM_INSTRUCTIONS
            + "\n\nMARKET CONTEXT:\n"
            + json.dumps(
                context.model_dump(
                    mode="json"
                ),
                indent=2,
            )
        )

        response = (
            self.client.responses.create(
                model=
                    self.settings.openai_model,
                input=prompt,
            )
        )

        raw = response.output_text.strip()

        # Tolerate fenced JSON if a model ever adds it.
        if raw.startswith("```"):
            raw = raw.strip("`")

            if raw.startswith("json"):
                raw = raw[4:]

            raw = raw.strip()

        data = json.loads(raw)

        # These values are enforced here even before
        # Pydantic validates the response.
        data["trading_authority"] = False
        data["live_order_allowed"] = False

        # Quantity is intentionally discarded if supplied.
        data.pop(
            "quantity",
            None,
        )

        data.pop(
            "requested_quantity",
            None,
        )

        data.pop(
            "dollar_amount",
            None,
        )

        data.pop(
            "position_size",
            None,
        )

        return AgentProposal.model_validate(
            data
        )
