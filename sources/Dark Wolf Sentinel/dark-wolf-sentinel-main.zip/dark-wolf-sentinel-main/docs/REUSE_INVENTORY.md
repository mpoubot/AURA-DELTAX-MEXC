# Reuse Inventory

Generated from the existing local PAPER trading system.

This document is an architectural inventory only.
No source files were modified.

## Candidate Components

### Risk authority

- Source: `app/risk.py`
- Lines: 153
- SHA256: `e9b3783ddbc08557974a3c5718eaa58e2ff41a4e2351e9bf74414463dcfd8e62`
- Functions: 1
- Classes: 0
- Imports: app, config

**Key functions**

- `evaluate_trade`

### Unified portfolio risk

- Source: `app/portfolio_risk.py`
- Lines: 780
- SHA256: `8d09628ef04ecc5519600b417ef0bc5cd7e192b930dc5dc1825680186a58afc9`
- Functions: 10
- Classes: 0
- Imports: config, contextlib, fcntl, json, pathlib, sqlite3

**Key functions**

- `_account`
- `_main_open_positions`
- `_top5_open_positions`
- `unified_snapshot`
- `pre_entry_check`
- `final_entry_check`
- `open_risk_for_asset_class`
- `portfolio_entry_lock`
- `write_status`
- `main`

### Paper trade journal

- Source: `app/paper.py`
- Lines: 431
- SHA256: `9e2c22c5efbd15269691dbf4b7715799e93ff044116cc4c61253903e29ba6888`
- Functions: 9
- Classes: 0
- Imports: app, datetime, pathlib, sqlite3, zoneinfo

**Key functions**

- `connect`
- `initialize`
- `account`
- `open_trade`
- `get_trade`
- `close_trade`
- `performance_metrics`
- `open_risk_for_asset_class`
- `portfolio`

### Position monitor

- Source: `app/position_monitor.py`
- Lines: 393
- SHA256: `55585e9cbeebea7e3e6f48a2289d1192f96bd1b35c5b1e49c06b27259a06ce96`
- Functions: 13
- Classes: 0
- Imports: app, datetime, dotenv, httpx, json, pathlib, sys, time, zoneinfo

**Key functions**

- `now_utc`
- `write_status`
- `log_record`
- `headers`
- `get_open_positions`
- `stock_market_open`
- `recent_timestamp`
- `fetch_stock_prices`
- `fetch_crypto_prices`
- `exit_reason`
- `run_once`
- `self_test`
- `main`

### Outcome tracker

- Source: `app/outcome_tracker.py`
- Lines: 1133
- SHA256: `5b33efd73f81d5b89d4d7e7d0d1944336dbadc025686fae2c24af7c48f443e7a`
- Functions: 19
- Classes: 0
- Imports: argparse, datetime, dotenv, hashlib, httpx, json, pathlib, sqlite3

**Key functions**

- `now_utc`
- `iso_now`
- `parse_dt`
- `canonical_symbol`
- `make_id`
- `connect_db`
- `load_state`
- `save_state`
- `write_status`
- `insert_event`
- `ingest_scanner_record`
- `ingest_tv_record`
- `read_new_jsonl`
- `fetch_bars`
- `choose_price_bar`
- `measure_pending`
- `database_counts`
- `run_once`
- `main`

### Counterfactual simulator

- Source: `app/counterfactual_simulator.py`
- Lines: 755
- SHA256: `55958f85bd304f9e608042264ffe1f0ad39283454673ab7f2c665229c4ae91d6`
- Functions: 8
- Classes: 0
- Imports: datetime, dotenv, httpx, json, pathlib, sqlite3

**Key functions**

- `parse_dt`
- `first_safe_minute`
- `load_buy_events`
- `fetch_bars`
- `simulate_event`
- `summarize_threshold`
- `load_existing_trades`
- `main`

### Watchdog

- Source: `app/watchdog.py`
- Lines: 1134
- SHA256: `00e5323b4382923c9616f452859729781d3bb718cf5fee05ab6b19e3d69b30d7`
- Functions: 9
- Classes: 0
- Imports: app, datetime, json, os, pathlib, re, subprocess, time, urllib

**Key functions**

- `utc_now`
- `iso_now`
- `http_json`
- `launchctl_status`
- `file_age_seconds`
- `load_json`
- `send_notification`
- `load_previous_faults`
- `main`

### Live readiness

- Source: `app/live_readiness.py`
- Lines: 429
- SHA256: `0a9ea31dc67f5c1fd30dc8e88cf43d67b3d6f51f0658057eb8dd954d07402adb`
- Functions: 8
- Classes: 0
- Imports: datetime, json, pathlib, sqlite3

**Key functions**

- `now_utc`
- `load_json`
- `gate`
- `manual_status`
- `main_ai_stats`
- `top5_stats`
- `evaluate`
- `main`

### Market intelligence

- Source: `app/market_intel.py`
- Lines: 1234
- SHA256: `9ab9c3ab47e73f6cf909f3b6f1667f09f07354d047bb69cfc5f2e9f0e2abe286`
- Functions: 25
- Classes: 0
- Imports: app, argparse, datetime, email, hashlib, httpx, json, pathlib, re, urllib, xml

**Key functions**

- `now_utc`
- `log`
- `load_state`
- `save_state`
- `fingerprint`
- `parse_iso`
- `parse_rss_date`
- `recent_enough`
- `clean_text`
- `keyword_risk`
- `event`
- `news_market_relevance`
- `_headline_tokens`
- `dedupe_similar_news`
- `fetch_world_news`
- `rss_items`
- `fetch_sec`
- `fetch_fed`
- `fetch_nhc`
- `fetch_usgs`
- `dedupe`
- `overall_risk`
- `maybe_notify`
- `run_once`
- `main`

### Stock scanner

- Source: `app/scanner.py`
- Lines: 544
- SHA256: `9fdb01845a16a6a2ebd94383ecfbb49c583edb85a3f330cd2a56e5663d7f1d2b`
- Functions: 10
- Classes: 0
- Imports: datetime, dotenv, httpx, json, pandas, pathlib, zoneinfo

**Key functions**

- `load_state`
- `save_state`
- `write_scanner_status`
- `log_record`
- `fetch_bars`
- `prepare_dataframe`
- `add_indicators`
- `analyze_symbol`
- `send_to_ai`
- `main`

### Crypto scanner

- Source: `app/crypto_scanner.py`
- Lines: 787
- SHA256: `da759268af538175c5df5cdd4b42a62496879228babb38a57a3832ae39d64508`
- Functions: 11
- Classes: 0
- Imports: app, datetime, dotenv, httpx, json, math, notify, pandas, pathlib

**Key functions**

- `load_state`
- `save_state`
- `write_status`
- `log_record`
- `discover_symbols`
- `fetch_bars`
- `prepare_dataframe`
- `add_indicators`
- `analyze_symbol`
- `send_to_ai`
- `main`

### Top-5 strategy

- Source: `app/top5_dip_trader.py`
- Lines: 1937
- SHA256: `f33d213713ba3c603ebb9477922530627b90b9805609480abd29bb5b99585a6e`
- Functions: 22
- Classes: 0
- Imports: app, datetime, dotenv, httpx, json, math, pandas, pathlib, sqlite3, zoneinfo

**Key functions**

- `utc_now`
- `iso`
- `parse_dt`
- `connect`
- `initialize`
- `account`
- `open_positions`
- `signal_seen`
- `mark_signal`
- `performance_metrics`
- `alpaca_headers`
- `fetch_bars`
- `bars_dataframe`
- `closed_15m_dataframe`
- `latest_price`
- `dip_signal`
- `dip_risk_decision`
- `open_position`
- `close_position`
- `monitor_position`
- `run`
- `setting_value`

### Broker reconciliation

- Source: `app/broker_reconciliation.py`
- Lines: 572
- SHA256: `05c62fa5ace61c922df1660016371c905153d9d4175b955014e5606bb0d633aa`
- Functions: 8
- Classes: 0
- Imports: datetime, json, pathlib, sqlite3

**Key functions**

- `utc_now`
- `nested`
- `broker_snapshot`
- `table_names`
- `count_open_positions`
- `position_symbol`
- `broker_symbols`
- `main`

### Broker monitor

- Source: `app/robinhood_broker_monitor.py`
- Lines: 1043
- SHA256: `b0370a198d70ff1ad4ff4938f7184762928892d4505cef663565029dbb2a9bd4`
- Functions: 18
- Classes: 0
- Imports: app, asyncio, datetime, httpx2, json, mcp, os, pathlib, pydantic, sqlite3, subprocess, time, urllib

**Key functions**

- `utc_now`
- `get_local_health`
- `load_agentic_account`
- `deny_interactive_auth`
- `deny_callback`
- `extract_data`
- `require_data_dict`
- `require_list`
- `dedupe_orders`
- `symbol_from_item`
- `symbols_from_items`
- `count_internal_open`
- `journal`
- `write_status`
- `safe_call`
- `run_monitor`
- `write_error`
- `main`

### Dry-run execution

- Source: `app/robinhood_dry_run.py`
- Lines: 742
- SHA256: `ccc1cc240f6b7c51a8f81ce0252b704f6ad3c5743e1ea6d61f282cc84482c3f1`
- Functions: 9
- Classes: 0
- Imports: dataclasses, datetime, decimal, json, pathlib, sqlite3, uuid

**Key functions**

- `utc_now`
- `object_dict`
- `decimal_string`
- `normalize_symbol`
- `validate_approved`
- `build_robinhood_template`
- `initialize`
- `journal_dry_run`
- `broker_call`

### Shadow broker review

- Source: `app/robinhood_shadow_review.py`
- Lines: 778
- SHA256: `dc27ae47bee29993efccefc6f09b17c33f0596ef69c11dc054ec0387e01a90e9`
- Functions: 15
- Classes: 0
- Imports: app, asyncio, datetime, httpx2, json, mcp, os, pathlib, pydantic, sqlite3, subprocess

**Key functions**

- `utc_now`
- `load_agentic_account`
- `deny_interactive_auth`
- `deny_callback`
- `ensure_schema`
- `pending_intents`
- `extract_data`
- `mask_value`
- `sanitize`
- `safe_call`
- `mark_reviewed`
- `mark_error`
- `write_status`
- `run`
- `main`

## Recommended Hackathon Treatment

| Component | Treatment |
|---|---|
| Deterministic risk engine | Copy then sanitize/adapt |
| Unified risk authority | Copy then sanitize/adapt |
| PAPER trade journal | Rebuild around Alpaca PAPER |
| Position monitor | Adapt for Alpaca positions/fills |
| Outcome tracker | Reuse architecture |
| Counterfactual analysis | Optional demo feature |
| Watchdog | Reuse concept; simplify for demo |
| Live-readiness framework | Rebrand as Safety Readiness |
| Market intelligence | Adapt to Alpaca data/news |
| Stock scanner | Adapt |
| Crypto scanner | Adapt |
| Top-5 strategy | Do not make core hackathon story |
| Robinhood reconciliation | Replace with Alpaca reconciliation |
| Robinhood broker monitor | Replace entirely |
| Robinhood dry-run adapter | Replace with Alpaca PAPER adapter |
| Robinhood shadow review | Replace with Alpaca MCP review layer |

## Core Hackathon Differentiator

AI proposes trades; deterministic code controls whether
portfolio risk permits execution.

Broker state is independently reconciled against internal
state, and mismatches become observable faults.
