# Architecture

## Layer 1 — Market Intelligence

Alpaca market data
- stocks
- ETFs
- crypto
- options where useful
- news

## Layer 2 — AI Decision Agent

Responsibilities:
- interpret market context
- construct trade thesis
- propose direction
- provide confidence
- explain catalysts and invalidation

The AI cannot approve portfolio risk.

## Layer 3 — Deterministic Risk Authority

Responsibilities:
- position sizing
- exposure limits
- risk-per-trade
- aggregate portfolio risk
- duplicate-position prevention
- kill switch
- order eligibility

This layer has final authority.

## Layer 4 — Alpaca PAPER Broker

Responsibilities:
- review order
- submit PAPER order
- receive execution state
- retrieve positions
- retrieve orders

LIVE execution is outside hackathon scope.

## Layer 5 — Reconciliation

Compare:
- intended order
- broker order
- fill
- internal position
- broker position

Mismatch => fault.

## Layer 6 — Monitoring

- watchdog
- position monitor
- audit log
- health checks
- dashboard
