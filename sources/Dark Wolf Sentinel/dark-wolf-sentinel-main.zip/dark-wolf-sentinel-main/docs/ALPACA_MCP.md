# Alpaca MCP Integration

Dark Wolf Sentinel uses Alpaca's official MCP Server as an
additional AI-native market-intelligence interface.

## Hackathon MCP mode

Enabled toolsets:

- stock-data
- news

Explicitly excluded:

- trading
- account
- positions
- watchlists
- order placement
- order cancellation
- position closing
- account modification

## Purpose

The MCP layer demonstrates that Sentinel can consume Alpaca
through the Model Context Protocol while preserving the same
authority separation used everywhere else.

MCP market intelligence
→ AI proposal
→ deterministic risk authority
→ separate PAPER execution adapter

The MCP server itself is not given trading tools in this mode.
