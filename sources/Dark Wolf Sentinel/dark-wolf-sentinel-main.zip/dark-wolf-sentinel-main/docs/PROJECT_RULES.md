# Dark Wolf Sentinel — Project Rules

1. ~/ai-trader remains untouched.
2. Hackathon code lives only in ~/darkwolf-hackathon.
3. Alpaca PAPER only.
4. Never store API keys in source code.
5. Never commit .env.
6. AI does not have final risk authority.
7. Deterministic risk checks must approve every PAPER order.
8. Every order attempt receives an audit record.
9. Broker state is reconciled against internal state.
10. Unexpected broker activity is a fault.
11. Kill switch must override all trade entry.
12. Strategy experimentation cannot weaken safety controls.
