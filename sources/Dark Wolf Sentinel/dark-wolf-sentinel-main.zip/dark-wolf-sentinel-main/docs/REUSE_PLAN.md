# Reuse Plan

Reference system:

~/ai-trader

Allowed:
- inspect architecture
- inspect source
- copy selected generic components into this project
- adapt copied components independently
- reproduce safety patterns

Do not:
- modify ~/ai-trader
- reuse Robinhood credentials
- reuse dashboard credentials
- copy .env
- copy Keychain secrets
- copy Cloudflare credentials
- share private account identifiers

Likely reusable concepts:
- deterministic risk engine
- unified portfolio-risk authority
- kill switch
- paper trade journal
- position monitor
- watchdog
- broker reconciliation
- dry-run intent journal
- outcome tracking

Hackathon-specific replacements:
- Robinhood broker layer -> Alpaca PAPER
- private production dashboard -> hackathon demo UI
- private infrastructure -> public-demo-safe architecture
