# Alpaca PAPER Execution Safety

Dark Wolf Sentinel separates trade intelligence from execution.

## Flow

AI proposal
→ deterministic risk decision
→ execution intent
→ unique Alpaca client order ID
→ Alpaca PAPER order
→ broker reconciliation

## Invariants

- Alpaca client is always created with `paper=True`.
- LIVE mode does not exist in this project.
- AI cannot set trading authority.
- Risk rejection cannot become an order.
- PAPER execution has a second independent enable flag.
- The enable flag defaults to `false`.
- Every decision gets a deterministic client order ID.
- Reusing a decision cannot intentionally create a second order.
- Submitted broker state is reconciled by broker order ID.
- Current Step 5 implementation supports equities only.

The execution flag remains disabled after Step 5.
