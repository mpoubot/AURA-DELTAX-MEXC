# Dark Wolf Sentinel Demo Script and Safety Checklist

Use this checklist for the existing analysis-only end-to-end demonstration.
It does not authorize PAPER or LIVE execution.

## 1. Preflight

- Use Alpaca PAPER credentials only.
- Confirm the PAPER account is flat and has no open orders.
- Confirm OpenAI API credit and `gpt-5.6` access are available.
- Confirm `uvx` is installed.
- Do not display `.env`, credentials, account identifiers, logs, or databases.
- Run:

```bash
.venv/bin/python -c 'from app.config import Settings; s=Settings(); s.assert_paper_only(); assert not s.paper_execution_enabled; assert not s.options_paper_execution_enabled; print("DEMO SAFETY FLAGS: PASS")'
.venv/bin/python scripts/check_safety.py
.venv/bin/python scripts/public_repo_audit.py
```

Stop unless every command passes. Do not change a flag to make the demo run.

## 2. Start the dashboard

```bash
.venv/bin/uvicorn app.dashboard_server:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000` and identify the visible safety boundary:

> Dark Wolf Sentinel uses Alpaca PAPER market data and read-only MCP news.
> GPT-5.6 proposes; deterministic code owns risk. Execution remains disabled.

## 3. Run one analysis cycle

In a second terminal:

```bash
.venv/bin/python -m scripts.run_sentinel_worker
```

Narrate only what the output proves:

1. The deterministic scanner ranks the current IEX opportunity set.
2. Alpaca MCP supplies read-only news; trading toolsets are excluded.
3. GPT-5.6 returns `PASS`, `BUY`, or `BEARISH` without quantity or authority.
4. Deterministic code controls risk and every execution boundary.
5. `PASS` is a successful no-trade decision, not a demo failure.

## 4. Mandatory safe result

The worker must finish with `SENTINEL WORKER: PASS`. Its output must show all
of the following:

```text
OPTIONS BROKER ORDER SUBMITTED: False
BROKER ORDER SUBMITTED: False
PAPER EXECUTION: False
AI AUTHORITY: False
MCP TRADING TOOLS: False
```

Verify the written artifact without printing news or credentials:

```bash
.venv/bin/python -c 'import json; d=json.load(open("data/sentinel_news_latest.json")); p=d["proposal"]; o=d["options_execution"]; s=d["options_shadow"]; checks=(d["paper_execution_enabled"],d["broker_order_submitted"],d["live_trading"],d["ai_trading_authority"],d["mcp_trading_tools"],p["trading_authority"],p["live_order_allowed"],o["submitted"],o["live_trading"],o["ai_live_trading_authority"],s["trading_authority"],s["order_authority"],s["execution_effect"]); assert all(value is False for value in checks); print("DEMO ZERO-AUTHORITY RESULT: PASS")'
```

Refresh the dashboard and show the fresh timestamp, selected symbol, GPT-5.6
proposal, confidence, deterministic risk result, and visible PAPER-safe state.

## 5. Stop conditions

Stop the demonstration without retrying or weakening safety if:

- Alpaca is not in PAPER mode.
- Either execution flag is true.
- The PAPER account has a position or open order.
- Any authority or execution field is not exactly false.
- MCP exposes a trading, account, position, watchlist, order, cancellation, or
  close-position tool.
- Credentials, OpenAI credit, market data, MCP, or the dashboard are unavailable.

Never submit, cancel, or close an order to prove the project works.

## 6. Close

> Dark Wolf Sentinel demonstrates an AI trading-analysis workflow with a hard
> separation between intelligence and authority. This run used real Alpaca
> market context, read-only MCP news, and GPT-5.6 analysis while execution,
> broker submission, LIVE trading, and AI authority all remained false.

End the local dashboard process after the demonstration.
