# AI Authority Model

Dark Wolf Sentinel deliberately separates intelligence from authority.

## GPT-5.6 may

- analyze supplied market context
- return PASS or BUY
- provide confidence
- propose entry, stop, and target
- explain thesis, catalyst, and invalidation

## GPT-5.6 may not

- select quantity
- select dollar allocation
- control leverage
- bypass confidence requirements
- approve portfolio risk
- submit orders
- cancel orders
- close positions
- enable PAPER execution
- enable LIVE execution

## Authority chain

GPT-5.6 proposal
→ untrusted TradeCandidate
→ deterministic risk authority
→ execution intent
→ Alpaca PAPER broker

An AI-generated BUY is not an order.
