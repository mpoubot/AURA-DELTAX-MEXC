# Lablab Step 3 Deployment Readiness

## Recommended platform

Select **Replit** in the Lablab platform dropdown. After organizer eligibility
approval, use a Replit **Reserved VM** deployment rather than a Static or
Streamlit deployment.

Dark Wolf Sentinel is an existing FastAPI application with a long-running ASGI
server, a separate Python analysis worker, an Alpaca MCP subprocess launched by
`uvx`, and regenerable local JSON state. Replit can run that architecture
directly, expose port 8000, and store production secrets outside the repository.
The Reserved VM option avoids a framework rewrite and gives judges a consistent
long-running service.

The alternatives fit less well:

- **Streamlit** would require replacing the verified FastAPI/HTML dashboard and
  does not guarantee persistent local storage.
- **Vercel** packages Python as serverless functions with a read-only deployed
  filesystem apart from temporary scratch space. That is a poor fit for the
  subprocess worker and generated latest-analysis artifact.
- **native.builder** targets native application construction rather than this
  Python ASGI service.
- **Other** is unnecessary because Replit supports the existing runtime without
  weakening the safety boundary.

## Runtime and persistence boundary

The tracked Replit configuration pins the runtime module to Python 3.12. The
deployment build creates an isolated project-local environment from that
interpreter and installs the locked requirements into it:

```bash
python -m venv .venv && PIP_USER=false .venv/bin/python -m pip install --no-user -r requirements.lock.txt
```

`PIP_USER=false` and `--no-user` explicitly prevent Replit's build environment
from redirecting installation into user site-packages, which are unavailable
inside the deployment virtual environment. Do not replace this isolation with
`--break-system-packages`.

The deployment then starts with that environment's interpreter:

```bash
.venv/bin/python -m scripts.start_judge_app
```

The top-level Replit Preview command remains
`python -m scripts.start_judge_app`; only the deployment build and run commands
use `.venv`. The `.venv/` directory is ignored by Git and must never be
committed.

The deployment-specific entry point validates configuration before opening the
server. It refuses to start unless PAPER mode is enabled, both PAPER execution
flags are disabled, required Alpaca/OpenAI configuration is present, GPT-5.6 is
selected, and `uvx` is available. It never prints secret values.

The dashboard starts quickly on `0.0.0.0:8000`. When the deployment-only startup
refresh is explicitly enabled, a background worker runs one analysis cycle. The
worker retains its existing fail-closed requirements: the PAPER account must be
flat, it must have no open orders, MCP must remain read-only, and every execution
or authority field must remain false.

`data/sentinel_news_latest.json` is a regenerable display artifact, not an
authoritative record. Replit deployment filesystems reset when republished, so
the startup refresh regenerates the artifact. No order state, credential, or
required audit record depends on deployment filesystem persistence. If refresh
fails, the dashboard remains analysis-empty; it does not trade or use stale data
to gain authority.

## Required deployment environment-variable names

Add these names through Replit's production Secrets/environment interface. Do
not put values in source files, `.replit`, deployment logs, screenshots, or the
Lablab description.

```text
ALPACA_API_KEY
ALPACA_SECRET_KEY
ALPACA_PAPER
OPENAI_API_KEY
OPENAI_MODEL
SENTINEL_PAPER_EXECUTION_ENABLED
SENTINEL_OPTIONS_PAPER_EXECUTION_ENABLED
SENTINEL_DEPLOYMENT_REFRESH_ON_START
```

The configuration must preserve PAPER-only mode, disabled equity/options PAPER
execution, GPT-5.6 analysis, and zero AI authority. Editor Secrets do not replace
production deployment Secrets; configure and verify the production set
separately.

## Exact local verification

Run from a clean clone using Python 3.12:

```bash
python3.12 -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install -r requirements.lock.txt
uvx --version
pytest -q
python scripts/check_safety.py
python scripts/public_repo_audit.py
python -c 'from app.config import Settings; from app.deployment import validate_judge_deployment; validate_judge_deployment(Settings()); print("DEPLOYMENT PREFLIGHT: PASS")'
SENTINEL_DEPLOYMENT_REFRESH_ON_START=false python -m scripts.start_judge_app
```

In another terminal, with the same virtual environment and declared environment
configuration:

```bash
curl --fail --silent --show-error http://127.0.0.1:8000/health
curl --fail --silent --show-error http://127.0.0.1:8000/ready
curl --fail --silent --show-error http://127.0.0.1:8000/
python -m scripts.run_sentinel_worker
curl --fail --silent --show-error http://127.0.0.1:8000/api/state
```

`SENTINEL_PORT` is an optional local-only override when port 8000 is already in
use. Replit must use the default port mapped in `.replit`.

After the worker, run the zero-authority artifact assertion from
[`DEMO_SCRIPT.md`](DEMO_SCRIPT.md). Stop unless every checked value is exactly
false.

## Future deployment procedure

Only after written organizer eligibility approval:

1. Create the approved remote repository and push the verified local commit.
2. Import that exact repository and commit into Replit.
3. Confirm Python 3.12, the project-local `.venv` locked dependency build, port
   8000, and the configured
   `.venv/bin/python -m scripts.start_judge_app` deployment run command.
4. Add the required production environment names through Replit Secrets without
   exposing their values.
5. Use a flat Alpaca PAPER account with zero open orders.
6. Run in Preview first. Verify `/health`, `/ready`, `/`, the startup analysis,
   `/api/state`, the safety scan, and the zero-authority artifact assertion.
7. Select Reserved VM and publish only when all checks pass.
8. Open the public URL in a signed-out browser, confirm the dashboard renders,
   and repeat the health/readiness/state checks before entering the URL in
   Lablab.

## Rollback and safety notes

- A failed or ambiguous preflight is a stop condition, not a reason to relax a
  flag or substitute credentials.
- If the deployment misbehaves, unpublish it first. Keep LIVE, execution, broker
  submission, and AI authority disabled while diagnosing locally.
- Roll back to the last verified commit and redeploy; do not repair production
  state manually.
- Rotate credentials immediately if any secret may have entered logs, source,
  screenshots, or a public field.
- Do not add a database merely to preserve the latest dashboard artifact. The
  artifact is intentionally regenerable and non-authoritative.

## Fields that remain blank

Until a deployment is explicitly authorized and verified, leave these fields
blank:

- Lablab deployment/public application URL
- Replit deployment URL, app slug, and deployment identifier
- Public repository URL
- Custom domain

The platform dropdown may be prepared as **Replit**, but no URL currently
exists.
