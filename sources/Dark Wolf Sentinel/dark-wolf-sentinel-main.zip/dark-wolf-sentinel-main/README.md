# Dark Wolf Sentinel

Dark Wolf Sentinel is a PAPER-only AI market-analysis and trade-safety
prototype for the Alpaca AI Trading Agents Hackathon. It scans a fixed
equity universe with Alpaca IEX data, ranks opportunities deterministically,
adds read-only Alpaca MCP news, asks GPT-5.6 for a structured `PASS`, `BUY`,
or `BEARISH` proposal, and sends any actionable proposal through deterministic
risk controls. The dashboard shows the analysis, authority boundary, and safe
execution state.

The AI proposes. Deterministic code decides. A proposal is never an order.

## Architecture

```text
Alpaca IEX market data
        |
        v
Deterministic scanner and ranking
        |
        +--> Alpaca MCP (read-only stock-data and news)
        |
        v
GPT-5.6 proposal (no quantity or trading authority)
        |
        v
Deterministic portfolio-risk authority
        |
        v
Inert intent / disabled Alpaca PAPER execution boundary
        |
        v
Audit state and read-only dashboard
```

- **Alpaca:** PAPER credentials provide IEX market data and read-only broker
  state. Broker clients are constructed with `paper=True`.
- **Alpaca MCP:** the official MCP server is launched with pinned compatibility
  versions and only the `stock-data,news` toolsets. Trading, account, position,
  watchlist, order, cancellation, and close-position tools are excluded.
- **GPT-5.6:** the OpenAI Responses API produces a structured market proposal.
  The response is treated as untrusted input and cannot choose size, approve
  risk, or submit an order.
- **Deterministic authority:** ordinary code owns eligibility, sizing, exposure,
  kill-switch checks, and every execution gate.

See [Architecture](docs/ARCHITECTURE.md),
[AI Authority Model](docs/AI_AUTHORITY_MODEL.md), and
[Execution Safety](docs/EXECUTION_SAFETY.md) for the detailed boundaries.

## Safety and zero-execution boundary

The public demonstration is analysis-only:

- Alpaca PAPER mode must be `true`.
- Equity and options PAPER execution flags must remain `false`.
- LIVE trading does not exist in this project.
- AI trading authority and live-order authority are always `false`.
- Alpaca MCP trading tools are excluded.
- The demo requires a flat PAPER account with no open orders and fails closed
  otherwise.
- No demo step submits, cancels, or closes an order or position.

Do not use LIVE credentials. Do not enable either execution flag for the demo.

## Prerequisites

- macOS or Linux
- Python 3.12
- Git
- Alpaca PAPER API credentials
- An OpenAI API key with access to `gpt-5.6` and available API credit
- Network access for Alpaca, OpenAI, and the first pinned MCP launch

## Clean installation

Clone or copy the repository into a clean directory, then run:

```bash
cd darkwolf-hackathon
python3.12 -m venv .venv
.venv/bin/python -m pip install --upgrade pip
.venv/bin/python -m pip install -r requirements.lock.txt
source .venv/bin/activate
uvx --version
```

The locked Python dependencies are in `requirements.lock.txt`. At demo time,
`uvx` launches `alpaca-mcp-server==2.3.0` with `fastmcp==3.4.7` to preserve the
verified MCP compatibility boundary.

## Environment setup

Create a private local environment file from the public template:

```bash
cp .env.example .env
chmod 600 .env
```

Set only your own PAPER/API credentials in `.env`:

```dotenv
ALPACA_API_KEY=your_alpaca_paper_key
ALPACA_SECRET_KEY=your_alpaca_paper_secret
ALPACA_PAPER=true

OPENAI_API_KEY=your_openai_api_key
OPENAI_MODEL=gpt-5.6

SENTINEL_PAPER_EXECUTION_ENABLED=false
SENTINEL_OPTIONS_PAPER_EXECUTION_ENABLED=false
```

Never commit `.env`. Before every demonstration, verify the safe mode without
printing credentials:

```bash
.venv/bin/python -c 'from app.config import Settings; s=Settings(); s.assert_paper_only(); assert not s.paper_execution_enabled; assert not s.options_paper_execution_enabled; print("DEMO SAFETY FLAGS: PASS")'
```

## Launch the read-only dashboard

Start the local dashboard:

```bash
.venv/bin/uvicorn app.dashboard_server:app --host 127.0.0.1 --port 8000
```

Open `http://127.0.0.1:8000`. The dashboard reads the most recent Sentinel
result and sanitized Alpaca PAPER account state. It provides no trading
controls.

## Run the safe end-to-end demo

Use a flat Alpaca PAPER account with no open orders. In a second terminal:

```bash
.venv/bin/python -m scripts.run_sentinel_worker
```

The command scans real IEX market data, retrieves read-only MCP news, requests
a GPT-5.6 proposal, applies deterministic boundaries, and writes the latest
local dashboard artifact. It must not submit an order.

Follow the maintained [demo script and safety checklist](docs/DEMO_SCRIPT.md)
when recording or presenting the project.

## Expected safe output

A successful run ends with `SENTINEL WORKER: PASS` and reports:

```text
OPTIONS BROKER ORDER SUBMITTED: False
BROKER ORDER SUBMITTED: False
PAPER EXECUTION: False
AI AUTHORITY: False
MCP TRADING TOOLS: False
```

The selected symbol, proposal action, and confidence vary with market data.
`PASS` is a valid result. If credentials, credit, market data, MCP, or safety
preconditions are unavailable, the worker must fail rather than trade.

## Verification

Focused MCP tests:

```bash
.venv/bin/pytest -q tests/test_alpaca_news.py tests/test_alpaca_mcp.py
```

Full deterministic suite:

```bash
.venv/bin/pytest -q
```

Static LIVE-trading and authority safety check:

```bash
.venv/bin/python scripts/check_safety.py
```

Public-repository secret audit:

```bash
.venv/bin/python scripts/public_repo_audit.py
```

The deployment-prepared baseline is 203 passing tests, `SAFETY CHECK: PASS`, and
`PUBLIC REPO AUDIT: PASS`. The secret audit compares public-candidate files
with configured private values but never prints those values.

## Deployment readiness

For Lablab Step 3, the recommended platform selection is **Replit** using a
Reserved VM after organizer eligibility approval. The repository includes a
deployment-only fail-closed startup path and secret-free `/health` and `/ready`
checks. No deployment or public URL exists yet.

See [Lablab Step 3 Deployment Readiness](docs/DEPLOYMENT.md) for the platform
rationale, required environment-variable names, clean verification commands,
future deployment procedure, rollback rules, and fields that must remain blank.

## Pre-event provenance

A working Sentinel prototype existed before the August 28 hackathon kickoff.
That fact is disclosed in [PRE_EVENT_BASELINE.md](PRE_EVENT_BASELINE.md). The
repository must not represent pre-event capabilities as having been created
during the event. Event-period commits and submission materials must preserve
that distinction accurately.

Organizer clarification on the eligibility of the disclosed pre-event core is
pending. This local repository is not yet a public submission.

## Local presentation package

The judge-facing presentation is stored locally in editable and preview forms:

- [Editable PowerPoint](submission-assets/dark-wolf-sentinel-pitch-deck.pptx)
- [PDF preview](submission-assets/dark-wolf-sentinel-pitch-deck.pdf)

The package remains local and unpublished while organizer eligibility
clarification is pending. See [submission asset notes](submission-assets/README.md)
for scope and verification details.

## License

Dark Wolf Sentinel is released under the [MIT License](LICENSE).
