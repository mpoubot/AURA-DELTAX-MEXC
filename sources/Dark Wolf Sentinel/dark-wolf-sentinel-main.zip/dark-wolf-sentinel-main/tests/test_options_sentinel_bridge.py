from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)

from app.agent.models import (
    AgentAction,
    AgentProposal,
)
from app.options_sentinel_bridge import (
    direction_for_proposal,
    evaluate_options_shadow,
    status,
)
from app.options_selector import (
    OptionDirection,
)


AS_OF = date(
    2026,
    8,
    28,
)

NOW = datetime(
    2026,
    8,
    28,
    16,
    30,
    tzinfo=timezone.utc,
)


class FakeSettings:
    alpaca_paper = True
    paper_execution_enabled = False
    alpaca_configured = True

    alpaca_api_key = "fake"
    alpaca_secret_key = "fake"

    min_confidence = 85
    risk_per_trade_pct = 1
    max_total_risk_pct = 3

    def assert_paper_only(
        self,
    ) -> None:
        assert self.alpaca_paper is True


class FakeQuote:
    def __init__(
        self,
        bid: float,
        ask: float,
        bid_size: int,
        ask_size: int,
    ) -> None:
        self.bid_price = bid
        self.ask_price = ask
        self.bid_size = bid_size
        self.ask_size = ask_size
        self.timestamp = NOW


class FakeGreeks:
    def __init__(
        self,
        delta: float,
    ) -> None:
        self.delta = delta


class FakeTrade:
    timestamp = (
        NOW
        - timedelta(
            seconds=60
        )
    )


class FakeSnapshot:
    def __init__(
        self,
        *,
        bid: float,
        ask: float,
        delta: float,
    ) -> None:
        self.latest_quote = FakeQuote(
            bid,
            ask,
            20,
            20,
        )

        self.latest_trade = FakeTrade()

        self.greeks = FakeGreeks(
            delta
        )

        self.daily_bar = None

        self.implied_volatility = 0.20


class FakeDataClient:
    def __init__(
        self,
    ) -> None:
        self.calls = 0

    def get_option_chain(
        self,
        request,
    ):
        self.calls += 1

        return {
            "SPY260918C00769000":
                FakeSnapshot(
                    bid=9.69,
                    ask=9.75,
                    delta=0.55,
                ),

            "SPY260918C00781000":
                FakeSnapshot(
                    bid=3.65,
                    ask=3.74,
                    delta=0.31,
                ),
        }


class FailingDataClient:
    def get_option_chain(
        self,
        request,
    ):
        raise ConnectionError(
            "synthetic outage"
        )


def buy_proposal() -> AgentProposal:
    return AgentProposal(
        action=AgentAction.BUY,
        symbol="SPY",
        confidence=90,
        entry_price=770,
        stop_price=760,
        target_price=790,
        thesis="Synthetic bullish integration test.",
        catalyst="Synthetic momentum.",
        invalidation="Synthetic support failure.",
        risk_notes="Test only.",
        trading_authority=False,
        live_order_allowed=False,

               thesis_expires_at="2099-01-01T00:00:00+00:00",)


def pass_proposal() -> AgentProposal:
    return AgentProposal(
        action=AgentAction.PASS,
        symbol="SPY",
        confidence=90,
        thesis="No trade.",
        trading_authority=False,
        live_order_allowed=False,

               thesis_expires_at=None,)


def test_buy_maps_only_to_bullish():
    assert (
        direction_for_proposal(
            buy_proposal()
        )
        == OptionDirection.BULLISH
    )


def test_pass_skips_options_without_market_call():
    client = FakeDataClient()

    result = evaluate_options_shadow(
        settings=FakeSettings(),
        proposal=pass_proposal(),
        equity=100000,
        data_client=client,
        as_of=AS_OF,
        as_of_time=NOW,
    )

    assert client.calls == 0

    assert (
        result["status"]
        == "SKIPPED_PASS"
    )

    assert (
        result["reason"]
        == "GPT_PASS"
    )

    assert (
        result["selection"]
        is None
    )


def test_buy_reaches_defined_risk_selector():
    client = FakeDataClient()

    result = evaluate_options_shadow(
        settings=FakeSettings(),
        proposal=buy_proposal(),
        equity=100000,
        data_client=client,
        as_of=AS_OF,
        as_of_time=NOW,
    )

    assert client.calls == 1

    assert (
        result["status"]
        == "OK"
    )

    assert (
        result["direction"]
        == "bullish"
    )

    selection = result[
        "selection"
    ]

    assert (
        selection["selected"]
        is True
    )

    assert (
        selection["risk_decision"][
            "approved"
        ]
        is True
    )

    assert (
        selection["risk_decision"][
            "trading_authority"
        ]
        is False
    )

    assert (
        selection["risk_decision"][
            "live_order_allowed"
        ]
        is False
    )


def test_options_market_data_failure_degrades_only_shadow():
    result = evaluate_options_shadow(
        settings=FakeSettings(),
        proposal=buy_proposal(),
        equity=100000,
        data_client=FailingDataClient(),
        as_of=AS_OF,
        as_of_time=NOW,
    )

    assert (
        result["status"]
        == "DEGRADED"
    )

    assert (
        result["error_type"]
        == "ConnectionError"
    )

    assert (
        result["trading_authority"]
        is False
    )

    assert (
        result["order_authority"]
        is False
    )

    assert (
        result["execution_effect"]
        is False
    )


def test_bridge_has_no_bearish_inference_or_authority():
    state = status()

    assert state[
        "agent_action_mapping"
    ] == {
        "PASS": None,
        "BUY": "bullish",
        "BEARISH": "bearish",
    }

    assert (
        state[
            "bearish_ai_action_supported"
        ]
        is True
    )

    assert (
        state[
            "bearish_inference_from_text"
        ]
        is False
    )

    assert (
        state[
            "trading_authority"
        ]
        is False
    )

    assert (
        state[
            "order_authority"
        ]
        is False
    )

    assert (
        state[
            "execution_effect"
        ]
        is False
    )


class FakeBearishDataClient:
    def __init__(
        self,
    ) -> None:
        self.calls = 0

    def get_option_chain(
        self,
        request,
    ):
        self.calls += 1

        return {
            "SPY260918P00769000":
                FakeSnapshot(
                    bid=9.69,
                    ask=9.75,
                    delta=-0.55,
                ),

            "SPY260918P00757000":
                FakeSnapshot(
                    bid=3.65,
                    ask=3.74,
                    delta=-0.31,
                ),
        }


def bearish_proposal() -> AgentProposal:
    return AgentProposal(
        action=AgentAction.BEARISH,
        symbol="SPY",
        confidence=90,
        thesis="Synthetic bearish integration test.",
        catalyst="Synthetic downside momentum.",
        invalidation="Synthetic trend recovery.",
        risk_notes="Options analysis only.",
        trading_authority=False,
        live_order_allowed=False,

               thesis_expires_at="2099-01-01T00:00:00+00:00",)


def test_bearish_maps_only_to_bearish_options():
    assert (
        direction_for_proposal(
            bearish_proposal()
        )
        == OptionDirection.BEARISH
    )


def test_bearish_reaches_bear_put_defined_risk_selector():
    client = FakeBearishDataClient()

    result = evaluate_options_shadow(
        settings=FakeSettings(),
        proposal=bearish_proposal(),
        equity=100000,
        data_client=client,
        as_of=AS_OF,
        as_of_time=NOW,
    )

    assert client.calls == 1
    assert result["status"] == "OK"
    assert result["direction"] == "bearish"

    selection = result["selection"]

    assert selection is not None
    assert selection["selected"] is True

    assert (
        selection["metrics"][
            "spread_type"
        ]
        == "bear_put_debit"
    )

    assert (
        selection["risk_decision"][
            "approved"
        ]
        is True
    )

    assert (
        result["trading_authority"]
        is False
    )

    assert (
        result["order_authority"]
        is False
    )

    assert (
        result["execution_effect"]
        is False
    )
