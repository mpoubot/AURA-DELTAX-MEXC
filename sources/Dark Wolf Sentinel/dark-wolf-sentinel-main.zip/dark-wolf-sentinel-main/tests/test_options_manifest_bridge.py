from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal

import pytest

from app.agent.models import (
    AgentAction,
    AgentProposal,
)
from app.options_intent_bridge import (
    build_shadow_order_intent,
)
from app.options_manifest_bridge import (
    OptionsManifestBridgeError,
    build_entry_manifest,
    status,
)
from app.options_selector import (
    OptionDirection,
    OptionSelectionResult,
)
from app.options_verticals import (
    OptionContractSpec,
    OptionLeg,
    OptionRight,
    OptionsRiskDecision,
    PositionSide,
    VerticalRiskMetrics,
    VerticalSpreadProposal,
    VerticalSpreadType,
)


NOW = datetime(
    2026,
    8,
    28,
    17,
    30,
    tzinfo=timezone.utc,
)

EXPIRY = date(
    2026,
    9,
    18,
)


def agent(
    *,
    action=AgentAction.BUY,
    symbol="SPY",
    thesis="Synthetic manifest adapter thesis.",
    thesis_expiry=None,
):
    if thesis_expiry is None:
        thesis_expiry = (
            NOW
            + timedelta(
                days=7
            )
        )

    kwargs = {
        "action":
            action,
        "symbol":
            symbol,
        "confidence":
            90,
        "thesis":
            thesis,
        "thesis_expires_at":
            thesis_expiry,
        "trading_authority":
            False,
        "live_order_allowed":
            False,
    }

    if action == AgentAction.BUY:
        kwargs.update(
            {
                "entry_price": 770,
                "stop_price": 760,
                "target_price": 790,
            }
        )

    return AgentProposal(
        **kwargs
    )


def approved_shadow(
    *,
    spread_type=
        VerticalSpreadType
        .BULL_CALL_DEBIT,
    direction=
        OptionDirection.BULLISH,
    thesis=
        "Synthetic manifest adapter thesis.",
    expiration=EXPIRY,
):
    if (
        spread_type
        == VerticalSpreadType
        .BULL_CALL_DEBIT
    ):
        right = OptionRight.CALL
        long_strike = Decimal("768")
        short_strike = Decimal("781")
        long_symbol = (
            "SPY260918C00768000"
        )
        short_symbol = (
            "SPY260918C00781000"
        )

    else:
        right = OptionRight.PUT
        long_strike = Decimal("768")
        short_strike = Decimal("755")
        long_symbol = (
            "SPY260918P00768000"
        )
        short_symbol = (
            "SPY260918P00755000"
        )

    long_contract = OptionContractSpec(
        symbol=long_symbol,
        underlying="SPY",
        right=right,
        strike=long_strike,
        expiration=expiration,
        multiplier=Decimal("100"),
        tradable=True,
        source="TEST",
    )

    short_contract = OptionContractSpec(
        symbol=short_symbol,
        underlying="SPY",
        right=right,
        strike=short_strike,
        expiration=expiration,
        multiplier=Decimal("100"),
        tradable=True,
        source="TEST",
    )

    vertical = VerticalSpreadProposal(
        long_leg=OptionLeg(
            contract=long_contract,
            side=PositionSide.LONG,
            premium=Decimal("8.80"),
        ),
        short_leg=OptionLeg(
            contract=short_contract,
            side=PositionSide.SHORT,
            premium=Decimal("2.49"),
        ),
        quantity=1,
        confidence=90,
        thesis=thesis,
    )

    metrics = VerticalRiskMetrics(
        spread_type=spread_type,
        underlying="SPY",
        expiration=expiration,
        quantity=1,
        multiplier=Decimal("100"),
        width=Decimal("13.00"),
        net_debit_per_share=
            Decimal("6.31"),
        net_credit_per_share=
            Decimal("0"),
        max_loss_per_spread=
            Decimal("631.00"),
        max_profit_per_spread=
            Decimal("669.00"),
        total_max_loss=
            Decimal("631.00"),
        total_max_profit=
            Decimal("669.00"),
        breakeven=
            Decimal("774.31"),
        reward_to_risk=
            Decimal("1.06"),
        trading_authority=False,
        order_authority=False,
        execution_effect=False,
    )

    risk = OptionsRiskDecision(
        approved=True,
        reason="APPROVED",
        underlying="SPY",
        spread_type=spread_type,
        requested_quantity=1,
        max_contracts_by_risk=1,
        approved_quantity=1,
        max_loss_per_spread=
            Decimal("631.00"),
        approved_max_loss=
            Decimal("630.50"),
        risk_budget=
            Decimal("1000.00"),
        projected_total_open_risk=
            Decimal("630.50"),
        trading_authority=False,
        live_order_allowed=False,
        order_authority=False,
        execution_effect=False,
    )

    selection = OptionSelectionResult(
        selected=True,
        reason="SELECTED",
        direction=direction,
        considered_contracts=2,
        eligible_contracts=2,
        pairs_evaluated=1,
        rejection_counts={},
        proposal=vertical,
        metrics=metrics,
        risk_decision=risk,
        trading_authority=False,
        order_authority=False,
        execution_effect=False,
    )

    return {
        "mode":
            "OPTIONS_SENTINEL_SHADOW",
        "status":
            "OK",
        "reason":
            "SELECTED_AND_RISK_APPROVED",
        "selection":
            selection.model_dump(
                mode="json"
            ),
        "trading_authority":
            False,
        "order_authority":
            False,
        "execution_effect":
            False,
    }


def packet(
    shadow,
    *,
    decision_id="manifest-test-001",
):
    result = build_shadow_order_intent(
        options_shadow=shadow,
        decision_id=decision_id,
    )

    assert result is not None
    assert (
        result["status"]
        == "READY_INERT"
    )

    return result


def test_valid_buy_builds_manifest():
    shadow = approved_shadow()
    order_packet = packet(
        shadow
    )

    manifest = build_entry_manifest(
        agent_proposal=agent(),
        options_shadow=shadow,
        options_order_intent=
            order_packet,
        created_at=NOW,
    )

    assert (
        manifest.underlying
        == "SPY"
    )

    assert (
        manifest.expiration
        == EXPIRY
    )

    assert (
        manifest.selected_debit
        == Decimal("6.31")
    )

    assert (
        manifest.executable_entry_limit
        == Decimal("6.30")
    )

    assert (
        manifest.approved_max_loss
        == Decimal("630.50")
    )

    assert (
        manifest.client_order_id
        == order_packet[
            "intent"
        ]["client_order_id"]
    )

    assert (
        manifest
        .thesis_expires_at
        == agent()
        .thesis_expires_at
    )


def test_record_id_is_deterministic():
    shadow = approved_shadow()

    order_packet = packet(
        shadow,
        decision_id=
            "same-decision",
    )

    one = build_entry_manifest(
        agent_proposal=agent(),
        options_shadow=shadow,
        options_order_intent=
            order_packet,
        created_at=NOW,
    )

    two = build_entry_manifest(
        agent_proposal=agent(),
        options_shadow=shadow,
        options_order_intent=
            order_packet,
        created_at=NOW,
    )

    assert (
        one.record_id
        == two.record_id
    )


def test_bearish_manifest_supported():
    shadow = approved_shadow(
        spread_type=
            VerticalSpreadType
            .BEAR_PUT_DEBIT,
        direction=
            OptionDirection.BEARISH,
        thesis=
            "Synthetic bearish thesis.",
    )

    order_packet = packet(
        shadow,
        decision_id=
            "bearish-manifest",
    )

    manifest = build_entry_manifest(
        agent_proposal=agent(
            action=
                AgentAction.BEARISH,
            thesis=
                "Synthetic bearish thesis.",
        ),
        options_shadow=shadow,
        options_order_intent=
            order_packet,
        created_at=NOW,
    )

    assert (
        manifest.spread_type
        == VerticalSpreadType
        .BEAR_PUT_DEBIT
    )


def test_pass_cannot_build_manifest():
    with pytest.raises(
        OptionsManifestBridgeError,
        match="ENTRY_MANIFEST_REQUIRES_BUY_OR_BEARISH",
    ):
        build_entry_manifest(
            agent_proposal=
                AgentProposal(
                    action=
                        AgentAction.PASS,
                    symbol="SPY",
                    confidence=10,
                    thesis="No trade.",
                    thesis_expires_at=None,
                    trading_authority=False,
                    live_order_allowed=False,
                ),
            options_shadow=
                approved_shadow(),
            options_order_intent=
                packet(
                    approved_shadow()
                ),
            created_at=NOW,
        )


def test_thesis_must_be_future():
    proposal = agent(
        thesis_expiry=(
            NOW
            - timedelta(
                seconds=1
            )
        )
    )

    shadow = approved_shadow()

    with pytest.raises(
        OptionsManifestBridgeError,
        match="THESIS_ALREADY_EXPIRED",
    ):
        build_entry_manifest(
            agent_proposal=proposal,
            options_shadow=shadow,
            options_order_intent=
                packet(shadow),
            created_at=NOW,
        )


def test_thesis_cannot_outlive_option():
    proposal = agent(
        thesis_expiry=datetime(
            2026,
            9,
            19,
            12,
            0,
            tzinfo=timezone.utc,
        )
    )

    shadow = approved_shadow()

    with pytest.raises(
        OptionsManifestBridgeError,
        match="THESIS_EXPIRY_AFTER_OPTION_EXPIRATION",
    ):
        build_entry_manifest(
            agent_proposal=proposal,
            options_shadow=shadow,
            options_order_intent=
                packet(shadow),
            created_at=NOW,
        )


def test_agent_underlying_mismatch_fails():
    shadow = approved_shadow()

    with pytest.raises(
        OptionsManifestBridgeError,
        match="AGENT_UNDERLYING_MISMATCH",
    ):
        build_entry_manifest(
            agent_proposal=agent(
                symbol="QQQ"
            ),
            options_shadow=shadow,
            options_order_intent=
                packet(shadow),
            created_at=NOW,
        )


def test_thesis_context_mismatch_fails():
    shadow = approved_shadow()

    with pytest.raises(
        OptionsManifestBridgeError,
        match="THESIS_CONTEXT_MISMATCH",
    ):
        build_entry_manifest(
            agent_proposal=agent(
                thesis=
                    "Different thesis."
            ),
            options_shadow=shadow,
            options_order_intent=
                packet(shadow),
            created_at=NOW,
        )


def test_metrics_expiration_mismatch_fails():
    shadow = approved_shadow()

    shadow[
        "selection"
    ]["metrics"]["expiration"] = (
        "2026-09-17"
    )

    with pytest.raises(
        OptionsManifestBridgeError,
        match="METRICS_EXPIRATION_MISMATCH",
    ):
        build_entry_manifest(
            agent_proposal=agent(),
            options_shadow=shadow,
            options_order_intent=
                packet(
                    approved_shadow()
                ),
            created_at=NOW,
        )


def test_intent_quantity_mismatch_fails():
    shadow = approved_shadow()

    order_packet = packet(
        shadow
    )

    order_packet[
        "intent"
    ]["quantity"] = 2

    with pytest.raises(
        OptionsManifestBridgeError,
        match="INTENT_RISK_QUANTITY_MISMATCH",
    ):
        build_entry_manifest(
            agent_proposal=agent(),
            options_shadow=shadow,
            options_order_intent=
                order_packet,
            created_at=NOW,
        )


def test_status_has_zero_authority():
    state = status()

    assert (
        state[
            "agent_thesis_expiry_required"
        ]
        is True
    )

    assert (
        state[
            "selected_contract_expiry_required"
        ]
        is True
    )

    assert (
        state[
            "horizon_policy_embedded"
        ]
        is False
    )

    assert (
        state[
            "broker_connection"
        ]
        is False
    )

    assert (
        state[
            "broker_reads"
        ]
        is False
    )

    assert (
        state[
            "broker_writes"
        ]
        is False
    )

    assert (
        state[
            "order_submission_authority"
        ]
        is False
    )

    assert (
        state[
            "execution_effect"
        ]
        is False
    )
