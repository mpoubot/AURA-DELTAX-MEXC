from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal

import pytest

from app.options_order_intent import (
    OptionsIntentError,
    build_mleg_request,
    client_order_id_for,
    status,
)
from app.options_selector import (
    OptionDirection,
    OptionQuoteCandidate,
    select_debit_vertical,
)
from app.options_verticals import (
    OptionContractSpec,
    OptionRight,
    OptionsPortfolioState,
    OptionsRiskPolicy,
)


TODAY = date(
    2026,
    8,
    28,
)

NOW = datetime(
    2026,
    8,
    28,
    16,
    30,
    tzinfo=timezone.utc,
)


def quote(
    symbol: str,
    *,
    right: OptionRight,
    strike: str,
    delta: str,
    bid: str,
    ask: str,
) -> OptionQuoteCandidate:
    return OptionQuoteCandidate(
        contract=OptionContractSpec(
            symbol=symbol,
            underlying="SPY",
            right=right,
            strike=Decimal(
                strike
            ),
            expiration=(
                TODAY
                + timedelta(
                    days=21
                )
            ),
            multiplier=
                Decimal("100"),
            tradable=True,
            source="SYNTHETIC",
        ),
        bid=Decimal(
            bid
        ),
        ask=Decimal(
            ask
        ),
        delta=Decimal(
            delta
        ),
        daily_volume=0,
        bid_size=25,
        ask_size=25,
        latest_quote_at=NOW,
        latest_trade_at=(
            NOW
            - timedelta(
                seconds=30
            )
        ),
        implied_volatility=
            Decimal("0.20"),
    )


def portfolio():
    return OptionsPortfolioState(
        equity=Decimal("100000"),
        current_open_risk=
            Decimal("0"),
    )


def policy():
    return OptionsRiskPolicy(
        min_confidence=85,
        risk_per_trade_pct=
            Decimal("1"),
        max_total_risk_pct=
            Decimal("3"),
    )


def bullish_selection(
    quantity: int = 1,
):
    return select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=[
            quote(
                "SPY260918C00769000",
                right=OptionRight.CALL,
                strike="769",
                delta="0.55",
                bid="9.60",
                ask="9.70",
            ),
            quote(
                "SPY260918C00781000",
                right=OptionRight.CALL,
                strike="781",
                delta="0.31",
                bid="3.65",
                ask="3.75",
            ),
        ],
        confidence=90,
        thesis="Bullish synthetic test.",
        portfolio=portfolio(),
        risk_policy=policy(),
        requested_quantity=
            quantity,
        as_of=TODAY,
        as_of_time=NOW,
    )


def bearish_selection(
    quantity: int = 1,
):
    return select_debit_vertical(
        direction=
            OptionDirection.BEARISH,
        chain=[
            quote(
                "SPY260918P00769000",
                right=OptionRight.PUT,
                strike="769",
                delta="-0.55",
                bid="9.60",
                ask="9.70",
            ),
            quote(
                "SPY260918P00757000",
                right=OptionRight.PUT,
                strike="757",
                delta="-0.31",
                bid="3.65",
                ask="3.75",
            ),
        ],
        confidence=90,
        thesis="Bearish synthetic test.",
        portfolio=portfolio(),
        risk_policy=policy(),
        requested_quantity=
            quantity,
        as_of=TODAY,
        as_of_time=NOW,
    )


def test_bull_call_builds_exact_two_leg_mleg():
    selection = bullish_selection()

    intent, request = (
        build_mleg_request(
            selection=selection,
            decision_id="bull-001",
        )
    )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    assert (
        intent.spread_type.value
        == "bull_call_debit"
    )

    assert intent.quantity == 1
    assert intent.limit_price > 0

    assert (
        payload["order_class"]
        == "mleg"
    )

    assert (
        payload["type"]
        == "limit"
    )

    assert (
        payload["time_in_force"]
        == "day"
    )

    assert len(
        payload["legs"]
    ) == 2

    long_leg = payload["legs"][0]
    short_leg = payload["legs"][1]

    assert (
        long_leg["side"]
        == "buy"
    )

    assert (
        long_leg[
            "position_intent"
        ]
        == "buy_to_open"
    )

    assert (
        short_leg["side"]
        == "sell"
    )

    assert (
        short_leg[
            "position_intent"
        ]
        == "sell_to_open"
    )

    assert "symbol" not in payload
    assert "side" not in payload


def test_bear_put_builds_exact_two_leg_mleg():
    selection = bearish_selection()

    intent, request = (
        build_mleg_request(
            selection=selection,
            decision_id="bear-001",
        )
    )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    assert (
        intent.spread_type.value
        == "bear_put_debit"
    )

    assert len(
        payload["legs"]
    ) == 2

    assert (
        payload["legs"][0][
            "position_intent"
        ]
        == "buy_to_open"
    )

    assert (
        payload["legs"][1][
            "position_intent"
        ]
        == "sell_to_open"
    )


def test_client_order_id_is_deterministic():
    one = client_order_id_for(
        "decision-123"
    )

    two = client_order_id_for(
        "decision-123"
    )

    three = client_order_id_for(
        "decision-456"
    )

    assert one == two
    assert one != three

    assert one.startswith(
        "dwo-"
    )


def test_unselected_candidate_is_rejected():
    selection = bullish_selection()

    selection.selected = False

    with pytest.raises(
        OptionsIntentError,
        match="SELECTION_NOT_SELECTED",
    ):
        build_mleg_request(
            selection=selection,
            decision_id="reject-001",
        )


def test_risk_rejected_candidate_is_rejected():
    selection = bullish_selection()

    assert (
        selection.risk_decision
        is not None
    )

    selection.risk_decision.approved = False

    with pytest.raises(
        OptionsIntentError,
        match="RISK_DECISION_NOT_APPROVED",
    ):
        build_mleg_request(
            selection=selection,
            decision_id="reject-002",
        )


def test_zero_quantity_is_rejected_even_if_sdk_accepts_it():
    selection = bullish_selection()

    assert (
        selection.risk_decision
        is not None
    )

    selection.risk_decision.approved_quantity = 0

    with pytest.raises(
        OptionsIntentError,
        match="NON_POSITIVE_APPROVED_QUANTITY",
    ):
        build_mleg_request(
            selection=selection,
            decision_id="reject-003",
        )


def test_quantity_cannot_exceed_risk_limit():
    selection = bullish_selection()

    assert (
        selection.risk_decision
        is not None
    )

    selection.risk_decision.approved_quantity = (
        selection
        .risk_decision
        .max_contracts_by_risk
        + 1
    )

    with pytest.raises(
        OptionsIntentError,
        match="QUANTITY_EXCEEDS_RISK_MAXIMUM",
    ):
        build_mleg_request(
            selection=selection,
            decision_id="reject-004",
        )


def test_any_authority_flag_fails_closed():
    selection = bullish_selection()

    selection.order_authority = True

    with pytest.raises(
        OptionsIntentError,
        match="SELECTION_ORDER_AUTHORITY_FORBIDDEN",
    ):
        build_mleg_request(
            selection=selection,
            decision_id="reject-005",
        )


def test_empty_decision_id_rejected():
    with pytest.raises(
        OptionsIntentError,
        match="EMPTY_DECISION_ID",
    ):
        client_order_id_for(
            "   "
        )


def test_status_is_non_executing():
    state = status()

    assert (
        state[
            "market_orders_allowed"
        ]
        is False
    )

    assert (
        state[
            "positive_quantity_enforced"
        ]
        is True
    )

    assert (
        state[
            "risk_approved_quantity_required"
        ]
        is True
    )

    assert (
        state[
            "broker_connection"
        ]
        is False
    )

    assert (
        state[
            "trading_authority"
        ]
        is False
    )

    assert (
        state[
            "order_submission_authority"
        ]
        is False
    )

    assert (
        state[
            "execution_effect"
        ]
        is False
    )


def test_debit_limit_never_rounds_above_risk_approved_loss():
    """
    Regression for a real readiness-audit edge case:

    a theoretical debit ending in half a cent must
    round DOWN for the executable limit, never up.
    """

    selection = bullish_selection()

    assert selection.metrics is not None
    assert selection.risk_decision is not None

    # Force the exact boundary discovered in the
    # real-market readiness audit.
    selection.metrics.net_debit_per_share = (
        Decimal("6.125")
    )

    selection.metrics.max_loss_per_spread = (
        Decimal("612.50")
    )

    selection.risk_decision.max_loss_per_spread = (
        Decimal("612.50")
    )

    selection.risk_decision.approved_max_loss = (
        Decimal("612.50")
    )

    selection.risk_decision.approved_quantity = 1

    intent, request = build_mleg_request(
        selection=selection,
        decision_id=
            "half-cent-rounding-regression",
    )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    assert (
        intent.limit_price
        == Decimal("6.12")
    )

    assert (
        Decimal(
            str(
                payload[
                    "limit_price"
                ]
            )
        )
        == Decimal("6.12")
    )

    executable_max_loss = (
        intent.limit_price
        * Decimal("100")
        * Decimal(
            intent.quantity
        )
    )

    assert (
        executable_max_loss
        <= selection
        .risk_decision
        .approved_max_loss
    )


@pytest.mark.parametrize(
    (
        "displayed_debit",
        "approved_loss",
        "expected_limit",
    ),
    [
        (
            "5.73",
            "572.50",
            "5.72",
        ),
        (
            "5.56",
            "555.50",
            "5.55",
        ),
        (
            "5.58",
            "557.50",
            "5.57",
        ),
        (
            "5.61",
            "560.50",
            "5.60",
        ),
        (
            "5.57",
            "556.50",
            "5.56",
        ),
        (
            "5.60",
            "560.00",
            "5.60",
        ),
    ],
)
def test_limit_is_capped_by_approved_loss_budget(
    displayed_debit,
    approved_loss,
    expected_limit,
):
    selection = bullish_selection()

    assert selection.metrics is not None
    assert selection.risk_decision is not None

    selection.metrics.net_debit_per_share = (
        Decimal(
            displayed_debit
        )
    )

    selection.risk_decision.approved_quantity = 1

    selection.risk_decision.approved_max_loss = (
        Decimal(
            approved_loss
        )
    )

    intent, request = build_mleg_request(
        selection=selection,
        decision_id=(
            "risk-cap-"
            + displayed_debit
        ),
    )

    expected = Decimal(
        expected_limit
    )

    assert (
        intent.limit_price
        == expected
    )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    assert (
        Decimal(
            str(
                payload[
                    "limit_price"
                ]
            )
        )
        == expected
    )

    executable_loss = (
        intent.limit_price
        * Decimal("100")
        * Decimal(
            intent.quantity
        )
    )

    assert (
        executable_loss
        <= Decimal(
            approved_loss
        )
    )

    assert (
        intent.limit_price
        <= Decimal(
            displayed_debit
        )
    )
