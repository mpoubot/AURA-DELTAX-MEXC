from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal
from types import SimpleNamespace

import pytest

from app.broker.alpaca_options_paper_executor import (
    AlpacaOptionsPaperExecutor,
    OptionsPaperExecutionError,
    status,
)
from app.options_order_intent import (
    build_mleg_request,
)
from app.options_selector import (
    OptionDirection,
    OptionQuoteCandidate,
    select_debit_vertical,
)
from app.options_verticals import (
    OptionContractSpec,
    OptionRight,
    OptionsPortfolioState,
    OptionsRiskPolicy,
)


TODAY = date(
    2026,
    8,
    28,
)

NOW = datetime(
    2026,
    8,
    28,
    16,
    30,
    tzinfo=timezone.utc,
)


class FakeSettings:
    def __init__(
        self,
        *,
        paper: bool = True,
        options_enabled: bool = False,
        global_enabled: bool = False,
    ) -> None:
        self.alpaca_paper = paper
        self.paper_execution_enabled = global_enabled
        self.options_paper_execution_enabled = (
            options_enabled
        )

    def assert_paper_only(
        self,
    ) -> None:
        if not self.alpaca_paper:
            raise RuntimeError(
                "not paper"
            )


class FakeBrokerClient:
    def __init__(
        self,
    ) -> None:
        self.calls = []

    def submit_order(
        self,
        *,
        order_data,
    ):
        self.calls.append(
            order_data
        )

        return SimpleNamespace(
            id="fake-order-001",
            status="accepted",
        )


def quote(
    symbol: str,
    *,
    strike: str,
    delta: str,
    bid: str,
    ask: str,
) -> OptionQuoteCandidate:
    return OptionQuoteCandidate(
        contract=OptionContractSpec(
            symbol=symbol,
            underlying="SPY",
            right=OptionRight.CALL,
            strike=Decimal(
                strike
            ),
            expiration=(
                TODAY
                + timedelta(
                    days=21
                )
            ),
            multiplier=
                Decimal("100"),
            tradable=True,
            source="SYNTHETIC",
        ),
        bid=Decimal(
            bid
        ),
        ask=Decimal(
            ask
        ),
        delta=Decimal(
            delta
        ),
        bid_size=50,
        ask_size=50,
        latest_quote_at=NOW,
        latest_trade_at=(
            NOW
            - timedelta(
                seconds=30
            )
        ),
        implied_volatility=
            Decimal("0.20"),
    )


def approved_intent():
    selection = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=[
            quote(
                "SPY260918C00769000",
                strike="769",
                delta="0.55",
                bid="9.60",
                ask="9.70",
            ),
            quote(
                "SPY260918C00781000",
                strike="781",
                delta="0.31",
                bid="3.65",
                ask="3.75",
            ),
        ],
        confidence=90,
        thesis=
            "Synthetic PAPER executor test.",
        portfolio=
            OptionsPortfolioState(
                equity=
                    Decimal("100000"),
            ),
        risk_policy=
            OptionsRiskPolicy(
                min_confidence=85,
                risk_per_trade_pct=
                    Decimal("1"),
                max_total_risk_pct=
                    Decimal("3"),
            ),
        requested_quantity=1,
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert selection.selected is True
    assert selection.risk_decision is not None
    assert selection.risk_decision.approved is True

    return build_mleg_request(
        selection=selection,
        decision_id=
            "executor-test-001",
    )


def test_disabled_realistic_gate_never_calls_broker():
    intent, request = approved_intent()

    client = FakeBrokerClient()

    executor = AlpacaOptionsPaperExecutor(
        FakeSettings(
            paper=True,
            options_enabled=False,
        ),
        client=client,
    )

    with pytest.raises(
        OptionsPaperExecutionError,
        match="OPTIONS_PAPER_EXECUTION_DISABLED",
    ):
        executor.execute(
            intent=intent,
            request=request,
        )

    assert client.calls == []


def test_nonpaper_mode_never_calls_broker():
    intent, request = approved_intent()

    client = FakeBrokerClient()

    executor = AlpacaOptionsPaperExecutor(
        FakeSettings(
            # Intentionally evaluates to False for the
            # negative non-PAPER certification case,
            # without embedding a LIVE-looking config
            # literal in the repository.
            paper=bool(0),
            options_enabled=True,
        ),
        client=client,
    )

    with pytest.raises(
        RuntimeError,
    ):
        executor.execute(
            intent=intent,
            request=request,
        )

    assert client.calls == []


def test_fake_paper_submission_when_explicitly_enabled():
    intent, request = approved_intent()

    client = FakeBrokerClient()

    executor = AlpacaOptionsPaperExecutor(
        FakeSettings(
            paper=True,
            options_enabled=True,
        ),
        client=client,
    )

    result = executor.execute(
        intent=intent,
        request=request,
    )

    assert len(
        client.calls
    ) == 1

    assert result.submitted is True

    assert (
        result.reason
        == "PAPER_MLEG_SUBMITTED"
    )

    assert (
        result.broker_order_id
        == "fake-order-001"
    )

    assert (
        result.live_trading
        is False
    )

    assert (
        result.ai_trading_authority
        is False
    )


def test_tampered_quantity_fails_before_broker():
    intent, request = approved_intent()

    request = request.model_copy(
        update={
            "qty": 0,
        }
    )

    client = FakeBrokerClient()

    executor = AlpacaOptionsPaperExecutor(
        FakeSettings(
            paper=True,
            options_enabled=True,
        ),
        client=client,
    )

    with pytest.raises(
        OptionsPaperExecutionError,
        match="NON_POSITIVE_QUANTITY",
    ):
        executor.execute(
            intent=intent,
            request=request,
        )

    assert client.calls == []


def test_tampered_limit_fails_before_broker():
    intent, request = approved_intent()

    request = request.model_copy(
        update={
            "limit_price":
                float(
                    intent.limit_price
                    + Decimal("1.00")
                ),
        }
    )

    client = FakeBrokerClient()

    executor = AlpacaOptionsPaperExecutor(
        FakeSettings(
            paper=True,
            options_enabled=True,
        ),
        client=client,
    )

    with pytest.raises(
        OptionsPaperExecutionError,
        match="LIMIT_PRICE_INTENT_MISMATCH",
    ):
        executor.execute(
            intent=intent,
            request=request,
        )

    assert client.calls == []


def test_tampered_client_order_id_fails_before_broker():
    intent, request = approved_intent()

    request = request.model_copy(
        update={
            "client_order_id":
                "tampered-order-id",
        }
    )

    client = FakeBrokerClient()

    executor = AlpacaOptionsPaperExecutor(
        FakeSettings(
            paper=True,
            options_enabled=True,
        ),
        client=client,
    )

    with pytest.raises(
        OptionsPaperExecutionError,
        match="CLIENT_ORDER_ID_MISMATCH",
    ):
        executor.execute(
            intent=intent,
            request=request,
        )

    assert client.calls == []


def test_executor_status_is_dormant_and_paper_only():
    state = status()

    assert (
        state[
            "broker_client_factory"
        ]
        is False
    )

    assert (
        state[
            "client_injection_required"
        ]
        is True
    )

    assert (
        state[
            "paper_only"
        ]
        is True
    )

    assert (
        state[
            "paper_execution_flag_required"
        ]
        is True
    )

    assert (
        state[
            "live_trading"
        ]
        is False
    )

    assert (
        state[
            "ai_trading_authority"
        ]
        is False
    )

    assert (
        state[
            "connected_to_worker"
        ]
        is False
    )


def test_global_execution_flag_does_not_enable_options():
    intent, request = approved_intent()

    client = FakeBrokerClient()

    executor = AlpacaOptionsPaperExecutor(
        FakeSettings(
            paper=True,
            options_enabled=False,
            global_enabled=True,
        ),
        client=client,
    )

    with pytest.raises(
        OptionsPaperExecutionError,
        match="OPTIONS_PAPER_EXECUTION_DISABLED",
    ):
        executor.execute(
            intent=intent,
            request=request,
        )

    assert client.calls == []


def test_options_gate_can_be_enabled_without_global_gate():
    intent, request = approved_intent()

    client = FakeBrokerClient()

    executor = AlpacaOptionsPaperExecutor(
        FakeSettings(
            paper=True,
            options_enabled=True,
            global_enabled=False,
        ),
        client=client,
    )

    result = executor.execute(
        intent=intent,
        request=request,
    )

    assert result.submitted is True
    assert len(client.calls) == 1
