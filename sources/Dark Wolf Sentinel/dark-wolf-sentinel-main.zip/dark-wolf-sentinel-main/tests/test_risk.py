from app.models import (
    AssetClass,
    PortfolioState,
    TradeCandidate,
)
from app.risk import (
    RiskPolicy,
    evaluate_trade,
)


POLICY = RiskPolicy(
    min_confidence=85,
    risk_per_trade_pct=1,
    max_total_risk_pct=3,
    max_crypto_risk_pct=1,
    max_exposure_pct=60,
    max_position_pct=20,
)


def candidate(
    *,
    confidence: float = 90,
    asset_class: AssetClass = AssetClass.EQUITY,
) -> TradeCandidate:
    return TradeCandidate(
        symbol="AAPL",
        asset_class=asset_class,
        entry_price=100,
        stop_price=95,
        target_price=110,
        confidence=confidence,
        thesis="Test thesis",
    )


def portfolio() -> PortfolioState:
    return PortfolioState(
        equity=100_000,
    )


def test_approved_trade_has_no_live_authority():
    result = evaluate_trade(
        candidate(),
        portfolio(),
        POLICY,
    )

    assert result.approved is True
    assert result.live_order_allowed is False
    assert result.trading_authority is False
    assert result.risk_dollars <= 1000


def test_confidence_gate_is_enforced():
    result = evaluate_trade(
        candidate(confidence=84.99),
        portfolio(),
        POLICY,
    )

    assert result.approved is False
    assert (
        result.reason
        == "CONFIDENCE_BELOW_GATE"
    )


def test_kill_switch_blocks_trade():
    state = portfolio()
    state.kill_switch = True

    result = evaluate_trade(
        candidate(),
        state,
        POLICY,
    )

    assert result.approved is False
    assert (
        result.reason
        == "GLOBAL_KILL_SWITCH"
    )


def test_duplicate_symbol_blocked():
    state = portfolio()
    state.open_symbols = ["AAPL"]

    result = evaluate_trade(
        candidate(),
        state,
        POLICY,
    )

    assert result.approved is False
    assert (
        result.reason
        == "DUPLICATE_OPEN_SYMBOL"
    )


def test_crypto_risk_cap():
    item = candidate(
        asset_class=AssetClass.CRYPTO
    )

    item.symbol = "BTC/USD"

    state = portfolio()
    state.current_crypto_risk = 950

    result = evaluate_trade(
        item,
        state,
        POLICY,
    )

    assert result.approved is True

    assert (
        result.crypto_risk_after
        <= 1000
    )


def test_invalid_stop_blocked():
    item = candidate()
    item.stop_price = 101

    result = evaluate_trade(
        item,
        portfolio(),
        POLICY,
    )

    assert result.approved is False
    assert (
        result.reason
        == "INVALID_LONG_STOP"
    )
