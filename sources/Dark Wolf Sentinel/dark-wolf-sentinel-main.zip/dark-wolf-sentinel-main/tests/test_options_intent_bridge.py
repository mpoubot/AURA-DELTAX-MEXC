from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal

from app.options_intent_bridge import (
    build_shadow_order_intent,
    status,
)
from app.options_selector import (
    OptionDirection,
    OptionQuoteCandidate,
    select_debit_vertical,
)
from app.options_verticals import (
    OptionContractSpec,
    OptionRight,
    OptionsPortfolioState,
    OptionsRiskPolicy,
)


TODAY = date(
    2026,
    8,
    28,
)

NOW = datetime(
    2026,
    8,
    28,
    16,
    30,
    tzinfo=timezone.utc,
)


def quote(
    symbol: str,
    strike: str,
    delta: str,
    bid: str,
    ask: str,
) -> OptionQuoteCandidate:
    return OptionQuoteCandidate(
        contract=OptionContractSpec(
            symbol=symbol,
            underlying="SPY",
            right=OptionRight.CALL,
            strike=Decimal(strike),
            expiration=(
                TODAY
                + timedelta(
                    days=21
                )
            ),
            multiplier=Decimal("100"),
            tradable=True,
            source="SYNTHETIC",
        ),
        bid=Decimal(bid),
        ask=Decimal(ask),
        delta=Decimal(delta),
        bid_size=50,
        ask_size=50,
        latest_quote_at=NOW,
        latest_trade_at=(
            NOW
            - timedelta(
                seconds=30
            )
        ),
        implied_volatility=
            Decimal("0.20"),
    )


def approved_shadow():
    selection = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=[
            quote(
                "SPY260918C00769000",
                "769",
                "0.55",
                "9.60",
                "9.70",
            ),
            quote(
                "SPY260918C00781000",
                "781",
                "0.31",
                "3.65",
                "3.75",
            ),
        ],
        confidence=90,
        thesis="Synthetic bridge test.",
        portfolio=
            OptionsPortfolioState(
                equity=
                    Decimal("100000"),
            ),
        risk_policy=
            OptionsRiskPolicy(
                min_confidence=85,
                risk_per_trade_pct=
                    Decimal("1"),
                max_total_risk_pct=
                    Decimal("3"),
            ),
        requested_quantity=1,
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert selection.selected is True
    assert selection.risk_decision is not None
    assert selection.risk_decision.approved is True

    return {
        "status": "OK",
        "selection": selection.model_dump(
            mode="json"
        ),
        "trading_authority": False,
        "order_authority": False,
        "execution_effect": False,
    }


def test_pass_creates_no_intent():
    result = build_shadow_order_intent(
        options_shadow={
            "status": "SKIPPED_PASS",
            "trading_authority": False,
            "order_authority": False,
            "execution_effect": False,
        },
        decision_id="pass-001",
    )

    assert result is None


def test_approved_shadow_creates_inert_mleg():
    result = build_shadow_order_intent(
        options_shadow=approved_shadow(),
        decision_id="buy-001",
    )

    assert result is not None

    assert (
        result["status"]
        == "READY_INERT"
    )

    payload = result[
        "request_payload"
    ]

    assert (
        payload["order_class"]
        == "mleg"
    )

    assert (
        payload["type"]
        == "limit"
    )

    assert (
        payload["time_in_force"]
        == "day"
    )

    assert len(
        payload["legs"]
    ) == 2

    assert (
        result["trading_authority"]
        is False
    )

    assert (
        result[
            "order_submission_authority"
        ]
        is False
    )

    assert (
        result["broker_connection"]
        is False
    )

    assert (
        result["execution_effect"]
        is False
    )


def test_degraded_shadow_creates_no_request():
    result = build_shadow_order_intent(
        options_shadow={
            "status": "DEGRADED",
            "trading_authority": False,
            "order_authority": False,
            "execution_effect": False,
        },
        decision_id="degraded-001",
    )

    assert result is not None

    assert (
        result["status"]
        == "SKIPPED"
    )

    assert (
        result["request_payload"]
        is None
    )


def test_authority_tampering_fails_closed():
    shadow = approved_shadow()

    shadow[
        "order_authority"
    ] = True

    result = build_shadow_order_intent(
        options_shadow=shadow,
        decision_id="tamper-001",
    )

    assert result is not None

    assert (
        result["status"]
        == "DEGRADED"
    )

    assert (
        result["request_payload"]
        is None
    )


def test_status_has_zero_effect_authority():
    state = status()

    assert (
        state["pass_creates_intent"]
        is False
    )

    assert (
        state["risk_approval_required"]
        is True
    )

    assert (
        state["executor_dependency"]
        is False
    )

    assert (
        state["trading_authority"]
        is False
    )

    assert (
        state[
            "order_submission_authority"
        ]
        is False
    )

    assert (
        state["broker_connection"]
        is False
    )

    assert (
        state["execution_effect"]
        is False
    )
