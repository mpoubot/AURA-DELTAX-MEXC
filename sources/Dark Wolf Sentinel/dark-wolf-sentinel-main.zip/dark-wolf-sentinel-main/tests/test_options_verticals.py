from datetime import date
from decimal import Decimal

from app.options_verticals import (
    OptionContractSpec,
    OptionLeg,
    OptionRight,
    OptionsPortfolioState,
    OptionsRiskPolicy,
    PositionSide,
    VerticalSpreadProposal,
    VerticalSpreadType,
    calculate_vertical_risk,
    evaluate_vertical_risk,
    status,
)


EXPIRY = date(
    2030,
    1,
    18,
)


def contract(
    symbol: str,
    *,
    underlying: str = "TEST",
    right: OptionRight,
    strike: str,
) -> OptionContractSpec:
    return OptionContractSpec(
        symbol=symbol,
        underlying=underlying,
        right=right,
        strike=Decimal(strike),
        expiration=EXPIRY,
        multiplier=Decimal("100"),
        tradable=True,
        source="SYNTHETIC_TEST",
    )


def proposal(
    *,
    long_contract: OptionContractSpec,
    short_contract: OptionContractSpec,
    long_premium: str,
    short_premium: str,
    quantity: int = 1,
    confidence: float = 90,
) -> VerticalSpreadProposal:
    return VerticalSpreadProposal(
        long_leg=OptionLeg(
            contract=long_contract,
            side=PositionSide.LONG,
            premium=Decimal(
                long_premium
            ),
        ),
        short_leg=OptionLeg(
            contract=short_contract,
            side=PositionSide.SHORT,
            premium=Decimal(
                short_premium
            ),
        ),
        quantity=quantity,
        confidence=confidence,
        thesis="Synthetic vertical test.",
    )


def default_policy() -> OptionsRiskPolicy:
    return OptionsRiskPolicy(
        min_confidence=85,
        risk_per_trade_pct=
            Decimal("1"),
        max_total_risk_pct=
            Decimal("3"),
    )


def default_portfolio(
    *,
    current_open_risk: str = "0",
) -> OptionsPortfolioState:
    return OptionsPortfolioState(
        equity=Decimal("100000"),
        current_open_risk=
            Decimal(
                current_open_risk
            ),
    )


def test_bull_call_debit_math():
    p = proposal(
        long_contract=contract(
            "TESTC100",
            right=OptionRight.CALL,
            strike="100",
        ),
        short_contract=contract(
            "TESTC105",
            right=OptionRight.CALL,
            strike="105",
        ),
        long_premium="4.00",
        short_premium="2.00",
    )

    m = calculate_vertical_risk(
        p
    )

    assert (
        m.spread_type
        == VerticalSpreadType
        .BULL_CALL_DEBIT
    )

    assert (
        m.width
        == Decimal("5.00")
    )

    assert (
        m.net_debit_per_share
        == Decimal("2.00")
    )

    assert (
        m.max_loss_per_spread
        == Decimal("200.00")
    )

    assert (
        m.max_profit_per_spread
        == Decimal("300.00")
    )

    assert (
        m.breakeven
        == Decimal("102.00")
    )


def test_bear_put_debit_math():
    p = proposal(
        long_contract=contract(
            "TESTP100",
            right=OptionRight.PUT,
            strike="100",
        ),
        short_contract=contract(
            "TESTP95",
            right=OptionRight.PUT,
            strike="95",
        ),
        long_premium="4.00",
        short_premium="2.00",
    )

    m = calculate_vertical_risk(
        p
    )

    assert (
        m.spread_type
        == VerticalSpreadType
        .BEAR_PUT_DEBIT
    )

    assert (
        m.max_loss_per_spread
        == Decimal("200.00")
    )

    assert (
        m.max_profit_per_spread
        == Decimal("300.00")
    )

    assert (
        m.breakeven
        == Decimal("98.00")
    )


def test_bull_put_credit_math():
    p = proposal(
        long_contract=contract(
            "TESTP95",
            right=OptionRight.PUT,
            strike="95",
        ),
        short_contract=contract(
            "TESTP100",
            right=OptionRight.PUT,
            strike="100",
        ),
        long_premium="1.00",
        short_premium="2.50",
    )

    m = calculate_vertical_risk(
        p
    )

    assert (
        m.spread_type
        == VerticalSpreadType
        .BULL_PUT_CREDIT
    )

    assert (
        m.net_credit_per_share
        == Decimal("1.50")
    )

    assert (
        m.max_loss_per_spread
        == Decimal("350.00")
    )

    assert (
        m.max_profit_per_spread
        == Decimal("150.00")
    )

    assert (
        m.breakeven
        == Decimal("98.50")
    )


def test_bear_call_credit_math():
    p = proposal(
        long_contract=contract(
            "TESTC105",
            right=OptionRight.CALL,
            strike="105",
        ),
        short_contract=contract(
            "TESTC100",
            right=OptionRight.CALL,
            strike="100",
        ),
        long_premium="1.00",
        short_premium="2.50",
    )

    m = calculate_vertical_risk(
        p
    )

    assert (
        m.spread_type
        == VerticalSpreadType
        .BEAR_CALL_CREDIT
    )

    assert (
        m.max_loss_per_spread
        == Decimal("350.00")
    )

    assert (
        m.max_profit_per_spread
        == Decimal("150.00")
    )

    assert (
        m.breakeven
        == Decimal("101.50")
    )


def test_confidence_gate_fails_closed():
    p = proposal(
        long_contract=contract(
            "TESTC100",
            right=OptionRight.CALL,
            strike="100",
        ),
        short_contract=contract(
            "TESTC105",
            right=OptionRight.CALL,
            strike="105",
        ),
        long_premium="4",
        short_premium="2",
        confidence=84,
    )

    result = evaluate_vertical_risk(
        p,
        default_portfolio(),
        default_policy(),
    )

    assert result.approved is False

    assert (
        result.reason
        == "CONFIDENCE_BELOW_GATE"
    )


def test_risk_sizing_uses_max_loss():
    p = proposal(
        long_contract=contract(
            "TESTC100",
            right=OptionRight.CALL,
            strike="100",
        ),
        short_contract=contract(
            "TESTC105",
            right=OptionRight.CALL,
            strike="105",
        ),
        long_premium="4",
        short_premium="2",
        quantity=10,
    )

    result = evaluate_vertical_risk(
        p,
        default_portfolio(),
        default_policy(),
    )

    # $100k * 1% = $1,000 trade-risk cap.
    # Each spread max loss = $200.
    assert result.approved is True

    assert (
        result.max_contracts_by_risk
        == 5
    )

    assert (
        result.approved_quantity
        == 5
    )

    assert (
        result.approved_max_loss
        == Decimal("1000.00")
    )


def test_total_risk_cap_is_shared():
    p = proposal(
        long_contract=contract(
            "TESTC100",
            right=OptionRight.CALL,
            strike="100",
        ),
        short_contract=contract(
            "TESTC105",
            right=OptionRight.CALL,
            strike="105",
        ),
        long_premium="4",
        short_premium="2",
        quantity=10,
    )

    result = evaluate_vertical_risk(
        p,
        default_portfolio(
            current_open_risk="2800",
        ),
        default_policy(),
    )

    # 3% total cap = $3,000,
    # only $200 remains.
    assert result.approved is True

    assert (
        result.max_contracts_by_risk
        == 1
    )

    assert (
        result.approved_quantity
        == 1
    )

    assert (
        result.projected_total_open_risk
        == Decimal("3000.00")
    )


def test_invalid_vertical_fails_closed():
    p = proposal(
        long_contract=contract(
            "TESTC100",
            right=OptionRight.CALL,
            strike="100",
        ),
        short_contract=contract(
            "TESTC105",
            right=OptionRight.CALL,
            strike="105",
        ),
        long_premium="1",
        short_premium="2",
    )

    result = evaluate_vertical_risk(
        p,
        default_portfolio(),
        default_policy(),
    )

    assert result.approved is False

    assert result.reason.startswith(
        "INVALID_VERTICAL:"
    )


def test_no_authority_surface():
    state = status()

    assert (
        state[
            "defined_risk_only"
        ]
        is True
    )

    assert (
        state[
            "broker_connection"
        ]
        is False
    )

    assert (
        state[
            "trading_authority"
        ]
        is False
    )

    assert (
        state[
            "order_authority"
        ]
        is False
    )

    assert (
        state[
            "execution_effect"
        ]
        is False
    )
