from types import SimpleNamespace

import app.execution_journal as journal

from app.broker.alpaca_executor import (
    AlpacaPaperExecutor,
    client_order_id_for,
)
from app.models import (
    AssetClass,
    RiskDecision,
    TradeCandidate,
)


class FakeSettings:
    def __init__(
        self,
        enabled: bool,
    ):
        self.alpaca_paper = True
        self.alpaca_configured = True
        self.alpaca_api_key = "paper-test"
        self.alpaca_secret_key = "paper-test"
        self.paper_execution_enabled = enabled

    def assert_paper_only(self):
        assert self.alpaca_paper is True


class FakeClient:
    def __init__(self):
        self.submit_calls = 0
        self.get_calls = 0

    def submit_order(
        self,
        *,
        order_data,
    ):
        self.submit_calls += 1

        return SimpleNamespace(
            id="broker-order-1",
            client_order_id=
                order_data.client_order_id,
            symbol=order_data.symbol,
            status="accepted",
            side="buy",
            qty=order_data.qty,
            filled_qty=0,
            filled_avg_price=None,
        )

    def get_order_by_id(
        self,
        order_id,
    ):
        self.get_calls += 1

        assert order_id == "broker-order-1"

        return SimpleNamespace(
            id="broker-order-1",
            client_order_id=
                self.last_client_order_id,
            symbol="AAPL",
            status="filled",
            side="buy",
            qty=10,
            filled_qty=10,
            filled_avg_price=100.25,
        )


def candidate():
    return TradeCandidate(
        symbol="AAPL",
        asset_class=AssetClass.EQUITY,
        entry_price=100,
        stop_price=95,
        target_price=110,
        confidence=92,
        thesis="Execution test",
    )


def decision():
    return RiskDecision(
        approved=True,
        reason=
            "APPROVED_BY_DETERMINISTIC_RISK",
        symbol="AAPL",
        quantity=10,
        position_value=1000,
        risk_dollars=50,
        risk_pct_equity=0.05,
        exposure_after=1000,
        total_risk_after=50,
        crypto_risk_after=0,
        live_order_allowed=False,
        trading_authority=False,
    )


def reset_db(
    tmp_path,
):
    journal.DB_PATH = (
        tmp_path
        / "execution.db"
    )


def test_client_order_id_is_deterministic():
    a = client_order_id_for(
        "decision-123"
    )

    b = client_order_id_for(
        "decision-123"
    )

    assert a == b
    assert a.startswith("dws-")
    assert len(a) < 128


def test_prepare_is_idempotent(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExecutor(
        FakeSettings(False),
        client=client,
    )

    first = executor.prepare(
        candidate=candidate(),
        decision=decision(),
        decision_id="decision-1",
    )

    second = executor.prepare(
        candidate=candidate(),
        decision=decision(),
        decision_id="decision-1",
    )

    assert (
        first["client_order_id"]
        == second["client_order_id"]
    )

    assert first["state"] == "PREPARED"


def test_rejected_risk_cannot_prepare(
    tmp_path,
):
    reset_db(tmp_path)

    blocked = decision()
    blocked.approved = False

    executor = AlpacaPaperExecutor(
        FakeSettings(False),
        client=FakeClient(),
    )

    try:
        executor.prepare(
            candidate=candidate(),
            decision=blocked,
            decision_id="decision-2",
        )
    except RuntimeError as exc:
        assert "Risk decision rejected" in str(
            exc
        )
    else:
        raise AssertionError(
            "Rejected risk prepared an order."
        )


def test_execution_disabled_blocks_network(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExecutor(
        FakeSettings(False),
        client=client,
    )

    try:
        executor.submit(
            candidate=candidate(),
            decision=decision(),
            decision_id="decision-3",
        )
    except RuntimeError as exc:
        assert (
            "PAPER execution is disabled"
            in str(exc)
        )
    else:
        raise AssertionError(
            "Disabled execution submitted."
        )

    assert client.submit_calls == 0


def test_enabled_fake_submission_is_idempotent(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExecutor(
        FakeSettings(True),
        client=client,
    )

    first = executor.submit(
        candidate=candidate(),
        decision=decision(),
        decision_id="decision-4",
    )

    second = executor.submit(
        candidate=candidate(),
        decision=decision(),
        decision_id="decision-4",
    )

    assert client.submit_calls == 1

    assert (
        first["duplicate_prevented"]
        is False
    )

    assert (
        second["duplicate_prevented"]
        is True
    )


def test_reconciliation(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExecutor(
        FakeSettings(True),
        client=client,
    )

    submitted = executor.submit(
        candidate=candidate(),
        decision=decision(),
        decision_id="decision-5",
    )

    client.last_client_order_id = (
        submitted["order"][
            "client_order_id"
        ]
    )

    result = executor.reconcile(
        decision_id="decision-5"
    )

    assert client.get_calls == 1
    assert (
        result["intent"]["state"]
        == "RECONCILED"
    )
    assert (
        result["order"]["status"]
        == "filled"
    )


def test_probe_quantity_can_be_smaller_than_risk_size(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExecutor(
        FakeSettings(True),
        client=client,
    )

    result = executor.submit(
        candidate=candidate(),
        decision=decision(),
        decision_id="probe-downsize",
        execution_quantity=0.01,
    )

    assert client.submit_calls == 1

    assert (
        float(
            result["intent"]["quantity"]
        )
        == 0.01
    )


def test_probe_quantity_cannot_exceed_risk_size(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExecutor(
        FakeSettings(True),
        client=client,
    )

    try:
        executor.submit(
            candidate=candidate(),
            decision=decision(),
            decision_id="probe-too-large",
            execution_quantity=11,
        )

    except RuntimeError as exc:
        assert (
            "exceeds risk-approved quantity"
            in str(exc)
        )

    else:
        raise AssertionError(
            "Executor exceeded risk-approved size."
        )

    assert client.submit_calls == 0
