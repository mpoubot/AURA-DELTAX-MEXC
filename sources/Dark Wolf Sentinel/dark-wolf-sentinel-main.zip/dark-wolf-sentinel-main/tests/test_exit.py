from types import SimpleNamespace

import app.exit_journal as journal

from app.broker.alpaca_exit import (
    AlpacaPaperExitExecutor,
    exit_client_order_id_for,
)


class FakeSettings:
    def __init__(
        self,
        enabled: bool,
    ):
        self.alpaca_paper = True
        self.alpaca_configured = True
        self.alpaca_api_key = "paper"
        self.alpaca_secret_key = "paper"
        self.paper_execution_enabled = enabled

    def assert_paper_only(self):
        assert self.alpaca_paper is True


class FakeClient:
    def __init__(
        self,
        held=0.01,
    ):
        self.held = held
        self.submit_calls = 0
        self.get_calls = 0

    def get_open_position(
        self,
        symbol,
    ):
        assert symbol == "AAPL"

        return SimpleNamespace(
            qty=str(self.held)
        )

    def submit_order(
        self,
        *,
        order_data,
    ):
        self.submit_calls += 1

        return SimpleNamespace(
            id="exit-order-1",
            client_order_id=
                order_data.client_order_id,
            symbol=order_data.symbol,
            status="accepted",
            side="sell",
            qty=order_data.qty,
            filled_qty=0,
            filled_avg_price=None,
        )

    def get_order_by_id(
        self,
        order_id,
    ):
        self.get_calls += 1

        assert order_id == "exit-order-1"

        return SimpleNamespace(
            id="exit-order-1",
            client_order_id=
                exit_client_order_id_for(
                    "entry-1"
                ),
            symbol="AAPL",
            status="filled",
            side="sell",
            qty=0.01,
            filled_qty=0.01,
            filled_avg_price=310,
        )


def reset_db(
    tmp_path,
):
    journal.DB_PATH = (
        tmp_path
        / "exit.db"
    )


def test_exit_id_is_deterministic():
    assert (
        exit_client_order_id_for("abc")
        ==
        exit_client_order_id_for("abc")
    )


def test_cannot_exit_more_than_held(
    tmp_path,
):
    reset_db(tmp_path)

    executor = AlpacaPaperExitExecutor(
        FakeSettings(True),
        client=FakeClient(
            held=0.01
        ),
    )

    try:
        executor.prepare(
            symbol="AAPL",
            quantity=0.02,
            entry_decision_id="entry-x",
        )

    except RuntimeError as exc:
        assert (
            "exceeds broker-confirmed"
            in str(exc)
        )

    else:
        raise AssertionError(
            "Oversized exit was accepted."
        )


def test_disabled_exit_cannot_submit(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExitExecutor(
        FakeSettings(False),
        client=client,
    )

    try:
        executor.submit(
            symbol="AAPL",
            quantity=0.01,
            entry_decision_id="entry-y",
        )

    except RuntimeError as exc:
        assert (
            "PAPER execution is disabled"
            in str(exc)
        )

    else:
        raise AssertionError(
            "Disabled exit submitted."
        )

    assert client.submit_calls == 0


def test_exit_submission_idempotent(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExitExecutor(
        FakeSettings(True),
        client=client,
    )

    first = executor.submit(
        symbol="AAPL",
        quantity=0.01,
        entry_decision_id="entry-z",
    )

    second = executor.submit(
        symbol="AAPL",
        quantity=0.01,
        entry_decision_id="entry-z",
    )

    assert client.submit_calls == 1

    assert (
        first["duplicate_prevented"]
        is False
    )

    assert (
        second["duplicate_prevented"]
        is True
    )


def test_exit_reconciliation(
    tmp_path,
):
    reset_db(tmp_path)

    client = FakeClient()

    executor = AlpacaPaperExitExecutor(
        FakeSettings(True),
        client=client,
    )

    # Use entry-1 to match fake reconciliation ID.
    executor.submit(
        symbol="AAPL",
        quantity=0.01,
        entry_decision_id="entry-1",
    )

    result = executor.reconcile(
        entry_decision_id="entry-1"
    )

    assert client.get_calls == 1

    assert (
        result["intent"]["state"]
        == "RECONCILED"
    )

    assert (
        result["order"]["status"]
        == "filled"
    )
