from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal

import pytest

from alpaca.trading.enums import (
    PositionSide,
)

from app.options_lifecycle import (
    BrokerOptionPosition,
    LifecycleAction,
    OptionsLifecycleError,
    OptionsLifecyclePolicy,
    OptionsPositionRecord,
    build_close_mleg_intent,
    evaluate_lifecycle,
    reconcile_broker_positions,
    status,
)
from app.options_verticals import (
    VerticalSpreadType,
)


NOW = datetime(
    2026,
    8,
    28,
    17,
    0,
    tzinfo=timezone.utc,
)


def record():
    return OptionsPositionRecord(
        record_id=
            "spread-001",
        underlying="SPY",
        spread_type=
            VerticalSpreadType
            .BULL_CALL_DEBIT,
        long_symbol=
            "SPY260918C00769000",
        short_symbol=
            "SPY260918C00781000",
        quantity=1,
        expiration=date(
            2026,
            9,
            18,
        ),
        opened_at=NOW,
        thesis_expires_at=(
            NOW
            + timedelta(
                days=10
            )
        ),
        entry_debit=
            Decimal("5.00"),
        width=
            Decimal("12.00"),
        max_loss_per_spread=
            Decimal("500.00"),
        max_profit_per_spread=
            Decimal("700.00"),
    )


def positions():
    return [
        BrokerOptionPosition(
            symbol=
                "SPY260918C00769000",
            side=
                PositionSide.LONG,
            quantity=1,
        ),
        BrokerOptionPosition(
            symbol=
                "SPY260918C00781000",
            side=
                PositionSide.SHORT,
            quantity=1,
        ),
    ]


def policy():
    return OptionsLifecyclePolicy(
        profit_capture_pct=
            Decimal("50"),
        stop_loss_pct_of_debit=
            Decimal("50"),
        min_dte_exit=3,
    )


def test_exact_two_leg_reconciliation():
    result = (
        reconcile_broker_positions(
            record=record(),
            positions=positions(),
        )
    )

    assert (
        result["long"].side
        == PositionSide.LONG
    )

    assert (
        result["short"].side
        == PositionSide.SHORT
    )


def test_missing_leg_fails_closed():
    with pytest.raises(
        OptionsLifecycleError,
        match="EXPECTED_EXACTLY_TWO_OPTION_POSITIONS",
    ):
        reconcile_broker_positions(
            record=record(),
            positions=[
                positions()[0]
            ],
        )


def test_wrong_short_side_fails_closed():
    broken = positions()

    broken[1] = (
        broken[1].model_copy(
            update={
                "side":
                    PositionSide.LONG,
            }
        )
    )

    with pytest.raises(
        OptionsLifecycleError,
        match="SHORT_LEG_BROKER_SIDE_MISMATCH",
    ):
        reconcile_broker_positions(
            record=record(),
            positions=broken,
        )


def test_quantity_mismatch_fails_closed():
    broken = positions()

    broken[0] = (
        broken[0].model_copy(
            update={
                "quantity": 2,
            }
        )
    )

    with pytest.raises(
        OptionsLifecycleError,
        match="LONG_LEG_QUANTITY_MISMATCH",
    ):
        reconcile_broker_positions(
            record=record(),
            positions=broken,
        )


def test_hold_decision():
    result = evaluate_lifecycle(
        record=record(),
        positions=positions(),
        close_credit=
            Decimal("6.00"),
        policy=policy(),
        as_of=(
            NOW
            + timedelta(
                days=1
            )
        ),
    )

    assert (
        result.action
        == LifecycleAction.HOLD
    )

    assert result.exit_required is False

    assert (
        result.profit_target_credit
        == Decimal("8.50")
    )

    assert (
        result.stop_credit
        == Decimal("2.500")
    )


def test_profit_target_exit():
    result = evaluate_lifecycle(
        record=record(),
        positions=positions(),
        close_credit=
            Decimal("9.00"),
        policy=policy(),
        as_of=(
            NOW
            + timedelta(
                days=1
            )
        ),
    )

    assert (
        result.action
        == LifecycleAction.EXIT_PROFIT
    )

    assert result.exit_required is True


def test_stop_loss_exit():
    result = evaluate_lifecycle(
        record=record(),
        positions=positions(),
        close_credit=
            Decimal("2.00"),
        policy=policy(),
        as_of=(
            NOW
            + timedelta(
                days=1
            )
        ),
    )

    assert (
        result.action
        == LifecycleAction.EXIT_STOP
    )

    assert result.exit_required is True


def test_thesis_expiry_exit_has_priority():
    result = evaluate_lifecycle(
        record=record(),
        positions=positions(),
        close_credit=
            Decimal("9.00"),
        policy=policy(),
        as_of=(
            NOW
            + timedelta(
                days=11
            )
        ),
    )

    assert (
        result.action
        == LifecycleAction
        .EXIT_THESIS_EXPIRED
    )

    assert (
        result.reason
        == "THESIS_EXPIRED"
    )


def test_dte_exit():
    # Isolate the DTE rule. The shared fixture's
    # normal thesis expiry occurs earlier and is
    # intentionally higher priority than DTE.
    dte_record = record().model_copy(
        update={
            "thesis_expires_at":
                datetime(
                    2026,
                    9,
                    17,
                    17,
                    0,
                    tzinfo=timezone.utc,
                )
        }
    )

    result = evaluate_lifecycle(
        record=dte_record,
        positions=positions(),
        close_credit=
            Decimal("6.00"),
        policy=policy(),
        as_of=datetime(
            2026,
            9,
            15,
            17,
            0,
            tzinfo=timezone.utc,
        ),
    )

    assert (
        result.action
        == LifecycleAction.EXIT_DTE
    )

    assert result.dte == 3


def test_invalid_credit_above_width_fails():
    with pytest.raises(
        OptionsLifecycleError,
        match="CLOSE_CREDIT_EXCEEDS_SPREAD_WIDTH",
    ):
        evaluate_lifecycle(
            record=record(),
            positions=positions(),
            close_credit=
                Decimal("12.01"),
            policy=policy(),
            as_of=NOW,
        )


def exit_decision():
    return evaluate_lifecycle(
        record=record(),
        positions=positions(),
        close_credit=
            Decimal("9.00"),
        policy=policy(),
        as_of=(
            NOW
            + timedelta(
                days=1
            )
        ),
    )


def test_close_intent_uses_negative_credit():
    intent, request = (
        build_close_mleg_intent(
            record=record(),
            decision=
                exit_decision(),
            close_credit_limit=
                Decimal("8.75"),
            decision_id=
                "profit-close-001",
        )
    )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    assert (
        intent.close_credit
        == Decimal("8.75")
    )

    assert (
        intent.alpaca_limit_price
        == Decimal("-8.75")
    )

    assert (
        payload["limit_price"]
        == -8.75
    )

    assert (
        payload["order_class"]
        == "mleg"
    )

    assert len(
        payload["legs"]
    ) == 2

    assert (
        payload["legs"][0]["side"]
        == "sell"
    )

    assert (
        payload["legs"][0][
            "position_intent"
        ]
        == "sell_to_close"
    )

    assert (
        payload["legs"][1]["side"]
        == "buy"
    )

    assert (
        payload["legs"][1][
            "position_intent"
        ]
        == "buy_to_close"
    )

    assert intent.trading_authority is False
    assert (
        intent.order_submission_authority
        is False
    )
    assert intent.broker_connection is False
    assert intent.execution_effect is False


def test_hold_cannot_build_close_intent():
    decision = evaluate_lifecycle(
        record=record(),
        positions=positions(),
        close_credit=
            Decimal("6.00"),
        policy=policy(),
        as_of=(
            NOW
            + timedelta(
                days=1
            )
        ),
    )

    with pytest.raises(
        OptionsLifecycleError,
        match="EXIT_NOT_REQUIRED",
    ):
        build_close_mleg_intent(
            record=record(),
            decision=decision,
            close_credit_limit=
                Decimal("6.00"),
            decision_id=
                "hold-close-forbidden",
        )


def test_non_cent_credit_rejected():
    with pytest.raises(
        OptionsLifecycleError,
        match="CLOSE_CREDIT_MUST_BE_CENT_DENOMINATED",
    ):
        build_close_mleg_intent(
            record=record(),
            decision=
                exit_decision(),
            close_credit_limit=
                Decimal("8.755"),
            decision_id=
                "bad-credit-precision",
        )


def test_positive_internal_credit_maps_negative_alpaca_limit():
    intent, _ = build_close_mleg_intent(
        record=record(),
        decision=
            exit_decision(),
        close_credit_limit=
            Decimal("7.00"),
        decision_id=
            "credit-sign-proof",
    )

    assert intent.close_credit > 0
    assert intent.alpaca_limit_price < 0


def test_status_has_no_authority_and_no_policy_default():
    state = status()

    assert (
        state[
            "production_exit_policy_configured"
        ]
        is False
    )

    assert (
        state[
            "exact_two_leg_reconciliation"
        ]
        is True
    )

    assert (
        state[
            "pricing_policy_embedded"
        ]
        is False
    )

    assert (
        state["trading_authority"]
        is False
    )

    assert (
        state[
            "order_submission_authority"
        ]
        is False
    )

    assert (
        state["broker_connection"]
        is False
    )

    assert (
        state["execution_effect"]
        is False
    )
