from types import SimpleNamespace
from pathlib import Path

import pytest

from app.agent.bridge import (
    proposal_to_candidate,
)
from app.agent.models import (
    AgentAction,
    AgentProposal,
    MarketContext,
)
from app.agent.openai_agent import (
    OpenAITradingAgent,
)
from app.models import AssetClass


class FakeSettings:
    openai_configured = True
    openai_api_key = "fake"
    openai_model = "gpt-5.6"


class FakeResponses:
    def __init__(
        self,
        output_text: str,
    ):
        self.output_text = output_text
        self.calls = []

    def create(
        self,
        **kwargs,
    ):
        self.calls.append(kwargs)

        return SimpleNamespace(
            output_text=
                self.output_text
        )


class FakeClient:
    def __init__(
        self,
        output_text: str,
    ):
        self.responses = FakeResponses(
            output_text
        )


def context():
    return MarketContext(
        symbol="AAPL",
        asset_class="equity",
        current_price=310,
        timeframe="15m",
        market_regime="TREND",
        trend="UP",
        rsi=61,
        ema20=307,
        ema50=302,
        prior_high=309,
        volume_ratio=1.2,
        news_context=[
            "Synthetic unit-test context"
        ],
    )


def test_buy_proposal_parses():
    client = FakeClient(
        '''
        {
          "action": "BUY",\n          "thesis_expires_at": "2099-01-01T00:00:00+00:00",
          "symbol": "AAPL",
          "confidence": 92,
          "entry_price": 310,
          "stop_price": 304,
          "target_price": 322,
          "thesis": "Trend continuation.",
          "catalyst": "Momentum.",
          "invalidation": "Loss of support.",
          "risk_notes": "Volatility elevated.",
          "trading_authority": false,
          "live_order_allowed": false
        }
        '''
    )

    agent = OpenAITradingAgent(
        FakeSettings(),
        client=client,
    )

    result = agent.analyze(
        context()
    )

    assert result.action == AgentAction.BUY
    assert result.confidence == 92
    assert result.trading_authority is False
    assert result.live_order_allowed is False


def test_agent_quantity_is_discarded():
    client = FakeClient(
        '''
        {
          "action": "BUY",\n          "thesis_expires_at": "2099-01-01T00:00:00+00:00",
          "symbol": "AAPL",
          "confidence": 92,
          "entry_price": 310,
          "stop_price": 304,
          "target_price": 322,
          "thesis": "Trend continuation.",
          "catalyst": "Momentum.",
          "invalidation": "Support failure.",
          "risk_notes": "Test.",
          "quantity": 999999,
          "dollar_amount": 99999999,
          "trading_authority": true,
          "live_order_allowed": true
        }
        '''
    )

    agent = OpenAITradingAgent(
        FakeSettings(),
        client=client,
    )

    result = agent.analyze(
        context()
    )

    assert result.requested_quantity is None
    assert result.trading_authority is False
    assert result.live_order_allowed is False


def test_pass_does_not_create_candidate():
    proposal = AgentProposal(
        action=AgentAction.PASS,
        symbol="AAPL",
        confidence=40,
        thesis="Insufficient evidence.",
        trading_authority=False,
        live_order_allowed=False,

                   thesis_expires_at=None,)

    result = proposal_to_candidate(
        proposal,
        asset_class=AssetClass.EQUITY,
    )

    assert result is None


def test_buy_becomes_untrusted_candidate():
    proposal = AgentProposal(
        action=AgentAction.BUY,
        symbol="AAPL",
        confidence=90,
        entry_price=310,
        stop_price=304,
        target_price=322,
        thesis="Test.",
        trading_authority=False,
        live_order_allowed=False,

                   thesis_expires_at="2099-01-01T00:00:00+00:00",)

    candidate = proposal_to_candidate(
        proposal,
        asset_class=AssetClass.EQUITY,
    )

    assert candidate is not None
    assert candidate.confidence == 90

    # No quantity exists in TradeCandidate.
    assert not hasattr(
        candidate,
        "quantity",
    )


def test_invalid_long_prices_rejected():
    with pytest.raises(
        ValueError
    ):
        AgentProposal(
            action=AgentAction.BUY,
            symbol="AAPL",
            confidence=90,
            entry_price=310,
            stop_price=315,
            target_price=322,
            thesis="Invalid.",

            thesis_expires_at="2099-01-01T00:00:00+00:00",)


def test_agent_source_has_no_execution_import():
    source = Path(
        "app/agent/openai_agent.py"
    ).read_text()

    forbidden = [
        "alpaca_executor",
        "alpaca_exit",
        "submit_order(",
        "cancel_order(",
        "close_position(",
    ]

    for item in forbidden:
        assert item not in source


def test_bearish_proposal_parses():
    client = FakeClient(
        '''
        {
          "action": "BEARISH",\n          "thesis_expires_at": "2099-01-01T00:00:00+00:00",
          "symbol": "AAPL",
          "confidence": 91,
          "entry_price": null,
          "stop_price": null,
          "target_price": null,
          "thesis": "Downside thesis.",
          "catalyst": "Weakening momentum.",
          "invalidation": "Trend recovery.",
          "risk_notes": "Options analysis only.",
          "trading_authority": false,
          "live_order_allowed": false
        }
        '''
    )

    agent = OpenAITradingAgent(
        FakeSettings(),
        client=client,
    )

    result = agent.analyze(
        context()
    )

    assert result.action == AgentAction.BEARISH
    assert result.entry_price is None
    assert result.stop_price is None
    assert result.target_price is None
    assert result.trading_authority is False
    assert result.live_order_allowed is False


def test_bearish_does_not_create_equity_candidate():
    proposal = AgentProposal(
        action=AgentAction.BEARISH,
        symbol="AAPL",
        confidence=91,
        thesis="Bearish options-only test.",
        trading_authority=False,
        live_order_allowed=False,

                   thesis_expires_at="2099-01-01T00:00:00+00:00",)

    result = proposal_to_candidate(
        proposal,
        asset_class=AssetClass.EQUITY,
    )

    assert result is None


def test_bearish_rejects_equity_price_levels():
    with pytest.raises(
        ValueError
    ):
        AgentProposal(
            action=AgentAction.BEARISH,
            symbol="AAPL",
            confidence=91,
            entry_price=310,
            stop_price=315,
            target_price=290,
            thesis="Invalid bearish equity levels.",
            trading_authority=False,
            live_order_allowed=False,

            thesis_expires_at="2099-01-01T00:00:00+00:00",)


def test_buy_requires_explicit_thesis_expiry():
    with pytest.raises(
        ValueError,
        match="requires thesis_expires_at",
    ):
        AgentProposal(
            action=AgentAction.BUY,
            symbol="SPY",
            confidence=90,
            entry_price=500,
            stop_price=490,
            target_price=520,
            thesis="Missing expiry must fail.",
            trading_authority=False,
            live_order_allowed=False,
        )


def test_bearish_requires_explicit_thesis_expiry():
    with pytest.raises(
        ValueError,
        match="requires thesis_expires_at",
    ):
        AgentProposal(
            action=AgentAction.BEARISH,
            symbol="SPY",
            confidence=90,
            thesis="Missing bearish expiry must fail.",
            trading_authority=False,
            live_order_allowed=False,
        )


def test_thesis_expiry_must_be_timezone_aware():
    with pytest.raises(
        ValueError,
        match="timezone-aware",
    ):
        AgentProposal(
            action=AgentAction.BEARISH,
            symbol="SPY",
            confidence=90,
            thesis="Naive timestamp must fail.",
            thesis_expires_at=
                "2099-01-01T00:00:00",
            trading_authority=False,
            live_order_allowed=False,
        )


def test_pass_requires_null_thesis_expiry():
    with pytest.raises(
        ValueError,
        match="PASS proposal thesis expiration must be null",
    ):
        AgentProposal(
            action=AgentAction.PASS,
            symbol="SPY",
            confidence=20,
            thesis="No actionable thesis.",
            thesis_expires_at=
                "2099-01-01T00:00:00+00:00",
            trading_authority=False,
            live_order_allowed=False,
        )


def test_valid_buy_parses_timezone_aware_thesis_expiry():
    proposal = AgentProposal(
        action=AgentAction.BUY,
        symbol="SPY",
        confidence=90,
        entry_price=500,
        stop_price=490,
        target_price=520,
        thesis="Valid expiring thesis.",
        thesis_expires_at=
            "2099-01-01T00:00:00+00:00",
        trading_authority=False,
        live_order_allowed=False,
    )

    assert (
        proposal.thesis_expires_at
        is not None
    )

    assert (
        proposal
        .thesis_expires_at
        .utcoffset()
        is not None
    )
