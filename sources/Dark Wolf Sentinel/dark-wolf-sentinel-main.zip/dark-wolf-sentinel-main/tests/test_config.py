import pytest

from app.config import Settings


def test_paper_true_allowed():
    settings = Settings(
        ALPACA_PAPER=True
    )

    settings.assert_paper_only()


def test_paper_false_refused():
    settings = Settings(
        ALPACA_PAPER=False
    )

    with pytest.raises(
        RuntimeError
    ):
        settings.assert_paper_only()
