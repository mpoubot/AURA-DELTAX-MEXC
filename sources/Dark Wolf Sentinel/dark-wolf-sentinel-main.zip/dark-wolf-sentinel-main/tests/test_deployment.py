from __future__ import annotations

import tomllib
from pathlib import Path

import pytest
from fastapi.testclient import TestClient

from app.config import Settings
from app.deployment import (
    DeploymentConfigurationError,
    validate_judge_deployment,
)
from scripts.start_judge_app import deployment_port, refresh_on_start_enabled


REPOSITORY_ROOT = Path(__file__).resolve().parents[1]


def safe_settings(**overrides):
    values = {
        "ALPACA_API_KEY": "paper-key",
        "ALPACA_SECRET_KEY": "paper-secret",
        "ALPACA_PAPER": True,
        "OPENAI_API_KEY": "openai-test-key",
        "OPENAI_MODEL": "gpt-5.6",
        "SENTINEL_PAPER_EXECUTION_ENABLED": False,
        "SENTINEL_OPTIONS_PAPER_EXECUTION_ENABLED": False,
    }
    values.update(overrides)
    return Settings(**values)


def test_replit_deployment_uses_project_virtual_environment():
    replit_config = tomllib.loads(
        (REPOSITORY_ROOT / ".replit").read_text(encoding="utf-8")
    )

    assert replit_config["modules"] == ["python-3.12"]
    assert replit_config["run"] == "python -m scripts.start_judge_app"
    assert replit_config["deployment"]["build"] == (
        "python -m venv .venv && "
        "PIP_USER=false .venv/bin/python -m pip install "
        "--no-user -r requirements.lock.txt"
    )
    assert "--break-system-packages" not in (
        replit_config["deployment"]["build"]
    )
    assert replit_config["deployment"]["run"] == (
        ".venv/bin/python -m scripts.start_judge_app"
    )
    assert ".venv/" in (
        REPOSITORY_ROOT / ".gitignore"
    ).read_text(encoding="utf-8").splitlines()


def test_safe_deployment_preserves_zero_authority(monkeypatch):
    monkeypatch.setattr("app.deployment.shutil.which", lambda name: "/uvx")

    result = validate_judge_deployment(safe_settings())

    assert result["status"] == "ready"
    assert result["alpaca_paper"] is True
    assert result["paper_execution"] is False
    assert result["options_paper_execution"] is False
    assert result["live_trading"] is False
    assert result["broker_submission"] is False
    assert result["ai_execution_authority"] is False
    assert result["mcp_trading_tools"] is False


@pytest.mark.parametrize(
    "overrides",
    [
        {"ALPACA_PAPER": False},
        {"SENTINEL_PAPER_EXECUTION_ENABLED": True},
        {"SENTINEL_OPTIONS_PAPER_EXECUTION_ENABLED": True},
        {"ALPACA_API_KEY": None},
        {"OPENAI_API_KEY": None},
        {"OPENAI_MODEL": "different-model"},
    ],
)
def test_unsafe_or_incomplete_deployment_fails_closed(
    monkeypatch,
    overrides,
):
    monkeypatch.setattr("app.deployment.shutil.which", lambda name: "/uvx")

    with pytest.raises(DeploymentConfigurationError):
        validate_judge_deployment(safe_settings(**overrides))


def test_missing_uvx_fails_closed(monkeypatch):
    monkeypatch.setattr("app.deployment.shutil.which", lambda name: None)

    with pytest.raises(DeploymentConfigurationError):
        validate_judge_deployment(safe_settings())


def test_refresh_flag_is_explicit(monkeypatch):
    monkeypatch.setenv("SENTINEL_DEPLOYMENT_REFRESH_ON_START", "true")
    assert refresh_on_start_enabled() is True

    monkeypatch.setenv("SENTINEL_DEPLOYMENT_REFRESH_ON_START", "false")
    assert refresh_on_start_enabled() is False


def test_refresh_flag_rejects_ambiguous_value(monkeypatch):
    monkeypatch.setenv("SENTINEL_DEPLOYMENT_REFRESH_ON_START", "yes")

    with pytest.raises(RuntimeError):
        refresh_on_start_enabled()


def test_deployment_port_defaults_and_allows_local_override(monkeypatch):
    monkeypatch.delenv("SENTINEL_PORT", raising=False)
    assert deployment_port() == 8000

    monkeypatch.setenv("SENTINEL_PORT", "8765")
    assert deployment_port() == 8765


@pytest.mark.parametrize("value", ["not-a-port", "0", "65536"])
def test_deployment_port_rejects_invalid_values(monkeypatch, value):
    monkeypatch.setenv("SENTINEL_PORT", value)

    with pytest.raises(RuntimeError):
        deployment_port()


def test_readiness_endpoint_is_secret_free(monkeypatch):
    import app.dashboard_server as dashboard

    monkeypatch.setattr(dashboard, "Settings", lambda: safe_settings())
    monkeypatch.setattr("app.deployment.shutil.which", lambda name: "/uvx")

    response = TestClient(dashboard.app).get("/ready")

    assert response.status_code == 200
    assert response.json()["status"] == "ready"
    assert "paper-key" not in response.text
    assert "paper-secret" not in response.text


def test_readiness_endpoint_rejects_missing_configuration(monkeypatch):
    import app.dashboard_server as dashboard

    monkeypatch.setattr(
        dashboard,
        "Settings",
        lambda: safe_settings(**{"OPENAI_API_KEY": None}),
    )
    monkeypatch.setattr("app.deployment.shutil.which", lambda name: "/uvx")

    response = TestClient(dashboard.app).get("/ready")

    assert response.status_code == 503
    assert response.json()["status"] == "not_ready"
    assert "key" not in response.text.lower()
