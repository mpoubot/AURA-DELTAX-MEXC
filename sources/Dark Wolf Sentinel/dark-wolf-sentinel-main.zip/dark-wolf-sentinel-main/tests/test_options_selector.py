from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal

from app.options_selector import (
    OptionDirection,
    OptionQuoteCandidate,
    OptionSelectorPolicy,
    adapt_alpaca_chain,
    parse_occ_contract,
    select_debit_vertical,
    status,
)
from app.options_verticals import (
    OptionContractSpec,
    OptionRight,
    OptionsPortfolioState,
    OptionsRiskPolicy,
    VerticalSpreadType,
)


TODAY = date(
    2026,
    8,
    28,
)

NOW = datetime(
    2026,
    8,
    28,
    16,
    0,
    tzinfo=timezone.utc,
)


def option(
    symbol: str,
    *,
    right: OptionRight,
    strike: str,
    dte: int,
    bid: str,
    ask: str,
    delta: str,
    volume: int = 100,
    bid_size: int = 10,
    ask_size: int = 10,
    quote_age_seconds: int = 0,
    trade_age_seconds: int = 60,
) -> OptionQuoteCandidate:
    return OptionQuoteCandidate(
        contract=OptionContractSpec(
            symbol=symbol,
            underlying="SPY",
            right=right,
            strike=Decimal(
                strike
            ),
            expiration=(
                TODAY
                + timedelta(
                    days=dte
                )
            ),
            multiplier=
                Decimal("100"),
            tradable=True,
            source="SYNTHETIC",
        ),
        bid=Decimal(
            bid
        ),
        ask=Decimal(
            ask
        ),
        delta=Decimal(
            delta
        ),
        daily_volume=volume,
        bid_size=bid_size,
        ask_size=ask_size,
        latest_quote_at=(
            NOW
            - timedelta(
                seconds=
                    quote_age_seconds
            )
        ),
        latest_trade_at=(
            NOW
            - timedelta(
                seconds=
                    trade_age_seconds
            )
        ),
        implied_volatility=
            Decimal("0.20"),
    )


def portfolio():
    return OptionsPortfolioState(
        equity=Decimal("100000"),
        current_open_risk=
            Decimal("0"),
    )


def risk_policy():
    return OptionsRiskPolicy(
        min_confidence=85,
        risk_per_trade_pct=
            Decimal("1"),
        max_total_risk_pct=
            Decimal("3"),
    )


def test_occ_parser():
    result = parse_occ_contract(
        "SPY260918C00650000"
    )

    assert (
        result.underlying
        == "SPY"
    )

    assert (
        result.expiration
        == date(
            2026,
            9,
            18,
        )
    )

    assert (
        result.right
        == OptionRight.CALL
    )

    assert (
        result.strike
        == Decimal("650")
    )

    assert (
        result.multiplier
        == Decimal("100")
    )


def test_bullish_selects_call_debit():
    chain = [
        option(
            "SPYLONG",
            right=OptionRight.CALL,
            strike="650",
            dte=21,
            bid="5.90",
            ask="6.10",
            delta="0.55",
        ),
        option(
            "SPYSHORT",
            right=OptionRight.CALL,
            strike="655",
            dte=21,
            bid="3.35",
            ask="3.45",
            delta="0.30",
        ),
        option(
            "SPYNOISE",
            right=OptionRight.CALL,
            strike="670",
            dte=21,
            bid="1.00",
            ask="1.80",
            delta="0.10",
        ),
    ]

    result = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=chain,
        confidence=90,
        thesis="Bullish test.",
        portfolio=portfolio(),
        risk_policy=
            risk_policy(),
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert result.selected is True

    assert (
        result.metrics
        .spread_type
        == VerticalSpreadType
        .BULL_CALL_DEBIT
    )

    assert (
        result.proposal
        .long_leg
        .contract
        .strike
        == Decimal("650")
    )

    assert (
        result.proposal
        .short_leg
        .contract
        .strike
        == Decimal("655")
    )

    assert (
        result.risk_decision
        .approved
        is True
    )


def test_bearish_selects_put_debit():
    chain = [
        option(
            "SPYPUTLONG",
            right=OptionRight.PUT,
            strike="650",
            dte=21,
            bid="5.90",
            ask="6.10",
            delta="-0.55",
        ),
        option(
            "SPYPUTSHORT",
            right=OptionRight.PUT,
            strike="645",
            dte=21,
            bid="3.35",
            ask="3.45",
            delta="-0.30",
        ),
    ]

    result = select_debit_vertical(
        direction=
            OptionDirection.BEARISH,
        chain=chain,
        confidence=90,
        thesis="Bearish test.",
        portfolio=portfolio(),
        risk_policy=
            risk_policy(),
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert result.selected is True

    assert (
        result.metrics
        .spread_type
        == VerticalSpreadType
        .BEAR_PUT_DEBIT
    )

    assert (
        result.risk_decision
        .approved
        is True
    )


def test_zero_dte_is_rejected():
    chain = [
        option(
            "ZERO1",
            right=OptionRight.CALL,
            strike="650",
            dte=0,
            bid="5.90",
            ask="6.10",
            delta="0.55",
        ),
        option(
            "ZERO2",
            right=OptionRight.CALL,
            strike="655",
            dte=0,
            bid="3.35",
            ask="3.45",
            delta="0.30",
        ),
    ]

    result = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=chain,
        confidence=90,
        thesis="0DTE test.",
        portfolio=portfolio(),
        risk_policy=
            risk_policy(),
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert result.selected is False

    assert (
        result.rejection_counts[
            "DTE_TOO_SHORT"
        ]
        == 2
    )


def test_wide_markets_are_rejected():
    chain = [
        option(
            "WIDE1",
            right=OptionRight.CALL,
            strike="650",
            dte=21,
            bid="2.00",
            ask="4.00",
            delta="0.55",
        ),
        option(
            "WIDE2",
            right=OptionRight.CALL,
            strike="655",
            dte=21,
            bid="1.00",
            ask="2.00",
            delta="0.30",
        ),
    ]

    result = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=chain,
        confidence=90,
        thesis="Liquidity test.",
        portfolio=portfolio(),
        risk_policy=
            risk_policy(),
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert result.selected is False

    assert (
        result.rejection_counts[
            "BID_ASK_TOO_WIDE"
        ]
        == 2
    )


def test_zero_quote_size_is_rejected():
    chain = [
        option(
            "SIZE1",
            right=OptionRight.CALL,
            strike="650",
            dte=21,
            bid="5.90",
            ask="6.10",
            delta="0.55",
            bid_size=0,
        ),
        option(
            "SIZE2",
            right=OptionRight.CALL,
            strike="655",
            dte=21,
            bid="3.35",
            ask="3.45",
            delta="0.30",
            ask_size=0,
        ),
    ]

    result = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=chain,
        confidence=90,
        thesis="Quote depth test.",
        portfolio=portfolio(),
        risk_policy=
            risk_policy(),
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert result.selected is False

    assert (
        result.rejection_counts[
            "INSUFFICIENT_QUOTE_SIZE"
        ]
        == 2
    )


def test_stale_quote_is_rejected():
    chain = [
        option(
            "STALEQ1",
            right=OptionRight.CALL,
            strike="650",
            dte=21,
            bid="5.90",
            ask="6.10",
            delta="0.55",
            quote_age_seconds=121,
        ),
        option(
            "STALEQ2",
            right=OptionRight.CALL,
            strike="655",
            dte=21,
            bid="3.35",
            ask="3.45",
            delta="0.30",
            quote_age_seconds=121,
        ),
    ]

    result = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=chain,
        confidence=90,
        thesis="Quote freshness test.",
        portfolio=portfolio(),
        risk_policy=risk_policy(),
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert result.selected is False

    assert (
        result.rejection_counts[
            "STALE_QUOTE"
        ]
        == 2
    )


def test_stale_trade_is_rejected():
    chain = [
        option(
            "STALET1",
            right=OptionRight.CALL,
            strike="650",
            dte=21,
            bid="5.90",
            ask="6.10",
            delta="0.55",
            trade_age_seconds=1801,
        ),
        option(
            "STALET2",
            right=OptionRight.CALL,
            strike="655",
            dte=21,
            bid="3.35",
            ask="3.45",
            delta="0.30",
            trade_age_seconds=1801,
        ),
    ]

    result = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=chain,
        confidence=90,
        thesis="Trade freshness test.",
        portfolio=portfolio(),
        risk_policy=risk_policy(),
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert result.selected is False

    assert (
        result.rejection_counts[
            "STALE_LAST_TRADE"
        ]
        == 2
    )


def test_confidence_still_owned_by_risk_kernel():
    chain = [
        option(
            "CONF1",
            right=OptionRight.CALL,
            strike="650",
            dte=21,
            bid="5.90",
            ask="6.10",
            delta="0.55",
        ),
        option(
            "CONF2",
            right=OptionRight.CALL,
            strike="655",
            dte=21,
            bid="3.35",
            ask="3.45",
            delta="0.30",
        ),
    ]

    result = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=chain,
        confidence=80,
        thesis="Confidence test.",
        portfolio=portfolio(),
        risk_policy=
            risk_policy(),
        as_of=TODAY,
        as_of_time=NOW,
    )

    assert result.selected is True

    assert (
        result.risk_decision
        .approved
        is False
    )

    assert (
        result.risk_decision
        .reason
        == "CONFIDENCE_BELOW_GATE"
    )


def test_status_has_no_authority():
    state = status()

    assert (
        state[
            "zero_dte_allowed"
        ]
        is False
    )

    assert (
        state[
            "trading_authority"
        ]
        is False
    )

    assert (
        state[
            "order_authority"
        ]
        is False
    )

    assert (
        state[
            "execution_effect"
        ]
        is False
    )


class FakeQuote:
    bid_price = 4.90
    ask_price = 5.10
    bid_size = 25
    ask_size = 30
    timestamp = NOW


class FakeGreeks:
    delta = 0.55


class FakeBar:
    volume = 250


class FakeTrade:
    timestamp = (
        NOW
        - timedelta(
            seconds=30
        )
    )


class FakeSnapshot:
    latest_quote = FakeQuote()
    latest_trade = FakeTrade()
    greeks = FakeGreeks()
    daily_bar = FakeBar()
    implied_volatility = 0.22


def test_alpaca_snapshot_adapter():
    chain = {
        "SPY260918C00650000":
            FakeSnapshot(),
    }

    candidates, rejected = (
        adapt_alpaca_chain(
            chain
        )
    )

    assert rejected == {}

    assert len(
        candidates
    ) == 1

    item = candidates[0]

    assert (
        item.contract.strike
        == Decimal("650")
    )

    assert (
        item.delta
        == Decimal("0.55")
    )

    assert (
        item.daily_volume
        == 250
    )

    assert (
        item.bid_size
        == 25
    )

    assert (
        item.ask_size
        == 30
    )

    assert (
        item.latest_quote_at
        == NOW
    )

    assert (
        item.latest_trade_at
        == FakeTrade.timestamp
    )


def test_selector_policy_excludes_0dte():
    policy = (
        OptionSelectorPolicy()
    )

    assert (
        policy.min_dte
        >= 1
    )
