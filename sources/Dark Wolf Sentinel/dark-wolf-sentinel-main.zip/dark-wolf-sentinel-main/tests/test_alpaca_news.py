from app.mcp.alpaca_news import (
    build_news_arguments,
    collect_headlines,
)


class FakeTool:
    inputSchema = {
        "type": "object",
        "properties": {
            "symbols": {
                "type": "array",
            },
            "limit": {
                "type": "integer",
            },
            "sort": {
                "type": "string",
            },
        },
        "required": [
            "symbols",
        ],
    }


def test_news_arguments():
    args = build_news_arguments(
        FakeTool(),
        "MSFT",
        5,
    )

    assert args["symbols"] == [
        "MSFT"
    ]

    assert args["limit"] == 5

    assert args["sort"] == "desc"


def test_collect_headline():
    data = {
        "headline":
            "Microsoft announces update",
        "summary":
            "Example summary.",
    }

    result = collect_headlines(
        data
    )

    assert len(result) >= 1

    assert (
        "Microsoft announces update"
        in result[0]
    )
