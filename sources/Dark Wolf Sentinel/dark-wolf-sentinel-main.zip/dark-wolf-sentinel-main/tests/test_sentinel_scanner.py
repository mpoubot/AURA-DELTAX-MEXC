from app.sentinel_scanner import (
    score_snapshot,
)


def test_strong_setup_scores_high():
    score = score_snapshot(
        current_price=110,
        ema20_value=105,
        ema50_value=100,
        rsi_value=62,
        prior_high=109,
        volume_ratio=1.4,
    )

    assert score == 100


def test_weak_setup_scores_low():
    score = score_snapshot(
        current_price=95,
        ema20_value=100,
        ema50_value=105,
        rsi_value=85,
        prior_high=110,
        volume_ratio=0.5,
    )

    assert score == 0


def test_scanner_score_has_no_execution_authority():
    score = score_snapshot(
        current_price=110,
        ema20_value=105,
        ema50_value=100,
        rsi_value=62,
        prior_high=109,
        volume_ratio=1.4,
    )

    assert isinstance(
        score,
        float,
    )
