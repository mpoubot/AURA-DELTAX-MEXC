from decimal import Decimal
from types import SimpleNamespace

from alpaca.trading.enums import (
    OrderClass,
    OrderSide,
    OrderType,
    PositionIntent,
    TimeInForce,
)
from alpaca.trading.requests import (
    LimitOrderRequest,
    OptionLegRequest,
)

from app.options_execution_bridge import (
    execute_options_paper_if_enabled,
    status,
)
from app.options_order_intent import (
    OptionsMlegIntent,
)
from app.options_verticals import (
    VerticalSpreadType,
)


class FakeSettings:
    def __init__(
        self,
        *,
        options_enabled=False,
        global_enabled=False,
    ):
        self.alpaca_paper = True
        self.paper_execution_enabled = (
            global_enabled
        )
        self.options_paper_execution_enabled = (
            options_enabled
        )
        self.alpaca_api_key = "fake-key"
        self.alpaca_secret_key = "fake-secret"

    def assert_paper_only(self):
        assert self.alpaca_paper is True


def packet():
    legs = [
        OptionLegRequest(
            symbol="SPY260918C00769000",
            ratio_qty=1,
            side=OrderSide.BUY,
            position_intent=
                PositionIntent.BUY_TO_OPEN,
        ),
        OptionLegRequest(
            symbol="SPY260918C00781000",
            ratio_qty=1,
            side=OrderSide.SELL,
            position_intent=
                PositionIntent.SELL_TO_OPEN,
        ),
    ]

    request = LimitOrderRequest(
        qty=1,
        type=OrderType.LIMIT,
        time_in_force=TimeInForce.DAY,
        order_class=OrderClass.MLEG,
        legs=legs,
        limit_price=5.00,
        client_order_id=
            "dwo-execution-bridge-test",
    )

    payload = request.model_dump(
        mode="json",
        exclude_none=True,
    )

    intent = OptionsMlegIntent(
        decision_id="execution-bridge-test",
        client_order_id=
            "dwo-execution-bridge-test",
        underlying="SPY",
        spread_type=
            VerticalSpreadType
            .BULL_CALL_DEBIT,
        quantity=1,
        limit_price=Decimal("5.00"),
        long_symbol=
            "SPY260918C00769000",
        short_symbol=
            "SPY260918C00781000",
        request_payload=payload,
        trading_authority=False,
        order_submission_authority=False,
        broker_connection=False,
        execution_effect=False,
    )

    return {
        "status": "READY_INERT",
        "intent": intent.model_dump(
            mode="json"
        ),
        "request_payload": payload,
        "trading_authority": False,
        "order_submission_authority": False,
        "broker_connection": False,
        "execution_effect": False,
    }


class FactoryCounter:
    def __init__(
        self,
        client=None,
    ):
        self.calls = 0
        self.client = client

    def __call__(
        self,
        *args,
        **kwargs,
    ):
        self.calls += 1

        if self.client is None:
            raise AssertionError(
                "CLIENT_FACTORY_MUST_NOT_BE_CALLED"
            )

        return self.client


class FakeBroker:
    def __init__(
        self,
        *,
        positions=None,
        open_orders=None,
        market_open=True,
    ):
        self.positions = (
            positions
            if positions is not None
            else []
        )

        self.open_orders = (
            open_orders
            if open_orders is not None
            else []
        )

        self.market_open = market_open
        self.submit_calls = []

    def get_account(self):
        return SimpleNamespace(
            account_blocked=False,
            trading_blocked=False,
            options_approved_level=3,
            options_trading_level=3,
        )

    def get_clock(self):
        return SimpleNamespace(
            is_open=self.market_open,
        )

    def get_all_positions(self):
        return self.positions

    def get_orders(
        self,
        *,
        filter,
    ):
        return self.open_orders

    def submit_order(
        self,
        *,
        order_data,
    ):
        self.submit_calls.append(
            order_data
        )

        return SimpleNamespace(
            id="fake-options-order",
            status="accepted",
        )


def test_no_intent_never_builds_client():
    factory = FactoryCounter()

    result = (
        execute_options_paper_if_enabled(
            settings=FakeSettings(),
            options_order_intent=None,
            client_factory=factory,
        )
    )

    assert (
        result["status"]
        == "SKIPPED_NO_INTENT"
    )

    assert result["submitted"] is False
    assert factory.calls == 0


def test_disabled_gate_never_builds_client():
    factory = FactoryCounter()

    result = (
        execute_options_paper_if_enabled(
            settings=FakeSettings(
                options_enabled=False,
            ),
            options_order_intent=
                packet(),
            client_factory=factory,
        )
    )

    assert (
        result["status"]
        == "DISABLED"
    )

    assert (
        result["reason"]
        == "OPTIONS_PAPER_EXECUTION_DISABLED"
    )

    assert result["submitted"] is False
    assert factory.calls == 0


def test_global_gate_blocks_options_before_client():
    factory = FactoryCounter()

    result = (
        execute_options_paper_if_enabled(
            settings=FakeSettings(
                options_enabled=True,
                global_enabled=True,
            ),
            options_order_intent=
                packet(),
            client_factory=factory,
        )
    )

    assert (
        result["status"]
        == "BLOCKED"
    )

    assert (
        result["reason"]
        == "GLOBAL_EXECUTION_MUST_REMAIN_DISABLED"
    )

    assert factory.calls == 0


def test_enabled_flat_paper_account_submits_fake_mleg():
    broker = FakeBroker()

    factory = FactoryCounter(
        broker
    )

    result = (
        execute_options_paper_if_enabled(
            settings=FakeSettings(
                options_enabled=True,
                global_enabled=False,
            ),
            options_order_intent=
                packet(),
            client_factory=factory,
        )
    )

    assert factory.calls == 1
    assert len(
        broker.submit_calls
    ) == 1

    assert (
        result["status"]
        == "SUBMITTED"
    )

    assert result["submitted"] is True

    assert (
        result["broker_order_id"]
        == "fake-options-order"
    )


def test_existing_position_blocks_submission():
    broker = FakeBroker(
        positions=[
            SimpleNamespace(
                symbol="SPY260918C00769000"
            )
        ]
    )

    factory = FactoryCounter(
        broker
    )

    result = (
        execute_options_paper_if_enabled(
            settings=FakeSettings(
                options_enabled=True,
            ),
            options_order_intent=
                packet(),
            client_factory=factory,
        )
    )

    assert (
        result["status"]
        == "BLOCKED"
    )

    assert (
        result["reason"]
        == "EXISTING_POSITION"
    )

    assert broker.submit_calls == []


def test_open_order_blocks_submission():
    broker = FakeBroker(
        open_orders=[
            SimpleNamespace(
                id="already-open"
            )
        ]
    )

    result = (
        execute_options_paper_if_enabled(
            settings=FakeSettings(
                options_enabled=True,
            ),
            options_order_intent=
                packet(),
            client_factory=
                FactoryCounter(
                    broker
                ),
        )
    )

    assert (
        result["status"]
        == "BLOCKED"
    )

    assert (
        result["reason"]
        == "EXISTING_OPEN_ORDER"
    )

    assert broker.submit_calls == []


def test_market_closed_blocks_submission():
    broker = FakeBroker(
        market_open=False,
    )

    result = (
        execute_options_paper_if_enabled(
            settings=FakeSettings(
                options_enabled=True,
            ),
            options_order_intent=
                packet(),
            client_factory=
                FactoryCounter(
                    broker
                ),
        )
    )

    assert (
        result["status"]
        == "BLOCKED"
    )

    assert (
        result["reason"]
        == "MARKET_CLOSED"
    )

    assert broker.submit_calls == []


def test_status_is_paper_only_and_fail_closed():
    state = status()

    assert (
        state[
            "dedicated_options_gate"
        ]
        is True
    )

    assert (
        state[
            "global_gate_must_remain_off"
        ]
        is True
    )

    assert (
        state[
            "client_created_when_disabled"
        ]
        is False
    )

    assert (
        state[
            "flat_account_required"
        ]
        is True
    )

    assert (
        state[
            "zero_open_orders_required"
        ]
        is True
    )

    assert (
        state["live_trading"]
        is False
    )

    assert (
        state[
            "ai_live_trading_authority"
        ]
        is False
    )
