from app.news_relevance import (
    filter_relevant_news,
    score_news,
)


def test_direct_company_match_scores_high():
    result = score_news(
        "MSFT",
        "Microsoft expands Azure AI capacity.",
    )

    assert result.score >= 4


def test_ticker_scores_high():
    result = score_news(
        "MSFT",
        "MSFT shares rise after earnings.",
    )

    assert result.score >= 5


def test_unrelated_nvidia_news_filtered():
    items = [
        "Nvidia announces new GPU.",
        "Microsoft expands Azure AI capacity.",
    ]

    relevant, ranked = filter_relevant_news(
        "MSFT",
        items,
    )

    assert len(relevant) == 1

    assert (
        "Microsoft"
        in relevant[0]
    )

    assert ranked[0].score > ranked[1].score


def test_openai_context_can_be_relevant_to_msft():
    result = score_news(
        "MSFT",
        "OpenAI announces enterprise expansion.",
    )

    assert result.score >= 2
