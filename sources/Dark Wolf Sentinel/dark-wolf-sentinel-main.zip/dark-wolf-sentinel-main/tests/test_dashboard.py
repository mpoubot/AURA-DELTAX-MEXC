from app.dashboard_server import (
    sanitize_broker_snapshot,
)


def test_dashboard_hides_broker_identity():
    result = sanitize_broker_snapshot(
        {
            "account": {
                "status": "ACTIVE",
                "equity": "100000",
                "cash": "100000",
                "account_number":
                    "SECRET123",
                "id":
                    "SECRET-ID",
            },
            "positions": [],
            "open_orders": [],
        }
    )

    assert (
        "account_number"
        not in result
    )

    assert "id" not in result

    assert result[
        "positions"
    ] == 0

    assert result[
        "open_orders"
    ] == 0


def test_dashboard_account_values():
    result = sanitize_broker_snapshot(
        {
            "account": {
                "status": "ACTIVE",
                "equity": "99999.50",
                "cash": "50000",
            },
            "positions": [
                {"symbol": "TEST"}
            ],
            "open_orders": [],
        }
    )

    assert (
        result["equity"]
        == "99999.50"
    )

    assert (
        result["positions"]
        == 1
    )


def test_broker_failure_degrades_without_raising(
    monkeypatch,
):
    import app.dashboard_server as dashboard

    dashboard._LAST_GOOD_BROKER = None

    class BrokenBroker:
        def __init__(self, settings):
            pass

        def snapshot(self):
            raise ConnectionError(
                "synthetic outage"
            )

    monkeypatch.setattr(
        dashboard,
        "AlpacaPaperBroker",
        BrokenBroker,
    )

    result = dashboard.safe_broker_snapshot(
        object()
    )

    assert result["health"] == "DEGRADED"
    assert result["stale"] is True
    assert result["status"] == "UNAVAILABLE"
    assert result["equity"] is None
    assert result["positions"] is None
    assert (
        result["error"]
        == "BROKER_READ_FAILED"
    )


def test_broker_failure_preserves_last_good_snapshot(
    monkeypatch,
):
    import app.dashboard_server as dashboard

    dashboard._LAST_GOOD_BROKER = None

    class GoodBroker:
        def __init__(self, settings):
            pass

        def snapshot(self):
            return {
                "account": {
                    "status": "ACTIVE",
                    "equity": 100000.0,
                    "cash": 90000.0,
                },
                "positions": [
                    {"symbol": "TEST"}
                ],
                "open_orders": [],
            }

    monkeypatch.setattr(
        dashboard,
        "AlpacaPaperBroker",
        GoodBroker,
    )

    good = dashboard.safe_broker_snapshot(
        object()
    )

    assert good["health"] == "OK"
    assert good["stale"] is False
    assert good["equity"] == 100000.0
    assert good["positions"] == 1

    class BrokenBroker:
        def __init__(self, settings):
            pass

        def snapshot(self):
            raise ConnectionError(
                "synthetic outage"
            )

    monkeypatch.setattr(
        dashboard,
        "AlpacaPaperBroker",
        BrokenBroker,
    )

    degraded = dashboard.safe_broker_snapshot(
        object()
    )

    assert degraded["health"] == "DEGRADED"
    assert degraded["stale"] is True
    assert degraded["equity"] == 100000.0
    assert degraded["positions"] == 1
    assert (
        degraded["error"]
        == "BROKER_READ_FAILED"
    )
