from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal
import json

import pytest

from app.options_position_store import (
    EntryState,
    OptionsEntryManifest,
    OptionsPositionStore,
    OptionsPositionStoreError,
    status,
)
from app.options_verticals import (
    VerticalSpreadType,
)


NOW = datetime(
    2026,
    8,
    28,
    17,
    30,
    tzinfo=timezone.utc,
)


def manifest(
    *,
    record_id="position-001",
    client_order_id="dwo-position-001",
):
    return OptionsEntryManifest(
        record_id=record_id,
        decision_id=
            "sentinel-decision-001",
        client_order_id=
            client_order_id,
        underlying="SPY",
        spread_type=
            VerticalSpreadType
            .BULL_CALL_DEBIT,
        long_symbol=
            "SPY260918C00769000",
        short_symbol=
            "SPY260918C00782000",
        quantity=1,
        expiration=date(
            2026,
            9,
            18,
        ),
        thesis_expires_at=(
            NOW
            + timedelta(
                days=10
            )
        ),
        width=
            Decimal("13.00"),
        selected_debit=
            Decimal("6.275"),
        executable_entry_limit=
            Decimal("6.27"),
        approved_max_loss=
            Decimal("627.00"),
        created_at=NOW,
    )


def test_new_store_is_empty(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    document = store.load()

    assert document.revision == 0
    assert document.records == []
    assert store.active_record() is None


def test_prepare_is_durable_and_atomic(
    tmp_path,
):
    path = (
        tmp_path
        / "positions.json"
    )

    store = OptionsPositionStore(
        path
    )

    prepared = store.prepare_entry(
        manifest()
    )

    assert (
        prepared.state
        == EntryState.PREPARED
    )

    assert path.exists()

    raw = json.loads(
        path.read_text()
    )

    assert (
        raw["schema_version"]
        == 1
    )

    assert raw["revision"] == 1
    assert len(raw["records"]) == 1

    reloaded = (
        OptionsPositionStore(
            path
        ).active_record()
    )

    assert reloaded is not None

    assert (
        reloaded.client_order_id
        == "dwo-position-001"
    )


def test_prepare_is_idempotent(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    item = manifest()

    first = store.prepare_entry(
        item
    )

    revision = (
        store.load().revision
    )

    second = store.prepare_entry(
        item
    )

    assert first == second

    assert (
        store.load().revision
        == revision
    )


def test_second_active_record_fails_closed(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    with pytest.raises(
        OptionsPositionStoreError,
        match="ACTIVE_OPTIONS_RECORD_EXISTS",
    ):
        store.prepare_entry(
            manifest(
                record_id=
                    "position-002",
                client_order_id=
                    "dwo-position-002",
            )
        )


def test_prepared_to_submitted(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    submitted_at = (
        NOW
        + timedelta(
            seconds=2
        )
    )

    result = store.mark_submitted(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="new",
        submitted_at=
            submitted_at,
    )

    assert (
        result.state
        == EntryState.SUBMITTED
    )

    assert (
        result.broker_order_id
        == "broker-order-001"
    )

    assert (
        result.submitted_at
        == submitted_at
    )


def test_submitted_to_filled_and_lifecycle_record(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    submitted_at = (
        NOW
        + timedelta(
            seconds=2
        )
    )

    store.mark_submitted(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="new",
        submitted_at=
            submitted_at,
    )

    filled_at = (
        NOW
        + timedelta(
            seconds=4
        )
    )

    filled = store.mark_filled(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="filled",
        filled_debit=
            Decimal("6.25"),
        filled_at=
            filled_at,
    )

    assert (
        filled.state
        == EntryState.FILLED
    )

    position = (
        filled
        .to_position_record()
    )

    assert (
        position.entry_debit
        == Decimal("6.25")
    )

    assert (
        position.max_loss_per_spread
        == Decimal("625.00")
    )

    assert (
        position.max_profit_per_spread
        == Decimal("675.00")
    )

    assert (
        position.opened_at
        == filled_at
    )


def test_fill_above_limit_fails_closed(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    store.mark_submitted(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="new",
        submitted_at=(
            NOW
            + timedelta(
                seconds=1
            )
        ),
    )

    with pytest.raises(
        Exception,
        match="FILL_DEBIT_EXCEEDS_LIMIT",
    ):
        store.mark_filled(
            record_id=
                "position-001",
            broker_order_id=
                "broker-order-001",
            broker_status="filled",
            filled_debit=
                Decimal("6.28"),
            filled_at=(
                NOW
                + timedelta(
                    seconds=2
                )
            ),
        )


def test_wrong_broker_order_fails_closed(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    store.mark_submitted(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="new",
        submitted_at=(
            NOW
            + timedelta(
                seconds=1
            )
        ),
    )

    with pytest.raises(
        OptionsPositionStoreError,
        match="BROKER_ORDER_ID_MISMATCH",
    ):
        store.mark_filled(
            record_id=
                "position-001",
            broker_order_id=
                "different-order",
            broker_status="filled",
            filled_debit=
                Decimal("6.25"),
            filled_at=(
                NOW
                + timedelta(
                    seconds=2
                )
            ),
        )


def test_canceled_entry_releases_active_slot(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    canceled = (
        store.mark_canceled(
            record_id=
                "position-001",
            broker_status=
                "canceled",
        )
    )

    assert (
        canceled.state
        == EntryState.CANCELED
    )

    assert (
        store.active_record()
        is None
    )

    second = store.prepare_entry(
        manifest(
            record_id=
                "position-002",
            client_order_id=
                "dwo-position-002",
        )
    )

    assert (
        second.state
        == EntryState.PREPARED
    )


def test_filled_position_remains_active(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    store.mark_submitted(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="new",
        submitted_at=(
            NOW
            + timedelta(
                seconds=1
            )
        ),
    )

    store.mark_filled(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="filled",
        filled_debit=
            Decimal("6.25"),
        filled_at=(
            NOW
            + timedelta(
                seconds=2
            )
        ),
    )

    active = (
        store.active_record()
    )

    assert active is not None

    assert (
        active.state
        == EntryState.FILLED
    )

    with pytest.raises(
        OptionsPositionStoreError,
        match="ACTIVE_OPTIONS_RECORD_EXISTS",
    ):
        store.prepare_entry(
            manifest(
                record_id=
                    "position-002",
                client_order_id=
                    "dwo-position-002",
            )
        )


def test_filled_to_closed_releases_slot(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    store.mark_submitted(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="new",
        submitted_at=(
            NOW
            + timedelta(
                seconds=1
            )
        ),
    )

    store.mark_filled(
        record_id=
            "position-001",
        broker_order_id=
            "broker-order-001",
        broker_status="filled",
        filled_debit=
            Decimal("6.25"),
        filled_at=(
            NOW
            + timedelta(
                seconds=2
            )
        ),
    )

    closed = store.mark_closed(
        record_id=
            "position-001",
        closing_credit=
            Decimal("8.00"),
        close_broker_order_id=
            "close-order-001",
        closed_at=(
            NOW
            + timedelta(
                days=1
            )
        ),
    )

    assert (
        closed.state
        == EntryState.CLOSED
    )

    assert (
        store.active_record()
        is None
    )


def test_corrupt_store_fails_closed(
    tmp_path,
):
    path = (
        tmp_path
        / "positions.json"
    )

    path.write_text(
        "{not-json"
    )

    store = OptionsPositionStore(
        path
    )

    with pytest.raises(
        OptionsPositionStoreError,
        match="POSITION_STORE_READ_FAILED",
    ):
        store.load()


def test_status_is_zero_effect():
    state = status()

    assert (
        state[
            "pre_submission_manifest"
        ]
        is True
    )

    assert (
        state[
            "deterministic_client_order_recovery"
        ]
        is True
    )

    assert (
        state[
            "single_active_record"
        ]
        is True
    )

    assert (
        state[
            "broker_connection"
        ]
        is False
    )

    assert (
        state[
            "broker_writes"
        ]
        is False
    )

    assert (
        state[
            "order_submission_authority"
        ]
        is False
    )

    assert (
        state[
            "execution_effect"
        ]
        is False
    )
