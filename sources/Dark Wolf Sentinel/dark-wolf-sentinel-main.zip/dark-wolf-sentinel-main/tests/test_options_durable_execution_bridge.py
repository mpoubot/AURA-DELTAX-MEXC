from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal
from types import SimpleNamespace

from alpaca.trading.enums import (
    OrderStatus,
)

from app.agent.models import (
    AgentAction,
    AgentProposal,
)
from app.options_durable_execution_bridge import (
    execute_options_paper_durable_if_enabled,
    status,
)
from app.options_intent_bridge import (
    build_shadow_order_intent,
)
from app.options_position_store import (
    EntryState,
    OptionsPositionStore,
)
from app.options_selector import (
    OptionDirection,
    OptionSelectionResult,
)
from app.options_verticals import (
    OptionContractSpec,
    OptionLeg,
    OptionRight,
    OptionsRiskDecision,
    PositionSide,
    VerticalRiskMetrics,
    VerticalSpreadProposal,
    VerticalSpreadType,
)


NOW = datetime(
    2026,
    8,
    28,
    17,
    45,
    tzinfo=timezone.utc,
)

EXPIRY = date(
    2026,
    9,
    18,
)


class Settings:
    alpaca_paper = True
    paper_execution_enabled = False
    options_paper_execution_enabled = True

    alpaca_api_key = "fake"
    alpaca_secret_key = "fake"

    def assert_paper_only(self):
        assert self.alpaca_paper is True


def proposal():
    return AgentProposal(
        action=AgentAction.BUY,
        symbol="SPY",
        confidence=90,
        entry_price=770,
        stop_price=760,
        target_price=790,
        thesis="Durable execution bridge test.",
        thesis_expires_at=(
            NOW
            + timedelta(
                days=7
            )
        ),
        trading_authority=False,
        live_order_allowed=False,
    )


def shadow():
    long_contract = OptionContractSpec(
        symbol="SPY260918C00768000",
        underlying="SPY",
        right=OptionRight.CALL,
        strike=Decimal("768"),
        expiration=EXPIRY,
        multiplier=Decimal("100"),
        source="TEST",
    )

    short_contract = OptionContractSpec(
        symbol="SPY260918C00781000",
        underlying="SPY",
        right=OptionRight.CALL,
        strike=Decimal("781"),
        expiration=EXPIRY,
        multiplier=Decimal("100"),
        source="TEST",
    )

    vertical = VerticalSpreadProposal(
        long_leg=OptionLeg(
            contract=long_contract,
            side=PositionSide.LONG,
            premium=Decimal("8.80"),
        ),
        short_leg=OptionLeg(
            contract=short_contract,
            side=PositionSide.SHORT,
            premium=Decimal("2.49"),
        ),
        quantity=1,
        confidence=90,
        thesis=proposal().thesis,
    )

    metrics = VerticalRiskMetrics(
        spread_type=
            VerticalSpreadType
            .BULL_CALL_DEBIT,
        underlying="SPY",
        expiration=EXPIRY,
        quantity=1,
        multiplier=Decimal("100"),
        width=Decimal("13.00"),
        net_debit_per_share=
            Decimal("6.31"),
        net_credit_per_share=
            Decimal("0"),
        max_loss_per_spread=
            Decimal("631.00"),
        max_profit_per_spread=
            Decimal("669.00"),
        total_max_loss=
            Decimal("631.00"),
        total_max_profit=
            Decimal("669.00"),
        breakeven=
            Decimal("774.31"),
        reward_to_risk=
            Decimal("1.06"),
    )

    risk = OptionsRiskDecision(
        approved=True,
        reason="APPROVED",
        underlying="SPY",
        spread_type=
            VerticalSpreadType
            .BULL_CALL_DEBIT,
        requested_quantity=1,
        max_contracts_by_risk=1,
        approved_quantity=1,
        max_loss_per_spread=
            Decimal("631.00"),
        approved_max_loss=
            Decimal("630.50"),
        risk_budget=
            Decimal("1000.00"),
        projected_total_open_risk=
            Decimal("630.50"),
    )

    selection = OptionSelectionResult(
        selected=True,
        reason="SELECTED",
        direction=
            OptionDirection.BULLISH,
        considered_contracts=2,
        eligible_contracts=2,
        pairs_evaluated=1,
        rejection_counts={},
        proposal=vertical,
        metrics=metrics,
        risk_decision=risk,
    )

    return {
        "status":
            "OK",
        "selection":
            selection.model_dump(
                mode="json"
            ),
        "trading_authority":
            False,
        "order_authority":
            False,
        "execution_effect":
            False,
    }


def packet():
    value = build_shadow_order_intent(
        options_shadow=shadow(),
        decision_id=
            "durable-final-test",
    )

    assert value is not None
    assert value["status"] == "READY_INERT"

    return value


class FakeClient:
    def __init__(
        self,
        store,
        *,
        market_open=True,
        fail_submit=False,
    ):
        self.store = store
        self.market_open = market_open
        self.fail_submit = fail_submit

        self.submit_calls = 0

        self.order = None

    def get_account(self):
        return SimpleNamespace(
            account_blocked=False,
            trading_blocked=False,
            options_approved_level=3,
            options_trading_level=3,
        )

    def get_clock(self):
        return SimpleNamespace(
            is_open=self.market_open
        )

    def get_all_positions(self):
        return []

    def get_orders(
        self,
        filter=None,
    ):
        return []

    def submit_order(
        self,
        order_data,
    ):
        self.submit_calls += 1

        active = (
            self.store.active_record()
        )

        # Critical ordering proof.
        assert active is not None
        assert (
            active.state
            == EntryState.PREPARED
        )

        assert (
            active.client_order_id
            == order_data.client_order_id
        )

        if self.fail_submit:
            raise RuntimeError(
                "synthetic submit ambiguity"
            )

        self.order = SimpleNamespace(
            id="broker-final-test",
            client_order_id=
                order_data.client_order_id,
            status=
                OrderStatus.NEW,
            submitted_at=(
                NOW
                + timedelta(
                    seconds=1
                )
            ),
        )

        return self.order

    def get_order_by_id(
        self,
        order_id,
        filter=None,
    ):
        assert (
            order_id
            == "broker-final-test"
        )

        return self.order


class ForbiddenFactory:
    def __call__(
        self,
        *args,
        **kwargs,
    ):
        raise AssertionError(
            "broker client constructed"
        )


class ForbiddenStoreFactory:
    def __call__(
        self,
        *args,
        **kwargs,
    ):
        raise AssertionError(
            "durable store constructed"
        )


def test_gate_off_constructs_nothing():
    settings = Settings()

    settings.options_paper_execution_enabled = (
        False
    )

    result = execute_options_paper_durable_if_enabled(
        settings=settings,
        agent_proposal=proposal(),
        options_shadow=shadow(),
        options_order_intent=packet(),
        client_factory=
            ForbiddenFactory(),
        store_factory=
            ForbiddenStoreFactory(),
    )

    assert result["status"] == "DISABLED"

    assert (
        result["submitted"]
        is False
    )

    assert (
        result["manifest_written"]
        is False
    )


def test_preflight_block_does_not_prepare(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    client = FakeClient(
        store,
        market_open=False,
    )

    result = execute_options_paper_durable_if_enabled(
        settings=Settings(),
        agent_proposal=proposal(),
        options_shadow=shadow(),
        options_order_intent=packet(),
        client_factory=(
            lambda *args, **kwargs:
                client
        ),
        store_factory=(
            lambda path:
                store
        ),
        store_path=
            tmp_path
            / "positions.json",
    )

    assert (
        result["status"]
        == "BLOCKED"
    )

    assert (
        result["reason"]
        == "MARKET_CLOSED"
    )

    assert (
        store.active_record()
        is None
    )

    assert client.submit_calls == 0


def test_manifest_exists_before_submit_and_advances_submitted(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    client = FakeClient(
        store
    )

    result = execute_options_paper_durable_if_enabled(
        settings=Settings(),
        agent_proposal=proposal(),
        options_shadow=shadow(),
        options_order_intent=packet(),
        client_factory=(
            lambda *args, **kwargs:
                client
        ),
        store_factory=(
            lambda path:
                store
        ),
        store_path=
            tmp_path
            / "positions.json",
    )

    assert (
        client.submit_calls
        == 1
    )

    assert (
        result["submitted"]
        is True
    )

    assert (
        result[
            "manifest_written"
        ]
        is True
    )

    assert (
        result[
            "durable_state"
        ]
        == "submitted"
    )

    assert (
        result[
            "durable_update_status"
        ]
        == "SUBMITTED_PERSISTED"
    )

    active = store.active_record()

    assert active is not None

    assert (
        active.state
        == EntryState.SUBMITTED
    )


def test_submit_failure_retains_prepared(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    client = FakeClient(
        store,
        fail_submit=True,
    )

    result = execute_options_paper_durable_if_enabled(
        settings=Settings(),
        agent_proposal=proposal(),
        options_shadow=shadow(),
        options_order_intent=packet(),
        client_factory=(
            lambda *args, **kwargs:
                client
        ),
        store_factory=(
            lambda path:
                store
        ),
        store_path=
            tmp_path
            / "positions.json",
    )

    assert (
        client.submit_calls
        == 1
    )

    assert (
        result["submitted"]
        is False
    )

    assert (
        result[
            "manifest_written"
        ]
        is True
    )

    assert (
        result[
            "durable_state"
        ]
        == "prepared"
    )

    assert (
        result[
            "durable_update_status"
        ]
        == "PREPARED_RETAINED_FOR_RECOVERY"
    )


def test_existing_submitted_record_blocks_second_entry(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    client = FakeClient(
        store
    )

    first = execute_options_paper_durable_if_enabled(
        settings=Settings(),
        agent_proposal=proposal(),
        options_shadow=shadow(),
        options_order_intent=packet(),
        client_factory=(
            lambda *args, **kwargs:
                client
        ),
        store_factory=(
            lambda path:
                store
        ),
        store_path=
            tmp_path
            / "positions.json",
    )

    assert first["submitted"] is True

    calls_before = (
        client.submit_calls
    )

    second = execute_options_paper_durable_if_enabled(
        settings=Settings(),
        agent_proposal=proposal(),
        options_shadow=shadow(),
        options_order_intent=packet(),
        client_factory=(
            lambda *args, **kwargs:
                client
        ),
        store_factory=(
            lambda path:
                store
        ),
        store_path=
            tmp_path
            / "positions.json",
    )

    assert (
        second["status"]
        == "BLOCKED"
    )

    assert (
        second["reason"]
        == "ACTIVE_DURABLE_OPTIONS_RECORD"
    )

    assert (
        client.submit_calls
        == calls_before
    )


def test_status_reports_final_safety_boundary():
    state = status()

    assert (
        state[
            "durable_manifest_before_submit"
        ]
        is True
    )

    assert (
        state[
            "prepared_recovery_before_new_submission"
        ]
        is True
    )

    assert (
        state[
            "same_cycle_resubmit_after_recovery"
        ]
        is False
    )

    assert (
        state[
            "filled_recovery_supported"
        ]
        is False
    )

    assert (
        state[
            "live_trading"
        ]
        is False
    )
