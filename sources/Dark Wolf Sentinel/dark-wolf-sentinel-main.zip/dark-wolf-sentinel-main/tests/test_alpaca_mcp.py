import pytest

from app.mcp.alpaca_readonly import (
    ALLOWED_TOOLSETS,
    assert_read_only,
)


def test_mcp_toolsets_exclude_trading():
    assert (
        ALLOWED_TOOLSETS
        == "stock-data,news"
    )

    assert (
        "trading"
        not in ALLOWED_TOOLSETS
    )

    assert (
        "account"
        not in ALLOWED_TOOLSETS
    )


def test_read_only_tools_pass():
    assert_read_only(
        [
            "get_stock_bars",
            "get_stock_latest_trade",
            "get_stock_snapshot",
            "get_most_active_stocks",
            "get_market_movers",
            "get_news",
        ]
    )


@pytest.mark.parametrize(
    "tool",
    [
        "place_stock_order",
        "cancel_all_orders",
        "close_position",
        "create_watchlist",
        "update_account_config",
        "delete_watchlist_by_id",
    ],
)
def test_write_tool_rejected(
    tool,
):
    with pytest.raises(
        RuntimeError
    ):
        assert_read_only(
            [
                "get_stock_bars",
                "get_stock_latest_trade",
                "get_stock_snapshot",
                "get_most_active_stocks",
                "get_market_movers",
                "get_news",
                tool,
            ]
        )
