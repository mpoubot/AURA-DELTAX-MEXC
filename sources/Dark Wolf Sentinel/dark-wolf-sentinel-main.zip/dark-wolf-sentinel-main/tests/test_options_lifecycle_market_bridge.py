from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal
from types import SimpleNamespace

from alpaca.trading.enums import (
    AssetClass,
    PositionSide,
)

from app.options_lifecycle import (
    LifecycleAction,
    OptionsLifecyclePolicy,
    OptionsPositionRecord,
)
from app.options_lifecycle_market_bridge import (
    evaluate_market_lifecycle,
    status,
)
from app.options_verticals import (
    VerticalSpreadType,
)


NOW = datetime(
    2026,
    8,
    28,
    17,
    15,
    tzinfo=timezone.utc,
)


class FakeSettings:
    alpaca_paper = True
    paper_execution_enabled = False
    options_paper_execution_enabled = False

    alpaca_api_key = "fake"
    alpaca_secret_key = "fake"

    def assert_paper_only(self):
        assert self.alpaca_paper is True


def record():
    return OptionsPositionRecord(
        record_id="bridge-spread",
        underlying="SPY",
        spread_type=
            VerticalSpreadType
            .BULL_CALL_DEBIT,
        long_symbol=
            "SPY260918C00769000",
        short_symbol=
            "SPY260918C00782000",
        quantity=1,
        expiration=date(
            2026,
            9,
            18,
        ),
        opened_at=(
            NOW
            - timedelta(
                days=1
            )
        ),
        thesis_expires_at=(
            NOW
            + timedelta(
                days=10
            )
        ),
        entry_debit=
            Decimal("5.00"),
        width=
            Decimal("13.00"),
        max_loss_per_spread=
            Decimal("500.00"),
        max_profit_per_spread=
            Decimal("800.00"),
    )


def policy():
    return OptionsLifecyclePolicy(
        profit_capture_pct=
            Decimal("50"),
        stop_loss_pct_of_debit=
            Decimal("50"),
        min_dte_exit=3,
    )


def broker_positions():
    return [
        SimpleNamespace(
            symbol=
                record().long_symbol,
            asset_class=
                AssetClass.US_OPTION,
            side=
                PositionSide.LONG,
            qty="1",
        ),
        SimpleNamespace(
            symbol=
                record().short_symbol,
            asset_class=
                AssetClass.US_OPTION,
            side=
                PositionSide.SHORT,
            qty="1",
        ),
    ]


class FakeTradingClient:
    def __init__(
        self,
        positions,
    ):
        self.positions = positions
        self.reads = 0

    def get_all_positions(
        self,
    ):
        self.reads += 1
        return self.positions


class TradingFactory:
    def __init__(
        self,
        positions,
    ):
        self.calls = 0
        self.client = FakeTradingClient(
            positions
        )

    def __call__(
        self,
        *args,
        **kwargs,
    ):
        self.calls += 1
        return self.client


class Quote:
    def __init__(
        self,
        *,
        bid,
        ask,
        timestamp,
    ):
        self.bid_price = bid
        self.ask_price = ask
        self.timestamp = timestamp


class FakeDataClient:
    def __init__(
        self,
        quotes,
    ):
        self.quotes = quotes
        self.calls = 0

    def get_option_latest_quote(
        self,
        request,
    ):
        self.calls += 1
        return self.quotes


class DataFactory:
    def __init__(
        self,
        quotes,
    ):
        self.calls = 0
        self.client = FakeDataClient(
            quotes
        )

    def __call__(
        self,
        *args,
        **kwargs,
    ):
        self.calls += 1
        return self.client


def fresh_quotes(
    *,
    long_bid="8.78",
    long_ask="8.86",
    short_bid="2.98",
    short_ask="3.02",
):
    return {
        record().long_symbol:
            Quote(
                bid=long_bid,
                ask=long_ask,
                timestamp=(
                    NOW
                    - timedelta(
                        seconds=1
                    )
                ),
            ),

        record().short_symbol:
            Quote(
                bid=short_bid,
                ask=short_ask,
                timestamp=(
                    NOW
                    - timedelta(
                        seconds=1
                    )
                ),
            ),
    }


def test_flat_account_skips_quote_client():
    trading = TradingFactory(
        []
    )

    data = DataFactory(
        fresh_quotes()
    )

    result = evaluate_market_lifecycle(
        settings=FakeSettings(),
        record=record(),
        policy=policy(),
        trading_client_factory=
            trading,
        option_data_client_factory=
            data,
        now=NOW,
    )

    assert result["status"] == "FLAT"
    assert result["positions_count"] == 0
    assert result["quotes_requested"] == 0

    assert trading.calls == 1
    assert data.calls == 0


def test_conservative_credit_uses_long_bid_minus_short_ask():
    result = evaluate_market_lifecycle(
        settings=FakeSettings(),
        record=record(),
        policy=policy(),
        trading_client_factory=
            TradingFactory(
                broker_positions()
            ),
        option_data_client_factory=
            DataFactory(
                fresh_quotes()
            ),
        now=NOW,
    )

    assert result["status"] == "OK"

    assert (
        result[
            "conservative_close_credit"
        ]
        == "5.76"
    )

    assert (
        Decimal(
            result[
                "midpoint_credit_diagnostic"
            ]
        )
        == Decimal("5.82")
    )

    assert (
        result[
            "decision"
        ]["action"]
        == LifecycleAction.HOLD.value
    )


def test_profit_exit_uses_conservative_not_midpoint():
    # Conservative:
    # 9.00 - 3.00 = 6.00
    #
    # Midpoint is larger, but neither midpoint nor
    # mark is allowed to drive the decision.
    quotes = fresh_quotes(
        long_bid="9.00",
        long_ask="10.00",
        short_bid="2.00",
        short_ask="3.00",
    )

    result = evaluate_market_lifecycle(
        settings=FakeSettings(),
        record=record(),
        policy=policy(),
        trading_client_factory=
            TradingFactory(
                broker_positions()
            ),
        option_data_client_factory=
            DataFactory(quotes),
        now=NOW,
    )

    assert (
        result[
            "conservative_close_credit"
        ]
        == "6.00"
    )

    assert (
        result[
            "decision"
        ]["action"]
        == LifecycleAction.HOLD.value
    )


def test_stale_long_quote_fails_closed():
    quotes = fresh_quotes()

    quotes[
        record().long_symbol
    ].timestamp = (
        NOW
        - timedelta(
            seconds=121
        )
    )

    result = evaluate_market_lifecycle(
        settings=FakeSettings(),
        record=record(),
        policy=policy(),
        trading_client_factory=
            TradingFactory(
                broker_positions()
            ),
        option_data_client_factory=
            DataFactory(quotes),
        now=NOW,
    )

    assert (
        result["status"]
        == "DEGRADED"
    )

    assert (
        result["error_reason"]
        == "LONG_QUOTE_STALE"
    )


def test_crossed_quote_fails_closed():
    quotes = fresh_quotes(
        long_bid="9.00",
        long_ask="8.00",
    )

    result = evaluate_market_lifecycle(
        settings=FakeSettings(),
        record=record(),
        policy=policy(),
        trading_client_factory=
            TradingFactory(
                broker_positions()
            ),
        option_data_client_factory=
            DataFactory(quotes),
        now=NOW,
    )

    assert (
        result["status"]
        == "DEGRADED"
    )

    assert (
        result["error_reason"]
        == "LONG_CROSSED_QUOTE"
    )


def test_wrong_position_side_fails_closed():
    positions = broker_positions()

    positions[1].side = (
        PositionSide.LONG
    )

    result = evaluate_market_lifecycle(
        settings=FakeSettings(),
        record=record(),
        policy=policy(),
        trading_client_factory=
            TradingFactory(
                positions
            ),
        option_data_client_factory=
            DataFactory(
                fresh_quotes()
            ),
        now=NOW,
    )

    assert (
        result["status"]
        == "DEGRADED"
    )

    assert (
        result["error_reason"]
        == "SHORT_LEG_BROKER_SIDE_MISMATCH"
    )


def test_extra_position_blocks_before_quotes():
    positions = (
        broker_positions()
        + [
            SimpleNamespace(
                symbol=
                    "SPY260918C00800000",
                asset_class=
                    AssetClass.US_OPTION,
                side=
                    PositionSide.LONG,
                qty="1",
            )
        ]
    )

    data = DataFactory(
        fresh_quotes()
    )

    result = evaluate_market_lifecycle(
        settings=FakeSettings(),
        record=record(),
        policy=policy(),
        trading_client_factory=
            TradingFactory(
                positions
            ),
        option_data_client_factory=
            data,
        now=NOW,
    )

    assert (
        result["status"]
        == "BLOCKED"
    )

    assert (
        result["reason"]
        == "EXPECTED_EXACTLY_TWO_OPTION_POSITIONS"
    )

    assert data.calls == 0


def test_execution_enabled_blocks_read_only_bridge():
    settings = FakeSettings()

    settings.options_paper_execution_enabled = (
        True
    )

    trading = TradingFactory(
        broker_positions()
    )

    result = evaluate_market_lifecycle(
        settings=settings,
        record=record(),
        policy=policy(),
        trading_client_factory=
            trading,
        option_data_client_factory=
            DataFactory(
                fresh_quotes()
            ),
        now=NOW,
    )

    assert (
        result["status"]
        == "BLOCKED"
    )

    assert (
        result["reason"]
        == "READ_ONLY_BRIDGE_REQUIRES_EXECUTION_OFF"
    )

    assert trading.calls == 0


def test_status_has_zero_effect():
    state = status()

    assert state["read_only"] is True
    assert (
        state[
            "close_credit_formula"
        ]
        == "long_bid_minus_short_ask"
    )

    assert (
        state[
            "midpoint_drives_exit"
        ]
        is False
    )

    assert (
        state[
            "trading_authority"
        ]
        is False
    )

    assert (
        state[
            "order_submission_authority"
        ]
        is False
    )

    assert (
        state["broker_writes"]
        is False
    )

    assert (
        state["execution_effect"]
        is False
    )
