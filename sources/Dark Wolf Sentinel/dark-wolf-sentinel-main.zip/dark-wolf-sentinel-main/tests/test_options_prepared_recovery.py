from datetime import (
    date,
    datetime,
    timedelta,
    timezone,
)
from decimal import Decimal
from types import SimpleNamespace

from app.options_position_store import (
    EntryState,
    OptionsEntryManifest,
    OptionsPositionStore,
)
from app.options_prepared_recovery import (
    recover_prepared_entry,
    status,
)
from app.options_verticals import (
    VerticalSpreadType,
)


NOW = datetime(
    2026,
    8,
    28,
    17,
    30,
    tzinfo=timezone.utc,
)


def manifest(
    *,
    client_order_id=
        "dwo-recovery-test",
):
    return OptionsEntryManifest(
        record_id=
            "recovery-record",
        decision_id=
            "recovery-decision",
        client_order_id=
            client_order_id,
        underlying="SPY",
        spread_type=
            VerticalSpreadType
            .BULL_CALL_DEBIT,
        long_symbol=
            "SPY260918C00769000",
        short_symbol=
            "SPY260918C00782000",
        quantity=1,
        expiration=date(
            2026,
            9,
            18,
        ),
        thesis_expires_at=(
            NOW
            + timedelta(
                days=7
            )
        ),
        width=Decimal("13.00"),
        selected_debit=
            Decimal("3.13"),
        executable_entry_limit=
            Decimal("3.13"),
        approved_max_loss=
            Decimal("313.00"),
        created_at=NOW,
    )


def leg(
    *,
    symbol,
    side,
    intent,
):
    return SimpleNamespace(
        symbol=symbol,
        side=side,
        position_intent=
            intent,
        ratio_qty=1,
    )


def broker_order(
    *,
    status="new",
    filled_qty="0",
    limit_price="3.13",
):
    return SimpleNamespace(
        id="broker-001",
        client_order_id=
            "dwo-recovery-test",
        order_class="mleg",
        type="limit",
        qty="1",
        limit_price=
            limit_price,
        status=status,
        filled_qty=
            filled_qty,
        submitted_at=(
            NOW
            + timedelta(
                seconds=2
            )
        ),
        legs=[
            leg(
                symbol=
                    "SPY260918C00769000",
                side="buy",
                intent="buy_to_open",
            ),
            leg(
                symbol=
                    "SPY260918C00782000",
                side="sell",
                intent="sell_to_open",
            ),
        ],
    )


class MissingError(Exception):
    status_code = 404


class AmbiguousError(Exception):
    status_code = 503


class FakeClient:
    def __init__(
        self,
        *,
        lookup=None,
        nested=None,
        lookup_error=None,
    ):
        self.lookup = lookup
        self.nested = (
            nested
            if nested is not None
            else lookup
        )
        self.lookup_error = (
            lookup_error
        )
        self.lookup_calls = 0
        self.nested_calls = 0

    def get_order_by_client_id(
        self,
        client_id,
    ):
        self.lookup_calls += 1

        if self.lookup_error:
            raise self.lookup_error

        return self.lookup

    def get_order_by_id(
        self,
        order_id,
        filter=None,
    ):
        self.nested_calls += 1
        assert filter.nested is True
        return self.nested


def prepared_store(
    tmp_path,
):
    store = OptionsPositionStore(
        tmp_path
        / "positions.json"
    )

    store.prepare_entry(
        manifest()
    )

    return store


def test_no_active_record():
    from tempfile import (
        TemporaryDirectory,
    )
    from pathlib import Path

    with TemporaryDirectory() as td:
        store = OptionsPositionStore(
            Path(td)
            / "positions.json"
        )

        result = recover_prepared_entry(
            store=store,
            client=FakeClient(),
        )

        assert (
            result["status"]
            == "NO_ACTIVE_RECORD"
        )


def test_404_keeps_prepared_and_never_resubmits(
    tmp_path,
):
    store = prepared_store(
        tmp_path
    )

    client = FakeClient(
        lookup_error=MissingError(
            "not found"
        )
    )

    result = recover_prepared_entry(
        store=store,
        client=client,
    )

    assert (
        result["status"]
        == "BROKER_NOT_FOUND"
    )

    assert (
        result[
            "resubmission_allowed"
        ]
        is False
    )

    assert (
        store.active_record().state
        == EntryState.PREPARED
    )

    assert client.nested_calls == 0


def test_ambiguous_lookup_keeps_prepared(
    tmp_path,
):
    store = prepared_store(
        tmp_path
    )

    result = recover_prepared_entry(
        store=store,
        client=FakeClient(
            lookup_error=
                AmbiguousError(
                    "service unavailable"
                )
        ),
    )

    assert (
        result["status"]
        == "DEGRADED"
    )

    assert (
        result["reason"]
        == "AMBIGUOUS_BROKER_LOOKUP_FAILURE"
    )

    assert (
        store.active_record().state
        == EntryState.PREPARED
    )


def test_new_order_advances_to_submitted(
    tmp_path,
):
    store = prepared_store(
        tmp_path
    )

    order = broker_order(
        status="new"
    )

    result = recover_prepared_entry(
        store=store,
        client=FakeClient(
            lookup=order,
            nested=order,
        ),
    )

    assert (
        result["status"]
        == "RECOVERED_SUBMITTED"
    )

    active = store.active_record()

    assert active is not None

    assert (
        active.state
        == EntryState.SUBMITTED
    )

    assert (
        active.broker_order_id
        == "broker-001"
    )


def test_canceled_zero_fill_is_terminal(
    tmp_path,
):
    store = prepared_store(
        tmp_path
    )

    order = broker_order(
        status="canceled",
        filled_qty="0",
    )

    result = recover_prepared_entry(
        store=store,
        client=FakeClient(
            lookup=order,
            nested=order,
        ),
    )

    assert (
        result["status"]
        == "RECOVERED_TERMINAL"
    )

    assert (
        store.active_record()
        is None
    )

    assert (
        store.get(
            "recovery-record"
        ).state
        == EntryState.CANCELED
    )


def test_rejected_zero_fill_is_terminal(
    tmp_path,
):
    store = prepared_store(
        tmp_path
    )

    order = broker_order(
        status="rejected"
    )

    result = recover_prepared_entry(
        store=store,
        client=FakeClient(
            lookup=order,
            nested=order,
        ),
    )

    assert (
        result["status"]
        == "RECOVERED_TERMINAL"
    )

    assert (
        store.get(
            "recovery-record"
        ).state
        == EntryState.REJECTED
    )


def test_filled_order_is_blocked_without_state_mutation(
    tmp_path,
):
    store = prepared_store(
        tmp_path
    )

    order = broker_order(
        status="filled",
        filled_qty="1",
    )

    result = recover_prepared_entry(
        store=store,
        client=FakeClient(
            lookup=order,
            nested=order,
        ),
    )

    assert (
        result["status"]
        == "BLOCKED_FILL_RECOVERY"
    )

    assert (
        result["reason"]
        == "MLEG_FILL_SEMANTICS_NOT_CERTIFIED"
    )

    assert (
        store.active_record().state
        == EntryState.PREPARED
    )


def test_nonzero_fill_blocks_even_if_canceled(
    tmp_path,
):
    store = prepared_store(
        tmp_path
    )

    order = broker_order(
        status="canceled",
        filled_qty="1",
    )

    result = recover_prepared_entry(
        store=store,
        client=FakeClient(
            lookup=order,
            nested=order,
        ),
    )

    assert (
        result["status"]
        == "BLOCKED_FILL_RECOVERY"
    )

    assert (
        store.active_record().state
        == EntryState.PREPARED
    )


def test_limit_mismatch_fails_closed(
    tmp_path,
):
    store = prepared_store(
        tmp_path
    )

    order = broker_order(
        limit_price="3.14"
    )

    result = recover_prepared_entry(
        store=store,
        client=FakeClient(
            lookup=order,
            nested=order,
        ),
    )

    assert (
        result["status"]
        == "DEGRADED"
    )

    assert (
        result["reason"]
        == "BROKER_ORDER_RECONCILIATION_FAILED"
    )

    assert (
        result["error_reason"]
        == "RECOVERED_ORDER_LIMIT_MISMATCH"
    )

    assert (
        store.active_record().state
        == EntryState.PREPARED
    )


def test_status_has_no_effect_authority():
    state = status()

    assert (
        state[
            "definitive_404_resubmits"
        ]
        is False
    )

    assert (
        state[
            "ambiguous_read_resubmits"
        ]
        is False
    )

    assert (
        state[
            "filled_recovery_supported"
        ]
        is False
    )

    assert (
        state[
            "broker_writes"
        ]
        is False
    )

    assert (
        state[
            "order_submission_authority"
        ]
        is False
    )

    assert (
        state[
            "execution_effect"
        ]
        is False
    )
