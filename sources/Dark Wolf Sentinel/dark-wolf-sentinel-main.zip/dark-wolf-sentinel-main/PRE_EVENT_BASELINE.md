# Dark Wolf Sentinel — Pre-Event Baseline

This document records that a working Dark Wolf Sentinel prototype
existed before the official Alpaca AI Trading Agents Hackathon
build window.

## Status before kickoff

The pre-event prototype includes:

- Alpaca PAPER connectivity
- Alpaca IEX market-data scanner
- deterministic opportunity ranking
- OpenAI proposal layer
- deterministic risk authority
- controlled Alpaca PAPER execution proof
- broker reconciliation
- Alpaca MCP read-only integration
- MCP news enrichment
- news relevance filtering
- read-only demonstration dashboard
- automated safety tests

## Safety state

The demonstration configuration is:

- Alpaca PAPER only
- LIVE trading disabled
- PAPER order execution disabled by default
- AI trading authority false
- MCP trading toolsets excluded
- deterministic code owns sizing/risk approval

## Hackathon provenance

This repository must not claim that pre-event functionality was
created during the official hackathon period.

Any functionality developed during the official event should be
documented separately and accurately.

This file exists to preserve transparent project provenance.
