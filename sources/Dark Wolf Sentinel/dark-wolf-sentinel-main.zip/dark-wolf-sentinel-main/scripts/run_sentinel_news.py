from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from app.agent.bridge import (
    proposal_to_candidate,
)
from app.agent.models import (
    AgentAction,
    MarketContext,
)
from app.agent.openai_agent import (
    OpenAITradingAgent,
)
from app.broker.alpaca_paper import (
    AlpacaPaperBroker,
)
from app.config import Settings
from app.mcp.alpaca_news import (
    fetch_news,
)
from app.models import (
    AssetClass,
    PortfolioState,
)
from app.news_relevance import (
    filter_relevant_news,
)
from app.options_sentinel_bridge import (
    evaluate_options_shadow,
)
from app.options_intent_bridge import (
    build_shadow_order_intent,
)
from app.options_durable_execution_bridge import (
    execute_options_paper_durable_if_enabled,
)
from app.risk import (
    RiskPolicy,
    evaluate_trade,
)
from app.sentinel_scanner import (
    scan,
)


RESULT_PATH = Path(
    "data/sentinel_news_latest.json"
)


def main() -> None:
    settings = Settings()

    settings.assert_paper_only()

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "Execution must remain disabled."
        )

    broker = AlpacaPaperBroker(
        settings
    )

    broker_state = broker.snapshot()

    if broker_state["positions"]:
        raise RuntimeError(
            "Broker must be flat."
        )

    if broker_state["open_orders"]:
        raise RuntimeError(
            "Unexpected broker orders."
        )

    print(
        "Scanning Alpaca IEX universe..."
    )

    ranked = scan(
        settings
    )

    if not ranked:
        raise RuntimeError(
            "Scanner returned no candidates."
        )

    print()
    print(
        "============================================"
    )
    print(
        " DETERMINISTIC RANKING"
    )
    print(
        "============================================"
    )

    for index, item in enumerate(
        ranked,
        start=1,
    ):
        print(
            f"{index:>2}. "
            f"{item.symbol:<5} "
            f"SCORE {item.score:>5} "
            f"TREND {item.trend:<5} "
            f"RSI {item.rsi}"
        )

    selected = ranked[0]

    print()
    print(
        "SELECTED:",
        selected.symbol,
    )

    print()
    print(
        "Retrieving Alpaca MCP news..."
    )

    raw_news = fetch_news(
        settings,
        selected.symbol,
        limit=10,
    )

    relevant_news, ranked_news = (
        filter_relevant_news(
            selected.symbol,
            raw_news,
            limit=5,
        )
    )

    print(
        "RAW NEWS ITEMS:",
        len(raw_news),
    )

    print(
        "RELEVANT NEWS ITEMS:",
        len(relevant_news),
    )

    if relevant_news:
        for item in relevant_news:
            print(
                "-",
                item,
            )
    else:
        print(
            "- No sufficiently relevant "
            "symbol news returned"
        )

    print()
    print(
        "NEWS RELEVANCE SCORES:"
    )

    for item in ranked_news:
        print(
            f"{item.score:>4} | "
            f"{item.text[:100]}"
        )

    context = MarketContext(
        symbol=selected.symbol,
        asset_class="equity",
        current_price=
            selected.current_price,
        timeframe="15m",
        market_regime=
            "SENTINEL_SCAN",
        trend=selected.trend,
        rsi=selected.rsi,
        ema20=selected.ema20,
        ema50=selected.ema50,
        prior_high=
            selected.prior_high,
        volume_ratio=
            selected.volume_ratio,
        news_context=
            relevant_news,
    )

    print()
    print(
        "Calling GPT-5.6 with "
        "technical + filtered MCP context..."
    )

    agent = OpenAITradingAgent(
        settings
    )

    proposal = agent.analyze(
        context
    )

    print()
    print(
        "GPT ACTION:",
        proposal.action.value,
    )

    print(
        "CONFIDENCE:",
        proposal.confidence,
    )

    print(
        "THESIS:",
        proposal.thesis,
    )

    print(
        "CATALYST:",
        proposal.catalyst,
    )

    candidate = proposal_to_candidate(
        proposal,
        asset_class=
            AssetClass.EQUITY,
    )

    risk_decision = None

    if candidate is None:
        print()

        if proposal.action == AgentAction.PASS:
            print(
                "RISK: NOT RUN — GPT PASS"
            )

        elif proposal.action == AgentAction.BEARISH:
            print(
                "RISK: NOT RUN — "
                "BEARISH OPTIONS-ONLY ACTION"
            )

        else:
            raise RuntimeError(
                "Unexpected action without "
                "equity candidate."
            )

    else:
        portfolio = PortfolioState(
            equity=float(
                broker_state[
                    "account"
                ]["equity"]
            ),
            current_open_risk=0,
            current_crypto_risk=0,
            current_exposure=0,
            open_symbols=[],
            kill_switch=False,
        )

        risk_decision = evaluate_trade(
            candidate,
            portfolio,
            RiskPolicy.from_settings(
                settings
            ),
        )

        print()
        print(
            "DETERMINISTIC RISK:",
            (
                "APPROVED"
                if risk_decision.approved
                else "REJECTED"
            ),
        )

        print(
            "REASON:",
            risk_decision.reason,
        )

        print(
            "MAX QUANTITY:",
            risk_decision.quantity,
        )

    decision_id = (
        selected.symbol
        + ":"
        + proposal.action.value
        + ":"
        + datetime.now(
            timezone.utc
        ).isoformat()
    )

    options_shadow = evaluate_options_shadow(
        settings=settings,
        proposal=proposal,
        equity=float(
            broker_state[
                "account"
            ]["equity"]
        ),
        current_open_risk=0,
        requested_quantity=1,
    )

    print()
    print(
        "OPTIONS SHADOW:",
        options_shadow[
            "status"
        ],
    )

    print(
        "OPTIONS REASON:",
        options_shadow[
            "reason"
        ],
    )

    print(
        "OPTIONS DIRECTION:",
        options_shadow[
            "direction"
        ],
    )

    print(
        "OPTIONS ORDER AUTHORITY:",
        options_shadow[
            "order_authority"
        ],
    )

    options_order_intent = (
        build_shadow_order_intent(
            options_shadow=
                options_shadow,
            decision_id=
                decision_id,
        )
    )

    print()

    if options_order_intent is None:
        print(
            "OPTIONS MLEG INTENT: NONE"
        )

    else:
        print(
            "OPTIONS MLEG INTENT:",
            options_order_intent[
                "status"
            ],
        )

        print(
            "OPTIONS MLEG REASON:",
            options_order_intent[
                "reason"
            ],
        )

        print(
            "OPTIONS SUBMISSION AUTHORITY:",
            options_order_intent[
                "order_submission_authority"
            ],
        )

    options_execution = (
        execute_options_paper_durable_if_enabled(
            settings=settings,
            agent_proposal=
                proposal,
            options_shadow=
                options_shadow,
            options_order_intent=
                options_order_intent,
        )
    )

    print()

    print(
        "OPTIONS EXECUTION STATUS:",
        options_execution["status"],
    )

    print(
        "OPTIONS EXECUTION REASON:",
        options_execution["reason"],
    )

    print(
        "OPTIONS BROKER ORDER SUBMITTED:",
        options_execution["submitted"],
    )

    if options_execution["submitted"]:
        broker_order_submitted = True

    generated_at = datetime.now(
        timezone.utc
    ).isoformat()

    result = {
        "generated_at":
            generated_at,
        "market_data_at":
            generated_at,
        "mode":
            "SENTINEL_MCP_NEWS_ANALYSIS",
        "news_source":
            "ALPACA_MCP_READ_ONLY",
        "selected_symbol":
            selected.symbol,
        "selected_snapshot":
            selected.__dict__,
        "ranking": [
            item.__dict__
            for item in ranked
        ],
        "news_context_raw":
            raw_news,
        "news_context":
            relevant_news,
        "news_raw_count":
            len(raw_news),
        "news_relevant_count":
            len(relevant_news),
        "news_relevance": [
            {
                "text":
                    item.text,
                "score":
                    item.score,
                "reasons":
                    item.reasons,
            }
            for item in ranked_news
        ],
        "proposal":
            proposal.model_dump(
                mode="json"
            ),
        "risk_decision":
            (
                risk_decision.model_dump(
                    mode="json"
                )
                if risk_decision
                else None
            ),
        "options_shadow":
            options_shadow,
        "options_order_intent":
            options_order_intent,
        "options_execution":
            options_execution,
        "paper_execution_enabled":
            False,
        "broker_order_submitted":
            False,
        "live_trading":
            False,
        "ai_trading_authority":
            False,
        "mcp_trading_tools":
            False,
    }

    RESULT_PATH.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    RESULT_PATH.write_text(
        json.dumps(
            result,
            indent=2,
        )
        + "\n"
    )

    print()
    print(
        "BROKER ORDER SUBMITTED: False"
    )
    print(
        "PAPER EXECUTION: False"
    )
    print(
        "AI AUTHORITY: False"
    )
    print(
        "MCP TRADING TOOLS: False"
    )


if __name__ == "__main__":
    main()
