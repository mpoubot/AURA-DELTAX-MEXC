from __future__ import annotations

from alpaca.trading.client import TradingClient

from app.config import get_settings


def main() -> None:
    settings = get_settings()

    settings.assert_paper_only()

    if not settings.alpaca_configured:
        raise RuntimeError(
            "Alpaca PAPER credentials missing."
        )

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "Readiness test requires execution disabled."
        )

    client = TradingClient(
        settings.alpaca_api_key,
        settings.alpaca_secret_key,
        paper=True,
    )

    account = client.get_account()
    clock = client.get_clock()
    asset = client.get_asset("AAPL")

    positions = client.get_all_positions()

    print("MODE: ALPACA_PAPER_READINESS")
    print("ACCOUNT STATUS:", account.status)
    print("EQUITY:", float(account.equity))
    print("CASH:", float(account.cash))
    print("MARKET OPEN:", bool(clock.is_open))
    print("AAPL TRADABLE:", bool(asset.tradable))
    print(
        "AAPL FRACTIONABLE:",
        bool(asset.fractionable),
    )
    print("POSITIONS:", len(positions))

    print(
        "PAPER EXECUTION ENABLED:",
        settings.paper_execution_enabled,
    )

    print("LIVE TRADING: False")
    print("TRADING AUTHORITY: False")

    assert float(account.equity) > 0
    assert asset.tradable is True
    assert asset.fractionable is True

    print()
    print("READINESS: PASS")
    print("NO ORDER SUBMITTED")


if __name__ == "__main__":
    main()
