from __future__ import annotations

from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]

SEARCH_DIRS = [
    ROOT / "app",
    ROOT / "tests",
    ROOT / "scripts",
]

FORBIDDEN = {
    "paper=False":
        "Alpaca client configured for LIVE",
    'paper = False':
        "Alpaca client configured for LIVE",
    "https://api.alpaca.markets":
        "LIVE Alpaca trading endpoint",
    "ALPACA_PAPER=false":
        "Live/paper bypass",
    "live_order_allowed=True":
        "Live order authorization",
    "trading_authority=True":
        "Trading authority enabled",
}

failures = []

scanner_path = Path(__file__).resolve()

for directory in SEARCH_DIRS:
    for path in directory.rglob("*.py"):
        if path.resolve() == scanner_path:
            continue

        text = path.read_text(
            errors="replace"
        )

        for needle, reason in FORBIDDEN.items():
            if needle in text:
                failures.append(
                    (
                        str(
                            path.relative_to(ROOT)
                        ),
                        needle,
                        reason,
                    )
                )

if failures:
    print(
        "SAFETY CHECK: FAIL"
    )

    for path, needle, reason in failures:
        print(
            f"- {path}: {reason}: "
            f"{needle!r}"
        )

    raise SystemExit(1)

print(
    "SAFETY CHECK: PASS"
)

print(
    "No LIVE Alpaca configuration "
    "or trading authority detected."
)
