from __future__ import annotations

import subprocess
from pathlib import Path


ROOT = Path(".").resolve()

PRIVATE_KEYS = (
    "OPENAI_API_KEY",
    "ALPACA_API_KEY",
    "ALPACA_SECRET_KEY",
)


def candidate_files() -> list[Path]:
    result = subprocess.run(
        [
            "git",
            "ls-files",
            "--cached",
            "--others",
            "--exclude-standard",
        ],
        check=True,
        capture_output=True,
        text=True,
    )

    output = []

    for raw in result.stdout.splitlines():
        p = Path(raw)

        if not p.is_file():
            continue

        output.append(p)

    return output


def read_private_values() -> dict[str, str]:
    env = Path(".env")

    if not env.exists():
        return {}

    values: dict[str, str] = {}

    for raw in env.read_text(
        errors="ignore"
    ).splitlines():

        line = raw.strip()

        if (
            not line
            or line.startswith("#")
            or "=" not in line
        ):
            continue

        key, value = line.split(
            "=",
            1,
        )

        key = key.strip()
        value = value.strip()

        if (
            key in PRIVATE_KEYS
            and value
        ):
            values[key] = value

    return values


def main() -> None:
    files = candidate_files()

    secrets = read_private_values()

    failures: list[
        tuple[str, str]
    ] = []

    suspicious_names = [
        p
        for p in files
        if (
            p.name.startswith(".env")
            and p.name != ".env.example"
        )
    ]

    for p in suspicious_names:
        failures.append(
            (
                str(p),
                "private env-like filename",
            )
        )

    for p in files:
        try:
            text = p.read_text(
                errors="ignore"
            )

        except Exception:
            continue

        for key, value in secrets.items():
            if (
                len(value) >= 8
                and value in text
            ):
                failures.append(
                    (
                        str(p),
                        f"contains current {key}",
                    )
                )

        if "s\x6b-proj-" in text:
            failures.append(
                (
                    str(p),
                    "contains OpenAI-style secret prefix",
                )
            )

    print(
        "PUBLIC-CANDIDATE FILES:",
        len(files),
    )

    print(
        "PRIVATE VALUES CHECKED:",
        len(secrets),
    )

    if failures:
        print()
        print(
            "PUBLIC REPO AUDIT: FAIL"
        )

        for path, reason in failures:
            print(
                "-",
                path,
                "|",
                reason,
            )

        raise SystemExit(1)

    print()
    print(
        "PUBLIC REPO AUDIT: PASS"
    )

    print(
        "No current API secrets found "
        "in public-candidate files."
    )


if __name__ == "__main__":
    main()
