from __future__ import annotations

import json
from datetime import datetime, timedelta, timezone
from pathlib import Path

from alpaca.data.historical import StockHistoricalDataClient
from alpaca.data.enums import DataFeed
from alpaca.data.requests import (
    StockBarsRequest,
    StockLatestTradeRequest,
)
from alpaca.data.timeframe import TimeFrame

from app.agent.bridge import proposal_to_candidate
from app.agent.models import MarketContext
from app.agent.openai_agent import OpenAITradingAgent
from app.broker.alpaca_paper import AlpacaPaperBroker
from app.config import Settings
from app.models import AssetClass, PortfolioState
from app.risk import RiskPolicy, evaluate_trade


RESULT_PATH = Path("data/gpt_market_probe.json")


def ema(values: list[float], period: int) -> float:
    multiplier = 2 / (period + 1)
    value = values[0]

    for price in values[1:]:
        value = (
            price * multiplier
            + value * (1 - multiplier)
        )

    return value


def rsi(
    values: list[float],
    period: int = 14,
) -> float | None:
    if len(values) < period + 1:
        return None

    changes = [
        values[i] - values[i - 1]
        for i in range(1, len(values))
    ]

    gains = [
        max(change, 0)
        for change in changes[-period:]
    ]

    losses = [
        abs(min(change, 0))
        for change in changes[-period:]
    ]

    avg_gain = sum(gains) / period
    avg_loss = sum(losses) / period

    if avg_loss == 0:
        return 100.0

    rs = avg_gain / avg_loss

    return 100 - (100 / (1 + rs))


def main() -> None:
    settings = Settings()

    settings.assert_paper_only()

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "GPT analysis requires PAPER execution disabled."
        )

    if not settings.openai_configured:
        raise RuntimeError(
            "OpenAI is not configured."
        )

    # Confirm broker is flat before AI analysis.
    broker = AlpacaPaperBroker(settings)
    broker_state = broker.snapshot()

    if broker_state["positions"]:
        raise RuntimeError(
            "Unexpected broker position before AI probe."
        )

    if broker_state["open_orders"]:
        raise RuntimeError(
            "Unexpected open broker order before AI probe."
        )

    data = StockHistoricalDataClient(
        settings.alpaca_api_key,
        settings.alpaca_secret_key,
    )

    now = datetime.now(timezone.utc)

    bars = data.get_stock_bars(
        StockBarsRequest(
            symbol_or_symbols="AAPL",
            timeframe=TimeFrame.Minute,
            feed=DataFeed.IEX,
            start=now - timedelta(days=3),
            end=now,
        )
    )

    raw_bars = list(bars["AAPL"])

    if len(raw_bars) < 60:
        raise RuntimeError(
            f"Insufficient AAPL bars: {len(raw_bars)}"
        )

    closes = [
        float(bar.close)
        for bar in raw_bars
    ]

    volumes = [
        float(bar.volume)
        for bar in raw_bars
    ]

    latest = data.get_stock_latest_trade(
        StockLatestTradeRequest(
            symbol_or_symbols="AAPL",
            feed=DataFeed.IEX,
        )
    )["AAPL"]

    current_price = float(latest.price)

    ema20_value = ema(
        closes[-60:],
        20,
    )

    ema50_value = ema(
        closes[-100:],
        50,
    )

    rsi_value = rsi(closes)

    prior_high = max(
        closes[-21:-1]
    )

    recent_volume = (
        sum(volumes[-20:]) / 20
    )

    prior_volume = (
        sum(volumes[-40:-20]) / 20
    )

    volume_ratio = (
        recent_volume / prior_volume
        if prior_volume > 0
        else None
    )

    if (
        current_price
        > ema20_value
        > ema50_value
    ):
        trend = "UP"

    elif (
        current_price
        < ema20_value
        < ema50_value
    ):
        trend = "DOWN"

    else:
        trend = "MIXED"

    context = MarketContext(
        symbol="AAPL",
        asset_class="equity",
        current_price=current_price,
        timeframe="1m",
        market_regime="INTRADAY",
        trend=trend,
        rsi=(
            round(rsi_value, 2)
            if rsi_value is not None
            else None
        ),
        ema20=round(
            ema20_value,
            4,
        ),
        ema50=round(
            ema50_value,
            4,
        ),
        prior_high=round(
            prior_high,
            4,
        ),
        volume_ratio=(
            round(volume_ratio, 3)
            if volume_ratio is not None
            else None
        ),
        news_context=[],
    )

    print()
    print("MARKET CONTEXT:")
    print(
        json.dumps(
            context.model_dump(
                mode="json"
            ),
            indent=2,
        )
    )

    print()
    print("Calling GPT-5.6...")

    agent = OpenAITradingAgent(
        settings
    )

    proposal = agent.analyze(
        context
    )

    print()
    print("GPT-5.6 PROPOSAL:")
    print(
        json.dumps(
            proposal.model_dump(
                mode="json"
            ),
            indent=2,
        )
    )

    candidate = proposal_to_candidate(
        proposal,
        asset_class=AssetClass.EQUITY,
    )

    risk_decision = None

    if candidate is None:
        print()
        print(
            "AI returned PASS — no risk sizing required."
        )

    else:
        portfolio = PortfolioState(
            equity=float(
                broker_state[
                    "account"
                ]["equity"]
            ),
            current_open_risk=0,
            current_crypto_risk=0,
            current_exposure=0,
            open_symbols=[],
            kill_switch=False,
        )

        risk_decision = evaluate_trade(
            candidate,
            portfolio,
            RiskPolicy.from_settings(
                settings
            ),
        )

        print()
        print(
            "DETERMINISTIC RISK DECISION:"
        )

        print(
            json.dumps(
                risk_decision.model_dump(
                    mode="json"
                ),
                indent=2,
            )
        )

    result = {
        "mode": "AI_ANALYSIS_ONLY",
        "model": settings.openai_model,
        "context": context.model_dump(
            mode="json"
        ),
        "proposal": proposal.model_dump(
            mode="json"
        ),
        "risk_decision": (
            risk_decision.model_dump(
                mode="json"
            )
            if risk_decision
            else None
        ),
        "alpaca_paper": True,
        "paper_execution_enabled": False,
        "broker_order_submitted": False,
        "live_trading": False,
        "ai_trading_authority": False,
    }

    RESULT_PATH.write_text(
        json.dumps(
            result,
            indent=2,
        )
        + "\n"
    )

    print()
    print("SAFETY:")
    print("Broker order submitted: False")
    print("PAPER execution enabled: False")
    print("LIVE trading: False")
    print("AI trading authority: False")


if __name__ == "__main__":
    main()
