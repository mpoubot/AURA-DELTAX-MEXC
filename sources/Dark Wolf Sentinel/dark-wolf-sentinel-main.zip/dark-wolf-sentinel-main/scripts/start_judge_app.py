from __future__ import annotations

import os
import subprocess
import sys
import threading

import uvicorn

from app.config import Settings
from app.deployment import validate_judge_deployment


DEFAULT_PORT = 8000
PORT_ENV = "SENTINEL_PORT"
REFRESH_ENV = "SENTINEL_DEPLOYMENT_REFRESH_ON_START"


def refresh_on_start_enabled() -> bool:
    raw = os.environ.get(REFRESH_ENV, "false").strip().lower()

    if raw not in {"true", "false"}:
        raise RuntimeError(
            f"{REFRESH_ENV} must be exactly true or false."
        )

    return raw == "true"


def deployment_port() -> int:
    raw = os.environ.get(PORT_ENV, str(DEFAULT_PORT)).strip()

    try:
        port = int(raw)
    except ValueError as exc:
        raise RuntimeError(f"{PORT_ENV} must be an integer.") from exc

    if not 1 <= port <= 65535:
        raise RuntimeError(f"{PORT_ENV} must be between 1 and 65535.")

    return port


def initial_analysis() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "scripts.run_sentinel_worker"],
        check=False,
    )

    if result.returncode == 0:
        print("DEPLOYMENT INITIAL ANALYSIS: PASS", flush=True)
    else:
        print(
            "DEPLOYMENT INITIAL ANALYSIS: FAILED CLOSED",
            flush=True,
        )


def main() -> None:
    settings = Settings()
    readiness = validate_judge_deployment(settings)
    refresh = refresh_on_start_enabled()
    port = deployment_port()

    print("DEPLOYMENT PREFLIGHT: PASS", flush=True)
    print(f"ALPACA PAPER: {readiness['alpaca_paper']}", flush=True)
    print(
        f"PAPER EXECUTION: {readiness['paper_execution']}",
        flush=True,
    )
    print(
        "OPTIONS PAPER EXECUTION: "
        f"{readiness['options_paper_execution']}",
        flush=True,
    )
    print(f"LIVE TRADING: {readiness['live_trading']}", flush=True)
    print(
        "AI EXECUTION AUTHORITY: "
        f"{readiness['ai_execution_authority']}",
        flush=True,
    )

    if refresh:
        threading.Thread(
            target=initial_analysis,
            name="sentinel-initial-analysis",
            daemon=True,
        ).start()

    uvicorn.run(
        "app.dashboard_server:app",
        host="0.0.0.0",
        port=port,
        log_level="info",
    )


if __name__ == "__main__":
    main()
