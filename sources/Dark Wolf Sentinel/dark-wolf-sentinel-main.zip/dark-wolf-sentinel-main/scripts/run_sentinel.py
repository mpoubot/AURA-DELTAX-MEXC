from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path

from app.agent.bridge import (
    proposal_to_candidate,
)
from app.agent.models import (
    MarketContext,
)
from app.agent.openai_agent import (
    OpenAITradingAgent,
)
from app.broker.alpaca_paper import (
    AlpacaPaperBroker,
)
from app.config import Settings
from app.models import (
    AssetClass,
    PortfolioState,
)
from app.risk import (
    RiskPolicy,
    evaluate_trade,
)
from app.sentinel_scanner import (
    scan,
)


RESULT_PATH = Path(
    "data/sentinel_latest.json"
)


def main() -> None:
    settings = Settings()

    settings.assert_paper_only()

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "Sentinel analysis requires "
            "execution disabled."
        )

    broker = AlpacaPaperBroker(
        settings
    )

    broker_state = broker.snapshot()

    if broker_state["open_orders"]:
        raise RuntimeError(
            "Unexpected broker open orders."
        )

    if broker_state["positions"]:
        raise RuntimeError(
            "Unexpected broker positions."
        )

    print(
        "Scanning Alpaca IEX universe..."
    )

    ranked = scan(
        settings
    )

    if not ranked:
        raise RuntimeError(
            "Scanner returned no symbols."
        )

    print()
    print(
        "============================================"
    )
    print(
        " DETERMINISTIC MARKET RANKING"
    )
    print(
        "============================================"
    )

    for index, item in enumerate(
        ranked,
        start=1,
    ):
        print(
            f"{index:>2}. "
            f"{item.symbol:<5} "
            f"SCORE {item.score:>5} "
            f"TREND {item.trend:<5} "
            f"RSI {item.rsi} "
            f"VOL {item.volume_ratio}"
        )

    selected = ranked[0]

    print()
    print(
        "SELECTED FOR GPT-5.6:",
        selected.symbol,
    )

    context = MarketContext(
        symbol=selected.symbol,
        asset_class="equity",
        current_price=
            selected.current_price,
        timeframe="15m",
        market_regime=
            "SENTINEL_SCAN",
        trend=selected.trend,
        rsi=selected.rsi,
        ema20=selected.ema20,
        ema50=selected.ema50,
        prior_high=
            selected.prior_high,
        volume_ratio=
            selected.volume_ratio,
        news_context=[],
    )

    agent = OpenAITradingAgent(
        settings
    )

    print()
    print(
        "Calling GPT-5.6..."
    )

    proposal = agent.analyze(
        context
    )

    print()
    print(
        "GPT-5.6:",
        proposal.action.value,
        "| confidence:",
        proposal.confidence,
    )

    print(
        "THESIS:",
        proposal.thesis,
    )

    candidate = proposal_to_candidate(
        proposal,
        asset_class=
            AssetClass.EQUITY,
    )

    risk_decision = None

    if candidate is None:
        print()
        print(
            "FINAL SENTINEL STATE: PASS"
        )

    else:
        portfolio = PortfolioState(
            equity=float(
                broker_state[
                    "account"
                ]["equity"]
            ),
            current_open_risk=0,
            current_crypto_risk=0,
            current_exposure=0,
            open_symbols=[],
            kill_switch=False,
        )

        risk_decision = evaluate_trade(
            candidate,
            portfolio,
            RiskPolicy.from_settings(
                settings
            ),
        )

        print()
        print(
            "DETERMINISTIC RISK:",
            (
                "APPROVED"
                if risk_decision.approved
                else "REJECTED"
            ),
        )

        print(
            "REASON:",
            risk_decision.reason,
        )

        print(
            "MAX QUANTITY:",
            risk_decision.quantity,
        )

    result = {
        "generated_at":
            datetime.now(
                timezone.utc
            ).isoformat(),
        "mode":
            "SENTINEL_ANALYSIS_ONLY",
        "universe": [
            item.symbol
            for item in ranked
        ],
        "ranking": [
            item.__dict__
            for item in ranked
        ],
        "selected_symbol":
            selected.symbol,
        "proposal":
            proposal.model_dump(
                mode="json"
            ),
        "risk_decision":
            (
                risk_decision.model_dump(
                    mode="json"
                )
                if risk_decision
                else None
            ),
        "paper_execution_enabled":
            False,
        "broker_order_submitted":
            False,
        "live_trading":
            False,
        "ai_trading_authority":
            False,
    }

    RESULT_PATH.write_text(
        json.dumps(
            result,
            indent=2,
        )
        + "\n"
    )

    print()
    print(
        "BROKER ORDER SUBMITTED: False"
    )
    print(
        "PAPER EXECUTION ENABLED: False"
    )
    print(
        "LIVE: False"
    )


if __name__ == "__main__":
    main()
