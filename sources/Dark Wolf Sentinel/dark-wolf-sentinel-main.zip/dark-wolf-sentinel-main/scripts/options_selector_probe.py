from __future__ import annotations

from datetime import (
    date,
    timedelta,
)
from decimal import Decimal

from alpaca.data.historical.option import (
    OptionHistoricalDataClient,
)
from alpaca.data.requests import (
    OptionChainRequest,
)
from alpaca.trading.enums import (
    ContractType,
)

from app.config import Settings
from app.options_selector import (
    OptionDirection,
    adapt_alpaca_chain,
    select_debit_vertical,
)
from app.options_verticals import (
    OptionsPortfolioState,
    OptionsRiskPolicy,
)


UNDERLYING = "SPY"


def main() -> None:
    settings = Settings()

    settings.assert_paper_only()

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "PAPER execution must remain disabled."
        )

    client = (
        OptionHistoricalDataClient(
            api_key=
                settings.alpaca_api_key,
            secret_key=
                settings.alpaca_secret_key,
        )
    )

    today = date.today()

    chain = client.get_option_chain(
        OptionChainRequest(
            underlying_symbol=
                UNDERLYING,
            type=
                ContractType.CALL,
            expiration_date_gte=(
                today
                + timedelta(
                    days=7
                )
            ),
            expiration_date_lte=(
                today
                + timedelta(
                    days=45
                )
            ),
        )
    )

    candidates, adapter_rejections = (
        adapt_alpaca_chain(
            chain
        )
    )

    result = select_debit_vertical(
        direction=
            OptionDirection.BULLISH,
        chain=candidates,
        confidence=90,
        thesis=(
            "Read-only selector "
            "certification probe."
        ),
        portfolio=
            OptionsPortfolioState(
                equity=
                    Decimal("100000"),
                current_open_risk=
                    Decimal("0"),
            ),
        risk_policy=
            OptionsRiskPolicy
            .from_settings(
                settings
            ),
        requested_quantity=1,
        as_of=today,
        adapter_rejections=
            adapter_rejections,
    )

    print(
        "UNDERLYING:",
        UNDERLYING,
    )

    print(
        "RAW CHAIN:",
        len(chain),
    )

    print(
        "ADAPTED:",
        len(candidates),
    )

    print(
        "SELECTED:",
        result.selected,
    )

    print(
        "REASON:",
        result.reason,
    )

    print(
        "ELIGIBLE:",
        result.eligible_contracts,
    )

    print(
        "PAIRS EVALUATED:",
        result.pairs_evaluated,
    )

    print(
        "REJECTIONS:",
        result.rejection_counts,
    )

    if not result.selected:
        raise RuntimeError(
            "No valid defined-risk "
            "SPY vertical found."
        )

    proposal = result.proposal
    metrics = result.metrics
    risk = result.risk_decision

    assert proposal is not None
    assert metrics is not None
    assert risk is not None

    print()
    print(
        "LONG:",
        proposal
        .long_leg
        .contract
        .symbol,
    )

    print(
        "SHORT:",
        proposal
        .short_leg
        .contract
        .symbol,
    )

    print(
        "EXPIRATION:",
        metrics.expiration,
    )

    print(
        "WIDTH:",
        metrics.width,
    )

    print(
        "NET DEBIT:",
        metrics
        .net_debit_per_share,
    )

    print(
        "MAX LOSS:",
        metrics
        .max_loss_per_spread,
    )

    print(
        "MAX PROFIT:",
        metrics
        .max_profit_per_spread,
    )

    print(
        "REWARD/RISK:",
        metrics
        .reward_to_risk,
    )

    print(
        "RISK APPROVED:",
        risk.approved,
    )

    print(
        "RISK REASON:",
        risk.reason,
    )

    print(
        "APPROVED QUANTITY:",
        risk.approved_quantity,
    )

    print()
    print(
        "BROKER ORDER SUBMITTED: False"
    )

    print(
        "PAPER EXECUTION: False"
    )

    print(
        "LIVE TRADING: False"
    )

    print(
        "AI TRADING AUTHORITY: False"
    )

    assert (
        result.trading_authority
        is False
    )

    assert (
        result.order_authority
        is False
    )

    assert (
        result.execution_effect
        is False
    )

    assert risk.approved is True


if __name__ == "__main__":
    main()
