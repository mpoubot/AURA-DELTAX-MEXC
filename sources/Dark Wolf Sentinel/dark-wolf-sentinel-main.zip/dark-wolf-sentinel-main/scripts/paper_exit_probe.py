from __future__ import annotations

import json
import time
from pathlib import Path

from alpaca.trading.client import (
    TradingClient,
)

from app.broker.alpaca_exit import (
    AlpacaPaperExitExecutor,
)
from app.broker.alpaca_paper import (
    AlpacaPaperBroker,
)
from app.config import get_settings


ENTRY_PATH = Path(
    "data/paper_probe_complete.json"
)

EXIT_PATH = Path(
    "data/paper_exit_complete.json"
)


def filled(
    value: object,
) -> bool:
    text = str(value).lower()

    return (
        text == "filled"
        or text.endswith(".filled")
    )


def main() -> None:
    if EXIT_PATH.exists():
        raise RuntimeError(
            "Controlled exit probe already completed."
        )

    if not ENTRY_PATH.exists():
        raise RuntimeError(
            "Entry probe record missing."
        )

    entry = json.loads(
        ENTRY_PATH.read_text()
    )

    settings = get_settings()

    settings.assert_paper_only()

    if (
        settings.paper_execution_enabled
        is not True
    ):
        raise RuntimeError(
            "PAPER execution is disabled."
        )

    trading = TradingClient(
        settings.alpaca_api_key,
        settings.alpaca_secret_key,
        paper=True,
    )

    clock = trading.get_clock()

    if not bool(clock.is_open):
        raise RuntimeError(
            "US equity market is closed."
        )

    readonly = AlpacaPaperBroker(
        settings
    )

    before = readonly.snapshot()

    if before["open_orders"]:
        raise RuntimeError(
            "Unexpected open orders before exit."
        )

    aapl = [
        p
        for p in before["positions"]
        if p["symbol"] == "AAPL"
    ]

    if len(aapl) != 1:
        raise RuntimeError(
            "Expected exactly one AAPL position."
        )

    held = float(
        aapl[0]["qty"]
    )

    if held < 0.01:
        raise RuntimeError(
            "AAPL position is smaller "
            "than the controlled exit."
        )

    entry_decision_id = entry[
        "decision_id"
    ]

    executor = AlpacaPaperExitExecutor(
        settings
    )

    print("BROKER CONFIRMED AAPL QTY:", held)
    print("EXIT QTY: 0.01")
    print("SIDE: SELL")
    print("TYPE: MARKET")
    print("PAPER: True")
    print("LIVE: False")

    submitted = executor.submit(
        symbol="AAPL",
        quantity=0.01,
        entry_decision_id=
            entry_decision_id,
    )

    print()
    print(
        "EXIT ORDER ID:",
        submitted["order"].get(
            "order_id"
        ),
    )

    print(
        "CLIENT ORDER ID:",
        submitted["order"].get(
            "client_order_id"
        ),
    )

    print(
        "INITIAL STATUS:",
        submitted["order"].get(
            "status"
        ),
    )

    reconciled = None

    for attempt in range(1, 21):
        time.sleep(1)

        reconciled = executor.reconcile(
            entry_decision_id=
                entry_decision_id,
        )

        order = reconciled["order"]

        print(
            "RECONCILE",
            attempt,
            "STATUS:",
            order.get("status"),
            "FILLED QTY:",
            order.get("filled_qty"),
            "AVG PRICE:",
            order.get(
                "filled_avg_price"
            ),
        )

        if filled(
            order.get("status")
        ):
            break

    if reconciled is None:
        raise RuntimeError(
            "No exit reconciliation result."
        )

    final_order = reconciled["order"]

    if not filled(
        final_order.get("status")
    ):
        raise RuntimeError(
            "Exit did not fill within timeout."
        )

    time.sleep(1)

    after = readonly.snapshot()

    aapl_after = [
        p
        for p in after["positions"]
        if p["symbol"] == "AAPL"
    ]

    result = {
        "mode":
            "ALPACA_PAPER_CONTROLLED_EXIT",
        "symbol":
            "AAPL",
        "side":
            "SELL",
        "quantity":
            0.01,
        "entry_decision_id":
            entry_decision_id,
        "client_order_id":
            final_order.get(
                "client_order_id"
            ),
        "broker_order_id":
            final_order.get(
                "order_id"
            ),
        "broker_status":
            final_order.get(
                "status"
            ),
        "filled_quantity":
            final_order.get(
                "filled_qty"
            ),
        "filled_avg_price":
            final_order.get(
                "filled_avg_price"
            ),
        "positions_after":
            len(after["positions"]),
        "aapl_positions_after":
            len(aapl_after),
        "open_orders_after":
            len(after["open_orders"]),
        "paper":
            True,
        "live_trading":
            False,
        "trading_authority":
            False,
    }

    EXIT_PATH.write_text(
        json.dumps(
            result,
            indent=2,
        )
        + "\n"
    )

    print()
    print(
        "CONTROLLED PAPER EXIT COMPLETE"
    )

    for key, value in result.items():
        print(
            f"{key}: {value}"
        )


if __name__ == "__main__":
    main()
