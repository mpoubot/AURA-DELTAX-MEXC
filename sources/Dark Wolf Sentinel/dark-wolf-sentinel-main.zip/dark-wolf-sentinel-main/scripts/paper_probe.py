from __future__ import annotations

import json
import time
from pathlib import Path

from alpaca.data.historical import (
    StockHistoricalDataClient,
)
from alpaca.data.requests import (
    StockLatestTradeRequest,
)
from alpaca.trading.client import (
    TradingClient,
)

from app.audit import record_decision
from app.broker.alpaca_executor import (
    AlpacaPaperExecutor,
)
from app.broker.alpaca_paper import (
    AlpacaPaperBroker,
)
from app.config import get_settings
from app.models import (
    AssetClass,
    PortfolioState,
    TradeCandidate,
)
from app.risk import (
    RiskPolicy,
    evaluate_trade,
)


RESULT_PATH = Path(
    "data/paper_probe_complete.json"
)


def status_is_filled(
    value: object,
) -> bool:
    text = str(value).lower()

    return (
        text == "filled"
        or text.endswith(".filled")
    )


def main() -> None:
    if RESULT_PATH.exists():
        raise RuntimeError(
            "Controlled AAPL PAPER probe has "
            "already completed. Refusing duplicate."
        )

    settings = get_settings()

    settings.assert_paper_only()

    if settings.paper_execution_enabled is not True:
        raise RuntimeError(
            "PAPER execution flag is not enabled."
        )

    if not settings.alpaca_configured:
        raise RuntimeError(
            "Alpaca PAPER credentials missing."
        )

    trading = TradingClient(
        settings.alpaca_api_key,
        settings.alpaca_secret_key,
        paper=True,
    )

    account = trading.get_account()
    clock = trading.get_clock()
    asset = trading.get_asset("AAPL")

    if not bool(clock.is_open):
        raise RuntimeError(
            "US equity market is closed."
        )

    if not bool(asset.tradable):
        raise RuntimeError(
            "AAPL is not tradable."
        )

    if not bool(asset.fractionable):
        raise RuntimeError(
            "AAPL is not fractionable."
        )

    readonly = AlpacaPaperBroker(
        settings
    )

    snapshot = readonly.snapshot()

    if snapshot["open_orders"]:
        raise RuntimeError(
            "Unexpected pre-existing open orders."
        )

    if snapshot["positions"]:
        raise RuntimeError(
            "Unexpected pre-existing positions. "
            "First probe requires a clean account."
        )

    data = StockHistoricalDataClient(
        settings.alpaca_api_key,
        settings.alpaca_secret_key,
    )

    latest = data.get_stock_latest_trade(
        StockLatestTradeRequest(
            symbol_or_symbols="AAPL",
        )
    )

    trade = latest["AAPL"]

    price = float(
        trade.price
    )

    if price <= 0:
        raise RuntimeError(
            "Invalid AAPL market price."
        )

    candidate = TradeCandidate(
        symbol="AAPL",
        asset_class=AssetClass.EQUITY,
        entry_price=price,
        stop_price=round(
            price * 0.95,
            4,
        ),
        target_price=round(
            price * 1.10,
            4,
        ),
        confidence=92,
        thesis=(
            "Controlled Dark Wolf Sentinel "
            "Alpaca PAPER execution probe."
        ),
        catalyst=(
            "Hackathon execution-path validation."
        ),
        invalidation=(
            "5% deterministic probe stop."
        ),
    )

    equity = float(
        snapshot["account"]["equity"]
    )

    portfolio = PortfolioState(
        equity=equity,
        current_open_risk=0,
        current_crypto_risk=0,
        current_exposure=0,
        open_symbols=[],
        kill_switch=False,
    )

    policy = RiskPolicy.from_settings(
        settings
    )

    decision = evaluate_trade(
        candidate,
        portfolio,
        policy,
    )

    print(
        "LATEST AAPL PRICE:",
        round(price, 4),
    )

    print(
        "RISK APPROVED:",
        decision.approved,
    )

    print(
        "RISK REASON:",
        decision.reason,
    )

    print(
        "MAX RISK-APPROVED QTY:",
        decision.quantity,
    )

    print(
        "MAX RISK-APPROVED VALUE:",
        decision.position_value,
    )

    if not decision.approved:
        raise RuntimeError(
            "Deterministic risk rejected probe."
        )

    if decision.quantity < 0.01:
        raise RuntimeError(
            "Risk-approved quantity below "
            "controlled 0.01-share probe."
        )

    decision_id = record_decision(
        candidate,
        portfolio,
        decision,
    )

    print(
        "DECISION ID:",
        decision_id,
    )

    executor = AlpacaPaperExecutor(
        settings
    )

    print()
    print(
        "SUBMITTING ALPACA PAPER ORDER:"
    )
    print("SYMBOL: AAPL")
    print("SIDE: BUY")
    print("QUANTITY: 0.01")
    print("TYPE: MARKET")
    print("LIVE: False")

    submitted = executor.submit(
        candidate=candidate,
        decision=decision,
        decision_id=decision_id,
        execution_quantity=0.01,
    )

    order = submitted["order"]

    print()
    print(
        "BROKER ORDER ID:",
        order.get("order_id"),
    )

    print(
        "CLIENT ORDER ID:",
        order.get("client_order_id"),
    )

    print(
        "INITIAL STATUS:",
        order.get("status"),
    )

    print(
        "DUPLICATE PREVENTED:",
        submitted[
            "duplicate_prevented"
        ],
    )

    reconciled = None

    for attempt in range(1, 21):
        time.sleep(1)

        reconciled = executor.reconcile(
            decision_id=decision_id
        )

        current = reconciled["order"]

        print(
            "RECONCILE",
            attempt,
            "STATUS:",
            current.get("status"),
            "FILLED QTY:",
            current.get("filled_qty"),
            "AVG PRICE:",
            current.get(
                "filled_avg_price"
            ),
        )

        if status_is_filled(
            current.get("status")
        ):
            break

    if reconciled is None:
        raise RuntimeError(
            "No reconciliation result."
        )

    final_order = reconciled["order"]

    final_snapshot = (
        readonly.snapshot()
    )

    result = {
        "mode":
            "ALPACA_PAPER_CONTROLLED_PROBE",
        "symbol":
            "AAPL",
        "side":
            "BUY",
        "requested_quantity":
            0.01,
        "risk_approved":
            decision.approved,
        "risk_approved_max_quantity":
            decision.quantity,
        "decision_id":
            decision_id,
        "client_order_id":
            final_order.get(
                "client_order_id"
            ),
        "broker_order_id":
            final_order.get(
                "order_id"
            ),
        "broker_status":
            final_order.get(
                "status"
            ),
        "filled_quantity":
            final_order.get(
                "filled_qty"
            ),
        "filled_avg_price":
            final_order.get(
                "filled_avg_price"
            ),
        "positions_after":
            len(
                final_snapshot[
                    "positions"
                ]
            ),
        "open_orders_after":
            len(
                final_snapshot[
                    "open_orders"
                ]
            ),
        "paper":
            True,
        "live_trading":
            False,
        "trading_authority":
            False,
    }

    RESULT_PATH.write_text(
        json.dumps(
            result,
            indent=2,
        )
        + "\n"
    )

    print()
    print(
        "============================================"
    )
    print(
        " CONTROLLED PAPER PROBE COMPLETE"
    )
    print(
        "============================================"
    )

    for key, value in result.items():
        print(
            f"{key}: {value}"
        )


if __name__ == "__main__":
    main()
