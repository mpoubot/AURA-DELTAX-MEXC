from __future__ import annotations

import sys
import time
import traceback
from datetime import datetime, timezone

from app.config import Settings
from scripts.run_sentinel_news import (
    main as run_sentinel,
)


ATTEMPTS = 3
DELAYS_SECONDS = (
    3,
    8,
)


def utc_now() -> str:
    return datetime.now(
        timezone.utc
    ).isoformat()


def main() -> None:
    settings = Settings()

    # Safety is checked once and is never retryable.
    settings.assert_paper_only()

    if settings.paper_execution_enabled:
        raise RuntimeError(
            "Execution must remain disabled."
        )

    last_error: BaseException | None = None

    for attempt in range(
        1,
        ATTEMPTS + 1,
    ):
        print()
        print(
            f"[{utc_now()}] "
            f"SENTINEL ATTEMPT "
            f"{attempt}/{ATTEMPTS}",
            flush=True,
        )

        try:
            run_sentinel()

            print(
                f"[{utc_now()}] "
                "SENTINEL WORKER: PASS",
                flush=True,
            )

            return

        except Exception as exc:
            last_error = exc

            print(
                f"[{utc_now()}] "
                f"ATTEMPT {attempt} FAILED: "
                f"{type(exc).__name__}: {exc}",
                file=sys.stderr,
                flush=True,
            )

            traceback.print_exc(
                file=sys.stderr
            )

            if attempt >= ATTEMPTS:
                break

            delay = DELAYS_SECONDS[
                attempt - 1
            ]

            print(
                f"[{utc_now()}] "
                f"RETRYING IN {delay}s",
                file=sys.stderr,
                flush=True,
            )

            time.sleep(delay)

    raise RuntimeError(
        "Sentinel worker exhausted "
        f"{ATTEMPTS} attempts."
    ) from last_error


if __name__ == "__main__":
    main()
