# Security

Dark Wolf Sentinel is demonstrated using Alpaca PAPER trading.

## Credentials

Never commit:

- `.env`
- OpenAI API keys
- Alpaca API keys
- Alpaca secret keys
- broker account identifiers
- private logs or databases

Use `.env.example` as the configuration template.

## Trading authority

The AI proposal layer does not have broker authority.

The public demonstration defaults to:

`SENTINEL_PAPER_EXECUTION_ENABLED=false`

Alpaca MCP is restricted to read-only market-data and news
toolsets for the demonstration.

## Reporting

If credentials are accidentally exposed, revoke and replace them
immediately.
