"use client";

import { useState } from "react";
import { Check, ShieldQuestion, X } from "lucide-react";
import type { PendingApproval } from "@/lib/types";
import { pct01, usd } from "@/lib/format";
import { Badge, Card, EmptyState, Spinner, actionTone } from "./ui";

export function ApprovalQueue({
  items,
  onApprove,
  onReject,
}: {
  items: PendingApproval[];
  onApprove: (id: number) => Promise<void>;
  onReject: (id: number) => Promise<void>;
}) {
  const [busyId, setBusyId] = useState<number | null>(null);

  const run = async (id: number, fn: (id: number) => Promise<void>) => {
    setBusyId(id);
    try {
      await fn(id);
    } finally {
      setBusyId(null);
    }
  };

  return (
    <Card
      title="Approval Queue"
      icon={<ShieldQuestion size={16} />}
      right={
        items.length > 0 ? <Badge tone="amber">{items.length} pending</Badge> : null
      }
    >
      {items.length === 0 ? (
        <EmptyState>No proposals awaiting approval.</EmptyState>
      ) : (
        <div className="space-y-3">
          {items.map((p) => (
            <div
              key={p.id}
              className="rounded-lg border border-amber-500/20 bg-amber-500/5 p-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-slate-100">{p.symbol}</span>
                  <Badge tone={actionTone(p.action)}>{p.action}</Badge>
                  <span className="text-xs text-slate-400">
                    {p.suggested_quantity} sh · conf {pct01(p.confidence)}
                  </span>
                </div>
                <div className="text-xs text-slate-400">
                  ~{usd(p.reference_price)}
                </div>
              </div>
              <p className="mt-2 text-sm text-slate-300">{p.reasoning}</p>
              <div className="mt-2 flex items-center gap-2 text-xs text-slate-400">
                {p.stop_loss !== null && <span>SL {p.stop_loss}</span>}
                {p.take_profit !== null && <span>TP {p.take_profit}</span>}
              </div>
              <div className="mt-3 flex gap-2">
                <button
                  disabled={busyId === p.id}
                  onClick={() => run(p.id, onApprove)}
                  className="inline-flex items-center gap-1 rounded-md bg-emerald-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-emerald-500 disabled:opacity-50"
                >
                  {busyId === p.id ? <Spinner /> : <Check size={15} />} Approve
                </button>
                <button
                  disabled={busyId === p.id}
                  onClick={() => run(p.id, onReject)}
                  className="inline-flex items-center gap-1 rounded-md bg-rose-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-rose-500 disabled:opacity-50"
                >
                  <X size={15} /> Reject
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
