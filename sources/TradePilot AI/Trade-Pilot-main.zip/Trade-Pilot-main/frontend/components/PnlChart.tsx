"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  Cell,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { Position, PortfolioHistory } from "@/lib/types";
import { num, usd } from "@/lib/format";
import { EmptyState } from "./ui";

// Primary view: the real equity-over-time curve from /portfolio/history.
// Fallback: per-position unrealized P&L bars when there's no history but
// positions exist. Empty state only when neither is available.
export function PnlChart({
  positions,
  history,
}: {
  positions: Position[];
  history?: PortfolioHistory | null;
}) {
  const curve = (history?.points ?? []).map((p) => ({
    t: p.t,
    equity: Number(p.equity),
  }));

  if (curve.length >= 2) {
    const first = curve[0].equity;
    const last = curve[curve.length - 1].equity;
    const up = last >= first;
    const stroke = up ? "#34d399" : "#fb7185";
    return (
      <div>
        <div className="mb-1 flex items-center justify-between text-xs font-medium text-slate-400">
          <span>Equity over time</span>
          <span className={up ? "text-emerald-300" : "text-rose-300"}>
            {usd(last)}
          </span>
        </div>
        <div className="h-40 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={curve} margin={{ top: 6, right: 6, bottom: 0, left: -10 }}>
              <defs>
                <linearGradient id="eqfill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0%" stopColor={stroke} stopOpacity={0.35} />
                  <stop offset="100%" stopColor={stroke} stopOpacity={0.02} />
                </linearGradient>
              </defs>
              <XAxis
                dataKey="t"
                tick={{ fill: "#94a3b8", fontSize: 10 }}
                axisLine={{ stroke: "#1e293b" }}
                tickLine={false}
                minTickGap={28}
              />
              <YAxis
                tick={{ fill: "#94a3b8", fontSize: 11 }}
                axisLine={{ stroke: "#1e293b" }}
                tickLine={false}
                width={62}
                domain={["auto", "auto"]}
              />
              <Tooltip
                cursor={{ stroke: "#1e293b" }}
                contentStyle={{
                  background: "#0f172a",
                  border: "1px solid #1e293b",
                  borderRadius: 8,
                  color: "#e2e8f0",
                }}
                formatter={(v) => [usd(Number(v)), "Equity"]}
              />
              <Area
                type="monotone"
                dataKey="equity"
                stroke={stroke}
                strokeWidth={2}
                fill="url(#eqfill)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>
    );
  }

  const data = positions
    .map((p) => ({
      symbol: String(p.symbol ?? "?"),
      pnl: num(p.unrealized_pl) ?? 0,
    }))
    .filter((d) => d.symbol !== "?");

  if (data.length === 0) {
    return (
      <EmptyState>
        No equity history or open positions to chart yet. Run a scan (and reset
        the paper account if balance is low) to start building the curve.
      </EmptyState>
    );
  }

  return (
    <div>
      <div className="mb-1 text-xs font-medium text-slate-400">
        Unrealized P&L by position
      </div>
      <div className="h-40 w-full">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={data} margin={{ top: 6, right: 6, bottom: 0, left: -10 }}>
            <XAxis
              dataKey="symbol"
              tick={{ fill: "#94a3b8", fontSize: 12 }}
              axisLine={{ stroke: "#1e293b" }}
              tickLine={false}
            />
            <YAxis
              tick={{ fill: "#94a3b8", fontSize: 11 }}
              axisLine={{ stroke: "#1e293b" }}
              tickLine={false}
              width={54}
            />
            <Tooltip
              cursor={{ fill: "#1e293b55" }}
              contentStyle={{
                background: "#0f172a",
                border: "1px solid #1e293b",
                borderRadius: 8,
                color: "#e2e8f0",
              }}
              formatter={(v) => [usd(Number(v)), "P&L"]}
            />
            <Bar dataKey="pnl" radius={[4, 4, 0, 0]}>
              {data.map((d, i) => (
                <Cell key={i} fill={d.pnl >= 0 ? "#34d399" : "#fb7185"} />
              ))}
            </Bar>
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
}
