import type { ReactNode } from "react";

export function Card({
  title,
  icon,
  right,
  children,
  className = "",
}: {
  title?: string;
  icon?: ReactNode;
  right?: ReactNode;
  children: ReactNode;
  className?: string;
}) {
  return (
    <section
      className={`rounded-xl border border-slate-800 bg-slate-900/60 shadow-lg shadow-black/20 ${className}`}
    >
      {(title || right) && (
        <header className="flex items-center justify-between gap-2 border-b border-slate-800 px-4 py-3">
          <h2 className="flex items-center gap-2 text-sm font-semibold tracking-wide text-slate-200">
            {icon}
            {title}
          </h2>
          {right}
        </header>
      )}
      <div className="p-4">{children}</div>
    </section>
  );
}

export function Badge({
  children,
  tone = "slate",
}: {
  children: ReactNode;
  tone?: "green" | "red" | "amber" | "slate" | "blue";
}) {
  const tones: Record<string, string> = {
    green: "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
    red: "bg-rose-500/15 text-rose-300 border-rose-500/30",
    amber: "bg-amber-500/15 text-amber-300 border-amber-500/30",
    blue: "bg-sky-500/15 text-sky-300 border-sky-500/30",
    slate: "bg-slate-500/15 text-slate-300 border-slate-500/30",
  };
  return (
    <span
      className={`inline-flex items-center rounded-md border px-2 py-0.5 text-xs font-medium ${tones[tone]}`}
    >
      {children}
    </span>
  );
}

export function actionTone(action: string): "green" | "red" | "slate" {
  if (action === "BUY") return "green";
  if (action === "SELL") return "red";
  return "slate";
}

export function riskTone(decision: string | null): "green" | "red" | "slate" {
  if (decision === "APPROVE") return "green";
  if (decision === "REJECT") return "red";
  return "slate";
}

export function execTone(status: string): "green" | "red" | "amber" | "slate" {
  if (status === "EXECUTED") return "green";
  if (status === "PENDING_APPROVAL") return "amber";
  if (status.startsWith("REJECTED") || status === "EXECUTION_ERROR") return "red";
  return "slate";
}

export function Spinner() {
  return (
    <span className="inline-block h-3.5 w-3.5 animate-spin rounded-full border-2 border-slate-500 border-t-transparent" />
  );
}

export function EmptyState({ children }: { children: ReactNode }) {
  return (
    <div className="py-8 text-center text-sm text-slate-500">{children}</div>
  );
}
