"use client";

import { useState } from "react";
import { FlaskConical, Play } from "lucide-react";
import {
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { api } from "@/lib/api";
import type { BacktestResult } from "@/lib/types";
import { usd } from "@/lib/format";
import { Card, EmptyState, Spinner } from "./ui";

function Metric({
  label,
  value,
  tone = "slate",
}: {
  label: string;
  value: string;
  tone?: "slate" | "green" | "red";
}) {
  const color =
    tone === "green"
      ? "text-emerald-300"
      : tone === "red"
        ? "text-rose-300"
        : "text-slate-100";
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-950/40 px-3 py-2.5">
      <div className="text-xs text-slate-400">{label}</div>
      <div className={`mt-1 text-lg font-semibold tabular-nums ${color}`}>
        {value}
      </div>
    </div>
  );
}

export function BacktestPanel() {
  const [symbol, setSymbol] = useState("AAPL");
  const [start, setStart] = useState("2023-01-01");
  const [end, setEnd] = useState("2024-01-01");
  const [fastMa, setFastMa] = useState(10);
  const [slowMa, setSlowMa] = useState(30);
  const [positionPct, setPositionPct] = useState(10);

  const [result, setResult] = useState<BacktestResult | null>(null);
  const [running, setRunning] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const run = async () => {
    setRunning(true);
    setError(null);
    try {
      const res = await api.backtest({
        symbol,
        start,
        end,
        strategy: {
          fast_ma: fastMa,
          slow_ma: slowMa,
          position_pct: positionPct / 100,
        },
      });
      setResult(res);
    } catch (e) {
      setError(String(e));
      setResult(null);
    } finally {
      setRunning(false);
    }
  };

  const inputCls =
    "w-full rounded-md border border-slate-700 bg-slate-950/60 px-2 py-1.5 text-sm text-slate-100 focus:border-sky-500 focus:outline-none";

  return (
    <Card
      title="Backtest — historical simulation (read-only, never places orders)"
      icon={<FlaskConical size={16} />}
      right={
        result ? (
          <span className="text-xs text-slate-500">
            data: {result.data_source} · {result.bars} bars
          </span>
        ) : null
      }
    >
      {/* Form */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <label className="text-xs text-slate-400">
          Symbol
          <input
            className={inputCls}
            value={symbol}
            onChange={(e) => setSymbol(e.target.value.toUpperCase())}
          />
        </label>
        <label className="text-xs text-slate-400">
          Start
          <input
            type="date"
            className={inputCls}
            value={start}
            onChange={(e) => setStart(e.target.value)}
          />
        </label>
        <label className="text-xs text-slate-400">
          End
          <input
            type="date"
            className={inputCls}
            value={end}
            onChange={(e) => setEnd(e.target.value)}
          />
        </label>
        <label className="text-xs text-slate-400">
          Fast MA
          <input
            type="number"
            className={inputCls}
            value={fastMa}
            onChange={(e) => setFastMa(Number(e.target.value))}
          />
        </label>
        <label className="text-xs text-slate-400">
          Slow MA
          <input
            type="number"
            className={inputCls}
            value={slowMa}
            onChange={(e) => setSlowMa(Number(e.target.value))}
          />
        </label>
        <label className="text-xs text-slate-400">
          Position %
          <input
            type="number"
            className={inputCls}
            value={positionPct}
            onChange={(e) => setPositionPct(Number(e.target.value))}
          />
        </label>
      </div>

      <button
        onClick={run}
        disabled={running}
        className="mt-3 inline-flex items-center gap-2 rounded-md bg-violet-600 px-4 py-2 text-sm font-semibold text-white hover:bg-violet-500 disabled:opacity-60"
      >
        {running ? <Spinner /> : <Play size={15} />} Run Backtest
      </button>

      {error && (
        <div className="mt-3 rounded-md border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-sm text-rose-200">
          {error}
        </div>
      )}

      {/* Results */}
      {!result ? (
        <div className="mt-4">
          <EmptyState>
            Configure a symbol, date range, and strategy, then run a simulation.
            {" "}Uses real Alpaca history when credentials are set; otherwise a
            deterministic synthetic series.
          </EmptyState>
        </div>
      ) : (
        <div className="mt-4 space-y-4">
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Metric
              label="Total Return"
              value={`${result.total_return_pct}%`}
              tone={result.total_return_pct >= 0 ? "green" : "red"}
            />
            <Metric label="Win Rate" value={`${result.win_rate_pct}%`} />
            <Metric
              label="Max Drawdown"
              value={`${result.max_drawdown_pct}%`}
              tone="red"
            />
            <Metric
              label="Trades (W/L)"
              value={`${result.num_trades} (${result.wins}/${result.losses})`}
            />
          </div>

          <div>
            <div className="mb-1 flex items-center justify-between text-xs text-slate-400">
              <span>Equity curve</span>
              <span>
                {usd(result.initial_equity)} → {usd(result.final_equity)}
              </span>
            </div>
            <div className="h-56 w-full">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart
                  data={result.equity_curve}
                  margin={{ top: 8, right: 10, bottom: 0, left: 4 }}
                >
                  <CartesianGrid stroke="#1e293b" strokeDasharray="3 3" />
                  <XAxis
                    dataKey="date"
                    tick={{ fill: "#94a3b8", fontSize: 10 }}
                    axisLine={{ stroke: "#1e293b" }}
                    tickLine={false}
                    minTickGap={40}
                  />
                  <YAxis
                    domain={["auto", "auto"]}
                    tick={{ fill: "#94a3b8", fontSize: 10 }}
                    axisLine={{ stroke: "#1e293b" }}
                    tickLine={false}
                    width={64}
                    tickFormatter={(v) => `$${Math.round(Number(v) / 1000)}k`}
                  />
                  <Tooltip
                    contentStyle={{
                      background: "#0f172a",
                      border: "1px solid #1e293b",
                      borderRadius: 8,
                      color: "#e2e8f0",
                    }}
                    formatter={(v) => [usd(Number(v)), "Equity"]}
                  />
                  <Line
                    type="monotone"
                    dataKey="equity"
                    stroke="#a78bfa"
                    strokeWidth={2}
                    dot={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {result.data_source === "synthetic" && (
            <p className="text-xs text-amber-300/80">
              Synthetic data (no Alpaca credentials). Set ALPACA_API_KEY /
              ALPACA_SECRET_KEY for real historical bars.
            </p>
          )}
        </div>
      )}
    </Card>
  );
}
