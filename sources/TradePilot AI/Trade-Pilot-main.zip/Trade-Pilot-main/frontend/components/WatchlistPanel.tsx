"use client";

import { useState } from "react";
import { ListChecks, Plus, X } from "lucide-react";
import { Card, Spinner } from "./ui";

export function WatchlistPanel({
  symbols,
  busy,
  onChange,
}: {
  symbols: string[];
  busy: boolean;
  onChange: (symbols: string[]) => void;
}) {
  const [input, setInput] = useState("");

  const add = () => {
    const sym = input.trim().toUpperCase();
    if (!sym || symbols.includes(sym)) {
      setInput("");
      return;
    }
    onChange([...symbols, sym]);
    setInput("");
  };

  const remove = (sym: string) => onChange(symbols.filter((s) => s !== sym));

  return (
    <Card
      title="Watchlist"
      icon={<ListChecks size={16} />}
      right={busy ? <Spinner /> : null}
    >
      <div className="flex flex-wrap gap-2">
        {symbols.length === 0 && (
          <span className="text-sm text-slate-500">No symbols yet.</span>
        )}
        {symbols.map((sym) => (
          <span
            key={sym}
            className="inline-flex items-center gap-1 rounded-md border border-slate-700 bg-slate-800/60 px-2 py-1 text-sm font-medium text-slate-200"
          >
            {sym}
            <button
              onClick={() => remove(sym)}
              aria-label={`remove ${sym}`}
              className="rounded p-0.5 text-slate-400 hover:bg-slate-700 hover:text-rose-300"
            >
              <X size={13} />
            </button>
          </span>
        ))}
      </div>

      <div className="mt-3 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && add()}
          placeholder="Add symbol (e.g. NVDA)"
          className="w-full rounded-md border border-slate-700 bg-slate-950/60 px-3 py-1.5 text-sm text-slate-100 placeholder:text-slate-500 focus:border-sky-500 focus:outline-none"
        />
        <button
          onClick={add}
          className="inline-flex items-center gap-1 rounded-md bg-sky-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-sky-500"
        >
          <Plus size={15} /> Add
        </button>
      </div>
    </Card>
  );
}
