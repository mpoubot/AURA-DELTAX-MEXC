"use client";

import { Activity } from "lucide-react";
import type { DecisionLogItem } from "@/lib/types";
import { pct01 } from "@/lib/format";
import { Badge, Card, EmptyState, actionTone } from "./ui";

// Latest decision per symbol, derived from the (newest-first) decision log.
function latestPerSymbol(items: DecisionLogItem[]): DecisionLogItem[] {
  const seen = new Set<string>();
  const out: DecisionLogItem[] = [];
  for (const it of items) {
    if (!seen.has(it.symbol)) {
      seen.add(it.symbol);
      out.push(it);
    }
  }
  return out;
}

function ConfidenceBar({ value }: { value: number }) {
  const w = Math.round(Math.max(0, Math.min(1, value)) * 100);
  return (
    <div className="h-1.5 w-full rounded-full bg-slate-800">
      <div
        className="h-1.5 rounded-full bg-sky-400"
        style={{ width: `${w}%` }}
      />
    </div>
  );
}

export function SignalPanel({ items }: { items: DecisionLogItem[] }) {
  const signals = latestPerSymbol(items);

  return (
    <Card title="Signals — latest decision per symbol" icon={<Activity size={16} />}>
      {signals.length === 0 ? (
        <EmptyState>No signals yet. Run a watchlist scan.</EmptyState>
      ) : (
        <div className="space-y-3">
          {signals.map((s) => (
            <div
              key={s.id}
              className="rounded-lg border border-slate-800 bg-slate-950/40 p-3"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="text-base font-semibold text-slate-100">
                    {s.symbol}
                  </span>
                  <Badge tone={actionTone(s.action)}>{s.action}</Badge>
                  {s.instrument === "option" && (
                    <Badge tone="blue">
                      {(s.option_type ?? "option").toUpperCase()}
                    </Badge>
                  )}
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-400">confidence</div>
                  <div className="text-sm font-semibold tabular-nums text-slate-200">
                    {pct01(s.confidence)}
                  </div>
                </div>
              </div>
              <div className="mt-2">
                <ConfidenceBar value={s.confidence} />
              </div>
              <p className="mt-2 text-sm leading-snug text-slate-300">
                {s.reasoning || "No reasoning provided."}
              </p>
              <div className="mt-2 flex flex-wrap gap-2 text-xs text-slate-400">
                {s.market_trend && <span>trend: {s.market_trend}</span>}
                {s.news_sentiment !== null && (
                  <span>news: {s.news_sentiment.toFixed(2)}</span>
                )}
                {s.instrument === "option" ? (
                  <>
                    {s.strike != null && <span>strike: {s.strike}</span>}
                    {s.expiration && <span>exp: {s.expiration}</span>}
                    {s.premium != null && <span>premium: ${s.premium}</span>}
                    {s.suggested_quantity > 0 && (
                      <span>{s.suggested_quantity} contract(s)</span>
                    )}
                  </>
                ) : (
                  <>
                    {s.stop_loss !== null && <span>SL: {s.stop_loss}</span>}
                    {s.take_profit !== null && <span>TP: {s.take_profit}</span>}
                  </>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
