"use client";

import { History } from "lucide-react";
import type { DecisionLogItem } from "@/lib/types";
import { fmtTime } from "@/lib/format";
import { Badge, Card, EmptyState, actionTone, execTone, riskTone } from "./ui";

function execLabel(status: string): string {
  return status.replaceAll("_", " ").toLowerCase();
}

export function DecisionLogPanel({
  items,
  total,
}: {
  items: DecisionLogItem[];
  total: number;
}) {
  return (
    <Card
      title="Decision Log / Audit Trail"
      icon={<History size={16} />}
      right={<span className="text-xs text-slate-500">{total} records</span>}
    >
      {items.length === 0 ? (
        <EmptyState>No decisions logged yet.</EmptyState>
      ) : (
        <div className="tp-scroll max-h-[520px] space-y-0 overflow-y-auto pr-1">
          {items.map((it, idx) => (
            <div key={it.id} className="relative pl-5">
              {/* timeline rail */}
              <span className="absolute left-1 top-1.5 h-2 w-2 rounded-full bg-sky-400" />
              {idx < items.length - 1 && (
                <span className="absolute left-[7px] top-3 h-full w-px bg-slate-800" />
              )}
              <div className="pb-4">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-slate-500">
                    {fmtTime(it.timestamp)}
                  </span>
                  <span className="font-semibold text-slate-100">
                    {it.symbol}
                  </span>
                  <Badge tone={actionTone(it.action)}>{it.action}</Badge>
                  {it.instrument === "option" && (
                    <Badge tone="blue">
                      {(it.option_type ?? "option").toUpperCase()}
                      {it.strike != null ? ` ${it.strike}` : ""}
                    </Badge>
                  )}
                  {it.risk_decision && it.risk_decision !== "N/A" && (
                    <Badge tone={riskTone(it.risk_decision)}>
                      risk: {it.risk_decision}
                    </Badge>
                  )}
                  <Badge tone={execTone(it.execution_status)}>
                    {execLabel(it.execution_status)}
                  </Badge>
                  {it.order_id && (
                    <span className="text-xs text-emerald-300">
                      #{it.order_id.slice(0, 8)}
                    </span>
                  )}
                </div>
                {it.reasoning && (
                  <p className="mt-1 text-sm text-slate-300">{it.reasoning}</p>
                )}
                {it.risk_reason && it.risk_decision === "REJECT" && (
                  <p className="mt-1 text-xs text-rose-300">
                    Risk reason: {it.risk_reason}
                  </p>
                )}
                {it.execution_status === "EXECUTION_ERROR" &&
                  it.execution_detail && (
                    <p className="mt-1 line-clamp-2 text-xs text-rose-300/80">
                      {it.execution_detail}
                    </p>
                  )}
              </div>
            </div>
          ))}
        </div>
      )}
    </Card>
  );
}
