"use client";

import { Wallet } from "lucide-react";
import type { Account, PortfolioHistory } from "@/lib/types";
import { num, usd } from "@/lib/format";
import { Badge, Card, EmptyState } from "./ui";
import { PnlChart } from "./PnlChart";

function Stat({
  label,
  value,
  tone = "slate",
}: {
  label: string;
  value: string;
  tone?: "slate" | "green" | "red";
}) {
  const color =
    tone === "green"
      ? "text-emerald-300"
      : tone === "red"
        ? "text-rose-300"
        : "text-slate-100";
  return (
    <div className="rounded-lg border border-slate-800 bg-slate-950/40 px-3 py-2.5">
      <div className="text-xs text-slate-400">{label}</div>
      <div className={`mt-1 text-lg font-semibold tabular-nums ${color}`}>
        {value}
      </div>
    </div>
  );
}

export function PortfolioOverview({
  account,
  loading,
  history,
}: {
  account: Account | null;
  loading: boolean;
  history?: PortfolioHistory | null;
}) {
  const positions = account?.positions ?? [];
  const totalPnl = positions.reduce((s, p) => s + (num(p.unrealized_pl) ?? 0), 0);

  const right = account ? (
    account.available ? (
      <Badge tone="green">connected</Badge>
    ) : (
      <Badge tone="amber">no account data</Badge>
    )
  ) : null;

  return (
    <Card title="Portfolio Overview" icon={<Wallet size={16} />} right={right}>
      {!account?.available ? (
        <EmptyState>
          {loading
            ? "Loading account…"
            : "Alpaca account not connected. Run `alpaca profile login` (paper) so equity, buying power, and positions appear here."}
        </EmptyState>
      ) : (
        <>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            <Stat label="Equity" value={usd(num(account.equity))} />
            <Stat label="Buying Power" value={usd(num(account.buying_power))} />
            <Stat label="Cash" value={usd(num(account.cash))} />
            <Stat
              label="Unrealized P&L"
              value={usd(totalPnl)}
              tone={totalPnl > 0 ? "green" : totalPnl < 0 ? "red" : "slate"}
            />
          </div>

          <div className="mt-4">
            <PnlChart positions={positions} history={history} />
          </div>

          <div className="mt-4">
            <div className="mb-2 text-xs font-medium text-slate-400">
              Open Positions ({positions.length})
            </div>
            {positions.length === 0 ? (
              <EmptyState>No open positions.</EmptyState>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="text-left text-xs text-slate-500">
                      <th className="py-1 pr-3">Symbol</th>
                      <th className="py-1 pr-3">Qty</th>
                      <th className="py-1 pr-3">Mkt Value</th>
                      <th className="py-1 pr-3">Unreal. P&L</th>
                    </tr>
                  </thead>
                  <tbody>
                    {positions.map((p, i) => {
                      const pnl = num(p.unrealized_pl) ?? 0;
                      return (
                        <tr key={i} className="border-t border-slate-800/70">
                          <td className="py-1.5 pr-3 font-medium text-slate-200">
                            {String(p.symbol ?? "—")}
                          </td>
                          <td className="py-1.5 pr-3 tabular-nums text-slate-300">
                            {String(p.qty ?? "—")}
                          </td>
                          <td className="py-1.5 pr-3 tabular-nums text-slate-300">
                            {usd(num(p.market_value))}
                          </td>
                          <td
                            className={`py-1.5 pr-3 tabular-nums ${
                              pnl >= 0 ? "text-emerald-300" : "text-rose-300"
                            }`}
                          >
                            {usd(pnl)}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        </>
      )}
    </Card>
  );
}
