import type {
  Account,
  BacktestRequestBody,
  BacktestResult,
  DecisionLogResponse,
  PendingApproval,
  PortfolioHistory,
  ScanResponse,
} from "./types";

export const API_BASE =
  process.env.NEXT_PUBLIC_API_BASE ?? "https://hamzabhatti-tradepilot-ai.hf.space";

async function req<T>(path: string, init?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    headers: { "Content-Type": "application/json" },
    cache: "no-store",
    ...init,
  });
  if (!res.ok) {
    let detail = `${res.status} ${res.statusText}`;
    try {
      const body = await res.json();
      if (body?.detail) detail = String(body.detail);
    } catch {
      /* ignore */
    }
    throw new Error(detail);
  }
  return (await res.json()) as T;
}

export const api = {
  account: () => req<Account>("/account"),
  portfolioHistory: (period = "1M", timeframe = "1D") =>
    req<PortfolioHistory>(
      `/portfolio/history?period=${period}&timeframe=${timeframe}`,
    ),
  getWatchlist: () => req<{ symbols: string[] }>("/watchlist"),
  setWatchlist: (symbols: string[]) =>
    req<{ symbols: string[] }>("/watchlist", {
      method: "POST",
      body: JSON.stringify({ symbols }),
    }),
  scan: (humanApproval = false, mode: "stock" | "options" = "stock") =>
    req<ScanResponse>(
      `/watchlist/scan?human_approval=${humanApproval}&mode=${mode}`,
      { method: "POST" },
    ),
  decisionsLog: (limit = 100, offset = 0) =>
    req<DecisionLogResponse>(`/decisions/log?limit=${limit}&offset=${offset}`),
  pending: () =>
    req<{ count: number; items: PendingApproval[] }>("/approvals/pending"),
  approve: (id: number, note = "") =>
    req<unknown>(
      `/approvals/${id}/approve?note=${encodeURIComponent(note)}`,
      { method: "POST" },
    ),
  reject: (id: number, note = "") =>
    req<unknown>(
      `/approvals/${id}/reject?note=${encodeURIComponent(note)}`,
      { method: "POST" },
    ),
  backtest: (body: BacktestRequestBody) =>
    req<BacktestResult>("/backtest", {
      method: "POST",
      body: JSON.stringify(body),
    }),
};
