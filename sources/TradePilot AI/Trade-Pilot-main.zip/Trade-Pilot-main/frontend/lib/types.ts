// Shapes returned by the TradePilot FastAPI backend.

export interface Position {
  symbol?: string;
  qty?: string | number;
  market_value?: string | number;
  unrealized_pl?: string | number;
  unrealized_plpc?: string | number;
  avg_entry_price?: string | number;
  current_price?: string | number;
  side?: string;
  [k: string]: unknown;
}

export interface Account {
  available: boolean;
  account_number?: string | null;
  status?: string | null;
  currency?: string | null;
  equity?: number | null;
  cash?: number | null;
  buying_power?: number | null;
  positions?: Position[];
  error?: unknown;
}

export interface PortfolioHistoryPoint {
  t: string;
  equity: number;
  pnl: number | null;
}

export interface PortfolioHistory {
  available: boolean;
  base_value?: number | null;
  period?: string;
  timeframe?: string;
  points: PortfolioHistoryPoint[];
  error?: unknown;
}

export interface DecisionLogItem {
  id: number;
  timestamp: string;
  symbol: string;
  action: "BUY" | "SELL" | "HOLD" | string;
  confidence: number;
  suggested_quantity: number;
  stop_loss: number | null;
  take_profit: number | null;
  reference_price: number | null;
  reasoning: string | null;
  market_trend: string | null;
  news_sentiment: number | null;
  risk_decision: string | null;
  risk_reason: string | null;
  risk_rule: string | null;
  instrument?: string | null;
  option_symbol?: string | null;
  option_type?: string | null;
  strike?: number | null;
  expiration?: string | null;
  premium?: number | null;
  execution_status: string;
  execution_detail: string | null;
  order_id: string | null;
}

export interface PendingApproval {
  id: number;
  timestamp: string;
  symbol: string;
  action: string;
  confidence: number;
  suggested_quantity: number;
  stop_loss: number | null;
  take_profit: number | null;
  reference_price: number | null;
  reasoning: string | null;
  status: string;
  resolved_at: string | null;
  resolution_note: string | null;
  decision_log_id: number | null;
}

export interface DecisionLogResponse {
  total: number;
  limit: number;
  offset: number;
  items: DecisionLogItem[];
}

export interface ScanResponse {
  watchlist: string[];
  human_approval: boolean;
  mode?: string;
  count: number;
  results: DecisionLogItem[];
}

export interface BacktestTrade {
  symbol: string;
  entry_date: string;
  exit_date: string;
  entry: number;
  exit: number;
  qty: number;
  pnl: number;
  result: "win" | "loss";
  reason: string;
}

export interface BacktestResult {
  symbol: string;
  start: string;
  end: string;
  data_source: string;
  bars: number;
  strategy: Record<string, unknown>;
  initial_equity: number;
  final_equity: number;
  total_return: number;
  total_return_pct: number;
  win_rate: number;
  win_rate_pct: number;
  max_drawdown: number;
  max_drawdown_pct: number;
  num_trades: number;
  wins: number;
  losses: number;
  trades: BacktestTrade[];
  equity_curve: { date: string; equity: number }[];
}

export interface BacktestRequestBody {
  symbol: string;
  start: string;
  end: string;
  strategy?: Record<string, unknown>;
}
