"use client";

import { useCallback, useEffect, useState } from "react";
import { AlertTriangle, RefreshCw, Search, TrendingUp } from "lucide-react";
import { api, API_BASE } from "@/lib/api";
import type {
  Account,
  DecisionLogItem,
  PendingApproval,
  PortfolioHistory,
} from "@/lib/types";
import { PortfolioOverview } from "@/components/PortfolioOverview";
import { WatchlistPanel } from "@/components/WatchlistPanel";
import { SignalPanel } from "@/components/SignalPanel";
import { ApprovalQueue } from "@/components/ApprovalQueue";
import { DecisionLogPanel } from "@/components/DecisionLogPanel";
import { BacktestPanel } from "@/components/BacktestPanel";
import { Spinner } from "@/components/ui";

export default function Dashboard() {
  const [account, setAccount] = useState<Account | null>(null);
  const [history, setHistory] = useState<PortfolioHistory | null>(null);
  const [watchlist, setWatchlist] = useState<string[]>([]);
  const [log, setLog] = useState<DecisionLogItem[]>([]);
  const [logTotal, setLogTotal] = useState(0);
  const [pending, setPending] = useState<PendingApproval[]>([]);

  const [online, setOnline] = useState<boolean | null>(null);
  const [loading, setLoading] = useState(true);
  const [scanning, setScanning] = useState(false);
  const [wlBusy, setWlBusy] = useState(false);
  const [requireApproval, setRequireApproval] = useState(false);
  const [mode, setMode] = useState<"stock" | "options">("stock");
  const [error, setError] = useState<string | null>(null);

  const loadAll = useCallback(async () => {
    const [acc, wl, dl, pend, hist] = await Promise.allSettled([
      api.account(),
      api.getWatchlist(),
      api.decisionsLog(100, 0),
      api.pending(),
      api.portfolioHistory(),
    ]);

    const anyOk = [acc, wl, dl, pend].some((r) => r.status === "fulfilled");
    setOnline(anyOk);
    setError(anyOk ? null : `Cannot reach backend at ${API_BASE}. Is uvicorn running?`);

    if (acc.status === "fulfilled") setAccount(acc.value);
    if (hist.status === "fulfilled") setHistory(hist.value);
    if (wl.status === "fulfilled") setWatchlist(wl.value.symbols);
    if (dl.status === "fulfilled") {
      setLog(dl.value.items);
      setLogTotal(dl.value.total);
    }
    if (pend.status === "fulfilled") setPending(pend.value.items);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadAll();
    const t = setInterval(loadAll, 15000);
    return () => clearInterval(t);
  }, [loadAll]);

  const onWatchlistChange = async (symbols: string[]) => {
    setWatchlist(symbols); // optimistic
    setWlBusy(true);
    try {
      const res = await api.setWatchlist(symbols);
      setWatchlist(res.symbols);
    } catch (e) {
      setError(String(e));
    } finally {
      setWlBusy(false);
    }
  };

  const onScan = async () => {
    setScanning(true);
    try {
      await api.scan(requireApproval, mode);
      await loadAll();
    } catch (e) {
      setError(String(e));
    } finally {
      setScanning(false);
    }
  };

  const onApprove = async (id: number) => {
    await api.approve(id);
    await loadAll();
  };
  const onReject = async (id: number) => {
    await api.reject(id);
    await loadAll();
  };

  return (
    <div className="min-h-screen bg-slate-950/40">
      <header className="sticky top-0 z-10 border-b border-slate-800 bg-slate-950/80 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4 px-4 py-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="text-sky-400" size={22} />
            <span className="text-lg font-bold tracking-tight text-slate-100">
              TradePilot <span className="text-sky-400">AI</span>
            </span>
            {online === true && (
              <span className="ml-2 inline-flex items-center gap-1 text-xs text-emerald-400">
                <span className="h-1.5 w-1.5 rounded-full bg-emerald-400" /> online
              </span>
            )}
            {online === false && (
              <span className="ml-2 inline-flex items-center gap-1 text-xs text-rose-400">
                <span className="h-1.5 w-1.5 rounded-full bg-rose-400" /> offline
              </span>
            )}
          </div>

          <div className="flex items-center gap-3">
            <div className="flex overflow-hidden rounded-md border border-slate-700 text-xs">
              <button
                onClick={() => setMode("stock")}
                className={`px-2.5 py-1.5 font-medium ${
                  mode === "stock"
                    ? "bg-sky-600 text-white"
                    : "bg-slate-900 text-slate-400 hover:bg-slate-800"
                }`}
              >
                Stocks
              </button>
              <button
                onClick={() => setMode("options")}
                className={`px-2.5 py-1.5 font-medium ${
                  mode === "options"
                    ? "bg-violet-600 text-white"
                    : "bg-slate-900 text-slate-400 hover:bg-slate-800"
                }`}
              >
                Options
              </button>
            </div>
            <label className="flex cursor-pointer items-center gap-1.5 text-xs text-slate-400">
              <input
                type="checkbox"
                checked={requireApproval}
                onChange={(e) => setRequireApproval(e.target.checked)}
                className="accent-sky-500"
              />
              require approval
            </label>
            <button
              onClick={loadAll}
              className="rounded-md border border-slate-700 p-2 text-slate-300 hover:bg-slate-800"
              aria-label="refresh"
            >
              <RefreshCw size={15} />
            </button>
            <button
              onClick={onScan}
              disabled={scanning}
              className="inline-flex items-center gap-2 rounded-md bg-sky-600 px-4 py-2 text-sm font-semibold text-white hover:bg-sky-500 disabled:opacity-60"
            >
              {scanning ? <Spinner /> : <Search size={16} />}
              Scan Watchlist
            </button>
          </div>
        </div>
      </header>

      <main className="mx-auto max-w-7xl px-4 py-6">
        {error && (
          <div className="mb-4 flex items-center gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 px-4 py-2.5 text-sm text-rose-200">
            <AlertTriangle size={16} /> {error}
          </div>
        )}

        <div className="grid grid-cols-1 gap-4 lg:grid-cols-3">
          <div className="space-y-4 lg:col-span-2">
            <PortfolioOverview account={account} loading={loading} history={history} />
            <SignalPanel items={log} />
          </div>
          <div className="space-y-4">
            <WatchlistPanel
              symbols={watchlist}
              busy={wlBusy}
              onChange={onWatchlistChange}
            />
            <ApprovalQueue
              items={pending}
              onApprove={onApprove}
              onReject={onReject}
            />
          </div>
        </div>

        <div className="mt-4">
          <DecisionLogPanel items={log} total={logTotal} />
        </div>

        {/* Backtesting — a separate, read-only simulation surface. It never
            triggers the live/paper execution path. */}
        <div className="mt-6 border-t border-slate-800 pt-6">
          <div className="mb-3 flex items-center gap-2 text-xs uppercase tracking-wider text-slate-500">
            <span className="h-px flex-1 bg-slate-800" />
            Research · Simulation only
            <span className="h-px flex-1 bg-slate-800" />
          </div>
          <BacktestPanel />
        </div>

        <footer className="mt-6 text-center text-xs text-slate-600">
          Paper trading demo · backend {API_BASE}
        </footer>
      </main>
    </div>
  );
}
