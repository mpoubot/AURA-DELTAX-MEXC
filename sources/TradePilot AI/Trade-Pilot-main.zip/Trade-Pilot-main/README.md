# TradePilot AI

**Autonomous, explainable AI trading agents on Alpaca — stocks _and_ options — with a deterministic risk engine and a full audit trail.**

Built for the [Alpaca AI Trading Agents Hackathon](https://lablab.ai/ai-hackathons/alpaca-ai-trading-agents-hackathon). Everything runs against **Alpaca paper trading** (real market data, simulated funds).

---

## What it does

TradePilot runs a multi-agent pipeline over a watchlist and turns AI analysis into risk-checked paper trades:

```
Market Analyst  ─┐
News Sentiment  ─┼─▶  Decision Agent  ─▶  Risk Engine  ─▶  Execution  ─▶  Audit Log
(OpenAI + MCP)  ─┘    (OpenAI)            (deterministic)   (Alpaca CLI)   (Postgres)
```

1. **Market Analyst agent** — fetches recent price/volume/volatility for a symbol via the **Alpaca MCP server** and summarizes trend, momentum, and levels.
2. **News Sentiment agent** — pulls recent news via MCP and scores sentiment (−1…1).
3. **Decision agent** — combines both plus account state into a structured proposal (`action`, `confidence`, sizing, stop/target, plain-text **reasoning** for explainability).
4. **Risk engine** — a **pure, deterministic, fully-tested** module (no LLM) that approves/rejects each proposal: max position size, daily-loss limit, trades/day, concentration, duplicate protection, required stop/target.
5. **Execution** — approved trades are placed via the **Alpaca CLI**:
   - **Stocks:** bracket orders (market entry + take-profit + stop-loss), with legs anchored to the live price.
   - **Options:** single-leg **long CALL (bullish) / long PUT (bearish)**, near-the-money, a few weeks out, sized to the risk budget.
6. **Audit trail** — every step (proposal → risk verdict + reason → execution result) is logged with a timestamp to **Postgres**, queryable and shown on the dashboard.

Optional **human-in-the-loop**: approved trades can be parked as *pending* and approved/rejected from the dashboard instead of auto-executing.

A separate **read-only backtest** replays the decision → risk pipeline over historical Alpaca data and reports total return, win rate, and max drawdown — it never touches the live/paper execution path.

---

## Uses all three Alpaca surfaces

- **Trading API** — account, orders, market & options data (REST).
- **MCP server** — the AI agents fetch data through the official [alpaca-mcp-server](https://github.com/alpacahq/alpaca-mcp-server); data agents are restricted to a read-only tool allowlist (they can never see order-placement tools).
- **CLI** — order execution (`alpaca order submit`), account, and options chain.

---

## Tech stack

| Layer | Tech |
|---|---|
| Agents / LLM | [OpenAI Agents SDK](https://openai.github.io/openai-agents-python/) (`gpt-4o-mini` default) |
| Market data / tools | Alpaca MCP server (stdio) + Alpaca CLI + Trading API (REST) |
| Backend API | FastAPI + Uvicorn |
| Risk engine | Pure Python (pytest-covered) |
| Database | SQLAlchemy → Postgres (Neon) or SQLite fallback |
| Frontend | Next.js (App Router) + Tailwind + Recharts + lucide-react |

---

## Repository layout

```
backend/
  mcp_agent.py            # shared OpenAI-Agents runtime + MCP connection
  market_analyst_agent.py # analyze_market()
  news_sentiment_agent.py # analyze_news()
  decision_agent.py       # make_decision()
  risk_engine.py          # deterministic evaluate_trade() (+ tests)
  options.py              # options chain selection + sizing
  orchestrator.py         # pipeline, stock/option execution, approvals
  backtest.py             # read-only historical simulation
  database.py             # SQLAlchemy models (decision_log, pending_approvals)
  main.py                 # FastAPI app (endpoints)
  test_*.py               # unit + end-to-end tests
frontend/                 # Next.js dashboard
```

> The Alpaca MCP server (`alpaca-mcp-server/`) and the Alpaca CLI binary (`bin/`) are external and git-ignored — they're set up per the steps below.

---

## Setup

**Prerequisites:** Python 3.10+, Node 18+, [uv](https://docs.astral.sh/uv/), and the [Alpaca CLI](https://github.com/alpacahq/cli).

### 1. Alpaca MCP server
```bash
git clone https://github.com/alpacahq/alpaca-mcp-server.git
cd alpaca-mcp-server && uv sync && cd ..
# create alpaca-mcp-server/.env with ALPACA_API_KEY / ALPACA_SECRET_KEY / ALPACA_PAPER_TRADE=true
```

### 2. Alpaca CLI (paper login)
```bash
alpaca profile login --api-key --paper --key <PK...> --secret <secret>
alpaca account get   # verify
```

### 3. Backend
```bash
cd backend
python -m venv .venv
.venv/Scripts/python -m pip install -r requirements.txt   # (Windows) or .venv/bin/pip on macOS/Linux
cp ../.env.example .env      # then fill in your keys + DATABASE_URL
.venv/Scripts/python -m uvicorn main:app --reload --port 8000
```

### 4. Frontend
```bash
cd frontend
npm install
# point at the backend if not on :8000
# echo "NEXT_PUBLIC_API_BASE=http://localhost:8000" > .env.local
npm run dev   # http://localhost:3000
```

---

## Environment variables

See [`.env.example`](.env.example). Required: `ALPACA_API_KEY`, `ALPACA_SECRET_KEY`, `OPENAI_API_KEY`. Optional: `DATABASE_URL` (blank → local SQLite), `OPENAI_MODEL`, `RISK_*` overrides.

---

## API endpoints

| Method | Path | Purpose |
|---|---|---|
| POST | `/watchlist/scan?mode=stock\|options` | Run the pipeline over the watchlist |
| GET | `/decisions/log` | Paginated audit trail |
| GET | `/approvals/pending` | Proposals awaiting human approval |
| POST | `/approvals/{id}/approve` · `/reject` | Resolve a pending proposal |
| GET | `/account` | Paper account (equity, buying power, positions) |
| GET · POST | `/watchlist` | Read / update the watchlist |
| POST | `/backtest` | Read-only historical simulation |

---

## Testing

```bash
cd backend && .venv/Scripts/python -m pytest        # risk engine unit tests
.venv/Scripts/python test_orchestrator.py AAPL      # end-to-end (paper)
```

---

## Safety notes

- **Paper trading only.** All execution targets Alpaca's paper environment.
- The deterministic **risk engine has the final say** on every trade — the LLM only proposes.
- Data agents run under a **read-only MCP tool allowlist**; order placement is isolated to the CLI path.
- Secrets live only in local `.env` files (git-ignored). Never commit real keys.
