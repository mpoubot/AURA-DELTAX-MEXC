"""
Deterministic risk engine for TradePilot AI.

This module contains **pure, testable Python logic only** — no LLM/AI calls,
no network access, and no Alpaca API integration. It evaluates a proposed trade
against a set of configurable risk rules and returns an APPROVE / REJECT
decision with a human-readable reason.

The engine is intentionally side-effect free: callers supply everything it needs
(account equity, existing positions, open orders, today's trade count and P&L)
so the same inputs always produce the same output.
"""

from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Any, Iterable, Mapping, Optional, Union

# --- Decision constants -----------------------------------------------------

APPROVE = "APPROVE"
REJECT = "REJECT"


# --- Configuration ----------------------------------------------------------


def _as_bool(value: Any, default: bool) -> bool:
    if value is None:
        return default
    if isinstance(value, bool):
        return value
    return str(value).strip().lower() in ("1", "true", "yes", "y", "on")


@dataclass(frozen=True)
class RiskConfig:
    """Configurable risk limits.

    Percentages are expressed as fractions (0.05 == 5%). Defaults are tuned
    for a conservative paper-trading demo.
    """

    max_position_pct: float = 0.05          # max single-trade notional as % of equity
    max_daily_loss_pct: float = 0.03         # max cumulative daily loss as % of equity
    max_trades_per_day: int = 10             # max number of trades in a single day
    max_concentration_pct: float = 0.20      # max total exposure to one symbol as % of equity
    require_stop_loss: bool = True           # reject proposals with no stop_loss
    require_take_profit: bool = True         # reject proposals with no take_profit

    @classmethod
    def from_dict(cls, data: Optional[Mapping[str, Any]]) -> "RiskConfig":
        if not data:
            return cls()
        defaults = cls()
        return cls(
            max_position_pct=float(data.get("max_position_pct", defaults.max_position_pct)),
            max_daily_loss_pct=float(data.get("max_daily_loss_pct", defaults.max_daily_loss_pct)),
            max_trades_per_day=int(data.get("max_trades_per_day", defaults.max_trades_per_day)),
            max_concentration_pct=float(
                data.get("max_concentration_pct", defaults.max_concentration_pct)
            ),
            require_stop_loss=_as_bool(data.get("require_stop_loss"), defaults.require_stop_loss),
            require_take_profit=_as_bool(
                data.get("require_take_profit"), defaults.require_take_profit
            ),
        )

    @classmethod
    def from_env(cls, environ: Optional[Mapping[str, str]] = None) -> "RiskConfig":
        """Load limits from environment variables (RISK_* prefix)."""
        env = environ if environ is not None else os.environ
        defaults = cls()

        def _num(name: str, current: float) -> float:
            raw = env.get(name)
            return float(raw) if raw not in (None, "") else current

        def _int(name: str, current: int) -> int:
            raw = env.get(name)
            return int(raw) if raw not in (None, "") else current

        return cls(
            max_position_pct=_num("RISK_MAX_POSITION_PCT", defaults.max_position_pct),
            max_daily_loss_pct=_num("RISK_MAX_DAILY_LOSS_PCT", defaults.max_daily_loss_pct),
            max_trades_per_day=_int("RISK_MAX_TRADES_PER_DAY", defaults.max_trades_per_day),
            max_concentration_pct=_num(
                "RISK_MAX_CONCENTRATION_PCT", defaults.max_concentration_pct
            ),
            require_stop_loss=_as_bool(
                env.get("RISK_REQUIRE_STOP_LOSS"), defaults.require_stop_loss
            ),
            require_take_profit=_as_bool(
                env.get("RISK_REQUIRE_TAKE_PROFIT"), defaults.require_take_profit
            ),
        )


# --- Account context --------------------------------------------------------


@dataclass
class AccountContext:
    """Everything the engine needs to know about account state.

    Supplied by the caller so the engine stays pure and offline-testable.
    """

    equity: float = 0.0
    # symbol -> current market value of the held position (absolute dollars)
    positions: Mapping[str, float] = field(default_factory=dict)
    # list of currently-open orders: {"symbol", "side", "quantity", "price"}
    open_orders: Iterable[Mapping[str, Any]] = field(default_factory=list)
    trades_today: int = 0
    # realized P&L so far today; negative means a loss
    daily_pnl: float = 0.0

    @classmethod
    def coerce(cls, value: Union["AccountContext", Mapping[str, Any], None]) -> "AccountContext":
        if value is None:
            return cls()
        if isinstance(value, AccountContext):
            return value
        return cls(
            equity=float(value.get("equity", 0.0)),
            positions=value.get("positions", {}) or {},
            open_orders=value.get("open_orders", []) or [],
            trades_today=int(value.get("trades_today", 0)),
            daily_pnl=float(value.get("daily_pnl", 0.0)),
        )


# --- Decision result --------------------------------------------------------


@dataclass(frozen=True)
class RiskDecision:
    decision: str            # APPROVE or REJECT
    reason: str              # human-readable explanation
    rule: str = ""           # short machine id of the rule that triggered

    @property
    def approved(self) -> bool:
        return self.decision == APPROVE

    def __str__(self) -> str:  # pragma: no cover - convenience only
        return f"{self.decision}: {self.reason}"


def _approve(reason: str = "All risk checks passed") -> RiskDecision:
    return RiskDecision(APPROVE, reason, rule="ok")


def _reject(reason: str, rule: str) -> RiskDecision:
    return RiskDecision(REJECT, reason, rule=rule)


# --- Core evaluation --------------------------------------------------------

_REQUIRED_FIELDS = ("symbol", "side", "quantity", "price")


def _is_number(value: Any) -> bool:
    return isinstance(value, (int, float)) and not isinstance(value, bool)


def _orders_match(a: Mapping[str, Any], symbol: str, side: str, quantity: float, price: float) -> bool:
    try:
        return (
            str(a.get("symbol", "")).upper() == symbol
            and str(a.get("side", "")).lower() == side
            and float(a.get("quantity", a.get("qty", "nan"))) == quantity
            and float(a.get("price", a.get("limit_price", "nan"))) == price
        )
    except (TypeError, ValueError):
        return False


def evaluate_trade(
    proposal: Mapping[str, Any],
    context: Union[AccountContext, Mapping[str, Any], None] = None,
    config: Union[RiskConfig, Mapping[str, Any], None] = None,
) -> RiskDecision:
    """Evaluate a trade proposal against the configured risk rules.

    Args:
        proposal: dict with keys ``symbol``, ``side``, ``quantity``, ``price``,
            ``stop_loss`` and ``take_profit``.
        context: current account state (equity, positions, open orders,
            trades_today, daily_pnl). May be an ``AccountContext`` or a plain dict.
        config: risk limits. May be a ``RiskConfig``, a dict, or ``None`` for
            defaults.

    Returns:
        RiskDecision with ``decision`` == APPROVE or REJECT and a ``reason``.
    """
    cfg = config if isinstance(config, RiskConfig) else RiskConfig.from_dict(config)
    ctx = AccountContext.coerce(context)

    # --- 1. Structural validation of the proposal --------------------------
    for name in _REQUIRED_FIELDS:
        if proposal.get(name) in (None, ""):
            return _reject(f"Missing required field: {name}", rule="missing_field")

    symbol = str(proposal["symbol"]).upper()
    side = str(proposal["side"]).lower()
    if side not in ("buy", "sell"):
        return _reject(f"Invalid side: {proposal['side']!r} (expected 'buy' or 'sell')", "invalid_side")

    quantity = proposal["quantity"]
    price = proposal["price"]
    if not _is_number(quantity) or quantity <= 0:
        return _reject("Quantity must be a positive number", "invalid_quantity")
    if not _is_number(price) or price <= 0:
        return _reject("Price must be a positive number", "invalid_price")

    # --- 2. Stop-loss / take-profit presence -------------------------------
    stop_loss = proposal.get("stop_loss")
    take_profit = proposal.get("take_profit")
    if cfg.require_stop_loss and not _is_number(stop_loss):
        return _reject("stop_loss is required", "missing_stop_loss")
    if cfg.require_take_profit and not _is_number(take_profit):
        return _reject("take_profit is required", "missing_take_profit")

    # --- 3. Account sanity -------------------------------------------------
    if not _is_number(ctx.equity) or ctx.equity <= 0:
        return _reject("Account equity must be positive to trade", "invalid_equity")

    # --- 4. Duplicate-order protection -------------------------------------
    for order in ctx.open_orders:
        o_symbol = str(order.get("symbol", "")).upper()
        o_side = str(order.get("side", "")).lower()
        if o_symbol == symbol and o_side in ("buy", "sell") and o_side != side:
            return _reject(
                f"Cannot {side} {symbol}: an open {o_side} order already exists for this symbol",
                "conflicting_order_direction",
            )

    # --- 5. Max trades per day ---------------------------------------------
    if ctx.trades_today >= cfg.max_trades_per_day:
        return _reject(
            f"Daily trade limit reached ({ctx.trades_today}/{cfg.max_trades_per_day})",
            "max_trades_per_day",
        )

    # --- 6. Max position size (single-trade notional) ----------------------
    notional = float(quantity) * float(price)
    position_pct = notional / ctx.equity
    if position_pct > cfg.max_position_pct:
        return _reject(
            f"Position size {position_pct:.2%} exceeds max {cfg.max_position_pct:.2%} "
            f"(notional ${notional:,.2f} on ${ctx.equity:,.2f} equity)",
            "max_position_size",
        )

    # --- 7. Max concentration per symbol -----------------------------------
    existing_exposure = float(ctx.positions.get(symbol, 0.0))
    projected_exposure = existing_exposure + notional
    concentration_pct = projected_exposure / ctx.equity
    if concentration_pct > cfg.max_concentration_pct:
        return _reject(
            f"Concentration in {symbol} {concentration_pct:.2%} exceeds max "
            f"{cfg.max_concentration_pct:.2%}",
            "max_concentration",
        )

    # --- 8. Max daily loss limit -------------------------------------------
    loss_budget = cfg.max_daily_loss_pct * ctx.equity  # positive dollar amount
    current_loss = -ctx.daily_pnl if ctx.daily_pnl < 0 else 0.0
    if current_loss >= loss_budget:
        return _reject(
            f"Daily loss limit reached (lost ${current_loss:,.2f} of "
            f"${loss_budget:,.2f} budget)",
            "daily_loss_reached",
        )
    # Worst-case additional loss if this trade is stopped out.
    if _is_number(stop_loss):
        risk_per_unit = abs(float(price) - float(stop_loss))
        trade_risk = risk_per_unit * float(quantity)
        if current_loss + trade_risk > loss_budget:
            return _reject(
                f"Trade's worst-case loss ${trade_risk:,.2f} would breach remaining "
                f"daily loss budget (${loss_budget - current_loss:,.2f} left)",
                "daily_loss_projected",
            )

    return _approve()
