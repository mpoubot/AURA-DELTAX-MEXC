"""
Backtest engine — READ-ONLY historical simulation.

Replays the decision -> risk_engine pipeline against historical Alpaca market
data and reports total return, win rate, and max drawdown.

STRICT SEPARATION FROM LIVE/PAPER EXECUTION:
  * This module NEVER imports orchestrator, NEVER calls the Alpaca CLI, and
    NEVER places real or paper orders.
  * It only READS historical bars (Alpaca market-data REST API) and simulates
    fills in memory.

It does reuse the real, deterministic ``risk_engine.evaluate_trade`` — that is
the whole point of "replaying the risk engine". The decision step is
deterministic by default (a rules-based analog of the agent pipeline, mirroring
the market_analysis -> decision schema), or the real LLM ``decision_agent`` when
``use_llm`` is set and OPENAI_API_KEY is available.
"""

from __future__ import annotations

import logging
import math
import os
import random
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta
from typing import Any, Optional

from risk_engine import APPROVE, AccountContext, RiskConfig, evaluate_trade

logger = logging.getLogger("tradepilot.backtest")

ALPACA_DATA_URL = "https://data.alpaca.markets/v2/stocks/{symbol}/bars"


# --- Config -----------------------------------------------------------------


@dataclass
class StrategyConfig:
    fast_ma: int = 10
    slow_ma: int = 30
    stop_loss_pct: float = 0.05        # stop distance below entry (for a long)
    take_profit_pct: float = 0.10      # target distance above entry
    position_pct: float = 0.10         # fraction of equity per position
    initial_equity: float = 100_000.0
    max_daily_loss_pct: float = 0.03
    max_trades_per_day: int = 50
    use_llm: bool = False              # replay the real LLM decision_agent
    feed: str = "iex"                  # Alpaca data feed (iex is free)

    @classmethod
    def from_dict(cls, data: Optional[dict]) -> "StrategyConfig":
        d = data or {}
        base = cls()
        return cls(
            fast_ma=int(d.get("fast_ma", base.fast_ma)),
            slow_ma=int(d.get("slow_ma", base.slow_ma)),
            stop_loss_pct=float(d.get("stop_loss_pct", base.stop_loss_pct)),
            take_profit_pct=float(d.get("take_profit_pct", base.take_profit_pct)),
            position_pct=float(d.get("position_pct", base.position_pct)),
            initial_equity=float(d.get("initial_equity", base.initial_equity)),
            max_daily_loss_pct=float(d.get("max_daily_loss_pct", base.max_daily_loss_pct)),
            max_trades_per_day=int(d.get("max_trades_per_day", base.max_trades_per_day)),
            use_llm=bool(d.get("use_llm", base.use_llm)),
            feed=str(d.get("feed", base.feed)),
        )

    def to_risk_config(self) -> RiskConfig:
        # Align the risk limits with the strategy so entries at the configured
        # size are evaluated (not auto-rejected by the default 5% cap), while
        # still enforcing SL/TP presence, concentration, and daily-loss rules.
        return RiskConfig(
            max_position_pct=self.position_pct,
            max_daily_loss_pct=self.max_daily_loss_pct,
            max_trades_per_day=self.max_trades_per_day,
            max_concentration_pct=max(self.position_pct * 1.5, 0.5),
            require_stop_loss=True,
            require_take_profit=True,
        )


@dataclass
class Bar:
    d: str      # ISO date
    o: float
    h: float
    l: float
    c: float
    v: float


@dataclass
class OpenPosition:
    qty: int
    entry: float
    stop: float
    take: float
    entry_date: str


# --- Historical data --------------------------------------------------------


def _fetch_alpaca_bars(symbol: str, start: str, end: str, cfg: StrategyConfig) -> list[Bar]:
    """Fetch daily bars from Alpaca's market-data REST API (read-only)."""
    import httpx

    key = os.getenv("ALPACA_API_KEY")
    secret = os.getenv("ALPACA_SECRET_KEY")
    if not key or not secret:
        raise RuntimeError("no Alpaca credentials")

    headers = {"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": secret}
    bars: list[Bar] = []
    page_token: Optional[str] = None
    with httpx.Client(timeout=30) as client:
        while True:
            params: dict[str, Any] = {
                "timeframe": "1Day",
                "start": start,
                "end": end,
                "adjustment": "raw",
                "feed": cfg.feed,
                "limit": 10000,
            }
            if page_token:
                params["page_token"] = page_token
            resp = client.get(ALPACA_DATA_URL.format(symbol=symbol), headers=headers, params=params)
            resp.raise_for_status()
            payload = resp.json()
            for b in payload.get("bars", []) or []:
                bars.append(
                    Bar(d=b["t"][:10], o=b["o"], h=b["h"], l=b["l"], c=b["c"], v=b.get("v", 0))
                )
            page_token = payload.get("next_page_token")
            if not page_token:
                break
    return bars


def _synthetic_bars(symbol: str, start: str, end: str) -> list[Bar]:
    """Deterministic synthetic price series (seeded by symbol) for offline runs."""
    d0 = date.fromisoformat(start)
    d1 = date.fromisoformat(end)
    if d1 < d0:
        d0, d1 = d1, d0
    rng = random.Random(hash(symbol) & 0xFFFFFFFF)
    price = 100.0
    bars: list[Bar] = []
    cur = d0
    while cur <= d1:
        if cur.weekday() < 5:  # weekdays only
            drift, vol = 0.0004, 0.018
            ret = rng.gauss(drift, vol)
            close = max(1.0, price * (1 + ret))
            high = max(price, close) * (1 + abs(rng.gauss(0, 0.004)))
            low = min(price, close) * (1 - abs(rng.gauss(0, 0.004)))
            bars.append(Bar(d=cur.isoformat(), o=round(price, 2), h=round(high, 2),
                            l=round(low, 2), c=round(close, 2), v=1_000_000))
            price = close
        cur += timedelta(days=1)
    return bars


def load_bars(symbol: str, start: str, end: str, cfg: StrategyConfig) -> tuple[list[Bar], str]:
    try:
        bars = _fetch_alpaca_bars(symbol, start, end, cfg)
        if bars:
            return bars, "alpaca"
        logger.info("Alpaca returned no bars for %s; using synthetic", symbol)
    except Exception as exc:
        logger.info("Alpaca fetch unavailable (%s); using synthetic data", exc)
    return _synthetic_bars(symbol, start, end), "synthetic"


# --- Signal / decision (deterministic replay of the agent pipeline) ---------


def _sma(values: list[float], n: int) -> Optional[float]:
    if len(values) < n or n <= 0:
        return None
    return sum(values[-n:]) / n


def _analyze(closes: list[float], cfg: StrategyConfig) -> dict:
    """Deterministic market_analysis (mirrors market_analyst_agent's schema)."""
    fast = _sma(closes, cfg.fast_ma)
    slow = _sma(closes, cfg.slow_ma)
    if fast is None or slow is None:
        return {"trend": "neutral", "volatility": "unknown"}
    trend = "bullish" if fast > slow else "bearish" if fast < slow else "neutral"

    window = closes[-cfg.slow_ma:]
    rets = [
        (window[i] - window[i - 1]) / window[i - 1]
        for i in range(1, len(window))
        if window[i - 1]
    ]
    stdev = (sum((r) ** 2 for r in rets) / len(rets)) ** 0.5 if rets else 0.0
    vol = "high" if stdev > 0.03 else "moderate" if stdev > 0.015 else "low"
    spread = abs(fast - slow) / slow if slow else 0.0
    return {"trend": trend, "volatility": vol, "signal_strength": spread}


def _decide(symbol: str, analysis: dict, price: float, cfg: StrategyConfig,
            equity: float) -> dict:
    """Deterministic decision (mirrors decision_agent's output schema)."""
    trend = analysis.get("trend", "neutral")
    if trend == "bullish":
        action = "BUY"
    elif trend == "bearish":
        action = "SELL"
    else:
        action = "HOLD"

    confidence = max(0.0, min(1.0, float(analysis.get("signal_strength", 0.0)) * 12.0))
    sl = round(price * (1 - cfg.stop_loss_pct), 2)
    tp = round(price * (1 + cfg.take_profit_pct), 2)
    qty = int((cfg.position_pct * equity) // price) if price > 0 else 0
    return {
        "symbol": symbol,
        "action": action,
        "confidence": round(confidence, 2),
        "suggested_quantity": qty,
        "stop_loss": sl if action == "BUY" else None,
        "take_profit": tp if action == "BUY" else None,
        "reasoning": (
            f"{trend} trend (fast/slow MA), volatility {analysis.get('volatility')}; "
            f"news neutral in historical replay."
        ),
    }


def _decide_llm(symbol: str, analysis: dict, price: float, cfg: StrategyConfig,
                equity: float) -> dict:
    """Replay the real LLM decision_agent (only if enabled + key present)."""
    from decision_agent import make_decision

    market_analysis = {
        "symbol": symbol,
        "trend": analysis.get("trend", "neutral"),
        "volatility": analysis.get("volatility", "unknown"),
        "summary": f"Historical bar close {price}; MA-based {analysis.get('trend')} trend.",
    }
    news_analysis = {"symbol": symbol, "sentiment_score": 0.0,
                     "summary": "No news in historical backtest."}
    account_info = {"equity": equity, "cash": equity, "buying_power": equity * 2,
                    "positions": [], "paper": True}
    return make_decision(market_analysis, news_analysis, account_info)


# --- Simulation & metrics ---------------------------------------------------


def _max_drawdown(equity_curve: list[float]) -> float:
    peak = -math.inf
    max_dd = 0.0
    for e in equity_curve:
        peak = max(peak, e)
        if peak > 0:
            max_dd = max(max_dd, (peak - e) / peak)
    return max_dd


def run_backtest(symbol: str, start: str, end: str,
                 strategy: Optional[dict] = None) -> dict:
    """Run the read-only backtest. Returns metrics + equity curve + trades."""
    symbol = (symbol or "").strip().upper()
    cfg = StrategyConfig.from_dict(strategy)
    risk_cfg = cfg.to_risk_config()

    if not symbol:
        return {"error": "symbol is required"}
    try:
        date.fromisoformat(start)
        date.fromisoformat(end)
    except (ValueError, TypeError):
        return {"error": "start and end must be YYYY-MM-DD dates"}

    bars, source = load_bars(symbol, start, end, cfg)
    warmup = cfg.slow_ma
    if len(bars) <= warmup:
        return {"error": f"not enough historical bars ({len(bars)}) for warmup {warmup}",
                "data_source": source}

    cash = cfg.initial_equity
    position: Optional[OpenPosition] = None
    closes: list[float] = [b.c for b in bars]
    trades: list[dict] = []
    equity_curve: list[dict] = []
    day_trades: dict[str, int] = {}

    for i in range(len(bars)):
        bar = bars[i]

        # 1. Exit checks for an open position (stop first — conservative).
        if position is not None:
            exit_price = None
            reason = None
            if bar.l <= position.stop:
                exit_price, reason = position.stop, "stop_loss"
            elif bar.h >= position.take:
                exit_price, reason = position.take, "take_profit"
            if exit_price is not None:
                pnl = (exit_price - position.entry) * position.qty
                cash += exit_price * position.qty
                trades.append({
                    "symbol": symbol, "entry_date": position.entry_date,
                    "exit_date": bar.d, "entry": position.entry, "exit": exit_price,
                    "qty": position.qty, "pnl": round(pnl, 2),
                    "result": "win" if pnl > 0 else "loss", "reason": reason,
                })
                position = None

        # 2. Decision (only after warmup; no lookahead — uses closes[:i+1]).
        if i >= warmup:
            equity_now = cash + (position.qty * bar.c if position else 0.0)
            analysis = _analyze(closes[: i + 1], cfg)
            if cfg.use_llm and os.getenv("OPENAI_API_KEY"):
                proposal = _decide_llm(symbol, analysis, bar.c, cfg, equity_now)
            else:
                proposal = _decide(symbol, analysis, bar.c, cfg, equity_now)

            action = str(proposal.get("action", "HOLD")).upper()

            # 3a. Signal-based exit of an existing long.
            if position is not None and action == "SELL":
                pnl = (bar.c - position.entry) * position.qty
                cash += bar.c * position.qty
                trades.append({
                    "symbol": symbol, "entry_date": position.entry_date,
                    "exit_date": bar.d, "entry": position.entry, "exit": bar.c,
                    "qty": position.qty, "pnl": round(pnl, 2),
                    "result": "win" if pnl > 0 else "loss", "reason": "signal_exit",
                })
                position = None

            # 3b. Entry — flat + BUY + risk engine APPROVE.
            elif position is None and action == "BUY":
                qty = int(proposal.get("suggested_quantity") or 0)
                price = bar.c
                if qty >= 1 and price > 0:
                    risk_proposal = {
                        "symbol": symbol, "side": "buy", "quantity": qty, "price": price,
                        "stop_loss": proposal.get("stop_loss"),
                        "take_profit": proposal.get("take_profit"),
                    }
                    ctx = AccountContext(
                        equity=equity_now, positions={}, open_orders=[],
                        trades_today=day_trades.get(bar.d, 0), daily_pnl=0.0,
                    )
                    decision = evaluate_trade(risk_proposal, ctx, risk_cfg)
                    if decision.decision == APPROVE:
                        cash -= qty * price
                        position = OpenPosition(
                            qty=qty, entry=price,
                            stop=float(proposal["stop_loss"]),
                            take=float(proposal["take_profit"]),
                            entry_date=bar.d,
                        )
                        day_trades[bar.d] = day_trades.get(bar.d, 0) + 1

        # 4. Mark-to-market equity for the curve.
        equity = cash + (position.qty * bar.c if position else 0.0)
        equity_curve.append({"date": bar.d, "equity": round(equity, 2)})

    # Close any open position at the final bar (realize for metrics).
    if position is not None:
        last = bars[-1]
        pnl = (last.c - position.entry) * position.qty
        cash += last.c * position.qty
        trades.append({
            "symbol": symbol, "entry_date": position.entry_date, "exit_date": last.d,
            "entry": position.entry, "exit": last.c, "qty": position.qty,
            "pnl": round(pnl, 2), "result": "win" if pnl > 0 else "loss",
            "reason": "end_of_period",
        })
        equity_curve[-1]["equity"] = round(cash, 2)

    final_equity = cash
    total_return = (final_equity - cfg.initial_equity) / cfg.initial_equity
    wins = sum(1 for t in trades if t["result"] == "win")
    win_rate = wins / len(trades) if trades else 0.0
    max_dd = _max_drawdown([p["equity"] for p in equity_curve])

    return {
        "symbol": symbol,
        "start": start,
        "end": end,
        "data_source": source,
        "bars": len(bars),
        "strategy": {
            "fast_ma": cfg.fast_ma, "slow_ma": cfg.slow_ma,
            "stop_loss_pct": cfg.stop_loss_pct, "take_profit_pct": cfg.take_profit_pct,
            "position_pct": cfg.position_pct, "initial_equity": cfg.initial_equity,
            "use_llm": cfg.use_llm,
        },
        "initial_equity": round(cfg.initial_equity, 2),
        "final_equity": round(final_equity, 2),
        "total_return": round(total_return, 4),
        "total_return_pct": round(total_return * 100, 2),
        "win_rate": round(win_rate, 4),
        "win_rate_pct": round(win_rate * 100, 2),
        "max_drawdown": round(max_dd, 4),
        "max_drawdown_pct": round(max_dd * 100, 2),
        "num_trades": len(trades),
        "wins": wins,
        "losses": len(trades) - wins,
        "trades": trades,
        "equity_curve": equity_curve,
    }
