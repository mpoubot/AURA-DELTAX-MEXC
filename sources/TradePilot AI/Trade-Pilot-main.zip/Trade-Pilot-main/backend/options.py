"""
Options strategy support (READ-ONLY selection + sizing).

Translates the agents' directional view into a single-leg long option:
    bullish (decision BUY)  -> long CALL
    bearish (decision SELL) -> long PUT

Selects a near-the-money contract a few weeks out from the real Alpaca options
chain (market-data REST, indicative feed), prices it from the latest ask, and
sizes the number of contracts to fit the position budget. A long option's max
loss is the premium paid, so risk is inherently capped.

This module never places orders — it only reads the chain and builds a proposal.
Execution goes through the orchestrator's Alpaca-CLI path.
"""

from __future__ import annotations

import logging
import math
import os
from datetime import date, timedelta
from typing import Optional

logger = logging.getLogger("tradepilot.options")

_CHAIN_URL = "https://data.alpaca.markets/v1beta1/options/snapshots/{underlying}"
_CONTRACTS_URL = "https://paper-api.alpaca.markets/v2/options/contracts"

# Selection defaults (overridable via strategy config).
_MIN_DTE = 14
_MAX_DTE = 45
_STRIKE_BAND = 0.08   # search strikes within +/-8% of spot


def _headers() -> Optional[dict]:
    key = os.getenv("ALPACA_API_KEY")
    secret = os.getenv("ALPACA_SECRET_KEY")
    if not key or not secret:
        return None
    return {"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": secret}


def parse_occ(occ: str) -> tuple[str, str, str, float]:
    """Parse an OCC option symbol -> (underlying, expiration ISO, type, strike)."""
    strike = int(occ[-8:]) / 1000.0
    opt_type = "call" if occ[-9].upper() == "C" else "put"
    yymmdd = occ[-15:-9]
    underlying = occ[:-15]
    expiration = f"20{yymmdd[0:2]}-{yymmdd[2:4]}-{yymmdd[4:6]}"
    return underlying, expiration, opt_type, strike


def _fetch_chain(underlying: str, opt_type: str, price: float,
                 min_dte: int, max_dte: int) -> list[dict]:
    """Fetch priced near-ATM contracts from the options chain (indicative feed)."""
    headers = _headers()
    if not headers:
        return []
    try:
        import httpx

        today = date.today()
        params = {
            "feed": "indicative",
            "type": opt_type,
            "expiration_date_gte": (today + timedelta(days=min_dte)).isoformat(),
            "expiration_date_lte": (today + timedelta(days=max_dte)).isoformat(),
            "strike_price_gte": round(price * (1 - _STRIKE_BAND), 2),
            "strike_price_lte": round(price * (1 + _STRIKE_BAND), 2),
            "limit": 100,
        }
        with httpx.Client(timeout=20) as client:
            resp = client.get(_CHAIN_URL.format(underlying=underlying), headers=headers, params=params)
            resp.raise_for_status()
            snapshots = resp.json().get("snapshots", {}) or {}
    except Exception as exc:
        logger.info("options chain fetch failed for %s: %s", underlying, exc)
        return []

    out = []
    for occ, snap in snapshots.items():
        quote = (snap or {}).get("latestQuote", {}) or {}
        ask = quote.get("ap")
        if not ask or ask <= 0:
            continue
        _, expiration, _type, strike = parse_occ(occ)
        greeks = (snap or {}).get("greeks", {}) or {}
        out.append({
            "occ_symbol": occ,
            "type": _type,
            "strike": strike,
            "expiration": expiration,
            "premium": float(ask),
            "bid": quote.get("bp"),
            "delta": greeks.get("delta"),
        })
    return out


def _fetch_contracts_fallback(underlying: str, opt_type: str, price: float,
                              min_dte: int, max_dte: int) -> list[dict]:
    """Metadata-only fallback (no live quote) — premium is estimated later."""
    headers = _headers()
    if not headers:
        return []
    try:
        import httpx

        today = date.today()
        params = {
            "underlying_symbols": underlying,
            "type": opt_type,
            "expiration_date_gte": (today + timedelta(days=min_dte)).isoformat(),
            "expiration_date_lte": (today + timedelta(days=max_dte)).isoformat(),
            "strike_price_gte": round(price * (1 - _STRIKE_BAND), 2),
            "strike_price_lte": round(price * (1 + _STRIKE_BAND), 2),
            "limit": 100,
        }
        with httpx.Client(timeout=20) as client:
            resp = client.get(_CONTRACTS_URL, headers=headers, params=params)
            resp.raise_for_status()
            contracts = resp.json().get("option_contracts", []) or []
    except Exception as exc:
        logger.info("options contracts fallback failed for %s: %s", underlying, exc)
        return []

    out = []
    for c in contracts:
        strike = float(c.get("strike_price", 0) or 0)
        out.append({
            "occ_symbol": c["symbol"],
            "type": c["type"],
            "strike": strike,
            "expiration": c["expiration_date"],
            "premium": None,   # estimated in select_contract
            "delta": None,
        })
    return out


def _estimate_premium(price: float, strike: float, opt_type: str, expiration: str) -> float:
    """Rough premium estimate when no live quote is available (sizing only)."""
    intrinsic = max(0.0, price - strike) if opt_type == "call" else max(0.0, strike - price)
    try:
        dte = max(1, (date.fromisoformat(expiration) - date.today()).days)
    except Exception:
        dte = 30
    time_value = price * 0.03 * math.sqrt(dte / 30.0)
    return round(max(0.05, intrinsic + time_value), 2)


def select_contract(underlying: str, direction: str, price: float,
                    min_dte: int = _MIN_DTE, max_dte: int = _MAX_DTE) -> Optional[dict]:
    """Pick the near-ATM contract (with a live ask when possible)."""
    opt_type = "call" if direction == "bullish" else "put"

    candidates = _fetch_chain(underlying, opt_type, price, min_dte, max_dte)
    source = "chain"
    if not candidates:
        candidates = _fetch_contracts_fallback(underlying, opt_type, price, min_dte, max_dte)
        source = "estimate"
    if not candidates:
        return None

    # Closest to at-the-money, tie-break on nearest expiration.
    candidates.sort(key=lambda c: (abs(c["strike"] - price), c["expiration"]))
    chosen = candidates[0]

    premium = chosen.get("premium")
    if premium is None or premium <= 0:
        premium = _estimate_premium(price, chosen["strike"], opt_type, chosen["expiration"])
        source = "estimate"

    return {
        "occ_symbol": chosen["occ_symbol"],
        "type": opt_type,
        "strike": chosen["strike"],
        "expiration": chosen["expiration"],
        "premium": round(float(premium), 2),
        "cost_per_contract": round(float(premium) * 100.0, 2),
        "delta": chosen.get("delta"),
        "premium_source": source,
    }


def build_option_proposal(underlying: str, decision: dict, price: float,
                          equity: float, max_position_pct: float) -> Optional[dict]:
    """Turn a stock decision into a sized long-option proposal.

    Returns None for HOLD. Returns a proposal with ``contracts == 0`` when the
    premium is too large for the position budget (caller should skip).
    """
    action = str(decision.get("action", "HOLD")).upper()
    if action == "BUY":
        direction = "bullish"
    elif action == "SELL":
        direction = "bearish"
    else:
        return None

    contract = select_contract(underlying, direction, price)
    if not contract:
        return None

    budget = max(0.0, equity * max_position_pct)
    cost = contract["cost_per_contract"]
    contracts = int(budget // cost) if cost > 0 else 0

    summary = (
        f"Long {contract['type'].upper()} {underlying} {contract['strike']:g} "
        f"exp {contract['expiration']} @ ~${contract['premium']:.2f} "
        f"x{contracts} contract(s) (${contracts * cost:,.0f})"
    )
    return {
        "underlying": underlying,
        "occ_symbol": contract["occ_symbol"],
        "option_type": contract["type"],
        "strike": contract["strike"],
        "expiration": contract["expiration"],
        "premium": contract["premium"],
        "cost_per_contract": cost,
        "contracts": contracts,
        "delta": contract.get("delta"),
        "premium_source": contract["premium_source"],
        "confidence": float(decision.get("confidence", 0.0) or 0.0),
        "reasoning": f"[OPTIONS] {summary}. " + str(decision.get("reasoning") or ""),
    }
