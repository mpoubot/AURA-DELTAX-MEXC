"""
Database layer for TradePilot AI.

Defines the SQLAlchemy models that back the audit trail:
  * decision_log      — one row per symbol processed by the orchestrator,
                        capturing the proposal, the risk decision, and the
                        execution result, with a timestamp.
  * pending_approvals — proposals that passed the risk engine but are waiting
                        for a human to approve/reject (human_approval mode).

DATABASE_URL is read from the environment (.env). If it is unset or still a
placeholder, we fall back to a local SQLite file so the pipeline is runnable
out of the box.
"""

from __future__ import annotations

import os
from datetime import datetime, timezone
from pathlib import Path

from sqlalchemy import (
    Column,
    DateTime,
    Float,
    Integer,
    String,
    Text,
    create_engine,
    inspect as sa_inspect,
    text,
)
from sqlalchemy.orm import declarative_base, sessionmaker

Base = declarative_base()


def _utcnow() -> datetime:
    return datetime.now(timezone.utc)


def _resolve_database_url() -> str:
    url = os.getenv("DATABASE_URL", "").strip()
    # Ignore empty or obvious placeholder values from a scaffolded .env.
    if not url or "changeme" in url.lower() or "placeholder" in url.lower():
        default_path = Path(__file__).resolve().parent / "tradepilot.db"
        return f"sqlite:///{default_path.as_posix()}"
    return url


DATABASE_URL = _resolve_database_url()

_connect_args = {"check_same_thread": False} if DATABASE_URL.startswith("sqlite") else {}
engine = create_engine(DATABASE_URL, future=True, connect_args=_connect_args)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False, future=True)


class DecisionLog(Base):
    """Full audit record for one symbol run through the pipeline."""

    __tablename__ = "decision_log"

    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime(timezone=True), default=_utcnow, nullable=False)
    symbol = Column(String(20), nullable=False, index=True)

    # --- Proposal (from decision_agent) ---
    action = Column(String(8), nullable=False)              # BUY / SELL / HOLD
    confidence = Column(Float, nullable=False, default=0.0)
    suggested_quantity = Column(Integer, nullable=False, default=0)
    stop_loss = Column(Float, nullable=True)
    take_profit = Column(Float, nullable=True)
    reference_price = Column(Float, nullable=True)          # price used for risk sizing
    reasoning = Column(Text, nullable=True)

    # --- Context snapshot (for explainability / audit) ---
    market_trend = Column(String(16), nullable=True)
    news_sentiment = Column(Float, nullable=True)

    # --- Risk engine outcome ---
    risk_decision = Column(String(16), nullable=True)       # APPROVE / REJECT / N/A
    risk_reason = Column(Text, nullable=True)
    risk_rule = Column(String(40), nullable=True)

    # --- Instrument (stock vs option) ---
    instrument = Column(String(16), nullable=True, default="stock")
    option_symbol = Column(String(32), nullable=True)   # OCC symbol for options
    option_type = Column(String(8), nullable=True)      # call / put
    strike = Column(Float, nullable=True)
    expiration = Column(String(16), nullable=True)
    premium = Column(Float, nullable=True)

    # --- Execution outcome ---
    execution_status = Column(String(32), nullable=False, default="PENDING")
    execution_detail = Column(Text, nullable=True)          # order JSON or error text
    order_id = Column(String(64), nullable=True)

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "symbol": self.symbol,
            "action": self.action,
            "confidence": self.confidence,
            "suggested_quantity": self.suggested_quantity,
            "stop_loss": self.stop_loss,
            "take_profit": self.take_profit,
            "reference_price": self.reference_price,
            "reasoning": self.reasoning,
            "market_trend": self.market_trend,
            "news_sentiment": self.news_sentiment,
            "risk_decision": self.risk_decision,
            "risk_reason": self.risk_reason,
            "risk_rule": self.risk_rule,
            "instrument": self.instrument or "stock",
            "option_symbol": self.option_symbol,
            "option_type": self.option_type,
            "strike": self.strike,
            "expiration": self.expiration,
            "premium": self.premium,
            "execution_status": self.execution_status,
            "execution_detail": self.execution_detail,
            "order_id": self.order_id,
        }


class PendingApproval(Base):
    """A risk-approved proposal awaiting a human decision (human_approval mode)."""

    __tablename__ = "pending_approvals"

    id = Column(Integer, primary_key=True)
    timestamp = Column(DateTime(timezone=True), default=_utcnow, nullable=False)
    symbol = Column(String(20), nullable=False, index=True)

    action = Column(String(8), nullable=False)
    confidence = Column(Float, nullable=False, default=0.0)
    suggested_quantity = Column(Integer, nullable=False, default=0)
    stop_loss = Column(Float, nullable=True)
    take_profit = Column(Float, nullable=True)
    reference_price = Column(Float, nullable=True)
    reasoning = Column(Text, nullable=True)

    # Instrument (stock vs option)
    instrument = Column(String(16), nullable=True, default="stock")
    option_symbol = Column(String(32), nullable=True)
    option_type = Column(String(8), nullable=True)
    strike = Column(Float, nullable=True)
    expiration = Column(String(16), nullable=True)
    premium = Column(Float, nullable=True)

    status = Column(String(16), nullable=False, default="PENDING")  # PENDING/APPROVED/REJECTED
    resolved_at = Column(DateTime(timezone=True), nullable=True)
    resolution_note = Column(Text, nullable=True)
    decision_log_id = Column(Integer, nullable=True)

    def as_dict(self) -> dict:
        return {
            "id": self.id,
            "timestamp": self.timestamp.isoformat() if self.timestamp else None,
            "symbol": self.symbol,
            "action": self.action,
            "confidence": self.confidence,
            "suggested_quantity": self.suggested_quantity,
            "stop_loss": self.stop_loss,
            "take_profit": self.take_profit,
            "reference_price": self.reference_price,
            "reasoning": self.reasoning,
            "instrument": self.instrument or "stock",
            "option_symbol": self.option_symbol,
            "option_type": self.option_type,
            "strike": self.strike,
            "expiration": self.expiration,
            "premium": self.premium,
            "status": self.status,
            "resolved_at": self.resolved_at.isoformat() if self.resolved_at else None,
            "resolution_note": self.resolution_note,
            "decision_log_id": self.decision_log_id,
        }


_OPTION_COLUMNS = {
    "instrument": "VARCHAR(16)",
    "option_symbol": "VARCHAR(32)",
    "option_type": "VARCHAR(8)",
    "strike": "DOUBLE PRECISION" if not DATABASE_URL.startswith("sqlite") else "FLOAT",
    "expiration": "VARCHAR(16)",
    "premium": "DOUBLE PRECISION" if not DATABASE_URL.startswith("sqlite") else "FLOAT",
}


def _ensure_option_columns() -> None:
    """Idempotently add the option columns to pre-existing tables (both dialects,
    plain ADD COLUMN — checked against the live schema first)."""
    insp = sa_inspect(engine)
    for table in ("decision_log", "pending_approvals"):
        if not insp.has_table(table):
            continue
        existing = {c["name"] for c in insp.get_columns(table)}
        for col, coltype in _OPTION_COLUMNS.items():
            if col not in existing:
                try:
                    with engine.begin() as conn:
                        conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col} {coltype}"))
                except Exception:  # pragma: no cover - best effort
                    pass


def init_db() -> None:
    """Create tables if they do not already exist, then reconcile new columns."""
    Base.metadata.create_all(bind=engine)
    _ensure_option_columns()
