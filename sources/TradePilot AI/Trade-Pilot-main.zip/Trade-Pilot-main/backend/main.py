"""
TradePilot AI — FastAPI application.

Thin HTTP layer over the already-built modules:
  * orchestrator  — pipeline, execution, pending-approval resolution
  * risk_engine   — (used inside the orchestrator)
  * database      — decision_log / pending_approvals audit tables

Endpoints:
  POST   /watchlist/scan          run the pipeline over the current watchlist
  GET    /decisions/log           paginated audit trail
  GET    /approvals/pending       proposals awaiting human approval
  POST   /approvals/{id}/approve  approve + execute a pending proposal
  POST   /approvals/{id}/reject   reject a pending proposal
  GET    /account                 Alpaca paper account (equity, buying power, positions)
  GET    /watchlist               configured watchlist
  POST   /watchlist               update watchlist symbols
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
from pathlib import Path
from typing import Optional

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

# Load backend/.env before importing modules that read env at import time.
load_dotenv(Path(__file__).resolve().parent / ".env")

from backtest import run_backtest
from database import DecisionLog, SessionLocal, init_db
from orchestrator import (
    _alpaca_cli_path,
    approve_pending,
    list_pending_approvals,
    reject_pending,
    run_pipeline,
)

logger = logging.getLogger("tradepilot.api")

app = FastAPI(title="TradePilot AI", version="0.1.0")

# Allowed browser origins. Local dev + the deployed Vercel frontend by default;
# any *.vercel.app preview is matched by regex. Override/extend the explicit list
# with FRONTEND_ORIGINS (comma-separated) without a code change.
_DEFAULT_ORIGINS = [
    "http://localhost:3000",
    "http://localhost:3001",
    "https://trade-pilot-ai-navy.vercel.app",
]
_extra_origins = [
    o.strip() for o in os.getenv("FRONTEND_ORIGINS", "").split(",") if o.strip()
]

app.add_middleware(
    CORSMiddleware,
    allow_origins=_DEFAULT_ORIGINS + _extra_origins,
    allow_origin_regex=r"https://.*\.vercel\.app",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def _startup() -> None:
    init_db()


# --- Watchlist persistence (simple JSON file) ------------------------------

_WATCHLIST_FILE = Path(__file__).resolve().parent / "watchlist.json"
_DEFAULT_WATCHLIST = ["AAPL", "MSFT", "TSLA", "NVDA"]


def load_watchlist() -> list[str]:
    try:
        if _WATCHLIST_FILE.exists():
            data = json.loads(_WATCHLIST_FILE.read_text())
            symbols = data.get("symbols") if isinstance(data, dict) else data
            if isinstance(symbols, list) and symbols:
                return [str(s).upper() for s in symbols]
    except Exception as exc:  # pragma: no cover - defensive
        logger.warning("failed to read watchlist: %s", exc)
    return list(_DEFAULT_WATCHLIST)


def save_watchlist(symbols: list[str]) -> list[str]:
    cleaned = [str(s).strip().upper() for s in symbols if str(s).strip()]
    _WATCHLIST_FILE.write_text(json.dumps({"symbols": cleaned}, indent=2))
    return cleaned


# --- Request models --------------------------------------------------------


class WatchlistUpdate(BaseModel):
    symbols: list[str]


class BacktestRequest(BaseModel):
    symbol: str
    start: str  # YYYY-MM-DD
    end: str    # YYYY-MM-DD
    strategy: Optional[dict] = None


# --- Alpaca CLI account helper ---------------------------------------------


def _run_cli(args: list[str]) -> tuple[bool, object]:
    """Run an alpaca CLI command; return (ok, parsed_json_or_text)."""
    try:
        proc = subprocess.run(args, capture_output=True, text=True, timeout=30)
    except Exception as exc:
        return False, f"CLI invocation failed: {exc}"
    output = (proc.stdout or "").strip() or (proc.stderr or "").strip()
    try:
        parsed = json.loads(output)
    except (json.JSONDecodeError, ValueError):
        return proc.returncode == 0, output
    if isinstance(parsed, dict) and parsed.get("error"):
        return False, parsed
    return proc.returncode == 0, parsed


def get_account_info() -> dict:
    """Fetch paper account + positions via the Alpaca CLI."""
    cli = _alpaca_cli_path()
    ok_acct, acct = _run_cli([cli, "account", "get"])
    if not ok_acct:
        return {"available": False, "error": acct}

    ok_pos, positions = _run_cli([cli, "position", "list"])
    if not ok_pos or not isinstance(positions, list):
        positions = []

    def _num(key: str) -> Optional[float]:
        try:
            return float(acct.get(key)) if isinstance(acct, dict) and acct.get(key) is not None else None
        except (TypeError, ValueError):
            return None

    return {
        "available": True,
        "account_number": acct.get("account_number") if isinstance(acct, dict) else None,
        "status": acct.get("status") if isinstance(acct, dict) else None,
        "currency": acct.get("currency") if isinstance(acct, dict) else None,
        "equity": _num("equity"),
        "cash": _num("cash"),
        "buying_power": _num("buying_power"),
        "positions": positions,
    }


# --- Endpoints -------------------------------------------------------------


def _live_account_info() -> Optional[dict]:
    """Shape the real paper account for the orchestrator's risk sizing.

    Returns None when the account can't be read, so the orchestrator falls back
    to its demo default instead of sizing against a zero-equity account.
    """
    acct = get_account_info()
    if not acct.get("available"):
        return None
    equity = acct.get("equity")
    if not isinstance(equity, (int, float)) or equity <= 0:
        return None
    return {
        "equity": float(equity),
        "cash": float(acct.get("cash") or 0.0),
        "buying_power": float(acct.get("buying_power") or 0.0),
        "positions": acct.get("positions") or [],
        "daily_pnl": 0.0,
        "trades_today": 0,
        "paper": True,
    }


@app.get("/watchlist")
def get_watchlist() -> dict:
    return {"symbols": load_watchlist()}


@app.post("/watchlist")
def update_watchlist(body: WatchlistUpdate) -> dict:
    if not body.symbols:
        raise HTTPException(status_code=400, detail="symbols must not be empty")
    return {"symbols": save_watchlist(body.symbols)}


@app.post("/watchlist/scan")
def scan_watchlist(
    human_approval: bool = Query(False),
    mode: str = Query("stock", pattern="^(stock|options)$"),
) -> dict:
    symbols = load_watchlist()
    # Size trades against the REAL paper account (equity / buying power /
    # positions) rather than the orchestrator's hardcoded demo default — so the
    # risk engine can't approve an order the account can't actually afford
    # (which otherwise surfaces as Alpaca's 403 "insufficient buying power").
    account_info = _live_account_info()
    results = run_pipeline(
        symbols, human_approval=human_approval, mode=mode, account_info=account_info
    )
    return {
        "watchlist": symbols,
        "human_approval": human_approval,
        "mode": mode,
        "account_equity": (account_info or {}).get("equity"),
        "count": len(results),
        "results": results,
    }


@app.get("/decisions/log")
def decisions_log(
    limit: int = Query(50, ge=1, le=500),
    offset: int = Query(0, ge=0),
) -> dict:
    with SessionLocal() as session:
        total = session.query(DecisionLog).count()
        rows = (
            session.query(DecisionLog)
            .order_by(DecisionLog.timestamp.desc(), DecisionLog.id.desc())
            .offset(offset)
            .limit(limit)
            .all()
        )
        return {
            "total": total,
            "limit": limit,
            "offset": offset,
            "items": [r.as_dict() for r in rows],
        }


@app.get("/approvals/pending")
def approvals_pending() -> dict:
    items = list_pending_approvals()
    return {"count": len(items), "items": items}


@app.post("/approvals/{approval_id}/approve")
def approvals_approve(approval_id: int, note: str = Query("")) -> dict:
    result = approve_pending(approval_id, note=note)
    if "error" in result and "pending" not in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


@app.post("/approvals/{approval_id}/reject")
def approvals_reject(approval_id: int, note: str = Query("")) -> dict:
    result = reject_pending(approval_id, note=note)
    if "error" in result and "pending" not in result:
        raise HTTPException(status_code=404, detail=result["error"])
    return result


@app.get("/account")
def account() -> dict:
    return get_account_info()


@app.get("/portfolio/history")
def portfolio_history(
    period: str = Query("1M", pattern="^(1D|1W|1M|3M|6M|1A|all)$"),
    timeframe: str = Query("1D", pattern="^(1Min|5Min|15Min|1H|1D)$"),
) -> dict:
    """Equity-over-time for the paper account (Alpaca portfolio history, read-only).

    Returns {available, base_value, points:[{t, equity, pnl}]} so the dashboard
    can draw an equity curve. Degrades to {available:false} on any failure.
    """
    key = os.getenv("ALPACA_API_KEY")
    secret = os.getenv("ALPACA_SECRET_KEY")
    if not key or not secret:
        return {"available": False, "error": "no Alpaca credentials", "points": []}
    try:
        import httpx
        from datetime import datetime, timezone

        url = "https://paper-api.alpaca.markets/v2/account/portfolio/history"
        headers = {"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": secret}
        params = {"period": period, "timeframe": timeframe, "intraday_reporting": "market_hours"}
        with httpx.Client(timeout=20) as client:
            resp = client.get(url, headers=headers, params=params)
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:
        logger.info("portfolio history unavailable: %s", exc)
        return {"available": False, "error": str(exc), "points": []}

    ts = data.get("timestamp") or []
    eq = data.get("equity") or []
    pl = data.get("profit_loss") or []
    intraday = timeframe.endswith("Min") or timeframe.endswith("H")

    # Trim the leading run of zero-equity samples (before the account was
    # funded) so the curve starts at the first real balance instead of a flat 0.
    first = next((i for i, v in enumerate(eq) if v not in (None, 0, 0.0)), 0)

    points = []
    for i in range(first, len(ts)):
        t = ts[i]
        equity = eq[i] if i < len(eq) else None
        if equity is None:
            continue
        try:
            dt = datetime.fromtimestamp(int(t), tz=timezone.utc)
            label = dt.strftime("%Y-%m-%d %H:%M" if intraday else "%Y-%m-%d")
        except (TypeError, ValueError, OSError):
            label = str(t)
        points.append({
            "t": label,
            "equity": float(equity),
            "pnl": float(pl[i]) if i < len(pl) and pl[i] is not None else None,
        })
    return {
        "available": True,
        "base_value": data.get("base_value"),
        "period": period,
        "timeframe": data.get("timeframe", timeframe),
        "points": points,
    }


@app.post("/backtest")
def backtest(body: BacktestRequest) -> dict:
    """Read-only historical simulation. Never touches the live/paper execution
    path (no orchestrator, no Alpaca CLI, no orders)."""
    result = run_backtest(body.symbol, body.start, body.end, body.strategy)
    if "error" in result and "total_return" not in result:
        raise HTTPException(status_code=400, detail=result["error"])
    return result


@app.get("/")
def root() -> dict:
    return {"service": "TradePilot AI", "status": "ok"}
