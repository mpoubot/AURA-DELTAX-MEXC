"""
Shared LLM runtime for the TradePilot AI agents.

LLM layer: the **OpenAI Agents SDK** (https://openai.github.io/openai-agents-python/).
Reads OPENAI_API_KEY from the environment. Model is configurable via OPENAI_MODEL.

Responsibilities:
  1. Connect (over stdio) to the local Alpaca MCP server — the same server
     registered with Claude Code, launched independently so this backend can use
     it outside of a Claude Code session. The SDK's native `MCPServerStdio`
     handles the connection and exposes the server's tools to the agent.
  2. Run OpenAI agents that fetch data via MCP tools and reason over it.

Safety:
  * Data agents receive a **static allowlist** of read-only tools only
    (get_stock_bars, get_news, ...). Order-placement tools such as
    `place_stock_order` are never exposed here — execution stays exclusively in
    the orchestrator's Alpaca-CLI path.

Everything degrades gracefully: connection / model / parse failures surface as
``None`` so the calling agent returns neutral defaults instead of raising.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
from pathlib import Path
from typing import Any, Optional, Sequence

logger = logging.getLogger("tradepilot.mcp_agent")

# Model is configurable; default to a fast, inexpensive OpenAI model.
DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")


def _env_int(name: str, default: int) -> int:
    """Read a small positive int knob from the environment (token-budget tuning)."""
    try:
        return max(1, int(os.getenv(name, str(default))))
    except (TypeError, ValueError):
        return default


# Turn caps bound how many tool-calling round-trips an agent may make. Each extra
# turn re-sends the full (growing) conversation to the model, so keeping these
# low is the single biggest lever on token spend. Overridable via env.
MCP_MAX_TURNS = _env_int("AGENT_MCP_MAX_TURNS", 4)
LLM_MAX_TURNS = _env_int("AGENT_LLM_MAX_TURNS", 2)

# Disable the SDK's tracing exporter (it would otherwise POST traces to OpenAI
# and emit warnings). Safe no-op if the symbol is unavailable.
try:  # pragma: no cover - best effort
    from agents import set_tracing_disabled

    set_tracing_disabled(True)
except Exception:  # pragma: no cover
    pass


# --- Locating / launching the Alpaca MCP server ----------------------------


def _default_mcp_dir() -> Path:
    """Resolve the alpaca-mcp-server directory (sibling of backend/)."""
    override = os.getenv("ALPACA_MCP_DIR")
    if override:
        return Path(override)
    return Path(__file__).resolve().parent.parent / "alpaca-mcp-server"


def _mcp_stdio_params():
    """Build the stdio launch params for the Alpaca MCP server.

    Credentials reach the server two ways (either is sufficient):
      * ``--env-file <dir>/.env`` if that file exists, and/or
      * the ALPACA_* variables inherited through the subprocess environment.
    """
    from agents.mcp import MCPServerStdioParams

    mcp_dir = _default_mcp_dir()
    args = ["--directory", str(mcp_dir), "run", "alpaca-mcp-server"]

    env_file = mcp_dir / ".env"
    if env_file.exists():
        args += ["--env-file", str(env_file)]

    env = {k: v for k, v in os.environ.items()}
    return MCPServerStdioParams(command="uv", args=args, env=env)


def _has_openai_key() -> bool:
    if not os.getenv("OPENAI_API_KEY"):
        logger.warning("OPENAI_API_KEY is not set — cannot call the LLM")
        return False
    return True


def _final_text(result) -> Optional[str]:
    out = getattr(result, "final_output", None)
    if out is None:
        return None
    return out if isinstance(out, str) else str(out)


# --- Agent runners ----------------------------------------------------------


async def _run_mcp_agent_async(
    instructions: str,
    user_input: str,
    allowed_tools: Optional[Sequence[str]],
    model: str,
    max_turns: int,
) -> Optional[str]:
    from agents import Agent, Runner
    from agents.mcp import MCPServerStdio, create_static_tool_filter

    tool_filter = (
        create_static_tool_filter(allowed_tool_names=list(allowed_tools))
        if allowed_tools
        else None
    )

    async with MCPServerStdio(
        params=_mcp_stdio_params(),
        cache_tools_list=True,
        client_session_timeout_seconds=30,
        tool_filter=tool_filter,
    ) as server:
        agent = Agent(
            name="TradePilot Data Agent",
            instructions=instructions,
            model=model,
            mcp_servers=[server],
        )
        result = await Runner.run(agent, user_input, max_turns=max_turns)
        return _final_text(result)


async def _run_agent_async(
    instructions: str, user_input: str, model: str, max_turns: int
) -> Optional[str]:
    from agents import Agent, Runner

    agent = Agent(name="TradePilot Reasoner", instructions=instructions, model=model)
    result = await Runner.run(agent, user_input, max_turns=max_turns)
    return _final_text(result)


def run_mcp_agent_sync(
    instructions: str,
    user_input: str,
    allowed_tools: Optional[Sequence[str]] = None,
    max_turns: int = MCP_MAX_TURNS,
    model: str = DEFAULT_MODEL,
) -> Optional[str]:
    """Run an OpenAI agent that has access to the (allowlisted) Alpaca MCP tools.

    Returns the agent's final text output, or ``None`` on any failure.
    """
    if not _has_openai_key():
        return None
    try:
        return asyncio.run(
            _run_mcp_agent_async(instructions, user_input, allowed_tools, model, max_turns)
        )
    except Exception as exc:
        logger.warning("run_mcp_agent_sync failed: %s", exc)
        return None


def run_llm_sync(
    instructions: str,
    user_input: str,
    max_turns: int = LLM_MAX_TURNS,
    model: str = DEFAULT_MODEL,
) -> Optional[str]:
    """Single tool-less OpenAI agent call — for agents that reason over supplied
    data rather than fetching it. Returns the text output, or ``None``.
    """
    if not _has_openai_key():
        return None
    try:
        return asyncio.run(_run_agent_async(instructions, user_input, model, max_turns))
    except Exception as exc:
        logger.warning("run_llm_sync failed: %s", exc)
        return None


# --- JSON extraction / normalization helpers -------------------------------


def extract_json(text: Optional[str]) -> Optional[dict]:
    """Best-effort parse of a JSON object out of the model's final message."""
    if not text:
        return None
    text = text.strip()
    if text.startswith("```"):
        text = text.strip("`")
        if text.lower().startswith("json"):
            text = text[4:]
    start, end = text.find("{"), text.rfind("}")
    if start == -1 or end == -1 or end <= start:
        return None
    try:
        parsed = json.loads(text[start : end + 1])
        return parsed if isinstance(parsed, dict) else None
    except (json.JSONDecodeError, ValueError):
        return None


def clamp(value: Any, low: float, high: float, default: float) -> float:
    try:
        return max(low, min(high, float(value)))
    except (TypeError, ValueError):
        return default


def normalize_choice(value: Any, allowed, default: str) -> str:
    if isinstance(value, str) and value.strip().lower() in allowed:
        return value.strip().lower()
    return default
