"""
End-to-end pipeline test:

    market_analyst_agent -> news_sentiment_agent -> decision_agent

Runs all three for one symbol (default AAPL) and prints the full trade proposal.

This is a manual verification script (run directly), NOT a pytest unit test —
it needs real credentials and network access:
  * ALPACA_API_KEY / ALPACA_SECRET_KEY  -> for the Alpaca MCP server
  * ANTHROPIC_API_KEY                    -> for Claude reasoning

Account info here is a mock paper-account snapshot so the pipeline can run
without an extra Alpaca account call. Usage:
    ./.venv/Scripts/python.exe test_decision_pipeline.py           # AAPL
    ./.venv/Scripts/python.exe test_decision_pipeline.py TSLA
"""

from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent / ".env")
except Exception:
    pass

from decision_agent import make_decision
from market_analyst_agent import analyze_market
from news_sentiment_agent import analyze_news

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")

# Mock paper-account snapshot (shape mirrors what an Alpaca account fetch returns).
MOCK_ACCOUNT_INFO = {
    "equity": 100_000.0,
    "cash": 100_000.0,
    "buying_power": 200_000.0,
    "positions": [],  # flat — no existing positions
    "paper": True,
}


def _preflight() -> None:
    for var in ("ALPACA_API_KEY", "ALPACA_SECRET_KEY", "ANTHROPIC_API_KEY"):
        if not os.getenv(var):
            print(f"  [warn] {var} is not set — live analysis will be unavailable")


def main(symbol: str) -> None:
    print("=" * 70)
    print(f"TradePilot AI — decision pipeline for {symbol}")
    print("=" * 70)
    _preflight()

    print("\n[1/3] Market Analyst ...")
    market = analyze_market(symbol)
    print(json.dumps(market, indent=2))

    print("\n[2/3] News Sentiment ...")
    news = analyze_news(symbol)
    print(json.dumps(news, indent=2))

    print("\n[3/3] Decision Agent ...")
    proposal = make_decision(market, news, MOCK_ACCOUNT_INFO)

    print("\n" + "=" * 70)
    print("TRADE PROPOSAL (proposal only — not yet risk-checked or executed)")
    print("=" * 70)
    print(json.dumps(proposal, indent=2))


if __name__ == "__main__":
    args = sys.argv[1:]
    main(args[0].upper() if args else "AAPL")
