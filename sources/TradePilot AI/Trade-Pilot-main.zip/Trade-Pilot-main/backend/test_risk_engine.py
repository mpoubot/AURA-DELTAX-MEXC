"""
Unit tests for the deterministic risk engine.

These tests are fully offline: no network, no Alpaca API, no LLM. All account
state (equity, positions, open orders, daily P&L) is supplied as mock data.
"""

import pytest

from risk_engine import (
    APPROVE,
    REJECT,
    AccountContext,
    RiskConfig,
    evaluate_trade,
)


# --- Fixtures / helpers -----------------------------------------------------


@pytest.fixture
def account():
    """A healthy mock account: $100k equity, flat, no trades yet."""
    return AccountContext(
        equity=100_000.0,
        positions={},
        open_orders=[],
        trades_today=0,
        daily_pnl=0.0,
    )


def make_proposal(**overrides):
    """A well-formed baseline proposal: 10 shares @ $100 = $1,000 notional (1%)."""
    proposal = {
        "symbol": "AAPL",
        "side": "buy",
        "quantity": 10,
        "price": 100.0,
        "stop_loss": 95.0,
        "take_profit": 110.0,
    }
    proposal.update(overrides)
    return proposal


# --- Happy path -------------------------------------------------------------


def test_valid_trade_is_approved(account):
    result = evaluate_trade(make_proposal(), account)
    assert result.decision == APPROVE
    assert result.approved is True


def test_context_and_config_accept_plain_dicts():
    result = evaluate_trade(
        make_proposal(),
        {"equity": 100_000.0},
        {"max_position_pct": 0.05},
    )
    assert result.approved is True


# --- Required fields / structural validation --------------------------------


@pytest.mark.parametrize("missing", ["symbol", "side", "quantity", "price"])
def test_missing_required_field_rejected(account, missing):
    proposal = make_proposal()
    proposal[missing] = None
    result = evaluate_trade(proposal, account)
    assert result.decision == REJECT
    assert result.rule == "missing_field"


def test_missing_stop_loss_rejected(account):
    result = evaluate_trade(make_proposal(stop_loss=None), account)
    assert result.decision == REJECT
    assert result.rule == "missing_stop_loss"


def test_missing_take_profit_rejected(account):
    result = evaluate_trade(make_proposal(take_profit=None), account)
    assert result.decision == REJECT
    assert result.rule == "missing_take_profit"


def test_stop_loss_can_be_disabled_via_config(account):
    cfg = RiskConfig(require_stop_loss=False, require_take_profit=False)
    result = evaluate_trade(make_proposal(stop_loss=None, take_profit=None), account, cfg)
    assert result.approved is True


def test_invalid_side_rejected(account):
    result = evaluate_trade(make_proposal(side="hold"), account)
    assert result.rule == "invalid_side"


@pytest.mark.parametrize("bad_qty", [0, -5])
def test_non_positive_quantity_rejected(account, bad_qty):
    result = evaluate_trade(make_proposal(quantity=bad_qty), account)
    assert result.rule == "invalid_quantity"


def test_non_positive_price_rejected(account):
    result = evaluate_trade(make_proposal(price=0), account)
    assert result.rule == "invalid_price"


# --- Account sanity ---------------------------------------------------------


def test_zero_equity_rejected():
    result = evaluate_trade(make_proposal(), AccountContext(equity=0.0))
    assert result.rule == "invalid_equity"


# --- Max position size ------------------------------------------------------


def test_position_size_within_limit_approved(account):
    # 40 * $100 = $4,000 = 4% of $100k (under 5% default)
    result = evaluate_trade(make_proposal(quantity=40), account)
    assert result.approved is True


def test_position_size_over_limit_rejected(account):
    # 60 * $100 = $6,000 = 6% of $100k (over 5% default)
    result = evaluate_trade(make_proposal(quantity=60), account)
    assert result.decision == REJECT
    assert result.rule == "max_position_size"


def test_position_size_limit_is_configurable(account):
    cfg = RiskConfig(max_position_pct=0.10)
    result = evaluate_trade(make_proposal(quantity=60), account, cfg)  # 6% now allowed
    assert result.approved is True


# --- Max concentration per symbol -------------------------------------------


def test_concentration_over_limit_rejected(account):
    # Already hold $18k of AAPL; add $3k -> $21k = 21% (over 20% default)
    account.positions = {"AAPL": 18_000.0}
    result = evaluate_trade(make_proposal(quantity=30, price=100.0), account)  # $3k, 3% single trade
    assert result.decision == REJECT
    assert result.rule == "max_concentration"


def test_concentration_within_limit_approved(account):
    account.positions = {"AAPL": 15_000.0}
    result = evaluate_trade(make_proposal(quantity=30, price=100.0), account)  # -> $18k = 18%
    assert result.approved is True


# --- Max trades per day -----------------------------------------------------


def test_trade_count_at_limit_rejected(account):
    account.trades_today = 10  # default cap
    result = evaluate_trade(make_proposal(), account)
    assert result.decision == REJECT
    assert result.rule == "max_trades_per_day"


def test_trade_count_under_limit_approved(account):
    account.trades_today = 9
    result = evaluate_trade(make_proposal(), account)
    assert result.approved is True


# --- Max daily loss ---------------------------------------------------------


def test_daily_loss_already_breached_rejected(account):
    account.daily_pnl = -3_000.0  # lost 3% of $100k -> at limit
    result = evaluate_trade(make_proposal(), account)
    assert result.decision == REJECT
    assert result.rule == "daily_loss_reached"


def test_daily_loss_projected_breach_rejected(account):
    # Already down $2,900 of a $3,000 budget ($100 left).
    account.daily_pnl = -2_900.0
    # 40 shares @ $100 = $4,000 notional (4%, under the 5% position cap) but a
    # $10 stop distance -> $400 worst-case loss > $100 remaining budget.
    result = evaluate_trade(
        make_proposal(quantity=40, price=100.0, stop_loss=90.0), account
    )
    assert result.decision == REJECT
    assert result.rule == "daily_loss_projected"


def test_daily_loss_within_budget_approved(account):
    account.daily_pnl = -500.0  # small loss, plenty of budget
    result = evaluate_trade(make_proposal(), account)
    assert result.approved is True


# --- Duplicate-order protection ---------------------------------------------


def test_duplicate_open_order_rejected(account):
    account.open_orders = [
        {"symbol": "AAPL", "side": "buy", "quantity": 10, "price": 100.0}
    ]
    result = evaluate_trade(make_proposal(), account)
    assert result.decision == REJECT
    assert result.rule == "duplicate_order"


def test_non_duplicate_order_approved(account):
    # Same symbol but different quantity -> not a duplicate.
    account.open_orders = [
        {"symbol": "AAPL", "side": "buy", "quantity": 25, "price": 100.0}
    ]
    result = evaluate_trade(make_proposal(quantity=10), account)
    assert result.approved is True


def test_duplicate_detection_handles_qty_alias(account):
    # Alpaca-style order dict using "qty" and "limit_price" aliases.
    account.open_orders = [
        {"symbol": "AAPL", "side": "buy", "qty": 10, "limit_price": 100.0}
    ]
    result = evaluate_trade(make_proposal(), account)
    assert result.rule == "duplicate_order"


# --- Config loading ---------------------------------------------------------


def test_config_from_env_overrides_defaults():
    env = {
        "RISK_MAX_POSITION_PCT": "0.08",
        "RISK_MAX_DAILY_LOSS_PCT": "0.05",
        "RISK_MAX_TRADES_PER_DAY": "20",
        "RISK_MAX_CONCENTRATION_PCT": "0.30",
        "RISK_REQUIRE_STOP_LOSS": "false",
    }
    cfg = RiskConfig.from_env(env)
    assert cfg.max_position_pct == 0.08
    assert cfg.max_daily_loss_pct == 0.05
    assert cfg.max_trades_per_day == 20
    assert cfg.max_concentration_pct == 0.30
    assert cfg.require_stop_loss is False


def test_config_defaults_are_demo_safe():
    cfg = RiskConfig()
    assert cfg.max_position_pct == 0.05
    assert cfg.max_daily_loss_pct == 0.03
    assert cfg.max_trades_per_day == 10
