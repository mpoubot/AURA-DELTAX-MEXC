"""
End-to-end smoke test for the TradePilot AI agents.

Runs both agents against a real symbol (default AAPL) through the live Alpaca
paper-trading MCP connection and prints the structured output.

This is a manual verification script (run it directly), NOT a pytest unit test —
it needs real credentials and network access:
  * ALPACA_API_KEY / ALPACA_SECRET_KEY  -> for the Alpaca MCP server
  * OPENAI_API_KEY                    -> for Openai reasoning

It loads backend/.env automatically, so once that file is populated you can run:
    ./.venv/Scripts/python.exe test_agents.py           # AAPL
    ./.venv/Scripts/python.exe test_agents.py TSLA MSFT  # custom symbols
"""

from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path

# Load backend/.env so ALPACA_* and OPENAI_API_KEY are available to both this
# process and the MCP server subprocess (which inherits our environment).
try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent / ".env")
except Exception:
    pass

from market_analyst_agent import analyze_market
from news_sentiment_agent import analyze_news

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")


def _preflight() -> bool:
    """Warn about missing credentials but still run (agents degrade gracefully)."""
    ok = True
    for var in ("ALPACA_API_KEY", "ALPACA_SECRET_KEY", "OPENAI_API_KEY"):
        if not os.getenv(var):
            print(f"  [warn] {var} is not set — live data/reasoning will be unavailable")
            ok = False
    return ok


def main(symbols: list[str]) -> None:
    print("=" * 70)
    print("TradePilot AI — agent smoke test")
    print("=" * 70)
    creds_ok = _preflight()
    if not creds_ok:
        print(
            "\nRunning anyway; without credentials the agents return neutral "
            "defaults instead of live analysis.\n"
        )

    for symbol in symbols:
        print(f"\n---------- {symbol} ----------")

        print(">> Market Analyst (analyze_market)")
        market = analyze_market(symbol)
        print(json.dumps(market, indent=2))

        print("\n>> News Sentiment (analyze_news)")
        news = analyze_news(symbol)
        print(json.dumps(news, indent=2))

    print("\n" + "=" * 70)
    print("Done.")


if __name__ == "__main__":
    args = sys.argv[1:]
    main([s.upper() for s in args] if args else ["AAPL"])
