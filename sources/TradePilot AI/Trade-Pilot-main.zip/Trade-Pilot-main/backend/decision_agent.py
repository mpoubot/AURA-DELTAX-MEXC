"""
Decision agent.

Combines the Market Analyst and News Sentiment outputs with current account /
position info and uses an OpenAI agent to produce a structured trade *proposal*:

    { symbol, action, confidence, suggested_quantity,
      stop_loss, take_profit, reasoning }

This agent only PROPOSES. It does NOT call the risk engine and it does NOT place
any order — final approval is a separate step (the deterministic risk engine).
The ``reasoning`` field is written for the dashboard: it must explain WHY the
decision was made, referencing the market trend and the news sentiment.

Never raises: on any failure it returns a safe HOLD proposal.
"""

from __future__ import annotations

import json
import os
import logging
from typing import Any, Optional

from mcp_agent import (
    DEFAULT_MODEL,
    clamp,
    extract_json,
    normalize_choice,
    run_llm_sync,
)

logger = logging.getLogger("tradepilot.decision")

_ACTION_CHOICES = ("buy", "sell", "hold")

_SYSTEM_PROMPT = (
    "You are the trade decision agent for a paper-trading demo. You are given a "
    "market technical analysis, a news sentiment analysis, and the current "
    "account/position state. Weigh all three and propose a single trade.\n\n"
    "IMPORTANT: You only PROPOSE. You do not approve trades and you do not place "
    "orders — a separate deterministic risk engine has the final say. Keep "
    "proposals conservative and sized sensibly relative to account equity.\n\n"
    "Respond with ONLY a single JSON object (no prose, no markdown fences) with "
    "exactly these keys:\n"
    '  "symbol": the ticker (string)\n'
    '  "action": one of "BUY", "SELL", "HOLD"\n'
    '  "confidence": a number from 0.0 to 1.0\n'
    '  "suggested_quantity": integer number of shares (0 for HOLD)\n'
    '  "stop_loss": a price (number) or null (null for HOLD)\n'
    '  "take_profit": a price (number) or null (null for HOLD)\n'
    '  "reasoning": a plain-text explanation of WHY this decision was made\n\n'
    "The reasoning MUST explicitly reference the market trend and the news "
    "sentiment (and the account context where relevant), because it is shown "
    "directly on a dashboard for explainability. For BUY/SELL, stop_loss and "
    "take_profit must be concrete price levels consistent with the action "
    "(for a BUY: stop_loss below and take_profit above the current price; for a "
    "SELL/short: the reverse). If conviction is low or data is missing, propose "
    "HOLD with quantity 0 and null stop_loss/take_profit."
)


def _safe_hold(symbol: str, reason: str) -> dict:
    return {
        "symbol": symbol,
        "action": "HOLD",
        "confidence": 0.0,
        "suggested_quantity": 0,
        "stop_loss": None,
        "take_profit": None,
        "reasoning": reason,
    }


def _to_optional_price(value: Any) -> Optional[float]:
    if value is None:
        return None
    try:
        price = float(value)
        return price if price > 0 else None
    except (TypeError, ValueError):
        return None


def _to_int_qty(value: Any) -> int:
    try:
        return max(0, int(round(float(value))))
    except (TypeError, ValueError):
        return 0


def make_decision(
    market_analysis: dict,
    news_analysis: dict,
    account_info: dict,
    model: str = DEFAULT_MODEL,
) -> dict:
    """Produce a structured trade proposal from the analyst + account inputs.

    Returns { symbol, action, confidence, suggested_quantity,
              stop_loss, take_profit, reasoning }.
    """
    market_analysis = market_analysis or {}
    news_analysis = news_analysis or {}
    account_info = account_info or {}

    symbol = str(
        market_analysis.get("symbol") or news_analysis.get("symbol") or ""
    ).strip().upper()

    if not symbol:
        return _safe_hold("", "No symbol provided; holding by default.")

    # Position-size ceiling — mirrors the risk engine's max_position_pct so the
    # agent proposes something that can actually clear risk approval. This is
    # still proposal-side sizing; the risk engine retains final say.
    try:
        max_pos_pct = float(os.getenv("RISK_MAX_POSITION_PCT", "0.05"))
    except (TypeError, ValueError):
        max_pos_pct = 0.05
    equity = float(account_info.get("equity", 0.0) or 0.0)
    max_position_value = equity * max_pos_pct

    try:
        user = (
            "Propose a trade for the following situation.\n\n"
            f"MARKET ANALYSIS:\n{json.dumps(market_analysis, indent=2)}\n\n"
            f"NEWS SENTIMENT:\n{json.dumps(news_analysis, indent=2)}\n\n"
            f"ACCOUNT / POSITIONS:\n{json.dumps(account_info, indent=2)}\n\n"
            f"POSITION LIMIT: do NOT propose a position whose notional "
            f"(quantity x price) exceeds ${max_position_value:,.0f} "
            f"({max_pos_pct:.0%} of equity). Size the quantity accordingly.\n\n"
            "Return the JSON proposal now."
        )
        text = run_llm_sync(_SYSTEM_PROMPT, user, model=model)
        data = extract_json(text)
        if not data:
            logger.info("decision agent: no structured result for %s", symbol)
            return _safe_hold(
                symbol,
                "Unable to obtain a model decision (no data or reasoning "
                "unavailable); holding as the safe default.",
            )

        action = normalize_choice(data.get("action"), _ACTION_CHOICES, "hold").upper()
        proposal = {
            "symbol": str(data.get("symbol") or symbol).upper(),
            "action": action,
            "confidence": clamp(data.get("confidence"), 0.0, 1.0, 0.0),
            "suggested_quantity": _to_int_qty(data.get("suggested_quantity")),
            "stop_loss": _to_optional_price(data.get("stop_loss")),
            "take_profit": _to_optional_price(data.get("take_profit")),
            "reasoning": str(data.get("reasoning") or "No reasoning provided."),
        }

        # Deterministic safety clamp: cap the proposed quantity so the notional
        # stays within the position ceiling, using the midpoint of SL/TP as a
        # price proxy. Keeps the proposal within reach of risk approval.
        if proposal["action"] in ("BUY", "SELL") and max_position_value > 0:
            sl, tp = proposal["stop_loss"], proposal["take_profit"]
            if isinstance(sl, (int, float)) and isinstance(tp, (int, float)):
                price = (sl + tp) / 2.0
                if price > 0:
                    max_qty = int(max_position_value // price)
                    if proposal["suggested_quantity"] > max_qty:
                        proposal["suggested_quantity"] = max_qty
                        proposal["reasoning"] += (
                            f" [Quantity capped to {max_qty} to respect the "
                            f"{max_pos_pct:.0%} position limit.]"
                        )

        # Normalize a HOLD to a no-op shape regardless of what the model returned.
        if proposal["action"] == "HOLD":
            proposal["suggested_quantity"] = 0
            proposal["stop_loss"] = None
            proposal["take_profit"] = None

        return proposal
    except Exception as exc:  # defensive: never crash the caller
        logger.warning("make_decision failed for %s: %s", symbol, exc)
        return _safe_hold(symbol, f"Decision agent error; holding as the safe default.")
