"""
Market Analyst agent.

Fetches recent price / volume / volatility data for a symbol via the Alpaca MCP
tools, then uses Claude to summarize the technical picture. Returns a structured
dict: { symbol, trend, volatility, summary }.

Never raises: on any failure (no data, no connection, no API key) it returns
neutral defaults.
"""

from __future__ import annotations

import logging

from mcp_agent import (
    DEFAULT_MODEL,
    extract_json,
    normalize_choice,
    run_mcp_agent_sync,
)

logger = logging.getLogger("tradepilot.market_analyst")

# Explicit allowlist of read-only Alpaca market-data tools exposed to this
# agent. Order-placement / position-closing tools are deliberately excluded.
_MARKET_TOOLS = (
    "get_stock_bars",
    "get_stock_latest_bar",
    "get_stock_quotes",
    "get_stock_latest_quote",
    "get_stock_trades",
    "get_stock_latest_trade",
    "get_stock_snapshot",
)

_TREND_CHOICES = ("bullish", "bearish", "neutral")
_VOL_CHOICES = ("low", "moderate", "high", "unknown")

_SYSTEM_PROMPT = (
    "You are a market technical analyst. Use the available Alpaca market-data "
    "tools to fetch recent price, volume, and volatility information for the "
    "requested stock symbol. Base your analysis ONLY on data you actually "
    "retrieve from the tools.\n\n"
    "Be economical with tool calls: make the FEWEST calls needed (ideally one "
    "bars call, plus at most the latest quote). Do not re-fetch data you already "
    "have. Once you have enough to judge trend and volatility, answer.\n\n"
    "When finished, respond with ONLY a single JSON object (no prose, no "
    "markdown code fences) with exactly these keys:\n"
    '  "symbol": the ticker (string)\n'
    '  "trend": one of "bullish", "bearish", "neutral"\n'
    '  "volatility": one of "low", "moderate", "high", "unknown"\n'
    '  "summary": 2-4 sentence technical summary covering trend, momentum, and '
    "notable price levels (string)\n\n"
    "If you cannot retrieve any usable data, return trend \"neutral\", "
    "volatility \"unknown\", and say so in the summary."
)


def _neutral(symbol: str, summary: str = "No market data available.") -> dict:
    return {
        "symbol": symbol,
        "trend": "neutral",
        "volatility": "unknown",
        "summary": summary,
    }


def analyze_market(symbol: str, model: str = DEFAULT_MODEL) -> dict:
    """Analyze the technical picture for ``symbol``.

    Returns { symbol, trend, volatility, summary }.
    """
    symbol = (symbol or "").strip().upper()
    if not symbol:
        return _neutral("", "No symbol provided.")

    try:
        user = (
            f"Analyze the recent technical picture for {symbol}. In a SINGLE "
            f"bars call fetch about the last 30 daily bars (limit=30), and only "
            f"if useful the latest quote, then assess trend, momentum, and "
            f"volatility. Keep tool usage minimal."
        )
        text = run_mcp_agent_sync(
            _SYSTEM_PROMPT, user, allowed_tools=_MARKET_TOOLS, model=model
        )
        data = extract_json(text)
        if not data:
            logger.info("market analyst: no structured result for %s", symbol)
            return _neutral(symbol)

        return {
            "symbol": str(data.get("symbol") or symbol).upper(),
            "trend": normalize_choice(data.get("trend"), _TREND_CHOICES, "neutral"),
            "volatility": normalize_choice(
                data.get("volatility"), _VOL_CHOICES, "unknown"
            ),
            "summary": str(data.get("summary") or "No summary available."),
        }
    except Exception as exc:  # defensive: never crash the caller
        logger.warning("analyze_market failed for %s: %s", symbol, exc)
        return _neutral(symbol)
