"""
Orchestrator — wires the full TradePilot AI pipeline for a watchlist.

Per symbol:
    market_analyst_agent.analyze_market
        -> news_sentiment_agent.analyze_news
        -> decision_agent.make_decision
        -> risk_engine.evaluate_trade
        -> (if APPROVED) execute via the Alpaca CLI as a bracket order (paper)
        -> log every step into the decision_log table.

Notes:
  * Execution uses the **Alpaca CLI subprocess** (`alpaca order submit`), NOT the
    MCP server. Paper vs live is determined by the logged-in CLI profile.
  * The risk engine needs an entry price, but the decision agent proposal does
    not carry one; we use the midpoint of stop_loss/take_profit as a
    deterministic reference price for sizing. (Documented assumption.)
  * With human_approval=True, an approved proposal is parked in
    pending_approvals instead of executing; the API layer resolves it later via
    approve_pending() / reject_pending().
"""

from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from database import DecisionLog, PendingApproval, SessionLocal, init_db
from decision_agent import make_decision
from market_analyst_agent import analyze_market
from news_sentiment_agent import analyze_news
import options
from risk_engine import APPROVE, AccountContext, RiskConfig, evaluate_trade

logger = logging.getLogger("tradepilot.orchestrator")

# Default demo paper account if the caller doesn't supply one.
DEFAULT_ACCOUNT_INFO = {
    "equity": 100_000.0,
    "cash": 100_000.0,
    "buying_power": 200_000.0,
    "positions": [],
    "daily_pnl": 0.0,
    "trades_today": 0,
    "paper": True,
}


# --- Alpaca CLI execution ---------------------------------------------------


def _alpaca_cli_path() -> str:
    """Locate the alpaca CLI: env override -> PATH -> repo bin/ -> 'alpaca'."""
    env_path = os.getenv("ALPACA_CLI")
    if env_path:
        return env_path
    found = shutil.which("alpaca")
    if found:
        return found
    bin_exe = Path(__file__).resolve().parent.parent / "bin" / "alpaca.exe"
    if bin_exe.exists():
        return str(bin_exe)
    return "alpaca"


def build_order_command(
    symbol: str,
    side: str,
    quantity: int,
    stop_loss: float,
    take_profit: float,
    limit_price: Optional[float] = None,
) -> list[str]:
    """Construct the `alpaca order submit` bracket-order command (paper mode).

    Uses a marketable LIMIT entry instead of a MARKET entry when a live price
    is available: Alpaca rejects market orders outside regular trading hours,
    whereas a limit order is accepted and queued for the next session — same
    fix already applied to options in build_option_order_command.
    """
    cmd = [
        _alpaca_cli_path(),
        "order", "submit",
        "--symbol", symbol,
        "--qty", str(quantity),
        "--side", side,
        "--order-class", "bracket",
        "--time-in-force", "gtc",
        "--take-profit", str(take_profit),
        "--stop-loss", str(stop_loss),
    ]
    if limit_price and limit_price > 0:
        # Small buffer through the live price so it fills immediately during
        # market hours, and queues correctly (instead of erroring) after hours.
        buffered = limit_price * 1.002 if side == "buy" else limit_price * 0.998
        cmd += ["--type", "limit", "--limit-price", f"{buffered:.2f}"]
    else:
        cmd += ["--type", "market"]
    profile = os.getenv("ALPACA_PROFILE")
    if profile:
        cmd += ["--profile", profile]
    return cmd


def execute_trade(
    symbol: str,
    side: str,
    quantity: int,
    stop_loss: float,
    take_profit: float,
    limit_price: Optional[float] = None,
) -> tuple[str, str, Optional[str]]:
    """Submit a bracket order via the Alpaca CLI.

    Returns (status, detail, order_id):
      status   -> "EXECUTED" or "EXECUTION_ERROR"
      detail   -> raw CLI output (order JSON on success, error text otherwise)
      order_id -> the order id on success, else None
    """
    cmd = build_order_command(symbol, side, quantity, stop_loss, take_profit, limit_price)
    logger.info("Executing: %s", " ".join(cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except Exception as exc:
        return "EXECUTION_ERROR", f"CLI invocation failed: {exc}", None

    output = (proc.stdout or "").strip() or (proc.stderr or "").strip()

    # Parse the JSON the CLI emits; detect the auth/error envelope.
    order_id = None
    parsed = None
    try:
        parsed = json.loads(output)
    except (json.JSONDecodeError, ValueError):
        parsed = None

    if isinstance(parsed, dict):
        if parsed.get("error"):
            return "EXECUTION_ERROR", output, None
        order_id = parsed.get("id")

    if proc.returncode != 0 and not order_id:
        return "EXECUTION_ERROR", output or f"exit code {proc.returncode}", None

    return "EXECUTED", output, order_id


def build_option_order_command(
    occ_symbol: str, contracts: int, limit_price: float
) -> list[str]:
    """Construct a single-leg long-option `alpaca order submit` command (paper).

    Uses a LIMIT order priced at the ask: option market orders are rejected
    outside market hours, whereas limit orders are accepted and queued.
    """
    cmd = [
        _alpaca_cli_path(),
        "order", "submit",
        "--symbol", occ_symbol,
        "--qty", str(contracts),
        "--side", "buy",
        "--type", "limit",
        "--limit-price", f"{limit_price:.2f}",
        "--time-in-force", "day",
    ]
    profile = os.getenv("ALPACA_PROFILE")
    if profile:
        cmd += ["--profile", profile]
    return cmd


def execute_option_trade(
    occ_symbol: str, contracts: int, limit_price: float
) -> tuple[str, str, Optional[str]]:
    """Submit a single-leg long option (buy_to_open) via the Alpaca CLI."""
    cmd = build_option_order_command(occ_symbol, contracts, limit_price)
    logger.info("Executing option order: %s", " ".join(cmd))
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=60)
    except Exception as exc:
        return "EXECUTION_ERROR", f"CLI invocation failed: {exc}", None

    output = (proc.stdout or "").strip() or (proc.stderr or "").strip()
    order_id = None
    try:
        parsed = json.loads(output)
    except (json.JSONDecodeError, ValueError):
        parsed = None
    if isinstance(parsed, dict):
        if parsed.get("error"):
            return "EXECUTION_ERROR", output, None
        order_id = parsed.get("id")
    if proc.returncode != 0 and not order_id:
        return "EXECUTION_ERROR", output or f"exit code {proc.returncode}", None
    return "EXECUTED", output, order_id


def _options_risk_config(config: RiskConfig) -> RiskConfig:
    """Risk config for long options — capped-risk, so no stop/target required."""
    return RiskConfig(
        max_position_pct=config.max_position_pct,
        max_daily_loss_pct=config.max_daily_loss_pct,
        max_trades_per_day=config.max_trades_per_day,
        max_concentration_pct=1.0,
        require_stop_loss=False,
        require_take_profit=False,
    )


# --- Helpers ----------------------------------------------------------------


def _reference_price(proposal: dict) -> Optional[float]:
    """Deterministic entry-price proxy: midpoint of stop_loss and take_profit."""
    sl, tp = proposal.get("stop_loss"), proposal.get("take_profit")
    if isinstance(sl, (int, float)) and isinstance(tp, (int, float)) and sl > 0 and tp > 0:
        return round((sl + tp) / 2.0, 4)
    return None


def _latest_price(symbol: str) -> Optional[float]:
    """Read-only latest trade price from Alpaca market data (for valid brackets)."""
    key = os.getenv("ALPACA_API_KEY")
    secret = os.getenv("ALPACA_SECRET_KEY")
    if not key or not secret:
        return None
    try:
        import httpx

        url = f"https://data.alpaca.markets/v2/stocks/{symbol}/trades/latest"
        headers = {"APCA-API-KEY-ID": key, "APCA-API-SECRET-KEY": secret}
        with httpx.Client(timeout=15) as client:
            resp = client.get(url, headers=headers, params={"feed": "iex"})
            resp.raise_for_status()
            return float(resp.json()["trade"]["p"])
    except Exception as exc:
        logger.info("latest price unavailable for %s: %s", symbol, exc)
        return None


def _live_bracket(
    symbol: str, side: str, stop_loss, take_profit
) -> tuple[Optional[float], Any, Any]:
    """Anchor stop-loss / take-profit to the live price on the correct side.

    Preserves the proposal's intended risk/reward *distances* but re-centers them
    on the real current price, so Alpaca's bracket validation (legs must straddle
    the base price) can never reject a well-formed proposal.
    Returns (live_price | None, stop_loss, take_profit).
    """
    price = _latest_price(symbol)
    if not price or price <= 0:
        return None, stop_loss, take_profit

    def _pct(level, default: float) -> float:
        if isinstance(level, (int, float)) and level > 0:
            return min(max(abs(price - level) / price, 0.005), 0.5)
        return default

    sl_pct = _pct(stop_loss, 0.03)
    tp_pct = _pct(take_profit, 0.06)
    if side == "buy":
        return round(price, 2), round(price * (1 - sl_pct), 2), round(price * (1 + tp_pct), 2)
    return round(price, 2), round(price * (1 + sl_pct), 2), round(price * (1 - tp_pct), 2)
def _fetch_open_orders() -> list[dict]:
    """Fetch currently open orders from Alpaca via the CLI (read-only)."""
    cmd = [_alpaca_cli_path(), "order", "list", "--status", "open"]
    profile = os.getenv("ALPACA_PROFILE")
    if profile:
        cmd += ["--profile", profile]
    try:
        proc = subprocess.run(cmd, capture_output=True, text=True, timeout=30)
        output = (proc.stdout or "").strip()
        orders = json.loads(output)
        if isinstance(orders, list):
            return orders
    except Exception as exc:
        logger.info("could not fetch open orders: %s", exc)
    return []

def _account_context(account_info: dict, trades_today: int, open_orders: Optional[list] = None) -> AccountContext:
    positions = {}
    for pos in account_info.get("positions", []) or []:
        sym = str(pos.get("symbol", "")).upper()
        if sym:
            positions[sym] = float(pos.get("market_value", 0.0) or 0.0)
    return AccountContext(
        equity=float(account_info.get("equity", 0.0) or 0.0),
        positions=positions,
        open_orders=open_orders or [],
        trades_today=trades_today,
        daily_pnl=float(account_info.get("daily_pnl", 0.0) or 0.0),
    )


def _new_log(session, **fields) -> DecisionLog:
    row = DecisionLog(**fields)
    session.add(row)
    session.commit()
    return row


def _process_option(session, symbol, proposal, base_fields, account_info,
                    config, human_approval, trades_today, results, open_orders) -> int:
    """Options branch: build a long call/put from the directional view, size it,
    run the risk engine, then execute (or park for approval) and log."""
    equity = float(account_info.get("equity", 0.0) or 0.0)
    price = _latest_price(symbol)
    if not price:
        row = _new_log(
            session, **base_fields, instrument="option", risk_decision="N/A",
            risk_reason="No underlying price for options selection.",
            execution_status="SKIPPED_NO_PRICE",
        )
        results.append(row.as_dict())
        return trades_today

    opt = options.build_option_proposal(symbol, proposal, price, equity, config.max_position_pct)
    if opt is None:
        row = _new_log(
            session, **base_fields, instrument="option", risk_decision="N/A",
            risk_reason="No option contract available for this view.",
            execution_status="SKIPPED_NO_CONTRACT",
        )
        results.append(row.as_dict())
        return trades_today

    opt_fields = dict(base_fields)
    opt_fields.update(
        instrument="option",
        suggested_quantity=opt["contracts"],
        reference_price=opt["cost_per_contract"],
        reasoning=opt["reasoning"],
        option_symbol=opt["occ_symbol"],
        option_type=opt["option_type"],
        strike=opt["strike"],
        expiration=opt["expiration"],
        premium=opt["premium"],
        stop_loss=None,
        take_profit=None,
    )
    contracts = opt["contracts"]
    if contracts < 1:
        row = _new_log(
            session, **opt_fields, risk_decision="N/A",
            risk_reason=(f"Premium ${opt['cost_per_contract']:,.0f}/contract exceeds "
                         f"the position budget."),
            execution_status="SKIPPED_TOO_EXPENSIVE",
        )
        results.append(row.as_dict())
        return trades_today

    # Risk engine (options config: long options have capped, premium-defined risk).
    risk_proposal = {
        "symbol": opt["occ_symbol"], "side": "buy", "quantity": contracts,
        "price": opt["cost_per_contract"], "stop_loss": None, "take_profit": None,
    }
    ctx = _account_context(account_info, trades_today, open_orders)
    decision = evaluate_trade(risk_proposal, ctx, _options_risk_config(config))

    if decision.decision != APPROVE:
        row = _new_log(
            session, **opt_fields, risk_decision=decision.decision,
            risk_reason=decision.reason, risk_rule=decision.rule,
            execution_status="REJECTED_BY_RISK",
        )
        results.append(row.as_dict())
        logger.warning("%s option: risk REJECT — %s", symbol, decision.reason)
        return trades_today

    if human_approval:
        row = _new_log(
            session, **opt_fields, risk_decision=decision.decision,
            risk_reason=decision.reason, risk_rule=decision.rule,
            execution_status="PENDING_APPROVAL",
        )
        pending = PendingApproval(
            symbol=symbol, action=opt_fields["action"], confidence=opt_fields["confidence"],
            suggested_quantity=contracts, stop_loss=None, take_profit=None,
            reference_price=opt["cost_per_contract"], reasoning=opt["reasoning"],
            status="PENDING", decision_log_id=row.id, instrument="option",
            option_symbol=opt["occ_symbol"], option_type=opt["option_type"],
            strike=opt["strike"], expiration=opt["expiration"], premium=opt["premium"],
        )
        session.add(pending)
        session.commit()
        results.append(row.as_dict())
        logger.info("%s option: APPROVED by risk — parked as pending approval.", symbol)
        return trades_today + 1

    limit_price = round(opt["premium"] * 1.02, 2)  # marketable limit at the ask
    status, detail, order_id = execute_option_trade(opt["occ_symbol"], contracts, limit_price)
    row = _new_log(
        session, **opt_fields, risk_decision=decision.decision,
        risk_reason=decision.reason, risk_rule=decision.rule,
        execution_status=status, execution_detail=detail, order_id=order_id,
    )
    results.append(row.as_dict())
    if status == "EXECUTED":
        trades_today += 1
        logger.info("%s option: EXECUTED %s x%s (order_id=%s)",
                    symbol, opt["occ_symbol"], contracts, order_id)
    else:
        logger.error("%s option: execution error — %s", symbol, detail)
    return trades_today


# --- Main pipeline ----------------------------------------------------------


def run_pipeline(
    watchlist: list[str],
    human_approval: bool = False,
    account_info: Optional[dict] = None,
    mode: str = "stock",
) -> list[dict]:
    """Run the full pipeline for each symbol in ``watchlist``.

    mode: "stock" (equity bracket orders) or "options" (single-leg long
    call/put derived from the same directional view).

    Returns a list of decision_log row dicts (the audit records created).
    """
    init_db()
    account_info = account_info or DEFAULT_ACCOUNT_INFO
    config = RiskConfig.from_env()
    mode = "options" if str(mode).lower() == "options" else "stock"
    results: list[dict] = []

    # Track trades placed/approved during this run so the per-day cap is honored.
    trades_today = int(account_info.get("trades_today", 0) or 0)
    trades_today = int(account_info.get("trades_today", 0) or 0)
    open_orders = _fetch_open_orders()
    with SessionLocal() as session:
        for raw_symbol in watchlist:
            symbol = str(raw_symbol).strip().upper()
            if not symbol:
                continue
            logger.info("=== Processing %s ===", symbol)

            # 1. Analyst agents -> decision agent
            market = analyze_market(symbol)
            news = analyze_news(symbol)
            proposal = make_decision(market, news, account_info)

            action = str(proposal.get("action", "HOLD")).upper()
            base_fields = dict(
                symbol=symbol,
                action=action,
                confidence=float(proposal.get("confidence", 0.0) or 0.0),
                suggested_quantity=int(proposal.get("suggested_quantity", 0) or 0),
                stop_loss=proposal.get("stop_loss"),
                take_profit=proposal.get("take_profit"),
                reasoning=proposal.get("reasoning"),
                market_trend=market.get("trend"),
                news_sentiment=news.get("sentiment_score"),
            )

            # 2. HOLD -> nothing to trade
            if action == "HOLD":
                row = _new_log(
                    session,
                    **base_fields,
                    risk_decision="N/A",
                    risk_reason="No trade proposed (HOLD).",
                    execution_status="SKIPPED_HOLD",
                )
                results.append(row.as_dict())
                logger.info("%s: HOLD — skipped.", symbol)
                continue

            # 2b. OPTIONS mode — express the directional view as a long option.
            if mode == "options":
                trades_today = _process_option(
                    session, symbol, proposal, base_fields, account_info,
                    config, human_approval, trades_today, results, open_orders,
                )
                continue

            side = "buy" if action == "BUY" else "sell"
            price = _reference_price(proposal)
            base_fields["reference_price"] = price

            if price is None:
                row = _new_log(
                    session,
                    **base_fields,
                    risk_decision="N/A",
                    risk_reason="No reference price (missing stop_loss/take_profit).",
                    execution_status="SKIPPED_NO_PRICE",
                )
                results.append(row.as_dict())
                logger.info("%s: no reference price — skipped.", symbol)
                continue

            # 3. Risk engine
            risk_proposal = {
                "symbol": symbol,
                "side": side,
                "quantity": proposal.get("suggested_quantity"),
                "price": price,
                "stop_loss": proposal.get("stop_loss"),
                "take_profit": proposal.get("take_profit"),
            }
            ctx = _account_context(account_info, trades_today, open_orders)
            decision = evaluate_trade(risk_proposal, ctx, config)

            if decision.decision != APPROVE:
                row = _new_log(
                    session,
                    **base_fields,
                    risk_decision=decision.decision,
                    risk_reason=decision.reason,
                    risk_rule=decision.rule,
                    execution_status="REJECTED_BY_RISK",
                )
                results.append(row.as_dict())
                logger.warning("%s: risk REJECT — %s", symbol, decision.reason)
                continue

            # 4a. human_approval -> park as pending, do not execute
            if human_approval:
                row = _new_log(
                    session,
                    **base_fields,
                    risk_decision=decision.decision,
                    risk_reason=decision.reason,
                    risk_rule=decision.rule,
                    execution_status="PENDING_APPROVAL",
                )
                pending = PendingApproval(
                    symbol=symbol,
                    action=action,
                    confidence=base_fields["confidence"],
                    suggested_quantity=base_fields["suggested_quantity"],
                    stop_loss=base_fields["stop_loss"],
                    take_profit=base_fields["take_profit"],
                    reference_price=price,
                    reasoning=base_fields["reasoning"],
                    status="PENDING",
                    decision_log_id=row.id,
                )
                session.add(pending)
                session.commit()
                results.append(row.as_dict())
                trades_today += 1  # reserve the slot
                logger.info("%s: APPROVED by risk — parked as pending approval.", symbol)
                continue

            # 4b. Auto-execute via Alpaca CLI (bracket order, paper).
            # Anchor SL/TP to the live price so bracket legs are always valid.
            live_price, exec_sl, exec_tp = _live_bracket(
                symbol, side, base_fields["stop_loss"], base_fields["take_profit"]
            )
            if live_price:
                base_fields["reference_price"] = live_price
                base_fields["stop_loss"] = exec_sl
                base_fields["take_profit"] = exec_tp
            status, detail, order_id = execute_trade(
                symbol, side, base_fields["suggested_quantity"],
                base_fields["stop_loss"], base_fields["take_profit"],
                limit_price=live_price,
            )
            row = _new_log(
                session,
                **base_fields,
                risk_decision=decision.decision,
                risk_reason=decision.reason,
                risk_rule=decision.rule,
                execution_status=status,
                execution_detail=detail,
                order_id=order_id,
            )
            results.append(row.as_dict())
            if status == "EXECUTED":
                trades_today += 1
                logger.info("%s: EXECUTED (order_id=%s)", symbol, order_id)
            else:
                logger.error("%s: execution error — %s", symbol, detail)

    return results


# --- Pending-approval API (used by the API layer) --------------------------


def list_pending_approvals() -> list[dict]:
    with SessionLocal() as session:
        rows = (
            session.query(PendingApproval)
            .filter(PendingApproval.status == "PENDING")
            .order_by(PendingApproval.timestamp.desc())
            .all()
        )
        return [r.as_dict() for r in rows]


def approve_pending(pending_id: int, note: str = "") -> dict:
    """Approve a parked proposal and execute it now."""
    with SessionLocal() as session:
        pending = session.get(PendingApproval, pending_id)
        if pending is None:
            return {"error": f"pending approval {pending_id} not found"}
        if pending.status != "PENDING":
            return {"error": f"already {pending.status.lower()}", **pending.as_dict()}

        live_price = None
        if pending.instrument == "option" and pending.option_symbol:
            # Options: execute the single-leg long option directly.
            limit_price = round((pending.premium or 0.0) * 1.02, 2) or 0.01
            status, detail, order_id = execute_option_trade(
                pending.option_symbol, pending.suggested_quantity, limit_price
            )
        else:
            side = "buy" if pending.action == "BUY" else "sell"
            # Anchor SL/TP to the live price so the bracket is valid at execution.
            live_price, exec_sl, exec_tp = _live_bracket(
                pending.symbol, side, pending.stop_loss, pending.take_profit
            )
            if live_price is None:
                exec_sl, exec_tp = pending.stop_loss, pending.take_profit
            status, detail, order_id = execute_trade(
                pending.symbol, side, pending.suggested_quantity, exec_sl, exec_tp,
                limit_price=live_price,
            )
        pending.status = "APPROVED"
        pending.resolved_at = datetime.now(timezone.utc)
        pending.resolution_note = note or "Approved by human."

        # Update the linked decision_log row with the execution outcome.
        if pending.decision_log_id:
            log_row = session.get(DecisionLog, pending.decision_log_id)
            if log_row:
                if live_price:
                    log_row.reference_price = live_price
                    log_row.stop_loss = exec_sl
                    log_row.take_profit = exec_tp
                log_row.execution_status = status
                log_row.execution_detail = detail
                log_row.order_id = order_id
        session.commit()
        return {"pending": pending.as_dict(), "execution_status": status, "order_id": order_id}


def reject_pending(pending_id: int, note: str = "") -> dict:
    """Reject a parked proposal without executing."""
    with SessionLocal() as session:
        pending = session.get(PendingApproval, pending_id)
        if pending is None:
            return {"error": f"pending approval {pending_id} not found"}
        if pending.status != "PENDING":
            return {"error": f"already {pending.status.lower()}", **pending.as_dict()}

        pending.status = "REJECTED"
        pending.resolved_at = datetime.now(timezone.utc)
        pending.resolution_note = note or "Rejected by human."
        if pending.decision_log_id:
            log_row = session.get(DecisionLog, pending.decision_log_id)
            if log_row:
                log_row.execution_status = "REJECTED_BY_HUMAN"
        session.commit()
        return {"pending": pending.as_dict()}


def get_decision_log(limit: int = 50) -> list[dict]:
    with SessionLocal() as session:
        rows = (
            session.query(DecisionLog)
            .order_by(DecisionLog.timestamp.desc())
            .limit(limit)
            .all()
        )
        return [r.as_dict() for r in rows]
