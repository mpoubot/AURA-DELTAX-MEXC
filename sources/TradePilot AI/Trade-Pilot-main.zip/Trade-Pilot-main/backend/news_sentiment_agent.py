"""
News Sentiment agent.

Fetches recent news for a symbol via the Alpaca MCP news tools, then uses Claude
to produce a sentiment score (-1 to 1) and a short explanation. Returns a
structured dict: { symbol, sentiment_score, summary }.

Never raises: on any failure (no news, no connection, no API key) it returns
neutral defaults (score 0.0).
"""

from __future__ import annotations

import logging

from mcp_agent import DEFAULT_MODEL, clamp, extract_json, run_mcp_agent_sync

logger = logging.getLogger("tradepilot.news_sentiment")

# Explicit allowlist: the Alpaca news retrieval tool only (read-only).
_NEWS_TOOLS = ("get_news",)

_SYSTEM_PROMPT = (
    "You are a financial news sentiment analyst. Use the available Alpaca news "
    "tools to fetch recent news articles for the requested stock symbol. Assess "
    "overall market sentiment based ONLY on the headlines and summaries you "
    "actually retrieve.\n\n"
    "Be economical: make a SINGLE news call for a handful of recent items "
    "(about 5), then answer. Do not make repeated tool calls.\n\n"
    "When finished, respond with ONLY a single JSON object (no prose, no "
    "markdown code fences) with exactly these keys:\n"
    '  "symbol": the ticker (string)\n'
    '  "sentiment_score": a number from -1.0 (very negative) to 1.0 (very '
    "positive), 0.0 for neutral/mixed\n"
    '  "summary": 2-3 sentences explaining the score and the key themes driving '
    "it (string)\n\n"
    "If you cannot retrieve any news, return sentiment_score 0.0 and say so in "
    "the summary."
)


def _neutral(symbol: str, summary: str = "No news data available.") -> dict:
    return {"symbol": symbol, "sentiment_score": 0.0, "summary": summary}


def analyze_news(symbol: str, model: str = DEFAULT_MODEL) -> dict:
    """Analyze recent news sentiment for ``symbol``.

    Returns { symbol, sentiment_score, summary }.
    """
    symbol = (symbol or "").strip().upper()
    if not symbol:
        return _neutral("", "No symbol provided.")

    try:
        user = (
            f"In a single news call, fetch about 5 recent items for {symbol} "
            f"(limit=5, roughly the last 1-2 weeks). Summarize the overall "
            f"sentiment and score it."
        )
        text = run_mcp_agent_sync(
            _SYSTEM_PROMPT,
            user,
            allowed_tools=_NEWS_TOOLS,
            model=model,
        )
        data = extract_json(text)
        if not data:
            logger.info("news sentiment: no structured result for %s", symbol)
            return _neutral(symbol)

        return {
            "symbol": str(data.get("symbol") or symbol).upper(),
            "sentiment_score": clamp(data.get("sentiment_score"), -1.0, 1.0, 0.0),
            "summary": str(data.get("summary") or "No summary available."),
        }
    except Exception as exc:  # defensive: never crash the caller
        logger.warning("analyze_news failed for %s: %s", symbol, exc)
        return _neutral(symbol)
