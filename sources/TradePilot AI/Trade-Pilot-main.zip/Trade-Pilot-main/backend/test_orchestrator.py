"""
End-to-end orchestrator test.

Runs the full pipeline for one symbol (default AAPL) in human_approval=False mode
against paper trading, then prints the resulting decision_log entry and the order
confirmation.

Manual verification script (run directly). For a real BUY/SELL + order
confirmation it needs:
  * ANTHROPIC_API_KEY                    -> agents produce a real proposal
  * ALPACA_API_KEY / ALPACA_SECRET_KEY   -> plus `alpaca profile login` (paper)
Without them the agents return HOLD and no order is placed — the DB logging path
still runs and is shown.

    ./.venv/Scripts/python.exe test_orchestrator.py            # AAPL
    ./.venv/Scripts/python.exe test_orchestrator.py TSLA
"""

from __future__ import annotations

import json
import logging
import os
import sys
from pathlib import Path

try:
    from dotenv import load_dotenv

    load_dotenv(Path(__file__).resolve().parent / ".env")
except Exception:
    pass

from database import DATABASE_URL
from orchestrator import build_order_command, get_decision_log, run_pipeline

logging.basicConfig(level=logging.INFO, format="%(levelname)s %(name)s: %(message)s")


def main(symbol: str) -> None:
    print("=" * 72)
    print(f"TradePilot AI — full pipeline (human_approval=False) for {symbol}")
    print(f"Database: {DATABASE_URL}")
    print("=" * 72)

    for var in ("ANTHROPIC_API_KEY", "ALPACA_API_KEY", "ALPACA_SECRET_KEY"):
        if not os.getenv(var):
            print(f"  [warn] {var} not set — live proposal/execution unavailable")

    results = run_pipeline([symbol], human_approval=False)

    print("\n" + "=" * 72)
    print("DECISION LOG ENTRY (as stored in the decision_log table)")
    print("=" * 72)
    for row in results:
        print(json.dumps(row, indent=2))

    print("\n" + "=" * 72)
    print("ORDER CONFIRMATION")
    print("=" * 72)
    for row in results:
        status = row["execution_status"]
        if status == "EXECUTED":
            print(f"{row['symbol']}: order submitted (order_id={row['order_id']}).")
            print("Raw Alpaca response:")
            print(row["execution_detail"])
        elif status == "PENDING_APPROVAL":
            print(f"{row['symbol']}: risk-approved, parked for human approval.")
        elif status == "REJECTED_BY_RISK":
            print(f"{row['symbol']}: no order — risk engine REJECT ({row['risk_reason']}).")
        elif status.startswith("SKIPPED"):
            print(f"{row['symbol']}: no order — {status} ({row['risk_reason']}).")
        elif status == "EXECUTION_ERROR":
            print(f"{row['symbol']}: execution attempted but the Alpaca CLI errored:")
            print(row["execution_detail"])
        else:
            print(f"{row['symbol']}: {status}")

    # Show the exact bracket-order command the orchestrator would run, for
    # transparency (uses illustrative levels if the live decision was HOLD).
    ex = next((r for r in results if r["execution_status"] == "EXECUTED"), None)
    print("\n" + "-" * 72)
    print("Bracket-order command shape used for execution:")
    if ex:
        cmd = build_order_command(
            ex["symbol"], "buy" if ex["action"] == "BUY" else "sell",
            ex["suggested_quantity"], ex["stop_loss"], ex["take_profit"],
        )
    else:
        cmd = build_order_command(symbol, "buy", 10, 180.0, 200.0)
        print("(illustrative — no live order was placed this run)")
    print("  " + " ".join(cmd))

    print("\n" + "=" * 72)
    print(f"Total decision_log rows now stored: {len(get_decision_log())}")
    print("=" * 72)


if __name__ == "__main__":
    args = sys.argv[1:]
    main(args[0].upper() if args else "AAPL")
